export async function requestNotificationPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
        console.error('This browser does not support desktop notification');
        return 'denied';
    }
    const permission = await Notification.requestPermission();
    return permission;
}

export function showNotification(title: string, options?: NotificationOptions) {
    if (!('Notification' in window) || !('serviceWorker' in navigator)) {
        console.error('Push notifications are not supported in this browser.');
        return;
    }

    if (Notification.permission === 'granted') {
        navigator.serviceWorker.ready.then(registration => {
            registration.showNotification(title, options);
        });
    }
}
