import React from 'react';
import { useInstitution } from '../../context/InstitutionContext';
import { Link } from 'react-router-dom';

// Reusable card component for curriculum management actions
const CurriculumActionCard: React.FC<{ icon: string; title: string }> = ({ icon, title }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className="bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
            role="button"
            tabIndex={0}
            aria-label={title}
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};


const ManageCurriculum: React.FC = () => {
    
    const curriculumActions = [
      { icon: '📝', title: 'বিষয় / কিতাব তালিকা', to: 'subjects' },
      { icon: '🧒', title: 'শিক্ষার্থী অগ্রগতি ট্র্যাকিং', to: 'progress-tracking' },
      { icon: '👩‍🏫', title: 'শিক্ষকের মন্তব্য', to: 'teacher-comments' },
    ];

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-6">📚 পাঠ্য ও অগ্রগতি</h1>
            
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {curriculumActions.map((action, index) => (
                    <Link to={action.to} key={index} className="no-underline h-full">
                        <CurriculumActionCard icon={action.icon} title={action.title} />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default ManageCurriculum;