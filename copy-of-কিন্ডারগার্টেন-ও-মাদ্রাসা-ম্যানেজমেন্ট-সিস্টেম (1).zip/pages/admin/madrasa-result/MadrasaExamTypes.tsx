
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, MadrasaExamTypeData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import MadrasaExamTypeModal from '../../../components/MadrasaExamTypeModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const MadrasaExamTypes: React.FC = () => {
    const { madrasaExamTypes, setMadrasaExamTypes } = useInstitution();
    const { addToast } = useNotification();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedExamType, setSelectedExamType] = useState<MadrasaExamTypeData | null>(null);

    const handleAddNew = () => {
        setSelectedExamType(null);
        setIsModalOpen(true);
    };

    const handleEdit = (examType: MadrasaExamTypeData) => {
        setSelectedExamType(examType);
        setIsModalOpen(true);
    };

    const handleDelete = (examType: MadrasaExamTypeData) => {
        setSelectedExamType(examType);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedExamType) {
            setMadrasaExamTypes(madrasaExamTypes.filter(et => et.id !== selectedExamType.id));
            addToast('পরীক্ষার ধরণ সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedExamType(null);
    };

    const handleSave = (data: Omit<MadrasaExamTypeData, 'id'> & { id?: string }) => {
        if (data.id) {
            setMadrasaExamTypes(madrasaExamTypes.map(et => et.id === data.id ? { ...et, ...data } as MadrasaExamTypeData : et));
            addToast('পরীক্ষার ধরণ সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else {
            const newExamType: MadrasaExamTypeData = { ...data, id: `met-${Date.now()}` };
            setMadrasaExamTypes([...madrasaExamTypes, newExamType]);
            addToast('নতুন পরীক্ষার ধরণ যোগ করা হয়েছে!', 'success');
        }
        setIsModalOpen(false);
    };

    return (
        <div>
            <PageHeader icon="📝" title="পরীক্ষার ধরণ">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700"
                >
                    নতুন ধরণ যোগ করুন
                </button>
            </PageHeader>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">ধরণ</th>
                                <th scope="col" className="px-6 py-3">পূর্ণমান</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {madrasaExamTypes.length > 0 ? madrasaExamTypes.map(examType => (
                                <tr key={examType.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{examType.name}</td>
                                    <td className="px-6 py-4">{examType.totalMarks}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => handleEdit(examType)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleDelete(examType)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={3} className="text-center py-10 text-gray-500">
                                        <p>কোনো পরীক্ষার ধরণ যোগ করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <MadrasaExamTypeModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                examTypeToEdit={selectedExamType}
            />

            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="পরীক্ষার ধরণ মুছুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই আইটেমটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default MadrasaExamTypes;
