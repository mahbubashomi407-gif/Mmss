import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match]);
};

const ClassFeeSummaryReport: React.FC = () => {
    const { students, classLevels, academicSessions, studentFeeRecords, institutionName, logoUrl, address, feeTypes } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [monthFilter, setMonthFilter] = useState<string>('all'); // 'all' or month index "0"-"11"
    
    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];

    const summaryData = useMemo(() => {
        const reportYear = academicYearFilter.split('-')[0];

        const feeTypeSummaries = feeTypes.map(feeType => {
            let totalForFeeType = 0;
            const collectionsByClass = classLevels.map(cl => {
                const studentsInClass = students.filter(s => 
                    s.academicYear === academicYearFilter && 
                    s.classLevel === cl.name &&
                    s.status !== 'পেন্ডিং'
                );
                const studentIdsInClass = new Set(studentsInClass.map(s => s.id));

                const records = studentFeeRecords.filter(rec => {
                    const yearMatch = rec.year.toString() === reportYear;
                    const studentMatch = studentIdsInClass.has(rec.studentId);
                    const monthMatch = monthFilter === 'all' || (rec.month && rec.month === months[parseInt(monthFilter)]);
                    const feeTypeMatch = rec.feeTypeId === feeType.id;
                    return yearMatch && studentMatch && monthMatch && feeTypeMatch;
                });

                const amount = records.reduce((sum, r) => sum + r.amountPaid, 0);
                totalForFeeType += amount;

                return {
                    className: cl.name,
                    amount,
                };
            });

            return {
                feeTypeId: feeType.id,
                feeTypeName: feeType.name,
                collectionsByClass,
                totalForFeeType,
            };
        }).filter(summary => summary.totalForFeeType > 0); // Only include fee types with collections

        const grandTotal = feeTypeSummaries.reduce((sum, s) => sum + s.totalForFeeType, 0);

        return { feeTypeSummaries, grandTotal };

    }, [academicYearFilter, monthFilter, classLevels, students, studentFeeRecords, feeTypes, months]);
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-summary-report');
        if (!printContent) return;
        
        const monthName = monthFilter === 'all' ? 'সকল মাস' : months[parseInt(monthFilter)];
        const reportTitle = `ফি সংগ্রহ সারসংক্ষেপ (ফি-এর ধরণ অনুযায়ী)`;
        const subTitle = `শিক্ষা বর্ষ: ${academicYearFilter} | মাস: ${monthName}`;
        
        const printWindow = window.open('', '', 'height=800,width=1200');
        if (printWindow) {
            printWindow.document.write('<html><head>');
            printWindow.document.write(`<title>${reportTitle}</title>`);
            printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
            printWindow.document.write(`<style>body { font-family: "SolaimanLipi", sans-serif; } @page { size: A4 portrait; margin: 0.5in; } .no-print { display: none; } .fee-type-table { page-break-inside: avoid; margin-bottom: 2rem; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ddd; padding: 6px; font-size: 12px; text-align: left; } th { background-color: #f2f2f2 !important; -webkit-print-color-adjust: exact; } .header { text-align: center; margin-bottom: 1rem; } .header img { height: 50px; width: 50px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.5rem; } tfoot { font-weight: bold; background-color: #f9f9f9 !important; -webkit-print-color-adjust: exact; } .text-right { text-align: right; } .fee-type-title { font-size: 1.1rem; font-weight: bold; margin-bottom: 0.5rem; } .grand-total { margin-top: 2rem; padding-top: 1rem; border-top: 2px solid #333; text-align: right; font-size: 1.2rem; font-weight: bold; }</style>`);
            printWindow.document.write('</head><body>');
            printWindow.document.write(`<div class="header">${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}<h1 style="font-size: 1.5rem; font-weight: bold; margin: 0;">${institutionName}</h1><p style="margin: 0.25rem 0;">${address.village}, ${address.upazila}, ${address.district}</p><h2 style="font-size: 1.2rem; margin: 0;">${reportTitle}</h2><p style="font-size: 0.9rem; margin: 0;">${subTitle}</p></div>`);
            printWindow.document.write(printContent.innerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => { printWindow.print(); printWindow.close(); }, 750);
        }
    };

    return (
        <div>
            <PageHeader icon="🏦" title="ফি সংগ্রহ রিপোর্ট (শ্রেণিভিত্তিক)" />
            
            <div className="bg-white p-4 rounded-xl shadow-md mb-6">
                 <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="p-2 border rounded-md bg-white w-full"><option value="">বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select>
                    <select value={monthFilter} onChange={e => setMonthFilter(e.target.value)} className="p-2 border rounded-md bg-white w-full"><option value="all">সকল মাস</option>{months.map((m, i) => <option key={i} value={i.toString()}>{m}</option>)}</select>
                    <button onClick={handlePrint} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 w-full">প্রিন্ট করুন</button>
                </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                 <p className="text-center text-gray-500 py-6 bg-gray-50 rounded-md">রিপোর্ট প্রিন্ট করতে উপরের ফিল্টার নির্বাচন করে 'প্রিন্ট করুন' বাটনে ক্লিক করুন। প্রিভিউ প্রিন্ট ডায়ালগে দেখা যাবে।</p>
            </div>

            <div id="printable-summary-report" className="hidden">
                {summaryData.feeTypeSummaries.map(summary => (
                    <div key={summary.feeTypeId} className="fee-type-table">
                        <h4 className="fee-type-title">{summary.feeTypeName}</h4>
                        <table className="w-full text-sm">
                            <thead>
                                <tr>
                                    <th>শ্রেণির নাম</th>
                                    <th className="text-right">মোট আদায়কৃত ফি</th>
                                </tr>
                            </thead>
                            <tbody>
                                {summary.collectionsByClass.map(classCollection => (
                                    classCollection.amount > 0 && (
                                        <tr key={classCollection.className}>
                                            <td>{classCollection.className}</td>
                                            <td className="text-right">৳ {toBengaliNumber(classCollection.amount.toLocaleString('bn-BD'))}</td>
                                        </tr>
                                    )
                                ))}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td className="text-right">সর্বমোট</td>
                                    <td className="text-right">৳ {toBengaliNumber(summary.totalForFeeType.toLocaleString('bn-BD'))}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                ))}
                <div className="grand-total">
                    সর্বমোট আদায়: ৳ {toBengaliNumber(summaryData.grandTotal.toLocaleString('bn-BD'))}
                </div>
            </div>
        </div>
    );
};

export default ClassFeeSummaryReport;
