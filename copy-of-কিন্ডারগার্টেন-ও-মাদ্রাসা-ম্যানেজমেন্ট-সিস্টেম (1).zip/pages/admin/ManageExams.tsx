

import React from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';
import { useInstitution } from '../../context/InstitutionContext';

const ActionCard: React.FC<{ icon: string; title: string }> = ({ icon, title }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className="bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
            role="button"
            tabIndex={0}
            aria-label={title}
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};

const ManageExams: React.FC = () => {
    const academicActions = [
      { to: 'entry', icon: '🔢', title: 'নম্বর এন্ট্রি' },
      { to: 'edit-result', icon: '✏️', title: 'ফলাফল ইডিট' },
      { to: 'class-result', icon: '📊', title: 'রেজাল্ট শিট' },
      { to: 'nombro-potro', icon: '📝', title: 'নম্বর পত্র' },
      { to: 'marksheet', icon: '📑', title: 'মার্কশীট' },
      { to: 'result-summary', icon: '📈', title: 'ফলাফল সামারি' },
      { to: 'export', icon: '📤', title: 'ফলাফল রিপোর্ট' },
      { to: 'publish-result', icon: '📢', title: 'ফলাফল প্রকাশ' },
      { to: 'admit-card', icon: '💳', title: 'প্রবেশপত্র' },
      { to: 'seat-plan', icon: '🪑', title: 'আসন বিন্যাস' },
      { to: 'grade-processing', icon: '⚙️', title: 'গ্রেড সিস্টেম সেটআপ' },
      { to: 'subject-assignment', icon: '📚', title: 'বিষয় অ্যাসাইনমেন্ট' },
    ];

    return (
        <div>
            <PageHeader icon="📝" title="পরীক্ষা ও মূল্যায়ন">
                <Link to="create" className="px-4 py-2 bg-white text-gray-700 font-semibold rounded-lg shadow-md hover:bg-gray-100 transition-colors border border-gray-200">
                    নতুন পরীক্ষা তৈরি
                </Link>
                <Link to="list" className="px-4 py-2 bg-white text-gray-700 font-semibold rounded-lg shadow-md hover:bg-gray-100 transition-colors border border-gray-200">
                    পরীক্ষা তালিকা
                </Link>
            </PageHeader>

            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {academicActions.map((action, index) => (
                    <Link to={action.to} key={index} className="no-underline h-full">
                        <ActionCard icon={action.icon} title={action.title} />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default ManageExams;