import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, ReligionData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import ReligionModal from '../../../components/ReligionModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const ManageReligions: React.FC = () => {
    const { religions, setReligions } = useInstitution();
    const { addToast } = useNotification();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedReligion, setSelectedReligion] = useState<ReligionData | null>(null);

    const handleAddNew = () => {
        setSelectedReligion(null);
        setIsModalOpen(true);
    };

    const handleEdit = (religion: ReligionData) => {
        setSelectedReligion(religion);
        setIsModalOpen(true);
    };

    const handleDelete = (religion: ReligionData) => {
        if (religion.isDefault) {
            addToast('ডিফল্ট আইটেম মোছা যাবে না।', 'error');
            return;
        }
        setSelectedReligion(religion);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedReligion && !selectedReligion.isDefault) {
            setReligions(religions.filter(r => r.id !== selectedReligion.id));
            addToast('ধর্ম সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedReligion(null);
    };

    const handleSave = (religionData: { name: string; id?: string }) => {
        // Check for duplicates (case-insensitive)
        const isDuplicate = religions.some(
            r => r.name.toLowerCase() === religionData.name.toLowerCase() && r.id !== religionData.id
        );
        if (isDuplicate) {
            addToast('এই নামটি ইতিমধ্যে বিদ্যমান।', 'error');
            return;
        }

        if (religionData.id) { // Editing
            setReligions(religions.map(r => r.id === religionData.id ? { ...r, name: religionData.name } : r));
            addToast('ধর্ম সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newReligion = { id: Date.now().toString(), name: religionData.name };
            setReligions([...religions, newReligion]);
            addToast('নতুন ধর্ম সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        setIsModalOpen(false);
        setSelectedReligion(null);
    };

    return (
        <div>
            <PageHeader icon="☪️" title="ধর্ম ব্যবস্থাপনা">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন ধর্ম যোগ করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">নাম</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {religions.length > 0 ? religions.map(religion => (
                                <tr key={religion.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{religion.name}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button 
                                            onClick={() => handleEdit(religion)} 
                                            className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" 
                                            title="সম্পাদনা"
                                        >
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button 
                                            onClick={() => handleDelete(religion)} 
                                            className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed" 
                                            title={religion.isDefault ? 'ডিফল্ট আইটেম মোছা যাবে না' : 'মুছুন'}
                                            disabled={religion.isDefault}
                                        >
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={2} className="text-center py-10 text-gray-500">
                                        <p>কোনো ধর্ম যোগ করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <ReligionModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                religionToEdit={selectedReligion}
            />
            
            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="ধর্ম মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই আইটেমটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default ManageReligions;