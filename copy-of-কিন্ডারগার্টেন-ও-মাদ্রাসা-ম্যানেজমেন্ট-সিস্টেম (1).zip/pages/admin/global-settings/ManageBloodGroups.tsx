import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, BloodGroupData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import BloodGroupModal from '../../../components/BloodGroupModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const ManageBloodGroups: React.FC = () => {
    const { bloodGroups, setBloodGroups } = useInstitution();
    const { addToast } = useNotification();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedBloodGroup, setSelectedBloodGroup] = useState<BloodGroupData | null>(null);

    const handleAddNew = () => {
        setSelectedBloodGroup(null);
        setIsModalOpen(true);
    };

    const handleEdit = (bloodGroup: BloodGroupData) => {
        setSelectedBloodGroup(bloodGroup);
        setIsModalOpen(true);
    };

    const handleDelete = (bloodGroup: BloodGroupData) => {
        if (bloodGroup.isDefault) {
            addToast('ডিফল্ট আইটেম মোছা যাবে না।', 'error');
            return;
        }
        setSelectedBloodGroup(bloodGroup);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedBloodGroup && !selectedBloodGroup.isDefault) {
            setBloodGroups(bloodGroups.filter(bg => bg.id !== selectedBloodGroup.id));
            addToast('রক্তের গ্রুপ সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedBloodGroup(null);
    };

    const handleSave = (bloodGroupData: { name: string; id?: string }) => {
        // Check for duplicates (case-insensitive)
        const isDuplicate = bloodGroups.some(
            bg => bg.name.toLowerCase() === bloodGroupData.name.toLowerCase() && bg.id !== bloodGroupData.id
        );
        if (isDuplicate) {
            addToast('এই নামটি ইতিমধ্যে বিদ্যমান।', 'error');
            return;
        }

        if (bloodGroupData.id) { // Editing
            setBloodGroups(bloodGroups.map(bg => bg.id === bloodGroupData.id ? { ...bg, name: bloodGroupData.name } : bg));
            addToast('রক্তের গ্রুপ সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newBloodGroup = { id: Date.now().toString(), name: bloodGroupData.name };
            setBloodGroups([...bloodGroups, newBloodGroup]);
            addToast('নতুন রক্তের গ্রুপ সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        setIsModalOpen(false);
        setSelectedBloodGroup(null);
    };

    return (
        <div>
            <PageHeader icon="🩸" title="রক্তের গ্রুপ ব্যবস্থাপনা">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন রক্তের গ্রুপ যোগ করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">নাম</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {bloodGroups.length > 0 ? bloodGroups.map(bloodGroup => (
                                <tr key={bloodGroup.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{bloodGroup.name}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button 
                                            onClick={() => handleEdit(bloodGroup)} 
                                            className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" 
                                            title="সম্পাদনা"
                                        >
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button 
                                            onClick={() => handleDelete(bloodGroup)} 
                                            className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed" 
                                            title={bloodGroup.isDefault ? 'ডিফল্ট আইটেম মোছা যাবে না' : 'মুছুন'}
                                            disabled={bloodGroup.isDefault}
                                        >
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={2} className="text-center py-10 text-gray-500">
                                        <p>কোনো রক্তের গ্রুপ যোগ করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <BloodGroupModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                bloodGroupToEdit={selectedBloodGroup}
            />
            
            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="রক্তের গ্রুপ মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই আইটেমটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default ManageBloodGroups;