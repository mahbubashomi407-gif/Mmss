import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, NationalityData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import NationalityModal from '../../../components/NationalityModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const ManageNationalities: React.FC = () => {
    const { nationalities, setNationalities } = useInstitution();
    const { addToast } = useNotification();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedNationality, setSelectedNationality] = useState<NationalityData | null>(null);

    const handleAddNew = () => {
        setSelectedNationality(null);
        setIsModalOpen(true);
    };

    const handleEdit = (nationality: NationalityData) => {
        setSelectedNationality(nationality);
        setIsModalOpen(true);
    };

    const handleDelete = (nationality: NationalityData) => {
        if (nationality.isDefault) {
            addToast('ডিফল্ট আইটেম মোছা যাবে না।', 'error');
            return;
        }
        setSelectedNationality(nationality);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedNationality && !selectedNationality.isDefault) {
            setNationalities(nationalities.filter(n => n.id !== selectedNationality.id));
            addToast('জাতীয়তা সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedNationality(null);
    };

    const handleSave = (nationalityData: { name: string; id?: string }) => {
        const isDuplicate = nationalities.some(
            n => n.name.toLowerCase() === nationalityData.name.toLowerCase() && n.id !== nationalityData.id
        );
        if (isDuplicate) {
            addToast('এই নামটি ইতিমধ্যে বিদ্যমান।', 'error');
            return;
        }

        if (nationalityData.id) { // Editing
            setNationalities(nationalities.map(n => n.id === nationalityData.id ? { ...n, name: nationalityData.name } : n));
            addToast('জাতীয়তা সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newNationality = { id: Date.now().toString(), name: nationalityData.name };
            setNationalities([...nationalities, newNationality]);
            addToast('নতুন জাতীয়তা সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        setIsModalOpen(false);
        setSelectedNationality(null);
    };

    return (
        <div>
            <PageHeader icon="🌍" title="জাতীয়তা ব্যবস্থাপনা">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন জাতীয়তা যোগ করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">নাম</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {nationalities.length > 0 ? nationalities.map(nat => (
                                <tr key={nat.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{nat.name}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button 
                                            onClick={() => handleEdit(nat)} 
                                            className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" 
                                            title="সম্পাদনা"
                                        >
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button 
                                            onClick={() => handleDelete(nat)} 
                                            className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed" 
                                            title={nat.isDefault ? 'ডিফল্ট আইটেম মোছা যাবে না' : 'মুছুন'}
                                            disabled={nat.isDefault}
                                        >
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={2} className="text-center py-10 text-gray-500">
                                        <p>কোনো জাতীয়তা যোগ করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <NationalityModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                nationalityToEdit={selectedNationality}
            />
            
            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="জাতীয়তা মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই আইটেমটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default ManageNationalities;