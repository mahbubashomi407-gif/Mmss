import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, DesignationData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import DesignationModal from '../../../components/DesignationModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const ManageDesignations: React.FC = () => {
    const { designations, setDesignations } = useInstitution();
    const { addToast } = useNotification();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedDesignation, setSelectedDesignation] = useState<DesignationData | null>(null);

    const handleAddNew = () => {
        setSelectedDesignation(null);
        setIsModalOpen(true);
    };

    const handleEdit = (designation: DesignationData) => {
        setSelectedDesignation(designation);
        setIsModalOpen(true);
    };

    const handleDelete = (designation: DesignationData) => {
        if (designation.isDefault) {
            addToast('ডিফল্ট আইটেম মোছা যাবে না।', 'error');
            return;
        }
        setSelectedDesignation(designation);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedDesignation && !selectedDesignation.isDefault) {
            setDesignations(designations.filter(d => d.id !== selectedDesignation.id));
            addToast('পদবি সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedDesignation(null);
    };

    const handleSave = (designationData: { name: string; id?: string }) => {
        const isDuplicate = designations.some(
            d => d.name.toLowerCase() === designationData.name.toLowerCase() && d.id !== designationData.id
        );
        if (isDuplicate) {
            addToast('এই নামটি ইতিমধ্যে বিদ্যমান।', 'error');
            return;
        }

        if (designationData.id) { // Editing
            setDesignations(designations.map(d => d.id === designationData.id ? { ...d, name: designationData.name } : d));
            addToast('পদবি সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newDesignation = { id: Date.now().toString(), name: designationData.name };
            setDesignations([...designations, newDesignation]);
            addToast('নতুন পদবি সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        setIsModalOpen(false);
        setSelectedDesignation(null);
    };

    return (
        <div>
            <PageHeader icon="🧑‍🏫" title="শিক্ষকের পদবি ব্যবস্থাপনা">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন পদবি যোগ করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">নাম</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {designations.length > 0 ? designations.map(d => (
                                <tr key={d.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{d.name}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button 
                                            onClick={() => handleEdit(d)} 
                                            className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" 
                                            title="সম্পাদনা"
                                        >
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button 
                                            onClick={() => handleDelete(d)} 
                                            className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors disabled:opacity-50 disabled:cursor-not-allowed" 
                                            title={d.isDefault ? 'ডিফল্ট আইটেম মোছা যাবে না' : 'মুছুন'}
                                            disabled={d.isDefault}
                                        >
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={2} className="text-center py-10 text-gray-500">
                                        <p>কোনো পদবি যোগ করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <DesignationModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                designationToEdit={selectedDesignation}
            />
            
            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="পদবি মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই আইটেমটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default ManageDesignations;
