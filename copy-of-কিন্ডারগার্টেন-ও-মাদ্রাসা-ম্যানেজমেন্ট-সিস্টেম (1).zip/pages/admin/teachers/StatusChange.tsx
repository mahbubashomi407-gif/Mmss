import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';

interface ModifiableTeacher extends TeacherData {
  newStatus: TeacherData['status'];
}

const statusOptions: TeacherData['status'][] = ['সক্রিয়', 'নিষ্ক্রিয়', 'ছুটিতে'];

const TeacherStatusChange: React.FC = () => {
    const { teachers, setTeachers } = useInstitution();
    const { addToast } = useNotification();
    
    const [modifiableTeachers, setModifiableTeachers] = useState<ModifiableTeacher[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);

    useEffect(() => {
        const initialModifiable = teachers.map(t => ({ ...t, newStatus: t.status }));
        setModifiableTeachers(initialModifiable);
    }, [teachers]);
    
    const hasUnsavedChanges = useMemo(() => {
        if (modifiableTeachers.length !== teachers.length) return false;
        return modifiableTeachers.some(mt => {
            const original = teachers.find(t => t.id === mt.id);
            return original && original.status !== mt.newStatus;
        });
    }, [modifiableTeachers, teachers]);

    const handleStatusUpdate = (id: string, newStatus: TeacherData['status']) => {
        setModifiableTeachers(prev =>
            prev.map(s => s.id === id ? { ...s, newStatus } : s)
        );
    };
    
    const handleSaveChanges = () => {
        const changesMap = new Map<string, TeacherData['status']>();
        modifiableTeachers.forEach(s => {
            if (s.status !== s.newStatus) {
                changesMap.set(s.id, s.newStatus);
            }
        });

        if (changesMap.size === 0) {
            addToast('কোনো পরিবর্তন করা হয়নি।', 'error');
            return;
        }

        const updatedTeachers = teachers.map(s => {
            if (changesMap.has(s.id)) {
                return { ...s, status: changesMap.get(s.id)! };
            }
            return s;
        });
        
        setTeachers(updatedTeachers);
        addToast(`${changesMap.size} জন শিক্ষকের স্ট্যাটাস সফলভাবে আপডেট করা হয়েছে!`, 'success');
        setIsModalOpen(false);
    };

    const getStatusBadge = (status: TeacherData['status']) => {
        switch (status) {
            case 'সক্রিয়': return 'bg-green-100 text-green-800';
            case 'নিষ্ক্রিয়': return 'bg-red-100 text-red-800';
            case 'ছুটিতে': return 'bg-yellow-100 text-yellow-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div>
            <PageHeader icon="⚙️" title="স্ট্যাটাস (সক্রিয় / নিষ্ক্রিয়)">
                {hasUnsavedChanges && (
                    <button onClick={() => setIsModalOpen(true)} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700">
                        পরিবর্তন সংরক্ষণ করুন
                    </button>
                )}
            </PageHeader>
            <div className="bg-white p-6 rounded-xl shadow-md">
                {modifiableTeachers.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th className="p-2">আইডি</th>
                                    <th className="p-2">শিক্ষকের নাম</th>
                                    <th className="p-2">বর্তমান স্ট্যাটাস</th>
                                    <th className="p-2">নতুন স্ট্যাটাস</th>
                                </tr>
                            </thead>
                            <tbody>
                                {modifiableTeachers.map(teacher => {
                                    const isChanged = teacher.status !== teacher.newStatus;
                                    return (
                                        <tr key={teacher.id} className={`border-b ${isChanged ? 'bg-yellow-50' : 'hover:bg-gray-50'}`}>
                                            <td className="p-2 font-mono text-xs">{teacher.uniqueId}</td>
                                            <td className="p-2 font-medium text-gray-800">{teacher.nameBn}</td>
                                            <td className="p-2">
                                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(teacher.status)}`}>
                                                    {teacher.status}
                                                </span>
                                            </td>
                                            <td className="p-2">
                                                <select
                                                    value={teacher.newStatus}
                                                    onChange={e => handleStatusUpdate(teacher.id, e.target.value as TeacherData['status'])}
                                                    className="w-full p-1.5 border border-gray-300 rounded-md bg-white text-xs focus:ring-2 focus:ring-teal-500"
                                                >
                                                    {statusOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                                </select>
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">কোনো শিক্ষক যোগ করা হয়নি।</p>
                )}
            </div>
            
            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onConfirm={handleSaveChanges}
                title="স্ট্যাটাস পরিবর্তন নিশ্চিত করুন"
            >
                আপনি কি নিশ্চিতভাবে নির্বাচিত শিক্ষকদের স্ট্যাটাস পরিবর্তন করতে চান?
            </Modal>
        </div>
    );
};

export default TeacherStatusChange;
