
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, HomeworkData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const AssignHomework: React.FC = () => {
    const { classLevels, sections, homeworks, setHomeworks } = useInstitution();
    const { addToast } = useNotification();
    const today = new Date().toISOString().split('T')[0];

    const [title, setTitle] = useState('');
    const [classLevel, setClassLevel] = useState('');
    const [section, setSection] = useState('');
    const [subject, setSubject] = useState('');
    const [description, setDescription] = useState('');
    const [assignDate, setAssignDate] = useState(today);
    const [submissionDate, setSubmissionDate] = useState('');
    const [file, setFile] = useState<File | null>(null);
    const [fileName, setFileName] = useState('');

    const availableSections = useMemo(() => classLevel ? sections.filter(s => s.classLevel === classLevel).map(s => s.name) : [], [classLevel, sections]);
    const availableSubjects = useMemo(() => classLevel ? classLevels.find(cl => cl.name === classLevel)?.subjects.map(s => s.name) || [] : [], [classLevel, classLevels]);

    useEffect(() => {
        if (!availableSections.includes(section)) setSection('');
        if (!availableSubjects.includes(subject)) setSubject('');
    }, [classLevel, availableSections, availableSubjects, section, subject]);
    
    const resetForm = () => {
        setTitle('');
        setClassLevel('');
        setSection('');
        setSubject('');
        setDescription('');
        setAssignDate(today);
        setSubmissionDate('');
        setFile(null);
        setFileName('');
        // Clear file input visually
        const fileInput = document.getElementById('file-upload') as HTMLInputElement;
        if (fileInput) {
            fileInput.value = '';
        }
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        let fileUrl;
        if (file) {
            fileUrl = await fileToBase64(file);
        }

        const newHomework: HomeworkData = {
            id: Date.now().toString(),
            title,
            classLevel,
            section,
            subject,
            description,
            assignDate,
            submissionDate,
            fileUrl,
            fileName: file ? file.name : undefined,
        };

        setHomeworks([newHomework, ...homeworks]);
        addToast('নতুন হোমওয়ার্ক সফলভাবে যোগ করা হয়েছে!', 'success');
        resetForm();
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0] || null;
        setFile(selectedFile);
        setFileName(selectedFile?.name || '');
    }

    return (
        <div>
            <PageHeader icon="📝" title="হোমওয়ার্ক / অ্যাক্টিভিটি দেওয়া" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-3xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">শ্রেণি<span className="text-red-500">*</span></label>
                            <select value={classLevel} onChange={e => setClassLevel(e.target.value)} required className="mt-1 w-full p-2 border border-gray-300 rounded-md"><option value="">নির্বাচন করুন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">সেকশন<span className="text-red-500">*</span></label>
                            <select value={section} onChange={e => setSection(e.target.value)} required disabled={!classLevel} className="mt-1 w-full p-2 border border-gray-300 rounded-md"><option value="">নির্বাচন করুন</option>{availableSections.map(s => <option key={s}>{s}</option>)}</select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">বিষয়<span className="text-red-500">*</span></label>
                            <select value={subject} onChange={e => setSubject(e.target.value)} required disabled={!classLevel} className="mt-1 w-full p-2 border border-gray-300 rounded-md"><option value="">নির্বাচন করুন</option>{availableSubjects.map(s => <option key={s}>{s}</option>)}</select>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700">শিরোনাম<span className="text-red-500">*</span></label>
                        <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="হোমওয়ার্কের শিরোনাম..." required className="mt-1 w-full p-2 border border-gray-300 rounded-md" />
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700">বিবরণ</label>
                        <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="হোমওয়ার্কের বিস্তারিত বিবরণ..." rows={4} className="mt-1 w-full p-2 border border-gray-300 rounded-md"></textarea>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">দেওয়ার তারিখ</label>
                            <input type="date" value={assignDate} onChange={e => setAssignDate(e.target.value)} required className="mt-1 w-full p-2 border border-gray-300 rounded-md"/>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">জমা দেওয়ার তারিখ<span className="text-red-500">*</span></label>
                            <input type="date" value={submissionDate} min={assignDate} onChange={e => setSubmissionDate(e.target.value)} required className="mt-1 w-full p-2 border border-gray-300 rounded-md"/>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700">ফাইল সংযুক্ত করুন (ঐচ্ছিক)</label>
                        <input id="file-upload" type="file" onChange={handleFileChange} className="mt-1 w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-teal-50 file:text-teal-700 hover:file:bg-teal-100"/>
                    </div>
                    
                    <div className="flex justify-end gap-3 pt-4 border-t">
                        <button type="button" onClick={resetForm} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">রিসেট</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">হোমওয়ার্ক তৈরি করুন</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AssignHomework;
