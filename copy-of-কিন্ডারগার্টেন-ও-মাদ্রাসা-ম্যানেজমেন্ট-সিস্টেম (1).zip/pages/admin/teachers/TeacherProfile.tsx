
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData } from '../../../context/InstitutionContext';
import { SearchIcon } from '../../../components/icons';

const InfoRow: React.FC<{ label: string; value?: React.ReactNode }> = ({ label, value }) => (
    <div className="flex justify-between py-2.5 border-b border-gray-100 last:border-b-0">
        <span className="text-sm font-medium text-gray-500">{label}</span>
        <div className="text-sm font-semibold text-gray-800 text-right">{value || 'N/A'}</div>
    </div>
);

const TeacherProfileView: React.FC<{ teacher: TeacherData }> = ({ teacher }) => {
    const { teacherRoles } = useInstitution();
    const [activeTab, setActiveTab] = useState('professional');
    
    const roleName = teacherRoles.find(r => r.id === teacher.roleId)?.name || 'N/A';

    const TabButton: React.FC<{ tab: string; label: string }> = ({ tab, label }) => (
        <button
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors duration-200 focus:outline-none -mb-px border-b-2
                ${activeTab === tab
                    ? 'border-teal-500 text-teal-600'
                    : 'border-transparent text-gray-500 hover:text-teal-600 hover:border-gray-300'
                }`}
        >
            {label}
        </button>
    );

    return (
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Header Section */}
            <div className="bg-teal-50 p-4 sm:p-5 flex flex-col sm:flex-row items-center gap-4 relative">
                <img 
                    src={teacher.photoUrl || 'https://via.placeholder.com/150x150?text=T'}
                    alt={teacher.nameBn}
                    className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md"
                />
                <div className="text-center sm:text-left">
                    <h2 className="text-2xl font-bold text-gray-900">{teacher.nameBn}</h2>
                    <p className="text-sm text-gray-600">{teacher.nameEn}</p>
                    <div className="mt-2 flex flex-wrap justify-center sm:justify-start gap-x-4 gap-y-1 text-sm font-semibold text-teal-800">
                        <p>ইউনিক আইডি: <span className="font-mono">{teacher.uniqueId}</span></p>
                        <p>পদবি: {teacher.designation}</p>
                        <p>রোল: {roleName}</p>
                    </div>
                </div>
            </div>

            {/* Tabbed Section */}
            <div>
                <div className="border-b border-gray-200 px-4 flex space-x-2">
                    <TabButton tab="professional" label="প্রাতিষ্ঠানিক তথ্য" />
                    <TabButton tab="personal" label="ব্যক্তিগত তথ্য" />
                    <TabButton tab="contact" label="যোগাযোগ ও ঠিকানা" />
                </div>
                <div className="p-4 sm:p-5">
                    {activeTab === 'professional' && (
                        <div className="space-y-1">
                             <InfoRow label="যোগদানের তারিখ" value={teacher.joiningDate ? new Date(teacher.joiningDate).toLocaleDateString('bn-BD') : ''} />
                             <InfoRow label="পদবি" value={teacher.designation} />
                             <InfoRow label="রোল" value={roleName} />
                             <InfoRow label="শিক্ষাগত যোগ্যতা" value={teacher.academicQualifications} />
                             <InfoRow label="পেশাগত প্রশিক্ষণ" value={teacher.professionalTraining} />
                             <InfoRow label="স্ট্যাটাস" value={<span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${teacher.status === 'সক্রিয়' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{teacher.status}</span>} />
                        </div>
                    )}
                    {activeTab === 'personal' && (
                        <div className="space-y-1">
                             <InfoRow label="জন্মতারিখ" value={teacher.dob ? new Date(teacher.dob).toLocaleDateString('bn-BD') : ''} />
                             <InfoRow label="লিঙ্গ" value={teacher.gender} />
                             <InfoRow label="ধর্ম" value={teacher.religion} />
                             <InfoRow label="রক্তের গ্রুপ" value={teacher.bloodGroup} />
                             <InfoRow label="জাতীয় পরিচয়পত্র (NID)" value={teacher.nid} />
                             <InfoRow label="জাতীয়তা" value={teacher.nationality} />
                        </div>
                    )}
                    {activeTab === 'contact' && (
                         <div className="space-y-3">
                            <InfoRow label="মোবাইল নম্বর" value={teacher.phone} />
                            <InfoRow label="ইমেইল" value={teacher.email} />
                             <div>
                                <h4 className="font-semibold text-gray-600 text-sm mt-3">বর্তমান ঠিকানা</h4>
                                <p className="text-sm text-gray-700 mt-1 p-2 bg-gray-50 rounded">
                                 {teacher.presentAddress.village}, {teacher.presentAddress.upazila}, {teacher.presentAddress.district}
                                </p>
                             </div>
                            <div>
                                <h4 className="font-semibold text-gray-600 text-sm">স্থায়ী ঠিকানা</h4>
                                <p className="text-sm text-gray-700 mt-1 p-2 bg-gray-50 rounded">
                                 {teacher.isSameAddress ? 'বর্তমান ঠিকানার অনুরূপ' : `${teacher.permanentAddress.village}, ${teacher.permanentAddress.upazila}, ${teacher.permanentAddress.district}`}
                                </p>
                            </div>
                         </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const TeacherProfile: React.FC = () => {
    const [searchParams] = useSearchParams();
    const teacherIdParam = searchParams.get('id');
    const teacherUniqueIdParam = searchParams.get('uniqueId');
    const { teachers } = useInstitution();
    const navigate = useNavigate();

    const [searchInput, setSearchInput] = useState(teacherUniqueIdParam || '');
    const [teacher, setTeacher] = useState<TeacherData | null>(null);
    const [searchError, setSearchError] = useState('');

    useEffect(() => {
        let foundTeacher: TeacherData | undefined;
        if (teacherIdParam) {
            foundTeacher = teachers.find(t => t.id === teacherIdParam);
        } else if (teacherUniqueIdParam) {
            // Make the comparison case-insensitive
            const lowerCaseUniqueIdParam = teacherUniqueIdParam.toLowerCase();
            foundTeacher = teachers.find(t => t.uniqueId.toLowerCase() === lowerCaseUniqueIdParam);
        }
        
        if (foundTeacher) {
            setTeacher(foundTeacher);
            setSearchInput(foundTeacher.uniqueId);
            setSearchError('');
        } else if (teacherIdParam || teacherUniqueIdParam) {
            setTeacher(null);
            setSearchError('এই আইডি দিয়ে কোনো শিক্ষককে খুঁজে পাওয়া যায়নি।');
        } else {
            setTeacher(null);
            setSearchError('');
        }
    }, [teacherIdParam, teacherUniqueIdParam, teachers]);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        setSearchError('');
        if (!searchInput.trim()) {
            setSearchError('অনুগ্রহ করে একটি ইউনিক আইডি লিখুন।');
            return;
        }
        navigate(`/app/teachers/profile?uniqueId=${searchInput.trim()}`);
    };

    return (
        <div>
            <PageHeader icon="👤" title="শিক্ষক প্রোফাইল" />
            
            <div className="bg-white p-4 rounded-xl shadow-md mb-6 max-w-lg mx-auto">
                <form onSubmit={handleSearch} className="flex items-center gap-2">
                    <label htmlFor="teacherIdSearch" className="text-sm font-semibold text-gray-700 shrink-0">শিক্ষকের ইউনিক আইডি:</label>
                    <div className="relative flex-grow">
                        <input
                            id="teacherIdSearch"
                            type="text"
                            value={searchInput}
                            onChange={(e) => setSearchInput(e.target.value)}
                            placeholder="ইউনিক আইডি দিয়ে খুঁজুন..."
                            className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                         <button type="submit" className="absolute inset-y-0 right-0 flex items-center pr-3" aria-label="Search">
                            <SearchIcon className="w-5 h-5 text-gray-400 hover:text-teal-600" />
                        </button>
                    </div>
                </form>
            </div>

            {searchError && (
                 <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-lg max-w-lg mx-auto text-center" role="alert">
                    <p>{searchError}</p>
                </div>
            )}

            {teacher ? (
                <TeacherProfileView teacher={teacher} />
            ) : (!searchError && !teacherIdParam && !teacherUniqueIdParam) && (
                <div className="text-center text-gray-500 py-10">
                    <p>শিক্ষকের প্রোফাইল দেখতে ইউনিক আইডি দিয়ে সার্চ করুন।</p>
                </div>
            )}
        </div>
    );
};

export default TeacherProfile;
