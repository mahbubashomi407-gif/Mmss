import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';

const StudentAssignment: React.FC = () => {
    const { teachers, sections, students } = useInstitution();
    const [selectedTeacherId, setSelectedTeacherId] = useState('');

    const selectedTeacher = useMemo(() => {
        return teachers.find(t => t.id === selectedTeacherId);
    }, [selectedTeacherId, teachers]);

    const assignedData = useMemo(() => {
        if (!selectedTeacher) {
            return [];
        }

        // Find sections where the selected teacher is the class teacher
        const assignedSections = sections.filter(s => s.teacherName === selectedTeacher.nameBn);

        if (assignedSections.length === 0) {
            return [];
        }

        // For each assigned section, get the list of students
        return assignedSections.map(section => {
            const sectionStudents = students
                .filter(student => student.classLevel === section.classLevel && student.section === section.name && student.status !== 'পেন্ডিং')
                .sort((a, b) => (a.roll || 999) - (b.roll || 999));
            return { section, students: sectionStudents };
        });
    }, [selectedTeacher, sections, students]);

    return (
        <div>
            <PageHeader icon="🧒" title="শিক্ষার্থী দায়িত্ব তালিকা" />
            
            <div className="bg-white p-4 rounded-xl shadow-md mb-6 max-w-md mx-auto">
                <label htmlFor="teacher-select" className="block text-sm font-semibold text-gray-700 mb-1">শিক্ষক নির্বাচন করুন:</label>
                <select
                    id="teacher-select"
                    value={selectedTeacherId}
                    onChange={e => setSelectedTeacherId(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md bg-white focus:ring-2 focus:ring-teal-500"
                >
                    <option value="">-- একজন শিক্ষক নির্বাচন করুন --</option>
                    {teachers.map(teacher => (
                        <option key={teacher.id} value={teacher.id}>
                            {teacher.nameBn} ({teacher.uniqueId})
                        </option>
                    ))}
                </select>
            </div>
            
            {selectedTeacherId ? (
                assignedData.length > 0 ? (
                    <div className="space-y-6">
                        {assignedData.map(({ section, students: sectionStudents }) => (
                            <div key={section.id} className="bg-white p-6 rounded-xl shadow-md">
                                <h3 className="text-xl font-bold text-gray-800 border-b pb-3 mb-4">
                                    শ্রেণি: <span className="text-teal-600">{section.classLevel}</span>, 
                                    সেকশন: <span className="text-teal-600">{section.name}</span>
                                </h3>
                                {sectionStudents.length > 0 ? (
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                                <tr>
                                                    <th className="px-4 py-2">রোল</th>
                                                    <th className="px-4 py-2 text-left">শিক্ষার্থীর নাম</th>
                                                    <th className="px-4 py-2 text-left">পিতার নাম</th>
                                                    <th className="px-4 py-2 text-left">অভিভাবকের মোবাইল</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {sectionStudents.map(student => (
                                                    <tr key={student.id} className="border-b hover:bg-gray-50">
                                                        <td className="px-4 py-2 font-mono text-center">{student.roll}</td>
                                                        <td className="px-4 py-2 font-medium">{student.nameBn}</td>
                                                        <td className="px-4 py-2">{student.fatherNameBn}</td>
                                                        <td className="px-4 py-2">{student.fatherPhone}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : (
                                    <p className="text-center text-gray-500 py-4">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                                )}
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">
                        <p>এই শিক্ষক কোনো সেকশনের শ্রেণি শিক্ষক হিসেবে দায়িত্বপ্রাপ্ত নন।</p>
                        <p className="text-sm mt-1">অনুগ্রহ করে "শ্রেণি / সেকশন দায়িত্ব" পেজ থেকে দায়িত্ব বরাদ্দ করুন।</p>
                    </div>
                )
            ) : (
                 <div className="text-center text-gray-500 py-10">
                    <p>শিক্ষার্থীদের তালিকা দেখতে অনুগ্রহ করে একজন শিক্ষক নির্বাচন করুন।</p>
                </div>
            )}
        </div>
    );
};

export default StudentAssignment;