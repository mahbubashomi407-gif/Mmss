import React, { useState, useMemo, useEffect } from 'react';
import ReactDOM from 'react-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData, TeacherSalaryRecordData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { SaveIcon, PencilIcon, TrashIcon } from '../../../components/icons';
import Modal from '../../../components/Modal';

// --- UTILITY FUNCTIONS ---
const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match]);
};
const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;

// --- MODAL COMPONENTS ---

// Modal for paying salary
const PaySalaryModal: React.FC<{ isOpen: boolean; onClose: () => void; teacher: TeacherData | null; month: string; year: number; onSave: (record: Omit<TeacherSalaryRecordData, 'id'>) => void; dueAmount: number; }> = ({ isOpen, onClose, teacher, month, year, onSave, dueAmount }) => {
    const [amount, setAmount] = useState<number | ''>(dueAmount);
    const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
    const [paymentMethod, setPaymentMethod] = useState<'ক্যাশ' | 'ব্যাংক' | 'অন্যান্য'>('ব্যাংক');
    const [notes, setNotes] = useState('');

    useEffect(() => {
        if (isOpen) {
            setAmount(dueAmount > 0 ? dueAmount : (teacher?.monthlySalary || ''));
            setPaymentDate(new Date().toISOString().split('T')[0]);
            setPaymentMethod('ব্যাংক');
            setNotes('');
        }
    }, [isOpen, dueAmount, teacher]);

    if (!isOpen || !teacher) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (amount === '' || amount <= 0) return;
        onSave({ teacherId: teacher.id, amount, paymentDate, month, year, paymentMethod, notes });
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b"><h3 className="text-lg font-bold">বেতন পরিশোধ করুন</h3><p className="text-sm text-gray-500">{teacher.nameBn} - {month}, {toBengaliNumber(year)}</p></div>
                    <div className="p-5 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div><label className="block text-sm font-medium">বেতনের পরিমাণ</label><input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} required className="mt-1 w-full p-2 border rounded-md" /></div>
                            <div><label className="block text-sm font-medium">পরিশোধের তারিখ</label><input type="date" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div>
                        </div>
                        <div><label className="block text-sm font-medium">পরিশোধ পদ্ধতি</label><select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as any)} className="mt-1 w-full p-2 border rounded-md bg-white"><option>ব্যাংক</option><option>ক্যাশ</option><option>অন্যান্য</option></select></div>
                        <div><label className="block text-sm font-medium">নোট (ঐচ্ছিক)</label><textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="mt-1 w-full p-2 border rounded-md"></textarea></div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t"><button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button><button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">সংরক্ষণ</button></div>
                </form>
            </div>
        </div>,
        document.body
    );
};

// Modal for editing an existing salary record
const EditSalaryRecordModal: React.FC<{ isOpen: boolean; onClose: () => void; onSave: (record: TeacherSalaryRecordData) => void; recordToEdit: TeacherSalaryRecordData | null; }> = ({ isOpen, onClose, onSave, recordToEdit }) => {
    const { teachers } = useInstitution();
    const [amount, setAmount] = useState<number | ''>('');
    const [paymentDate, setPaymentDate] = useState('');
    const [paymentMethod, setPaymentMethod] = useState<'ক্যাশ' | 'ব্যাংক' | 'অন্যান্য'>('ব্যাংক');
    const [notes, setNotes] = useState('');
    
    const teacher = useMemo(() => teachers.find(t => t.id === recordToEdit?.teacherId), [recordToEdit, teachers]);
    
    useEffect(() => {
        if (recordToEdit) { setAmount(recordToEdit.amount); setPaymentDate(recordToEdit.paymentDate); setPaymentMethod(recordToEdit.paymentMethod); setNotes(recordToEdit.notes || ''); }
    }, [recordToEdit]);
    
    if (!isOpen || !recordToEdit) return null;
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (amount === '' || amount <= 0) return;
        onSave({ ...recordToEdit, amount: Number(amount), paymentDate, paymentMethod, notes });
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b"><h3 className="text-lg font-bold">বেতন রেকর্ড সম্পাদনা</h3><p className="text-sm text-gray-500">{teacher?.nameBn} - {recordToEdit.month}, {toBengaliNumber(recordToEdit.year)}</p></div>
                    <div className="p-5 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div><label className="block text-sm font-medium">পরিমাণ*</label><input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} required className="mt-1 w-full p-2 border rounded-md" /></div>
                            <div><label className="block text-sm font-medium">তারিখ*</label><input type="date" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div>
                        </div>
                        <div><label className="block text-sm font-medium">পেমেন্ট পদ্ধতি</label><select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as any)} className="mt-1 w-full p-2 border rounded-md bg-white"><option>ব্যাংক</option><option>ক্যাশ</option><option>অন্যান্য</option></select></div>
                        <div><label className="block text-sm font-medium">নোট</label><textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="mt-1 w-full p-2 border rounded-md"></textarea></div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t"><button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button><button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">সংরক্ষণ</button></div>
                </form>
            </div>
        </div>,
        document.body
    );
};

// --- MAIN COMPONENT ---
const Salary: React.FC = () => {
    const { teachers, setTeachers, teacherSalaryRecords, setTeacherSalaryRecords } = useInstitution();
    const { addToast } = useNotification();
    const [activeTab, setActiveTab] = useState<'payment' | 'setup' | 'history'>('payment');
    
    // State for Payment Tab
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [selectedMonthIndex, setSelectedMonthIndex] = useState(new Date().getMonth());
    const [payModal, setPayModal] = useState<{ isOpen: boolean; teacher: TeacherData | null; dueAmount: number }>({ isOpen: false, teacher: null, dueAmount: 0 });
    
    // State for Setup Tab
    const [salaries, setSalaries] = useState<Record<string, number | ''>>({});
    const [initialSalaries, setInitialSalaries] = useState<Record<string, number | ''>>({});

    // State for History Tab
    const [editModal, setEditModal] = useState<{ isOpen: boolean; record: TeacherSalaryRecordData | null }>({ isOpen: false, record: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; record: TeacherSalaryRecordData | null }>({ isOpen: false, record: null });

    // --- Common data ---
    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
    const selectedMonthName = months[selectedMonthIndex];
    
    // --- Payment Tab Logic ---
    const teacherSalaryStatus = useMemo(() => {
        return teachers.filter(t => t.status === 'সক্রিয়').map(teacher => {
            const designated = teacher.monthlySalary || 0;
            const paid = teacherSalaryRecords.filter(rec => rec.teacherId === teacher.id && rec.year === selectedYear && rec.month === selectedMonthName).reduce((sum, rec) => sum + rec.amount, 0);
            const due = designated - paid;
            let paymentStatus: 'Paid' | 'Due' | 'Partial' | 'NotSet' = 'Due';
            if (designated <= 0) { paymentStatus = 'NotSet'; } 
            else if (due <= 0) { paymentStatus = 'Paid'; } 
            else if (paid > 0) { paymentStatus = 'Partial'; }
            return { ...teacher, designated, paid, due, paymentStatus };
        });
    }, [teachers, teacherSalaryRecords, selectedYear, selectedMonthName]);
    
    const handleSavePayment = (record: Omit<TeacherSalaryRecordData, 'id'>) => {
        setTeacherSalaryRecords([...teacherSalaryRecords, { ...record, id: `tsr-${Date.now()}` }]);
        addToast(`${record.month} মাসের বেতন সফলভাবে পরিশোধ করা হয়েছে!`, 'success');
        setPayModal({ isOpen: false, teacher: null, dueAmount: 0 });
    };

    // --- Setup Tab Logic ---
    useEffect(() => {
        if (activeTab === 'setup') {
            const currentSalaries = teachers.reduce((acc, t) => {
                acc[t.id] = t.monthlySalary || '';
                return acc;
            }, {} as Record<string, number | ''>);
            setSalaries(currentSalaries);
            setInitialSalaries(currentSalaries);
        }
    }, [activeTab, teachers]);
    
    const handleSalaryChange = (teacherId: string, amount: string) => {
        setSalaries(prev => ({ ...prev, [teacherId]: amount === '' ? '' : Number(amount) }));
    };

    const handleSaveSalaries = () => {
        const updatedTeachers = teachers.map(t => ({...t, monthlySalary: Number(salaries[t.id]) || 0 }));
        setTeachers(updatedTeachers);
        addToast('বেতন সফলভাবে সেট করা হয়েছে!', 'success');
        setInitialSalaries(salaries);
    };

    // --- History Tab Logic ---
    const salaryHistory = useMemo(() => {
        return teacherSalaryRecords.map(rec => ({...rec, teacherName: teachers.find(t => t.id === rec.teacherId)?.nameBn || 'অজানা'}))
                                   .sort((a,b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
    }, [teacherSalaryRecords, teachers]);

    const handleSaveEdit = (updatedRecord: TeacherSalaryRecordData) => {
        setTeacherSalaryRecords(teacherSalaryRecords.map(r => r.id === updatedRecord.id ? updatedRecord : r));
        addToast('বেতন রেকর্ড সফলভাবে আপডেট করা হয়েছে!', 'success');
        setEditModal({ isOpen: false, record: null });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.record) {
            setTeacherSalaryRecords(teacherSalaryRecords.filter(r => r.id !== deleteModal.record!.id));
            addToast('বেতন রেকর্ড সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, record: null });
    };

    // --- Render logic ---
    const getStatusBadge = (status: 'Paid' | 'Due' | 'Partial' | 'NotSet') => {
        switch (status) {
            case 'Paid': return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">পরিশোধিত</span>;
            case 'Due': return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">বকেয়া</span>;
            case 'Partial': return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">আংশিক</span>;
            case 'NotSet': return <span className="px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">অনির্ধারিত</span>;
        }
    };
    
    return (
        <div>
            <PageHeader icon="👨‍🏫" title="শিক্ষক বেতন / সম্মানী" />
            <div className="mb-6 border-b border-gray-200">
                <nav className="-mb-px flex space-x-4">
                    <button onClick={() => setActiveTab('payment')} className={`py-3 px-4 font-semibold text-sm ${activeTab === 'payment' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>বেতন পরিশোধ</button>
                    <button onClick={() => setActiveTab('setup')} className={`py-3 px-4 font-semibold text-sm ${activeTab === 'setup' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>বেতন সেটআপ</button>
                    <button onClick={() => setActiveTab('history')} className={`py-3 px-4 font-semibold text-sm ${activeTab === 'history' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>বেতনের ইতিহাস</button>
                </nav>
            </div>
            
            {activeTab === 'payment' && (
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <div className="flex items-center gap-4 mb-4">
                        <div><label className="text-sm font-medium">বছর:</label><select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">{years.map(y => <option key={y} value={y}>{toBengaliNumber(y)}</option>)}</select></div>
                        <div><label className="text-sm font-medium">মাস:</label><select value={selectedMonthIndex} onChange={e => setSelectedMonthIndex(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">{months.map((m, index) => <option key={index} value={index}>{m}</option>)}</select></div>
                    </div>
                    <div className="overflow-x-auto"><table className="w-full text-sm">
                        <thead className="bg-gray-100"><tr><th className="p-2 text-left">শিক্ষকের নাম</th><th className="p-2 text-right">নির্ধারিত বেতন</th><th className="p-2 text-right">প্রদত্ত</th><th className="p-2 text-right">বকেয়া</th><th className="p-2 text-center">স্ট্যাটাস</th><th className="p-2 text-center">পদক্ষেপ</th></tr></thead>
                        <tbody>{teacherSalaryStatus.map(teacher => (<tr key={teacher.id} className="border-b"><td className="p-2 font-medium">{teacher.nameBn}</td><td className="p-2 text-right">{formatCurrency(teacher.designated)}</td><td className="p-2 text-right text-green-600">{formatCurrency(teacher.paid)}</td><td className="p-2 text-right font-bold text-red-600">{formatCurrency(teacher.due)}</td><td className="p-2 text-center">{getStatusBadge(teacher.paymentStatus)}</td><td className="p-2 text-center"><button onClick={() => setPayModal({ isOpen: true, teacher, dueAmount: teacher.due > 0 ? teacher.due : teacher.designated })} disabled={teacher.paymentStatus === 'Paid' || teacher.paymentStatus === 'NotSet'} className="px-3 py-1 bg-teal-600 text-white text-xs font-semibold rounded-md hover:bg-teal-700 disabled:bg-gray-400 disabled:cursor-not-allowed">বেতন দিন</button></td></tr>))}</tbody>
                    </table></div>
                </div>
            )}

            {activeTab === 'setup' && (
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold">সকল শিক্ষকের বেতন নির্ধারণ করুন</h3>
                        <button onClick={handleSaveSalaries} disabled={JSON.stringify(salaries) === JSON.stringify(initialSalaries)} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 flex items-center gap-2"><SaveIcon className="w-4 h-4" /> সংরক্ষণ</button>
                    </div>
                    <div className="overflow-x-auto"><table className="w-full text-sm">
                        <thead className="bg-gray-100"><tr><th className="p-2 text-left">শিক্ষকের নাম</th><th className="p-2 text-left">পদবি</th><th className="p-2 w-48">মাসিক বেতন (টাকা)</th></tr></thead>
                        <tbody>{teachers.filter(t=>t.status==='সক্রিয়').map(teacher => (<tr key={teacher.id} className="border-b"><td className="p-2 font-medium">{teacher.nameBn}</td><td className="p-2 text-gray-600">{teacher.designation}</td><td className="p-1"><input type="number" value={salaries[teacher.id] || ''} onChange={(e) => handleSalaryChange(teacher.id, e.target.value)} className="w-full p-2 border-gray-300 rounded-md focus:ring-2 focus:ring-teal-500" placeholder="0" /></td></tr>))}</tbody>
                    </table></div>
                </div>
            )}
            
            {activeTab === 'history' && (
                <div className="bg-white p-6 rounded-xl shadow-md">
                     <div className="overflow-x-auto"><table className="w-full text-sm">
                        <thead className="bg-gray-100"><tr><th className="p-2 text-left">তারিখ</th><th className="p-2 text-left">শিক্ষকের নাম</th><th className="p-2 text-left">মাস/বছর</th><th className="p-2 text-right">পরিমাণ</th><th className="p-2 text-center">পদ্ধতি</th><th className="p-2 text-center">পদক্ষেপ</th></tr></thead>
                        <tbody>{salaryHistory.map(rec => (<tr key={rec.id} className="border-b"><td className="p-2">{new Date(rec.paymentDate).toLocaleDateString('bn-BD')}</td><td className="p-2 font-medium">{rec.teacherName}</td><td className="p-2">{rec.month}, {toBengaliNumber(rec.year)}</td><td className="p-2 text-right font-semibold">{formatCurrency(rec.amount)}</td><td className="p-2 text-center">{rec.paymentMethod}</td><td className="p-2 text-center space-x-1"><button onClick={() => setEditModal({isOpen: true, record: rec})} className="p-1 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button><button onClick={() => setDeleteModal({isOpen: true, record: rec})} className="p-1 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button></td></tr>))}</tbody>
                    </table></div>
                </div>
            )}
            
            <PaySalaryModal isOpen={payModal.isOpen} onClose={() => setPayModal({isOpen: false, teacher: null, dueAmount: 0})} teacher={payModal.teacher} month={selectedMonthName} year={selectedYear} onSave={handleSavePayment} dueAmount={payModal.dueAmount} />
            <EditSalaryRecordModal isOpen={editModal.isOpen} onClose={() => setEditModal({isOpen: false, record: null})} onSave={handleSaveEdit} recordToEdit={editModal.record} />
            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({isOpen: false, record: null})} onConfirm={handleConfirmDelete} title="রেকর্ড মুছে ফেলুন">আপনি কি নিশ্চিতভাবে এই বেতনের রেকর্ডটি মুছে ফেলতে চান?</Modal>
        </div>
    );
};

export default Salary;
