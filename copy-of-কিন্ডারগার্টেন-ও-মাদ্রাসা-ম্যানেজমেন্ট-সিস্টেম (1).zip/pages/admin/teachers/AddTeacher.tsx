
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

const initialFormData: Omit<TeacherData, 'id' | 'uniqueId'> = {
    photoUrl: null,
    nameBn: '',
    nameEn: '',
    dob: '',
    gender: 'পুরুষ',
    bloodGroup: '',
    religion: 'ইসলাম',
    nid: '',
    nationality: 'বাংলাদেশী',
    joiningDate: new Date().toISOString().split('T')[0],
    designation: '',
    roleId: '',
    academicQualifications: '',
    professionalTraining: '',
    email: '',
    phone: '',
    presentAddress: { village: '', postOffice: '', upazila: '', district: '' },
    permanentAddress: { village: '', postOffice: '', upazila: '', district: '' },
    isSameAddress: false,
    status: 'সক্রিয়',
};

const generateUniqueId = (teachers: TeacherData[]): string => {
    const yearPrefix = new Date().getFullYear().toString().slice(-2);
    const nextSequence = teachers.length + 1;
    const paddedSequence = String(nextSequence).padStart(3, '0');
    return `T${yearPrefix}${paddedSequence}`;
};

const AddTeacher: React.FC = () => {
    const { teachers, setTeachers, teacherRoles, bloodGroups, religions, nationalities, designations, genders } = useInstitution();
    const { addToast } = useNotification();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const teacherId = searchParams.get('id');
    const isEditMode = Boolean(teacherId);

    const [formData, setFormData] = useState<Omit<TeacherData, 'id' | 'uniqueId'>>(initialFormData);
    const photoInputRef = useRef<HTMLInputElement>(null);

    const teacherGenders = useMemo(() => genders.filter(g => ['পুরুষ', 'মহিলা', 'অন্যান্য'].includes(g.name)), [genders]);

    const potentialUniqueId = useMemo(() => {
        if (!isEditMode) {
            return generateUniqueId(teachers);
        }
        return '...';
    }, [teachers, isEditMode]);

    useEffect(() => {
        if (isEditMode) {
            const teacherToEdit = teachers.find(t => t.id === teacherId);
            if (teacherToEdit) {
                setFormData(teacherToEdit);
            } else {
                addToast('সম্পাদনার জন্য শিক্ষককে খুঁজে পাওয়া যায়নি!', 'error');
                navigate('/admin/teachers/list');
            }
        } else {
            setFormData(initialFormData);
        }
    }, [teacherId, isEditMode, teachers, addToast, navigate]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleAddressChange = (type: 'presentAddress' | 'permanentAddress', e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [type]: { ...prev[type], [name]: value }
        }));
    };

    const handleSameAddressCheck = (e: React.ChangeEvent<HTMLInputElement>) => {
        const isChecked = e.target.checked;
        setFormData(prev => ({
            ...prev,
            isSameAddress: isChecked,
            permanentAddress: isChecked ? prev.presentAddress : prev.permanentAddress,
        }));
    };
    
    useEffect(() => {
        if (formData.isSameAddress) {
            setFormData(prev => ({ ...prev, permanentAddress: prev.presentAddress }));
        }
    }, [formData.presentAddress, formData.isSameAddress]);


    const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({ ...prev, photoUrl: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (isEditMode) {
            setTeachers(teachers.map(t => t.id === teacherId ? { ...t, ...formData } as TeacherData : t));
            addToast('শিক্ষকের তথ্য সফলভাবে আপডেট করা হয়েছে!', 'success');
            navigate('/admin/teachers');
        } else {
            const newTeacher: TeacherData = { 
                ...formData, 
                id: `t-${Date.now().toString()}`,
                uniqueId: generateUniqueId(teachers)
            };
            setTeachers([...teachers, newTeacher]);
            addToast(`নতুন শিক্ষক যোগ হয়েছে! ইউনিক আইডি: ${newTeacher.uniqueId}`, 'success');
            
            setFormData(initialFormData);

            if (photoInputRef.current) {
                photoInputRef.current.value = '';
            }
        }
    };

    return (
        <div>
            <PageHeader icon={isEditMode ? "✏️" : "➕"} title={isEditMode ? "শিক্ষকের তথ্য সম্পাদনা" : "নতুন শিক্ষক যোগ"} />
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-md max-w-5xl mx-auto">
                 <div className="space-y-6">
                    <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">ব্যক্তিগত তথ্য</legend>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                            <div className="md:col-span-1 flex flex-col items-center">
                                <div className="w-32 h-32 rounded-full border-2 border-dashed bg-gray-50 flex items-center justify-center mb-2 overflow-hidden">
                                    {formData.photoUrl ? <img src={formData.photoUrl} alt="Teacher" className="w-full h-full object-cover" /> : <span className="text-sm text-gray-400">ছবি</span>}
                                </div>
                                <input type="file" accept="image/*" onChange={handlePhotoChange} ref={photoInputRef} className="text-sm w-full" />
                            </div>
                            <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-3">
                                <div><label className="block text-sm font-medium">শিক্ষকের নাম (বাংলা)<span className="text-red-500">*</span></label><input type="text" name="nameBn" value={formData.nameBn} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" required /></div>
                                <div><label className="block text-sm font-medium">Teacher's Name (English)<span className="text-red-500">*</span></label><input type="text" name="nameEn" value={formData.nameEn} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" required /></div>
                                <div><label className="block text-sm font-medium">জন্মতারিখ<span className="text-red-500">*</span></label><input type="date" name="dob" value={formData.dob} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" required /></div>
                                <div><label className="block text-sm font-medium">লিঙ্গ</label><select name="gender" value={formData.gender} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg">{teacherGenders.map(g => <option key={g.id} value={g.name}>{g.name}</option>)}</select></div>
                                <div>
                                    <label className="block text-sm font-medium">রক্তের গ্রুপ</label>
                                    <select name="bloodGroup" value={formData.bloodGroup || ''} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg">
                                        <option value="">নির্বাচন করুন</option>
                                        {bloodGroups.map(bg => <option key={bg.id} value={bg.name}>{bg.name}</option>)}
                                    </select>
                                </div>
                                <div><label className="block text-sm font-medium">ধর্ম</label><select name="religion" value={formData.religion} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg">{religions.map(r => <option key={r.id} value={r.name}>{r.name}</option>)}</select></div>
                                <div><label className="block text-sm font-medium">জাতীয় পরিচয়পত্র (NID)</label><input type="text" name="nid" value={formData.nid} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" /></div>
                                <div>
                                    <label className="block text-sm font-medium">জাতীয়তা</label>
                                    <select name="nationality" value={formData.nationality} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg">
                                        {nationalities.map(n => <option key={n.id} value={n.name}>{n.name}</option>)}
                                    </select>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    
                    <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">প্রাতিষ্ঠানিক ও শিক্ষাগত তথ্য</legend>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div><label className="block text-sm font-medium">ইউনিক আইডি</label><input type="text" value={isEditMode ? (formData as TeacherData).uniqueId : potentialUniqueId} className="mt-1 w-full p-2 border rounded-lg bg-gray-100" readOnly /></div>
                            <div><label className="block text-sm font-medium">যোগদানের তারিখ</label><input type="date" name="joiningDate" value={formData.joiningDate} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" /></div>
                            <div>
                                <label className="block text-sm font-medium">পদবি<span className="text-red-500">*</span></label>
                                <select name="designation" value={formData.designation} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" required>
                                    <option value="" disabled>পদবি নির্বাচন করুন</option>
                                    {designations.map(d => <option key={d.id} value={d.name}>{d.name}</option>)}
                                </select>
                            </div>
                            <div><label className="block text-sm font-medium">রোল/ভূমিকা<span className="text-red-500">*</span></label><select name="roleId" value={formData.roleId} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" required><option value="" disabled>রোল নির্বাচন করুন</option>{teacherRoles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}</select></div>
                            <div className="md:col-span-2"><label className="block text-sm font-medium">শিক্ষাগত যোগ্যতা<span className="text-red-500">*</span></label><input type="text" name="academicQualifications" value={formData.academicQualifications} onChange={handleInputChange} placeholder="সর্বশেষ ডিগ্রি" className="mt-1 w-full p-2 border rounded-lg" required /></div>
                            <div className="md:col-span-3"><label className="block text-sm font-medium">পেশাগত প্রশিক্ষণ (ঐচ্ছিক)</label><textarea name="professionalTraining" value={formData.professionalTraining} onChange={handleInputChange} rows={2} placeholder="প্রশিক্ষণের বিবরণ..." className="mt-1 w-full p-2 border rounded-lg" /></div>
                        </div>
                    </fieldset>

                    <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">যোগাযোগের তথ্য</legend>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><label className="block text-sm font-medium">মোবাইল নম্বর<span className="text-red-500">*</span></label><input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" required /></div>
                            <div><label className="block text-sm font-medium">ইমেইল (ঐচ্ছিক)</label><input type="email" name="email" value={formData.email} onChange={handleInputChange} className="mt-1 w-full p-2 border rounded-lg" /></div>
                        </div>
                    </fieldset>

                     <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">ঠিকানা</legend>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                            <div>
                                <h4 className="text-md font-semibold text-gray-600 mb-2">বর্তমান ঠিকানা</h4>
                                <div className="space-y-2">
                                    <input type="text" name="village" placeholder="গ্রাম/মহল্লা" value={formData.presentAddress.village} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full p-2 border rounded-lg text-sm" />
                                    <input type="text" name="upazila" placeholder="থানা/উপজেলা" value={formData.presentAddress.upazila} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full p-2 border rounded-lg text-sm" />
                                    <input type="text" name="district" placeholder="জেলা" value={formData.presentAddress.district} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full p-2 border rounded-lg text-sm" />
                                </div>
                            </div>
                             <div>
                                <div className="flex justify-between items-center mb-2"><h4 className="text-md font-semibold text-gray-600">স্থায়ী ঠিকানা</h4><label className="flex items-center text-sm"><input type="checkbox" name="isSameAddress" checked={formData.isSameAddress} onChange={handleSameAddressCheck} className="h-4 w-4 text-teal-600" /><span className="ml-2">বর্তমান ঠিকানার অনুরূপ</span></label></div>
                                <div className="space-y-2">
                                    <input type="text" name="village" placeholder="গ্রাম/মহল্লা" value={formData.permanentAddress.village} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full p-2 border rounded-lg text-sm disabled:bg-gray-100" />
                                    <input type="text" name="upazila" placeholder="থানা/উপজেলা" value={formData.permanentAddress.upazila} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full p-2 border rounded-lg text-sm disabled:bg-gray-100" />
                                    <input type="text" name="district" placeholder="জেলা" value={formData.permanentAddress.district} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full p-2 border rounded-lg text-sm disabled:bg-gray-100" />
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>
                
                 <div className="mt-8 flex justify-end gap-3">
                    <button type="submit" className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                        {isEditMode ? 'তথ্য আপডেট করুন' : 'শিক্ষক যোগ করুন'}
                    </button>
                </div>
            </form>
        </div>
    );
};

export default AddTeacher;
