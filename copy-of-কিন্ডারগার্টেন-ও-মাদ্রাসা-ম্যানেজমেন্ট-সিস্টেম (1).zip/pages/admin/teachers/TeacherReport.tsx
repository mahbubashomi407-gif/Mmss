import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
    };
    return num.replace(/[0-9]/g, (match) => map[match]);
};


const TeacherReport: React.FC = () => {
    const { teachers, teacherAttendanceRecords, institutionName, logoUrl } = useInstitution();
    const { addToast } = useNotification();
    const [activeTab, setActiveTab] = useState<'list' | 'attendance'>('list');

    // State for Attendance Report filters
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());

    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);

    const handlePrint = (reportId: string, reportTitle: string) => {
        const printContent = document.getElementById(reportId);
        if (!printContent) return;

        const printWindow = window.open('', '_blank', 'height=800,width=1200');
        if (!printWindow) {
            addToast('প্রিন্টিং ব্যর্থ হয়েছে। অনুগ্রহ করে এই সাইটের জন্য পপ-আপ অনুমতি দিন।', 'error');
            return;
        }

        printWindow.document.write('<html><head>');
        printWindow.document.write(`<title>${reportTitle}</title>`);
        printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
        printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
        printWindow.document.write(`
            <style>
                body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                @page { size: A4 landscape; margin: 0.5in; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; font-size: 11px; }
                th { background-color: #f2f2f2 !important; text-align: center; }
                td { text-align: left; }
                .text-center { text-align: center; }
                .font-mono { font-family: monospace; }
                .header-info { display: flex; flex-direction: column; align-items: center; gap: 0.5rem; margin-bottom: 1rem; text-align: center; }
                .header-info img { width: 4rem; height: 4rem; border-radius: 9999px; object-fit: cover; }
                .header-info h1 { font-size: 1.5rem; font-weight: bold; }
                .header-info h2 { font-size: 1.25rem; }
            </style>
        `);
        printWindow.document.write('</head><body>');
        printWindow.document.write(`
            <div class="header-info">
                ${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}
                <h1>${institutionName}</h1>
                <h2>${reportTitle}</h2>
            </div>
        `);
        printWindow.document.write(printContent.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        
        setTimeout(() => {
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }, 750);
    };
    
    const AttendanceStatusBadge: React.FC<{ status: 'Present' | 'Absent' | 'On Leave' | undefined }> = ({ status }) => {
        switch (status) {
            case 'Present': return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-green-100 text-green-700 font-bold text-xs" title="উপস্থিত">উ</span>;
            case 'Absent': return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-red-100 text-red-700 font-bold text-xs" title="অনুপস্থিত">অ</span>;
            case 'On Leave': return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-yellow-100 text-yellow-700 font-bold text-xs" title="ছুটি">ছু</span>;
            default: return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-gray-100 text-gray-400 font-bold text-xs">-</span>;
        }
    };
    
    // Memoized data for attendance report
    const { days, year, month } = useMemo(() => {
        const date = new Date(selectedYear, selectedMonth, 1);
        const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
        return { days: Array.from({ length: daysInMonth }, (_, i) => i + 1), year: selectedYear, month: selectedMonth };
    }, [selectedYear, selectedMonth]);

    const attendanceMap = useMemo(() => {
        const map = new Map<string, Map<string, 'Present' | 'Absent' | 'On Leave'>>();
        const monthFilter = `${year}-${String(month + 1).padStart(2, '0')}`;
        teachers.forEach(teacher => {
            const teacherAttendance = new Map<string, 'Present' | 'Absent' | 'On Leave'>();
            teacherAttendanceRecords.filter(rec => rec.teacherId === teacher.id && rec.date.startsWith(monthFilter)).forEach(rec => { teacherAttendance.set(rec.date, rec.status); });
            map.set(teacher.id, teacherAttendance);
        });
        return map;
    }, [teachers, teacherAttendanceRecords, year, month]);

    const getDayName = (day: number) => new Date(year, month, day).toLocaleDateString('bn-BD', { weekday: 'short' });
    const isWeekend = (day: number) => new Date(year, month, day).getDay() === 5; // Friday

    return (
        <div>
            <PageHeader icon="📊" title="শিক্ষক রিপোর্ট" />
            
            <div className="mb-6">
                <div className="border-b border-gray-200">
                    <nav className="-mb-px flex space-x-4">
                        <button onClick={() => setActiveTab('list')} className={`py-3 px-4 font-semibold text-sm ${activeTab === 'list' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>শিক্ষক তালিকা</button>
                        <button onClick={() => setActiveTab('attendance')} className={`py-3 px-4 font-semibold text-sm ${activeTab === 'attendance' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>হাজিরা রিপোর্ট</button>
                    </nav>
                </div>
            </div>

            {activeTab === 'list' && (
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <div className="flex justify-between items-center mb-4">
                        <h3 className="text-lg font-bold">সকল শিক্ষকের তালিকা</h3>
                        <button onClick={() => handlePrint('teacher-list-report', 'সকল শিক্ষকের তালিকা')} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg text-sm">প্রিন্ট করুন</button>
                    </div>
                     <p className="text-center text-gray-500 py-6 bg-gray-50 rounded-md">রিপোর্ট প্রিন্ট করতে উপরের 'প্রিন্ট করুন' বাটনে ক্লিক করুন।</p>
                    <div id="teacher-list-report" className="overflow-x-auto hidden">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-100"><tr><th className="p-2">ইউনিক আইডি</th><th className="p-2 text-left">নাম</th><th className="p-2 text-left">পদবি</th><th className="p-2 text-left">মোবাইল নম্বর</th><th className="p-2 text-left">যোগদানের তারিখ</th></tr></thead>
                            <tbody>
                                {teachers.map(teacher => (
                                    <tr key={teacher.id} className="border-b">
                                        <td className="p-2 font-mono text-center">{toBengaliNumber(teacher.uniqueId)}</td>
                                        <td className="p-2 font-medium">{teacher.nameBn}</td>
                                        <td className="p-2">{teacher.designation}</td>
                                        <td className="p-2">{toBengaliNumber(teacher.phone)}</td>
                                        <td className="p-2">{new Date(teacher.joiningDate).toLocaleDateString('bn-BD')}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
            
            {activeTab === 'attendance' && (
                 <div className="bg-white p-6 rounded-xl shadow-md">
                    <div className="flex flex-wrap justify-between items-center mb-4 gap-4">
                        <h3 className="text-lg font-bold">মাসিক হাজিরা রিপোর্ট</h3>
                        <div className="flex items-center gap-4">
                           <select value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))} className="p-2 border rounded-md bg-white"><option disabled>মাস</option>{months.map((m,i)=><option key={i} value={i}>{m}</option>)}</select>
                           <select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="p-2 border rounded-md bg-white"><option disabled>বছর</option>{years.map(y=><option key={y} value={y}>{y}</option>)}</select>
                           <button onClick={() => handlePrint('teacher-attendance-report', `শিক্ষক হাজিরা রিপোর্ট - ${months[selectedMonth]}, ${toBengaliNumber(selectedYear)}`)} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg text-sm">প্রিন্ট করুন</button>
                        </div>
                    </div>
                     <p className="text-center text-gray-500 py-6 bg-gray-50 rounded-md">মাসিক হাজিরা রিপোর্ট প্রিন্ট করতে উপরের ফিল্টার নির্বাচন করে 'প্রিন্ট করুন' বাটনে ক্লিক করুন।</p>
                     <div id="teacher-attendance-report" className="overflow-x-auto hidden">
                        <table className="w-full border-collapse text-xs">
                            <thead>
                                <tr className="bg-gray-50">
                                    <th className="sticky left-0 bg-gray-50 p-2 border min-w-[150px] text-left">শিক্ষকের নাম</th>
                                    {days.map(day => <th key={day} className={`p-1 border w-10 ${isWeekend(day) ? 'bg-gray-200' : ''}`}><div>{toBengaliNumber(day)}</div><div className="font-normal text-gray-500">{getDayName(day)}</div></th>)}
                                    <th className="p-2 border bg-green-50">উপস্থিত</th><th className="p-2 border bg-red-50">অনুপস্থিত</th><th className="p-2 border bg-yellow-50">ছুটি</th>
                                </tr>
                            </thead>
                            <tbody>
                                {teachers.map(teacher => {
                                    const records = attendanceMap.get(teacher.id);
                                    let present=0, absent=0, onLeave=0;
                                    records?.forEach(status => {
                                        if (status === 'Present') present++;
                                        else if (status === 'Absent') absent++;
                                        else if (status === 'On Leave') onLeave++;
                                    });
                                    return (
                                        <tr key={teacher.id} className="border-b">
                                            <td className="sticky left-0 bg-white p-2 border text-left font-medium text-gray-800">{teacher.nameBn}</td>
                                            {days.map(day => {
                                                const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                                                const status = records?.get(date);
                                                return <td key={day} className={`border text-center ${isWeekend(day) ? 'bg-gray-100' : ''}`}><AttendanceStatusBadge status={status} /></td>
                                            })}
                                            <td className="p-2 border font-bold text-green-700 text-center">{toBengaliNumber(present)}</td>
                                            <td className="p-2 border font-bold text-red-700 text-center">{toBengaliNumber(absent)}</td>
                                            <td className="p-2 border font-bold text-yellow-700 text-center">{toBengaliNumber(onLeave)}</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};

export default TeacherReport;