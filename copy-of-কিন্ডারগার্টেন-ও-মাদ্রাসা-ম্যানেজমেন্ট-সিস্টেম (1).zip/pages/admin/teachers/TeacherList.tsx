
import React, { useState, useMemo, useEffect } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon, EyeIcon, SearchIcon, RefreshIcon } from '../../../components/icons';

const TeacherList: React.FC = () => {
    const { teachers, setTeachers, teacherRoles } = useInstitution();
    const { addToast } = useNotification();

    const [searchTerm, setSearchTerm] = useState('');
    const [roleFilter, setRoleFilter] = useState('');
    const [statusFilter, setStatusFilter] = useState('');
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; teacher: TeacherData | null }>({ isOpen: false, teacher: null });

    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);

    const filteredTeachers = useMemo(() => {
        return teachers.filter(teacher => {
            const lowerSearchTerm = searchTerm.toLowerCase();
            const searchMatch =
                teacher.nameBn.toLowerCase().includes(lowerSearchTerm) ||
                teacher.nameEn.toLowerCase().includes(lowerSearchTerm) ||
                teacher.uniqueId.toLowerCase().includes(lowerSearchTerm) ||
                teacher.phone.includes(searchTerm);

            const roleMatch = !roleFilter || teacher.roleId === roleFilter;
            const statusMatch = !statusFilter || teacher.status === statusFilter;

            return searchMatch && roleMatch && statusMatch;
        });
    }, [teachers, searchTerm, roleFilter, statusFilter]);

    useEffect(() => {
        setCurrentPage(1);
    }, [searchTerm, roleFilter, statusFilter, itemsPerPage]);

    const paginatedTeachers = useMemo(() => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        return filteredTeachers.slice(startIndex, startIndex + itemsPerPage);
    }, [filteredTeachers, currentPage, itemsPerPage]);

    const totalPages = Math.ceil(filteredTeachers.length / itemsPerPage);

    const handleDelete = (teacher: TeacherData) => {
        setDeleteModal({ isOpen: true, teacher });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.teacher) {
            setTeachers(teachers.filter(t => t.id !== deleteModal.teacher!.id));
            addToast('শিক্ষক সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, teacher: null });
    };
    
    const getRoleName = (roleId: string) => teacherRoles.find(r => r.id === roleId)?.name || 'N/A';
    
    const getStatusBadge = (status: TeacherData['status']) => {
        switch (status) {
            case 'সক্রিয়': return 'bg-green-100 text-green-800';
            case 'নিষ্ক্রিয়': return 'bg-red-100 text-red-800';
            case 'ছুটিতে': return 'bg-yellow-100 text-yellow-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    return (
        <div>
            <PageHeader icon="📋" title="শিক্ষক তালিকা">
                <Link to="/admin/teachers/add" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                    নতুন শিক্ষক যোগ করুন
                </Link>
            </PageHeader>

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow min-w-[200px]">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><SearchIcon className="w-5 h-5 text-gray-400" /></span>
                        <input type="text" placeholder="আইডি, নাম বা মোবাইল দিয়ে খুঁজুন..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border rounded-lg" />
                    </div>
                    <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)} className="border rounded-lg py-2 px-3 bg-white">
                        <option value="">সকল রোল</option>
                        {teacherRoles.map(role => <option key={role.id} value={role.id}>{role.name}</option>)}
                    </select>
                    <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="border rounded-lg py-2 px-3 bg-white">
                        <option value="">সকল স্ট্যাটাস</option>
                        <option value="সক্রিয়">সক্রিয়</option>
                        <option value="নিষ্ক্রিয়">নিষ্ক্রিয়</option>
                        <option value="ছুটিতে">ছুটিতে</option>
                    </select>
                    <button onClick={() => { setSearchTerm(''); setRoleFilter(''); setStatusFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300" title="ফিল্টার রিসেট করুন">
                        <RefreshIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-4 py-2">ছবি</th>
                                <th className="px-4 py-2">ইউনিক আইডি</th>
                                <th className="px-4 py-2">নাম</th>
                                <th className="px-4 py-2">পদবি</th>
                                <th className="px-4 py-2">রোল</th>
                                <th className="px-4 py-2">মোবাইল</th>
                                <th className="px-4 py-2">স্ট্যাটাস</th>
                                <th className="px-4 py-2 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {paginatedTeachers.length > 0 ? paginatedTeachers.map(teacher => (
                                <tr key={teacher.id} className="border-b hover:bg-gray-50">
                                    <td className="px-4 py-1.5"><img src={teacher.photoUrl || 'https://via.placeholder.com/40x40?text=T'} alt={teacher.nameBn} className="w-9 h-9 rounded-full object-cover" /></td>
                                    <td className="px-4 py-1.5 font-mono text-xs font-semibold">{teacher.uniqueId}</td>
                                    <td className="px-4 py-1.5 font-medium text-gray-900">{teacher.nameBn}</td>
                                    <td className="px-4 py-1.5">{teacher.designation}</td>
                                    <td className="px-4 py-1.5">{getRoleName(teacher.roleId)}</td>
                                    <td className="px-4 py-1.5">{teacher.phone}</td>
                                    <td className="px-4 py-1.5"><span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(teacher.status)}`}>{teacher.status}</span></td>
                                    <td className="px-4 py-1.5 text-right space-x-1 whitespace-nowrap">
                                        <Link to={`/app/teachers/profile?id=${teacher.id}`} className="p-2 text-green-600 hover:bg-green-100 rounded-full inline-block" title="প্রোফাইল দেখুন"><EyeIcon className="w-4 h-4" /></Link>
                                        <Link to={`/app/teachers/add?id=${teacher.id}`} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full inline-block" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></Link>
                                        <button onClick={() => handleDelete(teacher)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={8} className="text-center py-10 text-gray-500">কোনো শিক্ষক পাওয়া যায়নি।</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="flex flex-col md:flex-row justify-between items-center mt-4 text-sm text-gray-600 gap-4">
                    <div className="flex items-center gap-2">
                        <span>প্রতি পাতায় দেখান:</span>
                        <select value={itemsPerPage} onChange={e => setItemsPerPage(Number(e.target.value))} className="p-1 border rounded-md">
                            <option value={5}>৫</option><option value={10}>১০</option><option value={15}>১৫</option>
                        </select>
                        <span className="hidden md:inline">| মোট শিক্ষক: {filteredTeachers.length}</span>
                    </div>
                    <div className="flex items-center gap-3">
                        <span className="md:hidden text-xs">মোট: {filteredTeachers.length}</span>
                        <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-3 py-1 border rounded-md disabled:opacity-50">পূর্ববর্তী</button>
                        <span>পাতা {totalPages > 0 ? currentPage : 0} / {totalPages}</span>
                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages || totalPages === 0} className="px-3 py-1 border rounded-md disabled:opacity-50">পরবর্তী</button>
                    </div>
                </div>
            </div>

            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({ isOpen: false, teacher: null })} onConfirm={handleConfirmDelete} title="শিক্ষক মুছে ফেলুন">
                আপনি কি নিশ্চিতভাবে শিক্ষক "{deleteModal.teacher?.nameBn}"-কে তালিকা থেকে মুছে ফেলতে চান?
            </Modal>
        </div>
    );
};

export default TeacherList;
