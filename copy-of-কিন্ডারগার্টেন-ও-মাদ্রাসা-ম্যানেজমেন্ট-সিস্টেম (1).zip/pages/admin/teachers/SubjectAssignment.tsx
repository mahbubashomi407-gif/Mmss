
import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { TrashIcon } from '../../../components/icons';

interface Assignment {
    classLevelId: string;
    subjectId: string;
}

const SubjectAssignment: React.FC = () => {
    const { teachers, setTeachers, classLevels } = useInstitution();
    const { addToast } = useNotification();

    const [selectedTeacherId, setSelectedTeacherId] = useState('');
    const [selectedTeacher, setSelectedTeacher] = useState<TeacherData | null>(null);
    const [modifiedAssignments, setModifiedAssignments] = useState<Assignment[]>([]);
    
    useEffect(() => {
        const teacher = teachers.find(t => t.id === selectedTeacherId);
        setSelectedTeacher(teacher || null);
        setModifiedAssignments(teacher?.assignments || []);
    }, [selectedTeacherId, teachers]);

    const hasUnsavedChanges = useMemo(() => {
        if (!selectedTeacher) return false;
        return JSON.stringify(selectedTeacher.assignments || []) !== JSON.stringify(modifiedAssignments);
    }, [selectedTeacher, modifiedAssignments]);

    const handleAddAssignment = (classLevelId: string, subjectId: string) => {
        if (!subjectId) return;
        const newAssignment = { classLevelId, subjectId };
        if (!modifiedAssignments.some(a => a.classLevelId === classLevelId && a.subjectId === subjectId)) {
            setModifiedAssignments([...modifiedAssignments, newAssignment]);
        }
    };

    const handleRemoveAssignment = (classLevelId: string, subjectId: string) => {
        setModifiedAssignments(
            modifiedAssignments.filter(a => !(a.classLevelId === classLevelId && a.subjectId === subjectId))
        );
    };

    const handleSaveChanges = () => {
        const updatedTeachers = teachers.map(t =>
            t.id === selectedTeacherId ? { ...t, assignments: modifiedAssignments } : t
        );
        setTeachers(updatedTeachers);
        // We need to update the selectedTeacher as well to make hasUnsavedChanges false
        const updatedTeacher = updatedTeachers.find(t => t.id === selectedTeacherId);
        setSelectedTeacher(updatedTeacher || null);
        addToast('বিষয় বরাদ্দ সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };
    
    const handleReset = () => {
        setModifiedAssignments(selectedTeacher?.assignments || []);
    };
    
    const getSubjectName = (subjectId: string): string => {
        for (const cl of classLevels) {
            const subject = cl.subjects.find(s => s.id === subjectId);
            if (subject) return subject.name;
        }
        return 'অজানা বিষয়';
    };

    const ClassAssignmentCard: React.FC<{ classLevel: typeof classLevels[0] }> = ({ classLevel }) => {
        const assignmentsForClass = modifiedAssignments.filter(a => a.classLevelId === classLevel.id);
        const assignedSubjectIds = new Set(assignmentsForClass.map(a => a.subjectId));
        const unassignedSubjects = classLevel.subjects.filter(s => !assignedSubjectIds.has(s.id));
        
        const [subjectToAdd, setSubjectToAdd] = useState('');

        return (
            <div className="p-4 border rounded-lg">
                <h4 className="font-semibold text-gray-700 mb-3">{classLevel.name}</h4>
                
                <div className="mb-3">
                    <p className="text-xs text-gray-500 mb-1">বরাদ্দকৃত বিষয়:</p>
                    <div className="flex flex-wrap gap-2">
                        {assignmentsForClass.length > 0 ? assignmentsForClass.map(a => (
                            <span key={a.subjectId} className="flex items-center gap-2 bg-teal-100 text-teal-800 text-sm font-semibold px-3 py-1 rounded-full">
                                {getSubjectName(a.subjectId)}
                                <button onClick={() => handleRemoveAssignment(classLevel.id, a.subjectId)} className="text-teal-600 hover:text-red-600">
                                    <TrashIcon className="w-3 h-3" />
                                </button>
                            </span>
                        )) : <p className="text-sm text-gray-400">কোনো বিষয় বরাদ্দ নেই।</p>}
                    </div>
                </div>

                {unassignedSubjects.length > 0 && (
                    <div className="flex items-center gap-2">
                        <select
                            value={subjectToAdd}
                            onChange={e => setSubjectToAdd(e.target.value)}
                            className="flex-grow p-2 border border-gray-300 rounded-md bg-white text-sm"
                        >
                            <option value="">-- নতুন বিষয় যোগ করুন --</option>
                            {unassignedSubjects.map(sub => (
                                <option key={sub.id} value={sub.id}>{sub.name}</option>
                            ))}
                        </select>
                        <button 
                            onClick={() => {
                                handleAddAssignment(classLevel.id, subjectToAdd);
                                setSubjectToAdd('');
                            }}
                            disabled={!subjectToAdd}
                            className="px-4 py-2 bg-blue-500 text-white text-sm font-semibold rounded-md hover:bg-blue-600 disabled:bg-gray-300"
                        >
                            যোগ করুন
                        </button>
                    </div>
                )}
            </div>
        );
    };

    return (
        <div>
            <PageHeader icon="📚" title="বিষয় / ক্লাস বরাদ্দ">
                 {hasUnsavedChanges && (
                    <div className="flex items-center gap-2">
                        <button onClick={handleReset} className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg shadow-md hover:bg-red-600">বাতিল</button>
                        <button onClick={handleSaveChanges} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700">সংরক্ষণ করুন</button>
                    </div>
                )}
            </PageHeader>
            
            <div className="bg-white p-4 rounded-xl shadow-md mb-6 max-w-md mx-auto">
                <label htmlFor="teacher-select" className="block text-sm font-semibold text-gray-700 mb-1">শিক্ষক নির্বাচন করুন:</label>
                <select
                    id="teacher-select"
                    value={selectedTeacherId}
                    onChange={e => setSelectedTeacherId(e.target.value)}
                    className="w-full p-2 border border-gray-300 rounded-md bg-white focus:ring-2 focus:ring-teal-500"
                >
                    <option value="">-- একজন শিক্ষক নির্বাচন করুন --</option>
                    {teachers.map(teacher => (
                        <option key={teacher.id} value={teacher.id}>
                            {teacher.nameBn} ({teacher.uniqueId})
                        </option>
                    ))}
                </select>
            </div>
            
            {selectedTeacher ? (
                <div className="bg-white p-6 rounded-xl shadow-md max-w-4xl mx-auto">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">
                        বরাদ্দসমূহ: <span className="text-teal-600">{selectedTeacher.nameBn}</span>
                    </h3>
                    <div className="space-y-6">
                        {classLevels.map(cl => <ClassAssignmentCard key={cl.id} classLevel={cl} />)}
                    </div>
                </div>
            ) : (
                 <div className="text-center text-gray-500 py-10">
                    <p>বিষয় বরাদ্দ করতে অনুগ্রহ করে একজন শিক্ষক নির্বাচন করুন।</p>
                </div>
            )}
        </div>
    );
};

export default SubjectAssignment;
