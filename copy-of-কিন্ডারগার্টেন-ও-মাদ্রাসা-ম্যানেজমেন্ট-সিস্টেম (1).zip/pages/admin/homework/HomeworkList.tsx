import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, HomeworkData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon, EyeIcon, DownloadIcon, GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, DuplicateIcon } from '../../../components/icons';
import HomeworkModal from '../../../components/HomeworkModal';
import { useLocation, useNavigate } from 'react-router-dom'; // Added useLocation and useNavigate

const HomeworkList: React.FC = () => {
    const { homeworks, setHomeworks, classLevels, sections } = useInstitution();
    const { addToast } = useNotification();
    const location = useLocation(); // Hook to access location state
    const navigate = useNavigate(); // Hook to programmatically navigate

    // Filters
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');

    // Modals
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [selectedHomework, setSelectedHomework] = useState<HomeworkData | (Omit<HomeworkData, 'id'> & {id?: string}) | null>(null);

    // Effect to reset filters if navigation state requests it
    useEffect(() => {
        if (location.state && (location.state as any).resetFilters) {
            setClassFilter('');
            setSectionFilter('');
            // Clear the state so subsequent visits don't trigger reset
            navigate(location.pathname, { replace: true, state: {} });
        }
    }, [location.state, navigate]);

    // Filter logic
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    const filteredHomeworks = useMemo(() => {
        return homeworks.filter(hw => {
            const classMatch = !classFilter || hw.classLevel === classFilter;
            const sectionMatch = !sectionFilter || hw.section === sectionFilter;

            return classMatch && sectionMatch;
        }).sort((a, b) => new Date(b.assignDate).getTime() - new Date(a.assignDate).getTime());
    }, [homeworks, classFilter, sectionFilter]);
    
     useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) {
            setSectionFilter('');
        }
    }, [availableSections, sectionFilter]);

    // Modal handlers
    const handleAddNew = () => {
        setSelectedHomework(null);
        setIsModalOpen(true);
    };

    const handleReuse = (hw: HomeworkData) => {
        const homeworkToReuse = { 
            ...hw, 
            id: undefined, 
            assignDate: new Date().toISOString().split('T')[0],
            submissionDate: '',
        };
        setSelectedHomework(homeworkToReuse);
        setIsModalOpen(true);
    };

    const handleEdit = (hw: HomeworkData) => {
        setSelectedHomework(hw);
        setIsModalOpen(true);
    };

    const handleView = (hw: HomeworkData) => {
        setSelectedHomework(hw);
        setIsViewModalOpen(true);
    };

    const handleDelete = (hw: HomeworkData) => {
        setSelectedHomework(hw);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedHomework) {
            setHomeworks(homeworks.filter(hw => hw.id !== selectedHomework.id));
            addToast('হোমওয়ার্ক সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedHomework(null);
    };

    const handleSave = (data: Omit<HomeworkData, 'id'> & { id?: string }) => {
        if (data.id) {
            setHomeworks(homeworks.map(hw => hw.id === data.id ? { ...hw, ...data } as HomeworkData : hw));
            addToast('হোমওয়ার্ক সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else {
            const newHomework = { ...data, id: Date.now().toString() };
            setHomeworks([newHomework, ...homeworks]);
            addToast('নতুন হোমওয়ার্ক যোগ করা হয়েছে!', 'success');
        }
        setIsModalOpen(false);
    };

    return (
        <div>
            <PageHeader icon="📋" title="হোমওয়ার্ক তালিকা">
                 <button onClick={handleAddNew} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                    নতুন হোমওয়ার্ক যোগ করুন
                </button>
            </PageHeader>

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">সকল শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সকল সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-4 py-2">শিরোনাম</th>
                                <th className="px-4 py-2">শ্রেণি/সেকশন</th>
                                <th className="px-4 py-2">বিষয়</th>
                                <th className="px-4 py-2">দেওয়ার তারিখ</th>
                                <th className="px-4 py-2">জমা দেওয়ার তারিখ</th>
                                <th className="px-4 py-2 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredHomeworks.length > 0 ? filteredHomeworks.map(hw => {
                                const today = new Date(); today.setHours(0, 0, 0, 0);
                                const isPast = new Date(hw.submissionDate) < today;
                                return (
                                <tr key={hw.id} className={`border-b hover:bg-gray-50 transition-opacity ${isPast ? 'opacity-60 bg-gray-50' : ''}`}>
                                    <td className="px-4 py-2 font-medium">{hw.title}</td>
                                    <td className="px-4 py-2">{hw.classLevel} ({hw.section})</td>
                                    <td className="px-4 py-2">{hw.subject}</td>
                                    <td className="px-4 py-2">{new Date(hw.assignDate).toLocaleDateString('bn-BD')}</td>
                                    <td className="px-4 py-2">{new Date(hw.submissionDate).toLocaleDateString('bn-BD')}</td>
                                    <td className="px-4 py-2 text-right space-x-1">
                                        <button onClick={() => handleReuse(hw)} className="p-2 text-purple-600 hover:bg-purple-100 rounded-full" title="পুনরায় ব্যবহার করুন"><DuplicateIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleView(hw)} className="p-2 text-green-600 hover:bg-green-100 rounded-full" title="দেখুন"><EyeIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleEdit(hw)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleDelete(hw)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )}) : (
                                <tr><td colSpan={6} className="text-center py-10 text-gray-500">কোনো হোমওয়ার্ক পাওয়া যায়নি।</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <HomeworkModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSave} homeworkToEdit={selectedHomework as HomeworkData | null} />
            
            <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} onConfirm={handleConfirmDelete} title="হোমওয়ার্ক মুছুন">
                আপনি কি নিশ্চিতভাবে এই হোমওয়ার্কটি মুছে ফেলতে চান?
            </Modal>
            
            {isViewModalOpen && selectedHomework && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setIsViewModalOpen(false)}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                        <div className="p-5 border-b">
                            <h3 className="text-lg font-bold">{selectedHomework.title}</h3>
                            <p className="text-xs text-gray-500">{selectedHomework.classLevel} ({selectedHomework.section}) - {selectedHomework.subject}</p>
                        </div>
                        <div className="p-5 max-h-80 overflow-y-auto">
                            <p className="whitespace-pre-wrap">{selectedHomework.description}</p>
                            {selectedHomework.fileUrl && (
                                <div className="mt-4">
                                    <a href={selectedHomework.fileUrl} download={selectedHomework.fileName} className="flex items-center gap-2 text-sm text-blue-600 font-semibold hover:underline">
                                        <DownloadIcon className="w-4 h-4" />
                                        <span>সংযুক্তি ডাউনলোড করুন ({selectedHomework.fileName})</span>
                                    </a>
                                </div>
                            )}
                        </div>
                         <div className="bg-gray-50 p-3 text-xs text-gray-600 flex justify-between">
                             <span><strong>দেওয়ার তারিখ:</strong> {new Date(selectedHomework.assignDate).toLocaleDateString('bn-BD')}</span>
                             <span className="font-semibold"><strong>জমা দেওয়ার তারিখ:</strong> {new Date(selectedHomework.submissionDate).toLocaleDateString('bn-BD')}</span>
                         </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default HomeworkList;