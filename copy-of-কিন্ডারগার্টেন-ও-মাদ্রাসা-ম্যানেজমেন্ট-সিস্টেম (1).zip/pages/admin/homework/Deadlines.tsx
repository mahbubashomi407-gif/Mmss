import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, HomeworkData } from '../../../context/InstitutionContext';
import { EyeIcon, DownloadIcon, CalendarIcon } from '../../../components/icons';

const Deadlines: React.FC = () => {
    const { homeworks } = useInstitution();
    
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [selectedHomework, setSelectedHomework] = useState<HomeworkData | null>(null);

    const upcomingDeadlines = useMemo(() => {
        const today = new Date();
        today.setHours(0, 0, 0, 0);

        const upcoming = homeworks
            .filter(hw => new Date(hw.submissionDate) >= today)
            .sort((a, b) => new Date(a.submissionDate).getTime() - new Date(b.submissionDate).getTime());

        const grouped: Record<string, HomeworkData[]> = {};
        upcoming.forEach(hw => {
            const dateStr = hw.submissionDate;
            if (!grouped[dateStr]) {
                grouped[dateStr] = [];
            }
            grouped[dateStr].push(hw);
        });

        return Object.entries(grouped);
    }, [homeworks]);
    
    const handleView = (hw: HomeworkData) => {
        setSelectedHomework(hw);
        setIsViewModalOpen(true);
    };

    const getDeadlineStyle = (dateStr: string) => {
        const today = new Date(); today.setHours(0,0,0,0);
        const tomorrow = new Date(today); tomorrow.setDate(today.getDate() + 1);
        const deadlineDate = new Date(dateStr); deadlineDate.setHours(0,0,0,0);

        if (deadlineDate.getTime() === today.getTime()) {
            return {
                label: 'আজ জমা দিতে হবে',
                headerClass: 'bg-red-100 text-red-800 border-red-200',
                iconColor: 'text-red-600'
            };
        }
        if (deadlineDate.getTime() === tomorrow.getTime()) {
            return {
                label: 'আগামীকাল জমা দিতে হবে',
                headerClass: 'bg-yellow-100 text-yellow-800 border-yellow-200',
                iconColor: 'text-yellow-600'
            };
        }
        return {
            label: new Date(dateStr).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' }),
            headerClass: 'bg-gray-100 text-gray-800 border-gray-200',
            iconColor: 'text-gray-500'
        };
    };

    return (
        <div>
            <PageHeader icon="🗓️" title="ডিউ ডেট / সময়সীমা" />

            {upcomingDeadlines.length > 0 ? (
                <div className="space-y-6">
                    {upcomingDeadlines.map(([date, hws]) => {
                        const style = getDeadlineStyle(date);
                        return (
                            <div key={date} className="bg-white rounded-xl shadow-md overflow-hidden">
                                <div className={`px-4 py-2 border-b font-bold flex items-center gap-2 ${style.headerClass}`}>
                                    <CalendarIcon className={`w-5 h-5 ${style.iconColor}`} />
                                    <span>{style.label}</span>
                                </div>
                                <div className="divide-y divide-gray-100">
                                    {hws.map(hw => (
                                        <div key={hw.id} className="p-4 flex justify-between items-center hover:bg-gray-50">
                                            <div>
                                                <p className="font-semibold text-gray-800">{hw.title}</p>
                                                <p className="text-sm text-gray-500">{hw.classLevel} ({hw.section}) - {hw.subject}</p>
                                            </div>
                                            <button onClick={() => handleView(hw)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="দেখুন">
                                                <EyeIcon className="w-5 h-5" />
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        );
                    })}
                </div>
            ) : (
                <div className="bg-white p-10 rounded-xl shadow-md text-center">
                    <p className="text-gray-500">কোনো আসন্ন হোমওয়ার্ক ডিউ ডেট নেই।</p>
                </div>
            )}

            {isViewModalOpen && selectedHomework && (
                 <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setIsViewModalOpen(false)}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                        <div className="p-5 border-b">
                            <h3 className="text-lg font-bold">{selectedHomework.title}</h3>
                            <p className="text-xs text-gray-500">{selectedHomework.classLevel} ({selectedHomework.section}) - {selectedHomework.subject}</p>
                        </div>
                        <div className="p-5 max-h-80 overflow-y-auto">
                            <p className="whitespace-pre-wrap">{selectedHomework.description}</p>
                            {selectedHomework.fileUrl && (
                                <div className="mt-4">
                                    <a href={selectedHomework.fileUrl} download={selectedHomework.fileName} className="flex items-center gap-2 text-sm text-blue-600 font-semibold hover:underline">
                                        <DownloadIcon className="w-4 h-4" />
                                        <span>সংযুক্তি ডাউনলোড করুন ({selectedHomework.fileName})</span>
                                    </a>
                                </div>
                            )}
                        </div>
                         <div className="bg-gray-50 p-3 text-xs text-gray-600 flex justify-between">
                             <span><strong>দেওয়ার তারিখ:</strong> {new Date(selectedHomework.assignDate).toLocaleDateString('bn-BD')}</span>
                             <span className="font-semibold"><strong>জমা দেওয়ার তারিখ:</strong> {new Date(selectedHomework.submissionDate).toLocaleDateString('bn-BD')}</span>
                         </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Deadlines;