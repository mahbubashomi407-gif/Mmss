import React from 'react';
import PageHeader from '../../../components/PageHeader';

const HomeworkStatus: React.FC = () => {
  return (
    <div>
      <PageHeader icon="🧒" title="শিক্ষার্থী জমা স্ট্যাটাস" />
      <div className="bg-white p-6 rounded-xl shadow-md">
        <p className="text-center text-gray-500">এই পেজের কাজ চলছে।</p>
      </div>
    </div>
  );
};

export default HomeworkStatus;
