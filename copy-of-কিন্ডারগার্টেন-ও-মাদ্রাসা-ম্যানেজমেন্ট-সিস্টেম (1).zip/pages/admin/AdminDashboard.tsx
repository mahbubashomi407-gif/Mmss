import React from 'react';
import { useInstitution } from '../../context/InstitutionContext';
import DashboardCard from '../../components/DashboardCard';
import DashboardActionCard from '../../components/DashboardActionCard';
import { StudentsIcon, TeachersIcon, CurrencyBangladeshiIcon, AddUserIcon, MegaphoneIcon } from '../../components/icons';

const AdminDashboard: React.FC = () => {
    const { students, teachers } = useInstitution();

    const stats = {
        totalStudents: students.filter(s => s.status !== 'পেন্ডিং').length,
        totalTeachers: teachers.filter(t => t.status === 'সক্রিয়').length,
    };

    const quickActions = [
        { to: '/app/students/add', icon: <AddUserIcon className="w-10 h-10" />, title: 'নতুন শিক্ষার্থী' },
        { to: '/app/teachers/add', icon: <AddUserIcon className="w-10 h-10" />, title: 'নতুন শিক্ষক' },
        { to: '/app/fees/student-fees', icon: <CurrencyBangladeshiIcon className="w-10 h-10" />, title: 'ফি আদায়' },
        { to: '/app/notices', icon: <MegaphoneIcon className="w-10 h-10" />, title: 'নোটিশ পাঠান' },
    ];

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">অ্যাডমিন ড্যাশবোর্ড</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <DashboardCard 
                    title="মোট শিক্ষার্থী" 
                    value={stats.totalStudents}
                    icon={<StudentsIcon className="w-8 h-8 text-white" />} 
                    color="bg-blue-500" 
                />
                <DashboardCard 
                    title="মোট শিক্ষক" 
                    value={stats.totalTeachers}
                    icon={<TeachersIcon className="w-8 h-8 text-white" />} 
                    color="bg-indigo-500" 
                />
                {/* Add more cards for income/expense later if needed */}
            </div>
            
            <div className="bg-white p-4 rounded-xl shadow-lg">
                <h2 className="text-lg font-bold text-gray-800 mb-3">দ্রুত পদক্ষেপ</h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                    {quickActions.map(item => (
                        <DashboardActionCard 
                            key={item.to}
                            to={item.to}
                            icon={item.icon}
                            title={item.title}
                        />
                    ))}
                </div>
            </div>
        </div>
    );
};

export default AdminDashboard;
