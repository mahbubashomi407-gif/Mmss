
import React from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';
import { useInstitution } from '../../context/InstitutionContext';

// Reusable card component
const ActionCard: React.FC<{ icon: string; title: string }> = ({ icon, title }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className="bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
            role="button"
            tabIndex={0}
            aria-label={title}
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};

const ManageMadrasaExams: React.FC = () => {
    
    const madrasaActions = [
      { to: 'entry', icon: '🔢', title: 'নম্বর এন্ট্রি' },
      { to: 'edit-result', icon: '✏️', title: 'ফলাফল ইডিট' },
      { to: 'class-result', icon: '📊', title: 'রেজাল্ট শিট' },
      { to: 'marksheet', icon: '📑', title: 'মার্কশীট' },
      { to: 'result-summary', icon: '📈', title: 'ফলাফল সামারি' },
      { to: 'export', icon: '📤', title: 'ফলাফল রিপোর্ট' },
      { to: 'publish-result', icon: '📢', title: 'ফলাফল প্রকাশ' },
      { to: 'grade-processing', icon: '⚙️', title: 'গ্রেড সিস্টেম সেটআপ' },
      { to: 'subject-assignment', icon: '📚', title: 'বিষয় অ্যাসাইনমেন্ট' },
      { to: 'exam-types', icon: '📝', title: 'পরীক্ষার ধরণ' },
    ];

    return (
        <div>
            <PageHeader icon="🌙" title="মাদরাসা রেজাল্ট" />
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {madrasaActions.map((action, index) => (
                    <Link to={action.to} key={index} className="no-underline h-full">
                        <ActionCard icon={action.icon} title={action.title} />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default ManageMadrasaExams;