import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherRoleData, StudentRoleData, AccountantRoleData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { PencilIcon, CheckCircleIcon } from '../../../components/icons';
import { getPermissionLabel, PERMISSIONS } from '../../../constants/permissions';
import Modal from '../../../components/Modal';
import RoleModal from '../../../components/RoleModal';

// A generic type for any of the roles we're managing
type RoleDataType = TeacherRoleData | AccountantRoleData | StudentRoleData;


// Generic Roles Component to handle Teacher, Accountant, and Student roles
interface RolesContentProps {
    roleType: 'teacher' | 'accountant' | 'student';
}

const RolesContent: React.FC<RolesContentProps> = ({ roleType }) => {
    const {
        teacherRoles, setTeacherRoles,
        accountantRoles, setAccountantRoles,
        studentRoles, setStudentRoles
    } = useInstitution();
    const { addToast } = useNotification();
    
    const [roleModal, setRoleModal] = useState<{ isOpen: boolean; roleToEdit: RoleDataType | null }>({ isOpen: false, roleToEdit: null });

    // Dynamically select the correct roles and setter from context based on props
    const roles: RoleDataType[] = {
        teacher: teacherRoles,
        accountant: accountantRoles,
        student: studentRoles
    }[roleType];

    const setRoles: React.Dispatch<React.SetStateAction<any[]>> = {
        teacher: setTeacherRoles,
        accountant: setAccountantRoles,
        student: setStudentRoles
    }[roleType];

    const permissionSetForRole = {
        teacher: (() => {
            const { studentPortal, ...teacherPerms } = PERMISSIONS;
            return teacherPerms;
        })(),
        accountant: {
            feesAndSalary: PERMISSIONS.feesAndSalary,
            accounting: PERMISSIONS.accounting,
            settings: { title: 'সেটিংস', permissions: { 'settings:manage_fee_types': PERMISSIONS.settings.permissions['settings:manage_fee_types'] } }
        },
        student: {
            studentPortal: PERMISSIONS.studentPortal
        }
    }[roleType];
    
    const handleSaveRole = (data: { name: string, permissions: string[], id?: string }) => {
        if (data.id) { // Editing existing role
            setRoles(prevRoles => prevRoles.map(r => r.id === data.id ? { ...r, ...data } : r));
            addToast('ভূমিকা সফলভাবে আপডেট করা হয়েছে!', 'success');
        }
        setRoleModal({ isOpen: false, roleToEdit: null });
    };

    return (
        <div className="space-y-4">
            {roles.map(role => (
                <div key={role.id} className="bg-white p-4 rounded-xl shadow-md">
                    <div className="flex justify-between items-center mb-3">
                        <h3 className="text-lg font-bold text-gray-800">{role.name}</h3>
                        <div className="space-x-2">
                            <button 
                                onClick={() => setRoleModal({ isOpen: true, roleToEdit: role })} 
                                className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-700 font-semibold rounded-lg shadow-sm hover:bg-gray-200 transition-colors text-sm"
                            >
                                <PencilIcon className="w-4 h-4" />
                                <span>অনুমতি সম্পাদনা করুন</span>
                            </button>
                        </div>
                    </div>
                    <div>
                        <h4 className="font-semibold text-gray-600 text-sm mb-2">অনুমতিসমূহ:</h4>
                        <div className="flex flex-wrap gap-2">
                            {role.permissions.length > 0 ? role.permissions.map(permKey => (
                                <span key={permKey} className="flex items-center gap-1 text-xs bg-teal-100 text-teal-800 px-2 py-1 rounded-full">
                                    <CheckCircleIcon className="w-3 h-3"/>
                                    {getPermissionLabel(permKey)}
                                </span>
                            )) : <p className="text-xs text-gray-500">কোনো অনুমতি দেওয়া হয়নি।</p>}
                        </div>
                    </div>
                </div>
            ))}

            <RoleModal 
                isOpen={roleModal.isOpen}
                onClose={() => setRoleModal({ isOpen: false, roleToEdit: null })}
                onSave={handleSaveRole}
                roleToEdit={roleModal.roleToEdit}
                permissionSet={permissionSetForRole}
            />
        </div>
    );
};

// Main Permissions Component
const Permissions: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'teacher' | 'accountant' | 'student'>('teacher');
    
    return (
        <div>
            <PageHeader icon="🔐" title="ইউজার পারমিশন" />
            
            <div className="border-b border-gray-200 mb-6">
                <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                    <button 
                        onClick={() => setActiveTab('teacher')} 
                        className={`py-3 px-1 border-b-2 font-semibold text-sm transition-colors duration-200 ${activeTab === 'teacher' ? 'border-b-2 border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                    >
                        শিক্ষক
                    </button>
                    <button 
                        onClick={() => setActiveTab('accountant')} 
                        className={`py-3 px-1 border-b-2 font-semibold text-sm transition-colors duration-200 ${activeTab === 'accountant' ? 'border-b-2 border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                    >
                        হিসাবরক্ষক
                    </button>
                    <button 
                        onClick={() => setActiveTab('student')} 
                        className={`py-3 px-1 border-b-2 font-semibold text-sm transition-colors duration-200 ${activeTab === 'student' ? 'border-b-2 border-teal-500 text-teal-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                    >
                        শিক্ষার্থী
                    </button>
                </nav>
            </div>

            <div>
                {activeTab === 'teacher' && <RolesContent roleType="teacher" />}
                {activeTab === 'accountant' && <RolesContent roleType="accountant" />}
                {activeTab === 'student' && <RolesContent roleType="student" />}
            </div>
        </div>
    );
};

export default Permissions;