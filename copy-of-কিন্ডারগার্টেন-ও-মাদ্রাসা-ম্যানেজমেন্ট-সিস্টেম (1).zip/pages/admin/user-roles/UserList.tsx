
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, SystemUserData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon, InfoIcon } from '../../../components/icons';

const UserList: React.FC = () => {
    const { systemUsers, setSystemUsers, institutionCode } = useInstitution();
    const { addToast } = useNotification();
    const navigate = useNavigate();

    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; user: SystemUserData | null }>({ isOpen: false, user: null });

    const handleConfirmDelete = () => {
        if (deleteModal.user) {
            setSystemUsers(systemUsers.filter(u => u.id !== deleteModal.user!.id));
            addToast('ব্যবহারকারী সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, user: null });
    };

    return (
        <div>
            <PageHeader icon="📋" title="ইউজার তালিকা">
                <button onClick={() => navigate('/app/user-roles/create')} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                    নতুন ইউজার তৈরী
                </button>
            </PageHeader>
            
            <div className="bg-blue-50 border-l-4 border-blue-400 text-blue-800 p-4 rounded-r-lg mb-6" role="alert">
                <div className="flex">
                    <div className="py-1"><InfoIcon className="w-6 h-6 mr-3"/></div>
                    <div>
                        <p className="font-bold">লগইন তথ্য</p>
                        <ul className="list-disc list-inside text-sm mt-1">
                            <li><strong>শিক্ষার্থী লগইন:</strong> মাদরাসা কোড, শিক্ষার্থীর ইউনিক আইডি এবং পাসওয়ার্ড ('123456') প্রয়োজন।</li>
                            <li><strong>অন্যান্য ব্যবহারকারী (এডমিন, শিক্ষক, হিসাবরক্ষক):</strong> মাদরাসা কোড ({institutionCode}), ইমেইল এবং পাসওয়ার্ড ('123456') দিয়ে লগইন করুন।</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="p-2 text-left">ইমেইল</th>
                                <th className="p-2 text-left">ভূমিকা (Role)</th>
                                <th className="p-2 text-center">স্ট্যাটাস</th>
                                <th className="p-2 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {systemUsers.map(user => (
                                <tr key={user.id} className="border-b hover:bg-gray-50">
                                    <td className="p-2 font-medium">{user.email}</td>
                                    <td className="p-2">{user.role}</td>
                                    <td className="p-2 text-center">
                                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${user.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                            {user.status === 'Active' ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                                        </span>
                                    </td>
                                    <td className="p-2 text-right space-x-1">
                                        <button onClick={() => navigate(`/app/user-roles/create?id=${user.id}`)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => setDeleteModal({ isOpen: true, user })} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                 {systemUsers.length === 0 && <p className="text-center text-gray-500 py-10">কোনো ব্যবহারকারী পাওয়া যায়নি।</p>}
            </div>
             <Modal
                isOpen={deleteModal.isOpen}
                onClose={() => setDeleteModal({ isOpen: false, user: null })}
                onConfirm={handleConfirmDelete}
                title="ব্যবহারকারী মুছে ফেলুন"
            >
                আপনি কি নিশ্চিতভাবে "{deleteModal.user?.email}" ব্যবহারকারীকে মুছে ফেলতে চান?
            </Modal>
        </div>
    );
};

export default UserList;
