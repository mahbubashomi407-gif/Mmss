
import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, SystemUserData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { useAuth } from '../../../context/AuthContext';
import { UserRole } from '../../../types';

const CreateUser: React.FC = () => {
    const { systemUsers, setSystemUsers } = useInstitution();
    const { addToast } = useNotification();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const userId = searchParams.get('id');
    const isEditMode = Boolean(userId);

    const { user, originalUser } = useAuth();
    const isSuperAdminImpersonating = originalUser?.role === UserRole.SUPER_ADMIN;

    const availableRoles: ('Admin' | 'Teacher' | 'Accountant')[] = isSuperAdminImpersonating
        ? ['Admin', 'Teacher', 'Accountant']
        : ['Teacher', 'Accountant'];

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [role, setRole] = useState<'Admin' | 'Teacher' | 'Accountant'>(availableRoles[0]);
    const [status, setStatus] = useState<'Active' | 'Inactive'>('Active');
    const [passwordError, setPasswordError] = useState('');

    useEffect(() => {
        if (isEditMode) {
            const userToEdit = systemUsers.find(u => u.id === userId);
            if (userToEdit) {
                setEmail(userToEdit.email);
                setRole(userToEdit.role as 'Admin' | 'Teacher' | 'Accountant');
                setStatus(userToEdit.status);
            } else {
                addToast('ব্যবহারকারী খুঁজে পাওয়া যায়নি!', 'error');
                navigate('/app/user-roles/list');
            }
        } else {
            setEmail('');
            setPassword('');
            setConfirmPassword('');
            setRole(availableRoles[0]);
            setStatus('Active');
        }
    }, [isEditMode, userId, systemUsers, addToast, navigate, availableRoles]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setPasswordError('');

        if (password !== confirmPassword) {
            setPasswordError('পাসওয়ার্ড দুটি মিলছে না।');
            return;
        }
        if (!isEditMode && !password) {
            setPasswordError('নতুন ব্যবহারকারীর জন্য পাসওয়ার্ড আবশ্যক।');
            return;
        }
        
        const isEmailTaken = systemUsers.some(
            u => u.email.toLowerCase() === email.toLowerCase() && u.id !== userId
        );
        if (isEmailTaken) {
            addToast('এই ইমেইল ইতিমধ্যে ব্যবহৃত হয়েছে।', 'error');
            return;
        }

        if (isEditMode) {
            setSystemUsers(systemUsers.map(u => u.id === userId ? { ...u, email, role, status } as SystemUserData : u));
            addToast('ব্যবহারকারীর তথ্য আপডেট করা হয়েছে!', 'success');
        } else {
            const newUser: SystemUserData = {
                id: `user-${Date.now()}`,
                email,
                role,
                status,
            };
            setSystemUsers([...systemUsers, newUser]);
            addToast('নতুন ব্যবহারকারী তৈরি করা হয়েছে!', 'success');
        }
        navigate('/app/user-roles/list');
    };

    const roleLabels: Record<'Admin' | 'Teacher' | 'Accountant', string> = {
        'Admin': 'এডমিন',
        'Teacher': 'শিক্ষক',
        'Accountant': 'হিসাব রক্ষক'
    };


    return (
        <div>
            <PageHeader icon={isEditMode ? '✏️' : '➕'} title={isEditMode ? 'ইউজার সম্পাদনা করুন' : 'নতুন ইউজার তৈরী'} />
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700">মাদরাসা কোড</label>
                    <input type="text" value={user?.institutionCode || ''} className="mt-1 w-full p-2 border rounded-md bg-gray-100 cursor-not-allowed" readOnly />
                </div>
                 <div>
                    <label className="block text-sm font-medium text-gray-700">ইমেইল*</label>
                    <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="mt-1 w-full p-2 border rounded-md" required />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">পাসওয়ার্ড {isEditMode ? '(খালি রাখলে অপরিবর্তিত থাকবে)' : '*'}</label>
                        <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="mt-1 w-full p-2 border rounded-md" />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">পাসওয়ার্ড নিশ্চিত করুন {isEditMode ? '' : '*'}</label>
                        <input type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="mt-1 w-full p-2 border rounded-md" />
                    </div>
                </div>
                {passwordError && <p className="text-sm text-red-500">{passwordError}</p>}
                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">ভূমিকা (Role)*</label>
                        <select
                            value={role}
                            onChange={e => setRole(e.target.value as 'Admin' | 'Teacher' | 'Accountant')}
                            className="mt-1 w-full p-2 border rounded-md bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
                            disabled={isEditMode}
                        >
                            {availableRoles.map(r => (
                                <option key={r} value={r}>{roleLabels[r]}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">স্ট্যাটাস*</label>
                        <select value={status} onChange={e => setStatus(e.target.value as any)} className="mt-1 w-full p-2 border rounded-md bg-white">
                            <option value="Active">সক্রিয়</option>
                            <option value="Inactive">নিষ্ক্রিয়</option>
                        </select>
                    </div>
                </div>
                 <div className="flex justify-end pt-4 border-t">
                    <button type="submit" className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                        {isEditMode ? 'আপডেট করুন' : 'তৈরী করুন'}
                    </button>
                </div>
            </form>
        </div>
    );
};
export default CreateUser;
