import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentFeeRecordData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon, SearchIcon, RefreshIcon } from '../../../components/icons';
import EditFeeRecordModal from '../../../components/EditFeeRecordModal';

const EditFees: React.FC = () => {
  const { studentFeeRecords, setStudentFeeRecords, students, feeTypes } = useInstitution();
  const { addToast } = useNotification();

  const [searchTerm, setSearchTerm] = useState('');
  const [editModal, setEditModal] = useState<{ isOpen: boolean; record: StudentFeeRecordData | null }>({ isOpen: false, record: null });
  const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; record: StudentFeeRecordData | null }>({ isOpen: false, record: null });
  
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const detailedRecords = useMemo(() => {
    return studentFeeRecords.map(record => {
      const student = students.find(s => s.id === record.studentId);
      const feeType = feeTypes.find(ft => ft.id === record.feeTypeId);
      return {
        ...record,
        studentName: student?.nameBn || 'অজানা',
        studentClass: student ? `${student.classLevel} (${student.section})` : 'N/A',
        feeTypeName: feeType?.name || 'অজানা',
      };
    }).sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
  }, [studentFeeRecords, students, feeTypes]);

  const filteredRecords = useMemo(() => {
    return detailedRecords.filter(record => {
      const lowerSearch = searchTerm.toLowerCase();
      return (
        record.studentName.toLowerCase().includes(lowerSearch) ||
        record.invoiceNumber.toLowerCase().includes(lowerSearch) ||
        record.feeTypeName.toLowerCase().includes(lowerSearch)
      );
    });
  }, [detailedRecords, searchTerm]);
  
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, itemsPerPage]);

  const paginatedRecords = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredRecords.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredRecords, currentPage, itemsPerPage]);

  const totalPages = Math.ceil(filteredRecords.length / itemsPerPage);

  const handleEdit = (record: StudentFeeRecordData) => {
    setEditModal({ isOpen: true, record });
  };

  const handleDelete = (record: StudentFeeRecordData) => {
    setDeleteModal({ isOpen: true, record });
  };

  const handleConfirmDelete = () => {
    if (deleteModal.record) {
      setStudentFeeRecords(studentFeeRecords.filter(r => r.id !== deleteModal.record!.id));
      addToast('ফি রেকর্ড সফলভাবে মুছে ফেলা হয়েছে!', 'success');
    }
    setDeleteModal({ isOpen: false, record: null });
  };
  
  const handleSaveEdit = (updatedRecord: StudentFeeRecordData) => {
      setStudentFeeRecords(studentFeeRecords.map(r => r.id === updatedRecord.id ? updatedRecord : r));
      addToast('ফি রেকর্ড সফলভাবে আপডেট করা হয়েছে!', 'success');
      setEditModal({isOpen: false, record: null});
  }

  return (
    <div>
      <PageHeader icon="🔄" title="ফি সংশোধন / এডিট" />

      <div className="bg-white p-4 rounded-xl shadow-md mb-6">
          <div className="flex items-center gap-4">
              <div className="relative flex-grow">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3"><SearchIcon className="w-5 h-5 text-gray-400" /></span>
                  <input
                      type="text"
                      placeholder="শিক্ষার্থীর নাম, ইনভয়েস নং, বা ফি-এর ধরন দিয়ে খুঁজুন..."
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
              </div>
              <button onClick={() => setSearchTerm('')} className="p-2.5 bg-gray-200 rounded-lg hover:bg-gray-300" title="রিসেট">
                  <RefreshIcon className="w-5 h-5" />
              </button>
          </div>
      </div>
      
      <div className="bg-white p-6 rounded-xl shadow-md">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
              <tr>
                <th className="p-2 text-left">ইনভয়েস নং</th>
                <th className="p-2 text-left">শিক্ষার্থীর নাম</th>
                <th className="p-2 text-left">শ্রেণি</th>
                <th className="p-2 text-left">ফি-এর ধরন</th>
                <th className="p-2 text-right">টাকা</th>
                <th className="p-2 text-left">পেমেন্টের তারিখ</th>
                <th className="p-2 text-right">পদক্ষেপ</th>
              </tr>
            </thead>
            <tbody>
              {paginatedRecords.length > 0 ? paginatedRecords.map(record => (
                <tr key={record.id} className="border-b hover:bg-gray-50">
                  <td className="p-2 font-mono text-xs">{record.invoiceNumber}</td>
                  <td className="p-2 font-medium">{record.studentName}</td>
                  <td className="p-2">{record.studentClass}</td>
                  <td className="p-2">{record.feeTypeName} {record.month && `(${record.month})`}</td>
                  <td className="p-2 text-right font-semibold">৳{record.amountPaid.toLocaleString('bn-BD')}</td>
                  <td className="p-2">{new Date(record.paymentDate).toLocaleDateString('bn-BD')}</td>
                  <td className="p-2 text-right space-x-1">
                    <button onClick={() => handleEdit(record as StudentFeeRecordData)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                    <button onClick={() => handleDelete(record as StudentFeeRecordData)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                  </td>
                </tr>
              )) : (
                <tr>
                    <td colSpan={7} className="text-center py-10 text-gray-500">
                        <p>কোনো পেমেন্ট রেকর্ড পাওয়া যায়নি।</p>
                    </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="flex flex-col md:flex-row justify-between items-center mt-4 text-sm text-gray-600 gap-4">
            <div className="flex items-center gap-2">
                <span>প্রতি পাতায় দেখান:</span>
                <select value={itemsPerPage} onChange={e => setItemsPerPage(Number(e.target.value))} className="p-1 border rounded-md ml-2 focus:ring-1 focus:ring-teal-500">
                    <option value={10}>১০</option> <option value={20}>২০</option> <option value={50}>৫০</option>
                </select>
                <span className="hidden md:inline">| মোট: {filteredRecords.length}</span>
            </div>
            <div className="flex items-center gap-3">
                 <span className="md:hidden text-xs">মোট: {filteredRecords.length}</span>
                <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-3 py-1 border rounded-md disabled:opacity-50 hover:bg-gray-100">পূর্ববর্তী</button>
                <span>পাতা {totalPages > 0 ? currentPage : 0} / {totalPages}</span>
                <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages || totalPages === 0} className="px-3 py-1 border rounded-md disabled:opacity-50 hover:bg-gray-100">পরবর্তী</button>
            </div>
        </div>
      </div>

      <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({ isOpen: false, record: null })} onConfirm={handleConfirmDelete} title="রেকর্ড মুছে ফেলুন">
        আপনি কি নিশ্চিতভাবে এই পেমেন্ট রেকর্ডটি মুছে ফেলতে চান?
      </Modal>
      
      <EditFeeRecordModal isOpen={editModal.isOpen} onClose={() => setEditModal({isOpen: false, record: null})} onSave={handleSaveEdit} recordToEdit={editModal.record} />

    </div>
  );
};

export default EditFees;