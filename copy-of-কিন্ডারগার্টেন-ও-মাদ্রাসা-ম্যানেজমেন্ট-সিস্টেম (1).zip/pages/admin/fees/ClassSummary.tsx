import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, CalendarIcon, RefreshIcon, ChevronDownIcon } from '../../../components/icons';

const ClassSummary: React.FC = () => {
    const { students, classLevels, sections, academicSessions, feeTypes, studentFeeRecords } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    
    // Fee calculation logic (consistent with DueReport)
    const calculateDues = (student: StudentData): { totalDue: number, totalPaid: number, arrears: number } => {
        let totalDue = 0;
        const studentAdmissionDate = new Date(student.admissionDate);
        
        const applicableOneTimeFees = feeTypes.filter(ft => 
            !ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel)
        );
        applicableOneTimeFees.forEach(fee => totalDue += fee.amount);

        const monthlyFee = feeTypes.find(ft => ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel));
        if (monthlyFee && activeSession) {
            const sessionStartDate = new Date(activeSession.startDate);
            const sessionEndDate = new Date(activeSession.endDate);
            const today = new Date();
            
            const calculationStartDate = studentAdmissionDate > sessionStartDate ? studentAdmissionDate : sessionStartDate;
            const calculationEndDate = today < sessionEndDate ? today : sessionEndDate;

            if (calculationEndDate > calculationStartDate) {
                const months = (calculationEndDate.getFullYear() - calculationStartDate.getFullYear()) * 12 + (calculationEndDate.getMonth() - calculationStartDate.getMonth()) + 1;
                totalDue += months * monthlyFee.amount;
            }
        }

        const totalPaid = studentFeeRecords
            .filter(rec => rec.studentId === student.id)
            .reduce((sum, rec) => sum + rec.amountPaid, 0);
            
        const arrears = totalDue - totalPaid;

        return { totalDue, totalPaid, arrears };
    };

    // Calculate summary data based on filters
    const classSummaryData = useMemo(() => {
        if (!classFilter) return null;

        const studentsInClass = students.filter(s => 
            s.academicYear === academicYearFilter && s.classLevel === classFilter && s.status !== 'পেন্ডিং'
        );

        const sectionsInClass = sections.filter(s => s.classLevel === classFilter);
        
        if (studentsInClass.length === 0 || sectionsInClass.length === 0) {
            return { sections: [], totalStudents: 0, totalCollected: 0, totalArrears: 0 };
        }

        const sectionSummaries = sectionsInClass.map(section => {
            const studentsInSection = studentsInClass.filter(s => s.section === section.name);
            let totalDue = 0;
            let totalPaid = 0;

            studentsInSection.forEach(student => {
                const dues = calculateDues(student);
                totalDue += dues.totalDue;
                totalPaid += dues.totalPaid;
            });

            return {
                name: section.name,
                studentCount: studentsInSection.length,
                totalDue,
                totalPaid,
                arrears: totalDue - totalPaid
            };
        });

        const totalStudents = sectionSummaries.reduce((sum, s) => sum + s.studentCount, 0);
        const totalCollected = sectionSummaries.reduce((sum, s) => sum + s.totalPaid, 0);
        const totalArrears = sectionSummaries.reduce((sum, s) => sum + s.arrears, 0);

        return { sections: sectionSummaries, totalStudents, totalCollected, totalArrears };
    }, [classFilter, academicYearFilter, students, sections, feeTypes, studentFeeRecords, activeSession]);
    
    const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;

    return (
        <div>
            <PageHeader icon="🏫" title="ক্লাস / জামাত ভিত্তিক ফি সারসংক্ষেপ" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span>
                        <select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none">
                            <option value="">সকল বর্ষ</option>
                            {academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                        </select>
                        <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span>
                    </div>
                    <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span>
                        <select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none">
                            <option value="">শ্রেণি নির্বাচন করুন</option>
                            {classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}
                        </select>
                        <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span>
                    </div>
                    <button onClick={() => setClassFilter('')} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300">
                        <RefreshIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>

            {classFilter && classSummaryData ? (
                <>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div className="bg-blue-50 p-4 rounded-xl text-center">
                            <p className="text-sm text-blue-600">মোট শিক্ষার্থী</p>
                            <p className="text-3xl font-bold text-blue-700">{classSummaryData.totalStudents.toLocaleString('bn-BD')}</p>
                        </div>
                        <div className="bg-green-50 p-4 rounded-xl text-center">
                            <p className="text-sm text-green-600">মোট আদায়</p>
                            <p className="text-3xl font-bold text-green-700">{formatCurrency(classSummaryData.totalCollected)}</p>
                        </div>
                        <div className="bg-red-50 p-4 rounded-xl text-center">
                            <p className="text-sm text-red-600">মোট বকেয়া</p>
                            <p className="text-3xl font-bold text-red-700">{formatCurrency(classSummaryData.totalArrears)}</p>
                        </div>
                    </div>
                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-lg font-bold text-gray-800 mb-4">সেকশন ভিত্তিক সারসংক্ষেপ</h3>
                        {classSummaryData.sections.length > 0 ? (
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="bg-gray-100">
                                        <tr>
                                            <th className="p-2 text-left">সেকশন</th>
                                            <th className="p-2 text-center">শিক্ষার্থী সংখ্যা</th>
                                            <th className="p-2 text-right">মোট প্রদেয়</th>
                                            <th className="p-2 text-right">মোট আদায়</th>
                                            <th className="p-2 text-right">মোট বকেয়া</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {classSummaryData.sections.map(sec => (
                                            <tr key={sec.name} className="border-b">
                                                <td className="p-2 font-medium">{sec.name}</td>
                                                <td className="p-2 text-center">{sec.studentCount.toLocaleString('bn-BD')}</td>
                                                <td className="p-2 text-right">{formatCurrency(sec.totalDue)}</td>
                                                <td className="p-2 text-right text-green-600 font-semibold">{formatCurrency(sec.totalPaid)}</td>
                                                <td className="p-2 text-right text-red-600 font-bold">{formatCurrency(sec.arrears)}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        ) : (
                             <p className="text-center text-gray-500 py-10">এই শ্রেণিতে কোনো সেকশন অথবা শিক্ষার্থী পাওয়া যায়নি।</p>
                        )}
                    </div>
                </>
            ) : (
                <div className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">
                    <p>সারসংক্ষেপ দেখতে অনুগ্রহ করে একটি শ্রেণি নির্বাচন করুন।</p>
                </div>
            )}
        </div>
    );
};

export default ClassSummary;