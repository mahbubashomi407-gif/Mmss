
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, GuardianNotificationData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';
import { useNotification } from '../../../context/NotificationContext';

const DueReport: React.FC = () => {
    const { students, classLevels, sections, academicSessions, feeTypes, studentFeeRecords, institutionName, logoUrl, notificationSettings, setGuardianNotifications, appNotificationTemplates } = useInstitution();
    const { addToast } = useNotification();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');

    // Pagination state
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState<number | string>(5);
    const [isNotifying, setIsNotifying] = useState(false);
    
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    
    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) setSectionFilter('');
    }, [availableSections, sectionFilter]);
    
    // Reset page on filter change
    useEffect(() => {
        setCurrentPage(1);
    }, [academicYearFilter, classFilter, sectionFilter, itemsPerPage]);

    // Due calculation logic
    const calculateDues = (student: StudentData): { totalDue: number, totalPaid: number, arrears: number } => {
        let totalDue = 0;
        const studentAdmissionDate = new Date(student.admissionDate);
        
        const applicableOneTimeFees = feeTypes.filter(ft => 
            !ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel)
        );
        applicableOneTimeFees.forEach(fee => totalDue += fee.amount);

        const monthlyFee = feeTypes.find(ft => ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel));
        if (monthlyFee && activeSession) {
            const sessionStartDate = new Date(activeSession.startDate);
            const sessionEndDate = new Date(activeSession.endDate);
            const today = new Date();
            
            const calculationStartDate = studentAdmissionDate > sessionStartDate ? studentAdmissionDate : sessionStartDate;
            const calculationEndDate = today < sessionEndDate ? today : sessionEndDate;

            if (calculationEndDate > calculationStartDate) {
                const months = (calculationEndDate.getFullYear() - calculationStartDate.getFullYear()) * 12 + (calculationEndDate.getMonth() - calculationStartDate.getMonth()) + 1;
                totalDue += months * monthlyFee.amount;
            }
        }

        const totalPaid = studentFeeRecords
            .filter(rec => rec.studentId === student.id)
            .reduce((sum, rec) => sum + rec.amountPaid, 0);
            
        const arrears = totalDue - totalPaid;

        return { totalDue, totalPaid, arrears };
    };
    
    // Memoize the list of all students with dues
    const allStudentsWithDues = useMemo(() => {
        return students
            .filter(student => student.status !== 'পেন্ডিং')
            .map(student => {
                const dues = calculateDues(student);
                return { ...student, ...dues };
            })
            .filter(student => student.arrears > 0)
            .sort((a, b) => b.arrears - a.arrears);
    }, [students, feeTypes, studentFeeRecords, activeSession]);

    // Filter the list based on UI controls
    const filteredResults = useMemo(() => {
        return allStudentsWithDues.filter(student =>
            (!academicYearFilter || student.academicYear === academicYearFilter) &&
            (!classFilter || student.classLevel === classFilter) &&
            (!sectionFilter || student.section === sectionFilter)
        );
    }, [allStudentsWithDues, academicYearFilter, classFilter, sectionFilter]);
    
    // Create paginated list
    const paginatedResults = useMemo(() => {
        if (itemsPerPage === 'all') {
            return filteredResults;
        }
        const numericItemsPerPage = Number(itemsPerPage);
        const startIndex = (currentPage - 1) * numericItemsPerPage;
        return filteredResults.slice(startIndex, startIndex + numericItemsPerPage);
    }, [filteredResults, currentPage, itemsPerPage]);

    const totalPages = useMemo(() => {
        if (itemsPerPage === 'all' || filteredResults.length === 0) return 1;
        return Math.ceil(filteredResults.length / Number(itemsPerPage));
    }, [filteredResults, itemsPerPage]);

    const totalArrears = useMemo(() => {
        return filteredResults.reduce((sum, student) => sum + student.arrears, 0);
    }, [filteredResults]);
    
    const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;
    
    const handleSendNotifications = () => {
        if (filteredResults.length === 0) {
            addToast('নোটিশ পাঠানোর জন্য কোনো শিক্ষার্থী নেই।', 'error');
            return;
        }

        if (!notificationSettings.automaticNotifications.feeDue.app) {
            addToast('বকেয়া ফি-এর জন্য অ্যাপ নোটিফিকেশন সক্রিয় করা নেই।', 'error');
            return;
        }
        
        setIsNotifying(true);
        const newNotifications: GuardianNotificationData[] = [];
        const monthName = new Date().toLocaleString('bn-BD', { month: 'long'});

        filteredResults.forEach(student => {
            let message = appNotificationTemplates.feeDue;
            message = message.replace('{{student_name}}', student.nameBn)
                             .replace('{{amount}}', `৳${student.arrears.toLocaleString('bn-BD')}`)
                             .replace('{{month}} মাসের বেতন', 'মোট ফি');

            newNotifications.push({
                id: `noti-due-${student.id}-${Date.now()}`,
                studentId: student.id,
                timestamp: new Date().toISOString(),
                title: 'ফি বকেয়া সংক্রান্ত নোটিশ',
                message,
                isRead: false
            });
        });
        
        setGuardianNotifications(prev => [...newNotifications, ...prev]);
        addToast(`${newNotifications.length} জন অভিভাবককে সফলভাবে নোটিফিকেশন পাঠানো হয়েছে!`, 'success');
        setIsNotifying(false);
    };

    return (
        <div>
            <PageHeader icon="📊" title="বকেয়া ফি রিপোর্ট" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none"><option value="">সকল বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none"><option value="">সকল শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none" disabled={!classFilter}><option value="">সকল সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-red-50 p-4 rounded-xl text-center"><p className="text-sm text-red-600">মোট বকেয়া</p><p className="text-3xl font-bold text-red-700">{formatCurrency(totalArrears)}</p></div>
                <div className="bg-blue-50 p-4 rounded-xl text-center"><p className="text-sm text-blue-600">মোট শিক্ষার্থী (বকেয়া)</p><p className="text-3xl font-bold text-blue-700">{filteredResults.length.toLocaleString('bn-BD')}</p></div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex justify-end mb-4">
                     <button onClick={handleSendNotifications} className="px-4 py-2 bg-yellow-500 text-white font-semibold rounded-lg text-sm shadow-md hover:bg-yellow-600 disabled:bg-gray-400" disabled={isNotifying || filteredResults.length === 0}>বকেয়া নোটিশ পাঠান</button>
                </div>
                <div id="printable-report" className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="bg-gray-100"><tr><th className="p-2">রোল</th><th className="p-2 text-left">শিক্ষার্থীর নাম</th><th className="p-2 text-left">শ্রেণি/সেকশন</th><th className="p-2 text-left">পিতার মোবাইল</th><th className="p-2 text-right">মোট প্রদেয়</th><th className="p-2 text-right">মোট জমা</th><th className="p-2 text-right">মোট বকেয়া</th></tr></thead>
                        <tbody>
                            {paginatedResults.length > 0 ? paginatedResults.map(s => (
                                <tr key={s.id} className="border-b">
                                    <td className="p-2 text-center">{s.roll}</td>
                                    <td className="p-2 font-medium">{s.nameBn}</td>
                                    <td className="p-2">{s.classLevel} ({s.section})</td>
                                    <td className="p-2">{s.fatherPhone}</td>
                                    <td className="p-2 text-right">{formatCurrency(s.totalDue)}</td>
                                    <td className="p-2 text-right text-green-600">{formatCurrency(s.totalPaid)}</td>
                                    <td className="p-2 text-right font-bold text-red-600">{formatCurrency(s.arrears)}</td>
                                </tr>
                            )) : (
                                <tr><td colSpan={7} className="text-center py-10 text-gray-500">কোনো বকেয়া পাওয়া যায়নি।</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="flex flex-col md:flex-row justify-between items-center mt-4 text-sm text-gray-600 gap-4">
                    <div className="flex items-center gap-2">
                        <span>প্রতি পাতায় দেখান:</span>
                        <select 
                            value={itemsPerPage} 
                            onChange={e => setItemsPerPage(e.target.value)}
                            className="p-1 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-teal-500"
                        >
                            <option value={5}>৫</option>
                            <option value={10}>১০</option>
                            <option value={15}>১৫</option>
                            <option value={'all'}>সব</option>
                        </select>
                        <span className="hidden md:inline">| মোট বকেয়া শিক্ষার্থী: {filteredResults.length}</span>
                    </div>
                    
                    {itemsPerPage !== 'all' && totalPages > 1 && (
                        <div className="flex items-center gap-3">
                            <span className="md:hidden text-xs">মোট: {filteredResults.length}</span>
                            <button 
                                onClick={() => setCurrentPage(p => p - 1)} 
                                disabled={currentPage === 1}
                                className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                            >
                                পূর্ববর্তী
                            </button>
                            <span>পাতা {totalPages > 0 ? currentPage : 0} / {totalPages}</span>
                            <button 
                                onClick={() => setCurrentPage(p => p + 1)} 
                                disabled={currentPage === totalPages || totalPages === 0}
                                className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                            >
                                পরবর্তী
                            </button>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default DueReport;
