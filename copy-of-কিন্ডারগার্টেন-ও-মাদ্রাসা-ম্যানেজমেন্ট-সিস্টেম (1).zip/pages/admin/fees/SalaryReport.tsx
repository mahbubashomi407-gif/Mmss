import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match]);
};

const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;

const SalaryReport: React.FC = () => {
    const { teachers, teacherSalaryRecords, institutionName, logoUrl, address } = useInstitution();

    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
    // State now holds month index (0-11) or -1 for "All Months"
    const [selectedMonthIndex, setSelectedMonthIndex] = useState<number>(new Date().getMonth());

    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
    
    const reportData = useMemo(() => {
        if (selectedMonthIndex === -1) { // Yearly Report
            const yearlyData = teachers.map(teacher => {
                const paidInYear = teacherSalaryRecords
                    .filter(rec => rec.teacherId === teacher.id && rec.year === selectedYear)
                    .reduce((sum, rec) => sum + rec.amount, 0);
                return { ...teacher, totalPaid: paidInYear };
            });
            const grandTotalPaid = yearlyData.reduce((sum, t) => sum + t.totalPaid, 0);
            return { type: 'yearly', data: yearlyData, grandTotalPaid };
        } else { // Monthly Report
            const selectedMonthName = months[selectedMonthIndex];
            const monthlyData = teachers.map(teacher => {
                const designated = teacher.monthlySalary || 0;
                const paidInMonth = teacherSalaryRecords
                    .filter(rec => rec.teacherId === teacher.id && rec.year === selectedYear && rec.month === selectedMonthName)
                    .reduce((sum, rec) => sum + rec.amount, 0);
                const due = designated - paidInMonth;
                return { ...teacher, designated, paidInMonth, due };
            });
            const totalDesignated = monthlyData.reduce((sum, t) => sum + t.designated, 0);
            const totalPaid = monthlyData.reduce((sum, t) => sum + t.paidInMonth, 0);
            const totalDue = monthlyData.reduce((sum, t) => sum + t.due, 0);
            return { type: 'monthly', data: monthlyData, totalDesignated, totalPaid, totalDue };
        }
    }, [teachers, teacherSalaryRecords, selectedYear, selectedMonthIndex]);

    const handlePrint = () => {
        const printContent = document.getElementById('printable-area');
        if (!printContent) return;
        const reportTitle = `শিক্ষক বেতন রিপোর্ট - ${selectedMonthIndex === -1 ? 'সকল মাস' : months[selectedMonthIndex]}, ${toBengaliNumber(selectedYear)}`;
        const printWindow = window.open('', '', 'height=800,width=1200');
        if (printWindow) {
            printWindow.document.write('<html><head>');
            printWindow.document.write(`<title>${reportTitle}</title>`);
            printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
            printWindow.document.write(`
                <style>
                    body { font-family: "SolaimanLipi", sans-serif; } 
                    @page { size: A4; margin: 0.75in; } 
                    .no-print { display: none; } 
                    table { width: 100%; border-collapse: collapse; } 
                    th, td { border: 1px solid #ddd; padding: 6px; font-size: 12px; } 
                    th { background-color: #f2f2f2; } 
                    .header { text-align: center; margin-bottom: 1rem; }
                    .header img { height: 50px; width: 50px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.5rem; }
                    tfoot { font-weight: bold; background-color: #f9f9f9; }
                </style>
            `);
            printWindow.document.write('</head><body>');
            const addressString = `${address.village}, ${address.upazila}, ${address.district}`;
            printWindow.document.write(`
                <div class="header">
                    ${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}
                    <h1 style="font-size: 1.5rem; font-weight: bold; margin: 0;">${institutionName}</h1>
                    <p style="margin: 0.25rem 0; font-size: 0.9rem;">${addressString}</p>
                    <h2 style="font-size: 1.2rem; margin: 0;">${reportTitle}</h2>
                </div>
            `);
            printWindow.document.write(printContent.innerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => { printWindow.print(); printWindow.close(); }, 500);
        }
    };

    return (
        <div>
            <PageHeader icon="📄" title="বেতন রিপোর্ট">
                 <button onClick={handlePrint} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700">রিপোর্ট প্রিন্ট করুন</button>
            </PageHeader>
             <div className="bg-white p-4 rounded-xl shadow-md mb-4 flex items-center gap-4">
                <div><label className="text-sm font-medium">বছর:</label><select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">{years.map(y=><option key={y} value={y}>{y}</option>)}</select></div>
                <div><label className="text-sm font-medium">মাস:</label>
                    <select value={selectedMonthIndex} onChange={e => setSelectedMonthIndex(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">
                        <option value={-1}>সকল মাস</option>
                        {months.map((m, index) => <option key={index} value={index}>{m}</option>)}
                    </select>
                </div>
            </div>
            
            <div id="printable-area" className="bg-white p-4 rounded-xl shadow-md">
                 <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                            {reportData.type === 'monthly' ? (
                                <tr><th className="p-2 text-left">শিক্ষকের নাম</th><th className="p-2 text-right">নির্ধারিত বেতন</th><th className="p-2 text-right">প্রদত্ত</th><th className="p-2 text-right">বকেয়া</th></tr>
                            ) : (
                                <tr><th className="p-2 text-left">শিক্ষকের নাম</th><th className="p-2 text-right">এই বছরে মোট প্রদত্ত</th></tr>
                            )}
                        </thead>
                        <tbody>
                            {reportData.data.map((teacher: any) => (
                                <tr key={teacher.id} className="border-b">
                                    <td className="p-2 font-medium">{teacher.nameBn}</td>
                                    {reportData.type === 'monthly' ? (
                                        <>
                                            <td className="p-2 text-right">{formatCurrency(teacher.designated)}</td>
                                            <td className="p-2 text-right text-green-600">{formatCurrency(teacher.paidInMonth)}</td>
                                            <td className="p-2 text-right font-bold text-red-600">{formatCurrency(teacher.due)}</td>
                                        </>
                                    ) : (
                                        <td className="p-2 text-right font-semibold text-green-700">{formatCurrency(teacher.totalPaid)}</td>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                        <tfoot className="bg-gray-100 font-bold">
                            {reportData.type === 'monthly' ? (
                                <tr>
                                    <td className="p-2 text-right">মোট</td>
                                    <td className="p-2 text-right">{formatCurrency(reportData.totalDesignated || 0)}</td>
                                    <td className="p-2 text-right">{formatCurrency(reportData.totalPaid || 0)}</td>
                                    <td className="p-2 text-right">{formatCurrency(reportData.totalDue || 0)}</td>
                                </tr>
                            ) : (
                                <tr>
                                    <td className="p-2 text-right">মোট</td>
                                    <td className="p-2 text-right">{formatCurrency(reportData.grandTotalPaid || 0)}</td>
                                </tr>
                            )}
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default SalaryReport;
