import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
    };
    return num.replace(/[0-9]/g, (match) => map[match]);
};

const AttendanceStatusBadge: React.FC<{ status: 'present' | 'absent' | 'leave' | undefined }> = ({ status }) => {
    switch (status) {
        case 'present':
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-green-100 text-green-700 font-bold text-xs" title="উপস্থিত">উ</span>;
        case 'absent':
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-red-100 text-red-700 font-bold text-xs" title="অনুপস্থিত">অ</span>;
        case 'leave':
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-yellow-100 text-yellow-700 font-bold text-xs" title="ছুটি">ছু</span>;
        default:
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-gray-100 text-gray-400 font-bold text-xs">-</span>;
    }
};

const AttendanceReport: React.FC = () => {
    const { students, attendanceRecords, classLevels, sections, academicSessions, institutionName, logoUrl } = useInstitution();
    const { addToast } = useNotification();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [monthFilter, setMonthFilter] = useState(currentMonth);

    // Derived data from filters
    const availableSections = useMemo(() => {
        if (!classFilter) return [];
        return sections.filter(s => s.classLevel === classFilter).map(s => s.name);
    }, [classFilter, sections]);

    // Reset section if class changes
    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) {
            setSectionFilter('');
        }
    }, [availableSections, sectionFilter]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        return students
            .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            .sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter]);

    const { days, year, month } = useMemo(() => {
        if (!monthFilter) return { days: [], year: 0, month: 0 };
        const [y, m] = monthFilter.split('-').map(Number);
        const date = new Date(y, m - 1, 1);
        const daysInMonth = new Date(y, m, 0).getDate();
        return {
            days: Array.from({ length: daysInMonth }, (_, i) => i + 1),
            year: y,
            month: m - 1, // 0-indexed for Date object
        };
    }, [monthFilter]);

    const attendanceMap = useMemo(() => {
        const map = new Map<string, Map<string, 'present' | 'absent' | 'leave'>>();
        filteredStudents.forEach(student => {
            const studentAttendance = new Map<string, 'present' | 'absent' | 'leave'>();
            attendanceRecords
                .filter(rec => rec.studentId === student.id && rec.date.startsWith(monthFilter))
                .forEach(rec => {
                    studentAttendance.set(rec.date, rec.status);
                });
            map.set(student.id, studentAttendance);
        });
        return map;
    }, [filteredStudents, attendanceRecords, monthFilter]);

    const studentStats = useMemo(() => {
        const stats = new Map<string, { present: number; absent: number; leave: number }>();
        filteredStudents.forEach(student => {
            const studentAttendance = attendanceMap.get(student.id) || new Map();
            const counts = { present: 0, absent: 0, leave: 0 };
            studentAttendance.forEach(status => {
                counts[status]++;
            });
            stats.set(student.id, counts);
        });
        return stats;
    }, [filteredStudents, attendanceMap]);

    const getDayName = (day: number) => {
        const date = new Date(year, month, day);
        return date.toLocaleDateString('bn-BD', { weekday: 'short' });
    };
    
    const isWeekend = (day: number) => {
        const date = new Date(year, month, day);
        const dayOfWeek = date.getDay();
        return dayOfWeek === 5; // Friday
    };
    
    const overallStats = useMemo(() => {
        let totalPresent = 0, totalAbsent = 0, totalLeave = 0;
        studentStats.forEach(stat => {
            totalPresent += stat.present;
            totalAbsent += stat.absent;
            totalLeave += stat.leave;
        });
        return { totalPresent, totalAbsent, totalLeave, totalStudents: filteredStudents.length };
    }, [studentStats, filteredStudents]);
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-report');
        const monthName = new Date(monthFilter).toLocaleString('bn-BD', { month: 'long', year: 'numeric' });
        const reportTitle = `মাসিক হাজিরা রিপোর্ট - ${classFilter} (${sectionFilter}) - ${monthName}`;

        if (!printContent) return;

        const printWindow = window.open('', '_blank', 'height=800,width=1200');
        if (!printWindow) {
            addToast('প্রিন্টিং ব্যর্থ হয়েছে। অনুগ্রহ করে এই সাইটের জন্য পপ-আপ অনুমতি দিন।', 'error');
            return;
        }

        printWindow.document.write('<html><head>');
        printWindow.document.write(`<title>${reportTitle}</title>`);
        printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
        printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
        printWindow.document.write(`
            <style>
                body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                @page { size: A4 landscape; margin: 0.5in; }
                .overflow-x-auto { overflow-x: visible !important; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 2px; text-align: center; font-size: 9px; white-space: nowrap; }
                th { background-color: #f2f2f2 !important; font-weight: bold; }
                th div:last-child { font-weight: normal; font-size: 8px; }
                .student-name { text-align: left !important; white-space: normal; min-width: 120px; width: 15%; }
                
                .print-summary-line { display: flex; justify-content: space-around; padding: 6px; border: 1px solid #ddd; background-color: #f9f9f9 !important; margin-bottom: 1rem; font-size: 11px; border-radius: 6px; }
                .print-summary-line strong { font-weight: 600; }

                .header-info { display: flex; flex-direction: column; align-items: center; gap: 0.5rem; margin-bottom: 1rem; text-align: center; }
                .header-info img { width: 4rem; height: 4rem; border-radius: 9999px; }
                .header-info h1 { font-size: 1.5rem; font-weight: bold; }
                .header-info h2 { font-size: 1.25rem; }
                .header-info p { font-size: 0.875rem; }
            </style>
        `);
        printWindow.document.write('</head><body>');
        printWindow.document.write(`
            <div class="header-info">
                ${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}
                <h1>${institutionName}</h1>
                <h2>মাসিক হাজিরা রিপোর্ট</h2>
                <p>শ্রেণি: ${classFilter} | সেকশন: ${sectionFilter} | মাস: ${monthName}</p>
            </div>
        `);
        printWindow.document.write(printContent.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        
        setTimeout(() => {
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }, 750);
    };

    return (
        <div>
            <PageHeader icon="🗓️" title="মাসিক / সাপ্তাহিক রিপোর্ট" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span>
                        <input type="month" value={monthFilter} onChange={e => setMonthFilter(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white" />
                    </div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setMonthFilter(currentMonth); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            {(classFilter && sectionFilter) ? (
                <div className="bg-white p-4 sm:p-6 rounded-xl shadow-md">
                     <div className="text-center">
                        <h3 className="text-lg font-bold text-teal-700">রিপোর্ট তৈরী হয়েছে</h3>
                        <p className="text-gray-600 my-4">মাসিক হাজিরা রিপোর্ট প্রিন্ট করার জন্য প্রস্তুত।</p>
                        <button onClick={handlePrint} className="px-6 py-3 bg-teal-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-teal-700 transition-colors">
                            প্রিন্ট করুন
                        </button>
                    </div>

                    <div id="printable-report" className="hidden">
                        <div className="print-summary-line">
                            <span><strong>মোট শিক্ষার্থী:</strong> {toBengaliNumber(overallStats.totalStudents)}</span>
                            <span><strong>মোট উপস্থিতি:</strong> {toBengaliNumber(overallStats.totalPresent)}</span>
                            <span><strong>মোট অনুপস্থিতি:</strong> {toBengaliNumber(overallStats.totalAbsent)}</span>
                            <span><strong>মোট ছুটি:</strong> {toBengaliNumber(overallStats.totalLeave)}</span>
                        </div>
                        {filteredStudents.length > 0 ? (
                        <div className="overflow-x-auto">
                            <table className="w-full border-collapse text-xs text-center">
                                <thead>
                                    <tr className="bg-gray-50">
                                        <th className="sticky left-0 bg-gray-50 p-2 border min-w-[150px] text-left student-name">শিক্ষার্থীর নাম</th>
                                        {days.map(day => (
                                            <th key={day} className={`p-1 border ${isWeekend(day) ? 'bg-gray-200' : ''}`}>
                                                <div>{toBengaliNumber(day)}</div>
                                                <div className="font-normal text-gray-500">{getDayName(day)}</div>
                                            </th>
                                        ))}
                                        <th className="p-2 border bg-green-50">উপস্থিত</th>
                                        <th className="p-2 border bg-red-50">অনুপস্থিত</th>
                                        <th className="p-2 border bg-yellow-50">ছুটি</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredStudents.map(student => {
                                        const records = attendanceMap.get(student.id);
                                        const stats = studentStats.get(student.id);
                                        return (
                                            <tr key={student.id} className="border-b hover:bg-gray-50">
                                                <td className="sticky left-0 bg-white hover:bg-gray-50 p-2 border text-left font-medium text-gray-800 student-name">
                                                    {student.nameBn} <span className="text-gray-500">({toBengaliNumber(student.roll || '')})</span>
                                                </td>
                                                {days.map(day => {
                                                    const date = `${monthFilter}-${String(day).padStart(2, '0')}`;
                                                    const status = records?.get(date);
                                                    return <td key={day} className={`border ${isWeekend(day) ? 'bg-gray-100' : ''}`}><AttendanceStatusBadge status={status} /></td>
                                                })}
                                                <td className="p-2 border font-bold text-green-700">{toBengaliNumber(stats?.present || 0)}</td>
                                                <td className="p-2 border font-bold text-red-700">{toBengaliNumber(stats?.absent || 0)}</td>
                                                <td className="p-2 border font-bold text-yellow-700">{toBengaliNumber(stats?.leave || 0)}</td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                        ) : (
                            <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                        )}
                    </div>
                </div>
            ) : (
                <div className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">
                    <p>হাজিরা রিপোর্ট দেখতে অনুগ্রহ করে একটি শ্রেণি ও সেকশন নির্বাচন করুন।</p>
                </div>
            )}
        </div>
    );
};

export default AttendanceReport;
