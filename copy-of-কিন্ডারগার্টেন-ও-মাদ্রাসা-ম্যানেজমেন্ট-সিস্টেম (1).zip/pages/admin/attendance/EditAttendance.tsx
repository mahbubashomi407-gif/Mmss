import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { SearchIcon } from '../../../components/icons';

type AttendanceStatus = 'present' | 'absent' | 'leave';

const EditAttendance: React.FC = () => {
    const { students, attendanceRecords, setAttendanceRecords, classLevels, sections } = useInstitution();
    const { addToast } = useNotification();
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (yesterday.getDay() === 5) { // if yesterday was Friday
        yesterday.setDate(yesterday.getDate() - 1);
    }
    const [selectedDate, setSelectedDate] = useState(yesterday.toISOString().split('T')[0]);
    
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');

    const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>({});
    const [initialAttendance, setInitialAttendance] = useState<Record<string, AttendanceStatus>>({});
    
    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 10;

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    
    const filteredStudents = useMemo(() => {
        let studentsToShow = (classFilter && sectionFilter) 
            ? students.filter(s => s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            : [];
            
        if (searchTerm.trim()) {
            const lowerSearchTerm = searchTerm.toLowerCase();
            studentsToShow = studentsToShow.filter(s => 
                s.nameBn.toLowerCase().includes(lowerSearchTerm) ||
                (s.roll && s.roll.toString().includes(lowerSearchTerm))
            );
        }
        
        return studentsToShow.sort((a,b) => (a.roll || 999) - (b.roll || 999));
    }, [students, classFilter, sectionFilter, searchTerm]);

    useEffect(() => {
        const recordsForDate = attendanceRecords.filter(rec => rec.date === selectedDate);
        const newAttendanceState: Record<string, AttendanceStatus> = {};

        filteredStudents.forEach(student => {
            const record = recordsForDate.find(rec => rec.studentId === student.id);
            newAttendanceState[student.id] = record ? record.status : 'present';
        });

        setAttendance(newAttendanceState);
        setInitialAttendance(newAttendanceState);
    }, [selectedDate, filteredStudents, attendanceRecords]);
    
    useEffect(() => {
        setCurrentPage(1); // Reset page on filter/search change
    }, [classFilter, sectionFilter, searchTerm]);

    const paginatedStudents = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        return filteredStudents.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [filteredStudents, currentPage]);
    const totalPages = Math.ceil(filteredStudents.length / ITEMS_PER_PAGE);

    const hasUnsavedChanges = useMemo(() => JSON.stringify(attendance) !== JSON.stringify(initialAttendance), [attendance, initialAttendance]);

    const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
        setAttendance(prev => ({ ...prev, [studentId]: status }));
    };

    const handleSubmit = () => {
        // We only update records for the students currently in the filter
        const studentIdsInView = new Set(filteredStudents.map(s => s.id));
        const otherRecords = attendanceRecords.filter(rec => !(rec.date === selectedDate && studentIdsInView.has(rec.studentId)));

        const newRecordsForDate = Object.entries(attendance)
            .filter(([studentId, _]) => studentIdsInView.has(studentId))
            .map(([studentId, status]) => ({
                id: `${studentId}-${selectedDate}`, studentId, date: selectedDate, status,
            }));

        setAttendanceRecords([...otherRecords, ...newRecordsForDate]);
        setInitialAttendance(attendance);
        addToast('হাজিরা সফলভাবে সংশোধন করা হয়েছে!', 'success');
    };
    
    const StatusRadioButton: React.FC<{ studentId: string; status: AttendanceStatus; label: string; color: string; }> = ({ studentId, status, label, color }) => (
        <label className="flex items-center cursor-pointer">
            <input type="radio" name={`attendance-${studentId}`} checked={attendance[studentId] === status} onChange={() => handleStatusChange(studentId, status)} className={`form-radio h-4 w-4 ${color}`} />
            <span className={`ml-2 text-sm`}>{label}</span>
        </label>
    );

    return (
        <div>
            <PageHeader icon="🔄" title="হাজিরা এডিট / সংশোধন">
                {hasUnsavedChanges && <button onClick={handleSubmit} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700">সংশোধন সংরক্ষণ করুন</button>}
            </PageHeader>
            <div className="bg-white p-4 rounded-xl shadow-md mb-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 items-center">
                    <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="p-2 border rounded-md" />
                    <select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="p-2 border rounded-md bg-white"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select>
                    <select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="p-2 border rounded-md bg-white" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select>
                    <div className="relative">
                        <input 
                            type="text" 
                            placeholder="নাম বা রোল দিয়ে খুঁজুন..." 
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full p-2 border rounded-md pl-8 disabled:bg-gray-100"
                            disabled={!classFilter || !sectionFilter}
                        />
                        <SearchIcon className="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    </div>
                </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                {classFilter && sectionFilter ? (
                    filteredStudents.length > 0 ? (
                        <>
                            <div className="space-y-3">
                                {paginatedStudents.map(student => (
                                    <div key={student.id} className="flex flex-col sm:flex-row items-center justify-between p-3 bg-gray-50 rounded-lg">
                                        <div className="flex items-center gap-3 mb-3 sm:mb-0">
                                            <img src={student.photoUrl || 'https://via.placeholder.com/40x40?text=S'} alt={student.nameBn} className="w-10 h-10 rounded-full object-cover"/>
                                            <div>
                                                <p className="font-semibold text-gray-800">{student.nameBn}</p>
                                                <p className="text-xs text-gray-500">রোল: {student.roll}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-4">
                                            <StatusRadioButton studentId={student.id} status="present" label="উপস্থিত" color="text-green-600" />
                                            <StatusRadioButton studentId={student.id} status="absent" label="অনুপস্থিত" color="text-red-600" />
                                            <StatusRadioButton studentId={student.id} status="leave" label="ছুটিতে" color="text-yellow-600" />
                                        </div>
                                    </div>
                                ))}
                            </div>
                            <div className="flex justify-between items-center mt-4 text-sm text-gray-600">
                                <p>মোট {filteredStudents.length} জন শিক্ষার্থীর মধ্যে {paginatedStudents.length} জন দেখানো হচ্ছে।</p>
                                {totalPages > 1 && (
                                    <div className="flex items-center gap-2">
                                        <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-3 py-1 border rounded-md disabled:opacity-50">পূর্ববর্তী</button>
                                        <span>পাতা {currentPage} / {totalPages}</span>
                                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages} className="px-3 py-1 border rounded-md disabled:opacity-50">পরবর্তী</button>
                                    </div>
                                )}
                            </div>
                        </>
                    ) : ( <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p> )
                ) : ( <p className="text-center text-gray-500 py-10">হাজিরা সংশোধন করতে অনুগ্রহ করে একটি শ্রেণি ও সেকশন নির্বাচন করুন।</p> )}
            </div>
        </div>
    );
};
export default EditAttendance;