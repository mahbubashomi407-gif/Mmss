
import React, { useState, useEffect, useMemo, useRef } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, GateLogData, GuardianNotificationData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { CheckCircleIcon, ArrowRightOnRectangleIcon } from '../../../components/icons';

declare var Html5QrcodeScanner: any;

const playSound = (type: 'arrival' | 'departure' | 'warning') => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (!audioContext) return;
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    if(type === 'arrival') {
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
    } else if (type === 'departure') {
        oscillator.type = 'triangle';
        oscillator.frequency.setValueAtTime(660, audioContext.currentTime);
    } else { // warning
         oscillator.type = 'square';
         oscillator.frequency.setValueAtTime(440, audioContext.currentTime);
    }
    
    gainNode.gain.setValueAtTime(0.5, audioContext.currentTime);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.15);
};

const ArrivalDeparture: React.FC = () => {
    const { students, gateLogs, setGateLogs, notificationSettings, setGuardianNotifications, appNotificationTemplates } = useInstitution();
    const { addToast } = useNotification();
    
    const [scanMode, setScanMode] = useState<'idle' | 'arrival' | 'departure'>('idle');
    const [lastScan, setLastScan] = useState<{ student: StudentData; status: 'আগমন' | 'প্রস্থান'; time: string; message: string; type: 'success' | 'warning' } | null>(null);
    const [logFilter, setLogFilter] = useState<'all' | 'present' | 'departed'>('all');

    const scannerRef = useRef<any>(null);
    const readerId = "qr-reader-gate";
    const today = new Date().toISOString().split('T')[0];

    const todaysLogs = useMemo(() => gateLogs.filter(log => log.date === today), [gateLogs, today]);
    
    const studentsMap = useMemo(() => {
        const map = new Map<string, StudentData>();
        students.forEach(s => map.set(s.id, s));
        return map;
    }, [students]);

    useEffect(() => {
        if (scanMode !== 'idle') {
            // Configure Html5QrcodeScanner to prefer the rear camera
            const scanner = new Html5QrcodeScanner(
                readerId,
                {
                    fps: 10, // Frames per second
                    qrbox: { width: 250, height: 250 }, // Size of QR box in px
                    supportedScanTypes: [0], // QR_CODE
                    // Use videoConstraints to default to the rear camera ('environment')
                    videoConstraints: {
                        facingMode: 'environment'
                    }
                },
                false // verbose
            );
            scannerRef.current = scanner;

            const onScanSuccess = (decodedText: string) => {
                const student = students.find(s => s.uniqueId === decodedText);
                const time = new Date();
                const timeString = time.toLocaleTimeString('en-GB'); // HH:MM:SS format
                const displayTime = time.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });

                if (!student) {
                    addToast(`ID "${decodedText}" সহ কোনো শিক্ষার্থী পাওয়া যায়নি!`, 'error');
                    playSound('warning');
                    return;
                }
                
                if (student.status === 'পেন্ডিং') {
                    addToast(`শিক্ষার্থী "${student.nameBn}" এর আবেদনটি এখনও পেন্ডিং আছে।`, 'error');
                    return;
                }

                const existingLog = gateLogs.find(log => log.studentId === student.id && log.date === today);

                if (scanMode === 'arrival') {
                    if (existingLog && existingLog.status === 'উপস্থিত' && existingLog.arrivalTime) {
                        setLastScan({ student, status: 'আগমন', time: existingLog.arrivalTime || '', message: 'ইতিমধ্যে আগমন রেকর্ড করা হয়েছে।', type: 'warning' });
                        addToast(`${student.nameBn}-এর আগমন ইতিমধ্যে রেকর্ড করা হয়েছে।`, 'error');
                        playSound('warning');
                    } else {
                        const newLog: GateLogData = { id: `${student.id}-${today}`, studentId: student.id, date: today, status: 'উপস্থিত', arrivalTime: timeString };
                        setGateLogs(prev => [...prev.filter(l => l.id !== newLog.id), newLog]); // Update or add
                        setLastScan({ student, status: 'আগমন', time: timeString, message: 'আগমন রেকর্ড করা হয়েছে।', type: 'success' });
                        addToast(`${student.nameBn}-এর আগমন রেকর্ড করা হয়েছে।`, 'success');
                        playSound('arrival');

                        if(notificationSettings.automaticNotifications.studentArrival.app) {
                            let message = appNotificationTemplates.studentArrival;
                            message = message.replace('{{student_name}}', student.nameBn).replace('{{time}}', displayTime);
                            const notification: GuardianNotificationData = {
                                id: `noti-arr-${Date.now()}`, studentId: student.id, timestamp: time.toISOString(),
                                title: 'শিক্ষার্থী আগমন', message: message, isRead: false
                            };
                            setGuardianNotifications(prev => [notification, ...prev]);
                        }
                    }
                } else if (scanMode === 'departure') {
                    if (!existingLog || !existingLog.arrivalTime) {
                        addToast(`${student.nameBn}-এর কোনো আগমন রেকর্ড পাওয়া যায়নি।`, 'error');
                        setLastScan(null);
                        playSound('warning');
                    } else if (existingLog.departureTime) {
                        setLastScan({ student, status: 'প্রস্থান', time: existingLog.departureTime, message: 'ইতিমধ্যে প্রস্থান রেকর্ড করা হয়েছে।', type: 'warning' });
                        addToast(`${student.nameBn} ইতিমধ্যে প্রস্থান করেছে।`, 'error');
                        playSound('warning');
                    } else {
                        const updatedLogs = gateLogs.map(log => log.id === existingLog.id ? { ...log, departureTime: timeString } : log);
                        setGateLogs(updatedLogs);
                        setLastScan({ student, status: 'প্রস্থান', time: timeString, message: 'প্রস্থান রেকর্ড করা হয়েছে।', type: 'success' });
                        addToast(`${student.nameBn}-এর প্রস্থান রেকর্ড করা হয়েছে।`, 'success');
                        playSound('departure');
                        
                        if(notificationSettings.automaticNotifications.studentDeparture.app) {
                            let message = appNotificationTemplates.studentDeparture;
                            message = message.replace('{{student_name}}', student.nameBn).replace('{{time}}', displayTime);
                            const notification: GuardianNotificationData = {
                                id: `noti-dep-${Date.now()}`, studentId: student.id, timestamp: time.toISOString(),
                                title: 'শিক্ষার্থী প্রস্থান', message: message, isRead: false
                            };
                            setGuardianNotifications(prev => [notification, ...prev]);
                        }
                    }
                }
            };
            
            scanner.render(onScanSuccess, (error: any) => {});
        } else {
            if (scannerRef.current) {
                scannerRef.current.clear().catch((err: any) => {});
                scannerRef.current = null;
            }
        }

        return () => { if (scannerRef.current) scannerRef.current.clear().catch((err: any) => {}); };
    }, [scanMode, students, gateLogs, setGateLogs, addToast, today, notificationSettings, setGuardianNotifications, appNotificationTemplates]);

    const isArrivalAppNotificationEnabled = notificationSettings.automaticNotifications.studentArrival.app;
    const isDepartureAppNotificationEnabled = notificationSettings.automaticNotifications.studentDeparture.app;

    const startScanning = (mode: 'arrival' | 'departure') => {
        if (mode === 'arrival' && !isArrivalAppNotificationEnabled) {
            addToast('শিক্ষার্থী আগমনের জন্য স্বয়ংক্রিয় অ্যাপ নোটিফিকেশন সেটিংস থেকে সক্রিয় করা নেই।', 'warning');
        }
        if (mode === 'departure' && !isDepartureAppNotificationEnabled) {
            addToast('শিক্ষার্থী প্রস্থানের জন্য স্বয়ংক্রিয় অ্যাপ নোটিফিকেশন সেটিংস থেকে সক্রিয় করা নেই।', 'warning');
        }
        setScanMode(mode);
        setLastScan(null);
    };

    const stopScanning = () => setScanMode('idle');
    
    const filteredLogs = useMemo(() => {
        const logsWithStudentData = todaysLogs
            .map(log => ({...log, student: studentsMap.get(log.studentId)}))
            .filter(log => log.student && log.student.status !== 'পেন্ডিং');
            
        if (logFilter === 'present') return logsWithStudentData.filter(log => log.status === 'উপস্থিত' && !log.departureTime);
        if (logFilter === 'departed') return logsWithStudentData.filter(log => log.status === 'উপস্থিত' && log.departureTime);
        
        return logsWithStudentData.sort((a,b) => (b.arrivalTime || '').localeCompare(a.arrivalTime || ''));
    }, [todaysLogs, logFilter, studentsMap]);
    
    const summary = useMemo(() => {
        const presentLogs = todaysLogs.filter(log => {
            const student = studentsMap.get(log.studentId);
            return student && student.status !== 'পেন্ডিং' && log.status === 'উপস্থিত' && !log.departureTime;
        });
        const departedLogs = todaysLogs.filter(log => {
            const student = studentsMap.get(log.studentId);
            return student && student.status !== 'পেন্ডING' && log.status === 'উপস্থিত' && log.departureTime;
        });
        return {
            present: presentLogs.length,
            departed: departedLogs.length
        };
    }, [todaysLogs, studentsMap]);

    return (
        <div>
            <PageHeader icon="🔳" title="QR কোড আগমন/প্রস্থান" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column: Scanner */}
                <div className="bg-white p-6 rounded-xl shadow-md">
                    {scanMode === 'idle' ? (
                        <div className="flex flex-col sm:flex-row gap-4">
                            <button onClick={() => startScanning('arrival')} className="w-full px-6 py-3 font-semibold rounded-lg shadow-md text-white bg-green-600 hover:bg-green-700 text-lg">আগমন স্ক্যান শুরু করুন</button>
                            <button onClick={() => startScanning('departure')} className="w-full px-6 py-3 font-semibold rounded-lg shadow-md text-white bg-yellow-600 hover:bg-yellow-700 text-lg">প্রস্থান স্ক্যান শুরু করুন</button>
                        </div>
                    ) : (
                        <button onClick={stopScanning} className="w-full mb-4 px-6 py-2 font-semibold rounded-lg shadow-md text-white bg-red-500 hover:bg-red-600">স্ক্যান বন্ধ করুন</button>
                    )}
                    
                    {scanMode !== 'idle' ? (
                        <div className="space-y-4 mt-4">
                            <h3 className="text-center font-bold text-xl">{scanMode === 'arrival' ? 'আগমনের জন্য স্ক্যান করুন' : 'প্রস্থানের জন্য স্ক্যান করুন'}</h3>
                            <div id={readerId} className="w-full border-2 border-dashed rounded-lg bg-gray-100 min-h-[300px]"></div>
                        </div>
                    ) : (
                        <div className="text-center py-20 text-gray-500 bg-gray-50 rounded-lg mt-4">
                            <p>শিক্ষার্থীদের আইডি কার্ডে থাকা QR কোড স্ক্যান করে হাজিরা নিতে "স্ক্যান শুরু করুন" বাটনে ক্লিক করুন।</p>
                            <p className="text-xs mt-2">সিস্টেমটি স্বয়ংক্রিয়ভাবে শিক্ষার্থীর শ্রেণি সনাক্ত করে হাজিরা নিয়ে নিবে।</p>
                        </div>
                    )}
                </div>
                
                {/* Right Column: Information Panel */}
                <div className="bg-white p-6 rounded-xl shadow-md space-y-6">
                    <div>
                        <h3 className="text-lg font-bold text-gray-800 mb-2 border-b pb-2">সর্বশেষ স্ক্যান</h3>
                        {lastScan ? (
                            <div className={`p-4 rounded-lg flex flex-col items-center gap-4 border ${lastScan.type === 'success' ? (lastScan.status === 'আগমন' ? 'bg-green-50 border-green-200' : 'bg-yellow-50 border-yellow-200') : 'bg-orange-50 border-orange-200'}`}>
                                <img src={lastScan.student.photoUrl || 'https://via.placeholder.com/96x96?text=S'} alt={lastScan.student.nameBn} className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg" />
                                <div className="text-center">
                                    <p className="font-bold text-xl text-gray-800">{lastScan.student.nameBn}</p>
                                    <p className="text-sm text-gray-600">আইডি: <span className="font-mono">{lastScan.student.uniqueId}</span></p>
                                    <p className="text-xs text-gray-500">শ্রেণি: {lastScan.student.classLevel} | রোল: {lastScan.student.roll}</p>
                                    <p className={`mt-2 font-semibold text-lg flex items-center justify-center gap-2 ${lastScan.type==='success' ? (lastScan.status === 'আগমন' ? 'text-green-700' : 'text-yellow-700') : 'text-orange-700'}`}>
                                        {lastScan.status === 'আগমন' ? <CheckCircleIcon className="w-6 h-6" /> : <ArrowRightOnRectangleIcon className="w-6 h-6"/>}
                                        <span>{lastScan.message} ({new Date(`1970-01-01T${lastScan.time}Z`).toLocaleTimeString('bn-BD', {timeZone: 'UTC', hour: '2-digit', minute:'2-digit'})})</span>
                                    </p>
                                </div>
                            </div>
                        ) : (
                            <div className="text-center py-16 text-gray-400 bg-gray-50 rounded-lg">
                                <p>স্ক্যান শুরু করুন...</p>
                            </div>
                        )}
                    </div>

                    <div className="border-t pt-4">
                        <h3 className="text-lg font-bold text-gray-800 mb-2">আজকের লগ ({new Date().toLocaleDateString('bn-BD')})</h3>
                        <div className="flex items-center gap-2 mb-4">
                            <button onClick={() => setLogFilter('all')} className={`text-xs px-3 py-1 rounded-full ${logFilter==='all' ? 'bg-teal-600 text-white' : 'bg-gray-200'}`}>সব ({todaysLogs.filter(log => studentsMap.get(log.studentId)?.status !== 'পেন্ডিং').length})</button>
                            <button onClick={() => setLogFilter('present')} className={`text-xs px-3 py-1 rounded-full ${logFilter==='present' ? 'bg-green-600 text-white' : 'bg-gray-200'}`}>উপস্থিত ({summary.present})</button>
                            <button onClick={() => setLogFilter('departed')} className={`text-xs px-3 py-1 rounded-full ${logFilter==='departed' ? 'bg-yellow-600 text-white' : 'bg-gray-200'}`}>প্রস্থান ({summary.departed})</button>
                        </div>
                        <div className="space-y-3 max-h-[25vh] overflow-y-auto pr-2">
                            {filteredLogs.map(log => (
                                <div key={log.id} className="p-2 bg-gray-50 rounded-md">
                                    <div className="flex items-center gap-2">
                                        <img src={log.student!.photoUrl || 'https://via.placeholder.com/24x24?text=S'} alt="" className="w-6 h-6 rounded-full object-cover"/>
                                        <p className="text-sm font-medium flex-grow">{log.student!.nameBn}</p>
                                    </div>
                                    <div className="text-xs text-gray-600 mt-1 flex justify-between">
                                        <span><strong>আগমন:</strong> {log.arrivalTime ? new Date(`1970-01-01T${log.arrivalTime}Z`).toLocaleTimeString('bn-BD', {timeZone: 'UTC', hour:'2-digit', minute:'2-digit'}) : '---'}</span>
                                        <span><strong>প্রস্থান:</strong> {log.departureTime ? new Date(`1970-01-01T${log.departureTime}Z`).toLocaleTimeString('bn-BD', {timeZone: 'UTC', hour:'2-digit', minute:'2-digit'}) : '---'}</span>
                                    </div>
                                </div>
                            ))}
                            {filteredLogs.length === 0 && <p className="text-center text-sm text-gray-500 py-10">কোনো রেকর্ড নেই।</p>}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ArrivalDeparture;
