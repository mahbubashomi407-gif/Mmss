
import React, { useState, useEffect, useMemo, useRef } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, GateLogData, GuardianNotificationData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { SearchIcon } from '../../../components/icons';

const getCurrentTime = () => {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    return `${hours}:${minutes}`;
};

const DailyAttendance: React.FC = () => {
    const { students, gateLogs, setGateLogs, classLevels, sections, notificationSettings, setGuardianNotifications, appNotificationTemplates } = useInstitution();
    const { addToast } = useNotification();
    
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    
    const [attendanceData, setAttendanceData] = useState<Record<string, Partial<GateLogData>>>({});
    const [initialAttendanceData, setInitialAttendanceData] = useState<Record<string, Partial<GateLogData>>>({});

    const [currentPage, setCurrentPage] = useState(1);
    const ITEMS_PER_PAGE = 5;

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    
    const filteredStudents = useMemo(() => {
        let studentsToShow = (classFilter && sectionFilter) 
            ? students.filter(s => s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            : [];
            
        if (searchTerm.trim()) {
            const lowerSearchTerm = searchTerm.toLowerCase();
            studentsToShow = studentsToShow.filter(s => 
                s.nameBn.toLowerCase().includes(lowerSearchTerm) ||
                (s.roll && s.roll.toString().includes(lowerSearchTerm))
            );
        }
        
        return studentsToShow.sort((a,b) => (a.roll || 999) - (b.roll || 999));
    }, [students, classFilter, sectionFilter, searchTerm]);

    useEffect(() => {
        const recordsForDate = gateLogs.filter(rec => rec.date === selectedDate);
        const newAttendanceState: Record<string, Partial<GateLogData>> = {};

        filteredStudents.forEach(student => {
            const record = recordsForDate.find(rec => rec.studentId === student.id);
            newAttendanceState[student.id] = {
                status: record?.status || 'অনুপস্থিত', // Default to 'অনুপস্থিত' if no record
                arrivalTime: record?.arrivalTime?.substring(0, 5) || '',
                departureTime: record?.departureTime?.substring(0, 5) || '',
            };
        });
        
        setAttendanceData(newAttendanceState);
        setInitialAttendanceData(JSON.parse(JSON.stringify(newAttendanceState)));
    }, [selectedDate, filteredStudents, gateLogs]);

    useEffect(() => {
        setCurrentPage(1); // Reset page on filter/search change
    }, [classFilter, sectionFilter, searchTerm]);

    const paginatedStudents = useMemo(() => {
        const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
        return filteredStudents.slice(startIndex, startIndex + ITEMS_PER_PAGE);
    }, [filteredStudents, currentPage]);

    const totalPages = Math.ceil(filteredStudents.length / ITEMS_PER_PAGE);

    const hasUnsavedChanges = useMemo(() => JSON.stringify(attendanceData) !== JSON.stringify(initialAttendanceData), [attendanceData, initialAttendanceData]);
    
    const handleStatusChange = (studentId: string, status: GateLogData['status']) => {
        setAttendanceData(prev => {
            const studentData = { ...(prev[studentId] || {}), status };
            if (status === 'উপস্থিত' && !studentData.arrivalTime) {
                studentData.arrivalTime = getCurrentTime();
            } else if (status !== 'উপস্থিত') { // If status is not present, clear times
                studentData.arrivalTime = '';
                studentData.departureTime = '';
            }
            return { ...prev, [studentId]: studentData };
        });
    };

    const handleTimeChange = (studentId: string, type: 'arrivalTime' | 'departureTime', value: string) => {
        setAttendanceData(prev => ({ ...prev, [studentId]: { ...prev[studentId], [type]: value } }));
    };
    
    const handleSetTimeNow = (studentId: string, type: 'arrivalTime' | 'departureTime') => {
        const timeString = getCurrentTime();
        handleTimeChange(studentId, type, timeString);
    };

    const handleSubmit = () => {
        const studentIdsInView = new Set(filteredStudents.map(s => s.id));
        const otherRecords = gateLogs.filter(rec => !(rec.date === selectedDate && studentIdsInView.has(rec.studentId)));

        const newRecordsForDate: GateLogData[] = Object.entries(attendanceData)
            .filter(([studentId, _]) => studentIdsInView.has(studentId))
            .map(([studentId, data]: [string, Partial<GateLogData>]) => ({
                id: `${studentId}-${selectedDate}`,
                studentId,
                date: selectedDate,
                status: data.status!,
                arrivalTime: data.status === 'উপস্থিত' && data.arrivalTime ? `${data.arrivalTime}:00` : undefined,
                departureTime: data.status === 'উপস্থিত' && data.departureTime ? `${data.departureTime}:00` : undefined,
            }));
        
        // --- Send Notifications based on changes ---
        const newNotifications: GuardianNotificationData[] = [];
        const now = new Date();

        filteredStudents.forEach(student => {
            const oldData = initialAttendanceData[student.id] || {};
            const newData = attendanceData[student.id] || {};

            // Arrival notification
            if (oldData.status !== 'উপস্থিত' && newData.status === 'উপস্থিত' && notificationSettings.automaticNotifications.studentArrival.app && newData.arrivalTime) {
                let message = appNotificationTemplates.studentArrival;
                message = message.replace('{{student_name}}', student.nameBn)
                               .replace('{{time}}', new Date(`${selectedDate}T${newData.arrivalTime}`).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }));
                newNotifications.push({ id: `noti-arr-${student.id}-${now.getTime()}`, studentId: student.id, timestamp: now.toISOString(), title: 'শিক্ষার্থী আগমন', message, isRead: false });
            }

            // Departure notification (only if arrival was recorded and departure is newly set)
            if (newData.status === 'উপস্থিত' && oldData.departureTime === '' && newData.departureTime !== '' && notificationSettings.automaticNotifications.studentDeparture.app) {
                let message = appNotificationTemplates.studentDeparture;
                message = message.replace('{{student_name}}', student.nameBn)
                               .replace('{{time}}', new Date(`${selectedDate}T${newData.departureTime}`).toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }));
                newNotifications.push({ id: `noti-dep-${student.id}-${now.getTime()}`, studentId: student.id, timestamp: now.toISOString(), title: 'শিক্ষার্থী প্রস্থান', message, isRead: false });
            }

            // Absence notification
            if (oldData.status !== 'অনুপস্থিত' && newData.status === 'অনুপস্থিত' && notificationSettings.automaticNotifications.studentAbsence.app) {
                let message = appNotificationTemplates.studentAbsence;
                message = message.replace('{{student_name}}', student.nameBn)
                               .replace('{{class}}', student.classLevel)
                               .replace('{{date}}', new Date(selectedDate).toLocaleDateString('bn-BD'));
                newNotifications.push({ id: `noti-abs-${student.id}-${now.getTime()}`, studentId: student.id, timestamp: now.toISOString(), title: 'শিক্ষার্থী অনুপস্থিত', message, isRead: false });
            }
        });
        
        if (newNotifications.length > 0) {
            setGuardianNotifications(prev => [...newNotifications, ...prev]);
            addToast(`${newNotifications.length}টি নোটিফিকেশন পাঠানো হয়েছে।`, 'success');
        }

        setGateLogs([...otherRecords, ...newRecordsForDate]);
        setInitialAttendanceData(JSON.parse(JSON.stringify(attendanceData)));
        addToast('হাজিরা সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };

    const StatusRadioButton: React.FC<{ studentId: string; status: GateLogData['status']; label: string; color: string; }> = ({ studentId, status, label, color }) => (
        <label className="flex items-center cursor-pointer"><input type="radio" name={`status-${studentId}`} checked={attendanceData[studentId]?.status === status} onChange={() => handleStatusChange(studentId, status)} className={`form-radio h-4 w-4 ${color}`} /><span className="ml-2 text-sm">{label}</span></label>
    );

    return (
        <div>
            <PageHeader icon="📋" title="ম্যানুয়াল আগমন/প্রস্থান">
                {hasUnsavedChanges && <button onClick={handleSubmit} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700">সংরক্ষণ করুন</button>}
            </PageHeader>
            <div className="bg-white p-4 rounded-xl shadow-md mb-6">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 items-center">
                    <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)} className="p-2 border rounded-md" />
                    <select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="p-2 border rounded-md bg-white"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select>
                    <select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="p-2 border rounded-md bg-white" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select>
                    <div className="relative">
                        <input 
                            type="text" 
                            placeholder="নাম বা রোল দিয়ে খুঁজুন..." 
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full p-2 border rounded-md pl-8 disabled:bg-gray-100"
                            disabled={!classFilter || !sectionFilter}
                        />
                        <SearchIcon className="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    </div>
                </div>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                {classFilter && sectionFilter ? (
                    filteredStudents.length > 0 ? (
                        <>
                           <div className="space-y-4">
                                {paginatedStudents.map(student => (
                                    <div key={student.id} className="p-4 border rounded-lg hover:bg-gray-50">
                                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between">
                                            <div className="mb-3 sm:mb-0"><p className="font-bold">{student.nameBn}</p><p className="text-sm text-gray-500">রোল: {student.roll}</p></div>
                                            <div className="flex items-center gap-4">
                                                <StatusRadioButton studentId={student.id} status="উপস্থিত" label="উপস্থিত" color="text-green-600" />
                                                <StatusRadioButton studentId={student.id} status="অনুপস্থিত" label="অনুপস্থিত" color="text-red-600" />
                                                <StatusRadioButton studentId={student.id} status="ছুটি" label="ছুটি" color="text-yellow-600" />
                                            </div>
                                        </div>
                                        {attendanceData[student.id]?.status === 'উপস্থিত' && (
                                            <div className="mt-3 pt-3 border-t flex flex-col sm:flex-row items-center gap-4">
                                                <div className="flex items-center gap-2 w-full sm:w-auto"><label className="text-sm">আগমন:</label><input type="time" value={attendanceData[student.id]?.arrivalTime || ''} onChange={(e) => handleTimeChange(student.id, 'arrivalTime', e.target.value)} className="p-1 border rounded-md w-28" /><button type="button" onClick={() => handleSetTimeNow(student.id, 'arrivalTime')} className="px-3 py-1 border rounded-md hover:bg-gray-100 text-xs font-semibold" title="এখন">এখন</button></div>
                                                <div className="flex items-center gap-2 w-full sm:w-auto"><label className="text-sm">প্রস্থান:</label><input type="time" value={attendanceData[student.id]?.departureTime || ''} onChange={(e) => handleTimeChange(student.id, 'departureTime', e.target.value)} className="p-1 border rounded-md w-28" /><button type="button" onClick={() => handleSetTimeNow(student.id, 'departureTime')} className="px-3 py-1 border rounded-md hover:bg-gray-100 text-xs font-semibold" title="এখন">এখন</button></div>
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                             <div className="flex justify-between items-center mt-4 text-sm text-gray-600"><p>মোট {filteredStudents.length} জন শিক্ষার্থীর মধ্যে {paginatedStudents.length} জন দেখানো হচ্ছে।</p>{totalPages > 1 && (<div className="flex items-center gap-2"><button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-3 py-1 border rounded-md disabled:opacity-50">পূর্ববর্তী</button><span>পাতা {currentPage} / {totalPages}</span><button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages} className="px-3 py-1 border rounded-md disabled:opacity-50">পরবর্তী</button></div>)}</div>
                        </>
                    ) : ( <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p> )
                ) : ( <p className="text-center text-gray-500 py-10">তালিকা দেখতে অনুগ্রহ করে একটি শ্রেণি ও সেকশন নির্বাচন করুন।</p> )}
            </div>
        </div>
    );
};
export default DailyAttendance;
