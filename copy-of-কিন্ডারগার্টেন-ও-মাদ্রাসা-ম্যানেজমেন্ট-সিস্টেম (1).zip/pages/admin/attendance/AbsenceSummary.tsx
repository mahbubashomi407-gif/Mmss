import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
    };
    return num.replace(/[0-9]/g, (match) => map[match]);
};


const AbsenceSummary: React.FC = () => {
    const { students, attendanceRecords, institutionName, logoUrl } = useInstitution();
    const { addToast } = useNotification();
    const [monthFilter, setMonthFilter] = useState(new Date().toISOString().slice(0, 7));

    const absenceData = useMemo(() => {
        const recordsInMonth = attendanceRecords.filter(rec => rec.date.startsWith(monthFilter) && rec.status === 'absent');
        const absenceCount: Record<string, number> = {};
        recordsInMonth.forEach(rec => {
            absenceCount[rec.studentId] = (absenceCount[rec.studentId] || 0) + 1;
        });

        return Object.entries(absenceCount)
            .map(([studentId, count]) => {
                const student = students.find(s => s.id === studentId);
                return { student, count };
            })
            .filter(item => item.student && item.student.status !== 'পেন্ডিং')
            .sort((a, b) => b.count - a.count);
    }, [monthFilter, attendanceRecords, students]);
    
    const handlePrint = () => {
        const printContent = document.getElementById('absence-summary-report');
        const monthName = new Date(monthFilter).toLocaleString('bn-BD', { month: 'long', year: 'numeric' });
        const reportTitle = `অনুপস্থিতি সারসংক্ষেপ - ${monthName}`;
        
        if (!printContent) return;

        const printWindow = window.open('', '_blank', 'height=800,width=1200');
        if (!printWindow) {
            addToast('প্রিন্টিং ব্যর্থ হয়েছে। অনুগ্রহ করে এই সাইটের জন্য পপ-আপ অনুমতি দিন।', 'error');
            return;
        }

        printWindow.document.write('<html><head>');
        printWindow.document.write(`<title>${reportTitle}</title>`);
        printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
        printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
        printWindow.document.write(`
            <style>
                body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                @page { size: A4 portrait; margin: 0.5in; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; font-size: 11px; }
                th { background-color: #f2f2f2 !important; text-align: center; }
                td { text-align: left; }
                .text-center { text-align: center; }
                .font-bold { font-weight: bold; }
                .header-info { display: flex; flex-direction: column; align-items: center; gap: 0.5rem; margin-bottom: 1rem; text-align: center; }
                .header-info img { width: 4rem; height: 4rem; border-radius: 9999px; object-fit: cover; }
                .header-info h1 { font-size: 1.5rem; font-weight: bold; }
                .header-info h2 { font-size: 1.25rem; }
            </style>
        `);
        printWindow.document.write('</head><body>');
        printWindow.document.write(`
            <div class="header-info">
                ${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}
                <h1>${institutionName}</h1>
                <h2>${reportTitle}</h2>
            </div>
        `);
        printWindow.document.write(printContent.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        
        setTimeout(() => {
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }, 750);
    };

    return (
        <div>
            <PageHeader icon="📊" title="অনুপস্থিতি সারসংক্ষেপ" />
             <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex flex-wrap justify-between items-center mb-4 gap-4">
                    <h3 className="text-lg font-bold">মাসিক অনুপস্থিতি রিপোর্ট</h3>
                    <div className="flex items-center gap-4">
                         <div className="flex items-center gap-2">
                            <label htmlFor="month-filter" className="font-semibold text-sm">মাস নির্বাচন:</label>
                            <input id="month-filter" type="month" value={monthFilter} onChange={e => setMonthFilter(e.target.value)} className="p-2 border rounded-md bg-white" />
                        </div>
                        <button onClick={handlePrint} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg text-sm">প্রিন্ট করুন</button>
                    </div>
                </div>

                <p className="text-center text-gray-500 py-6 bg-gray-50 rounded-md">
                    মাসিক অনুপস্থিতি রিপোর্ট প্রিন্ট করতে উপরের ফিল্টার নির্বাচন করে 'প্রিন্ট করুন' বাটনে ক্লিক করুন।
                </p>

                <div id="absence-summary-report" className="overflow-x-auto hidden">
                    {absenceData.length > 0 ? (
                        <table className="w-full text-sm">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="p-2 text-center">রোল</th>
                                    <th className="p-2 text-left">শিক্ষার্থীর নাম</th>
                                    <th className="p-2 text-left">শ্রেণি/সেকশন</th>
                                    <th className="p-2 text-center">মোট অনুপস্থিত</th>
                                </tr>
                            </thead>
                            <tbody>
                                {absenceData.map(({ student, count }) => (
                                    <tr key={student!.id} className="border-b">
                                        <td className="p-2 text-center">{toBengaliNumber(student!.roll || '')}</td>
                                        <td className="p-2 font-medium">{student!.nameBn}</td>
                                        <td className="p-2">{student!.classLevel} ({student!.section})</td>
                                        <td className="p-2 text-center font-bold text-red-600">{toBengaliNumber(count)} দিন</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                         <p className="text-center py-10">এই মাসে কোনো অনুপস্থিতি রেকর্ড করা হয়নি।</p>
                    )}
                </div>
            </div>
        </div>
    );
};
export default AbsenceSummary;
