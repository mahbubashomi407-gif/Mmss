
import React, { useState, useEffect, useMemo, useRef } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { CheckCircleIcon } from '../../../components/icons';

declare var Html5QrcodeScanner: any;

const playSuccessSound = () => {
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (!audioContext) return;
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(880, audioContext.currentTime);
    gainNode.gain.setValueAtTime(0.5, audioContext.currentTime);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.1);
};

const QrCodeAttendance: React.FC = () => {
    const { students, attendanceRecords, setAttendanceRecords } = useInstitution();
    const { addToast } = useNotification();
    
    const [isScanning, setIsScanning] = useState(false);
    const [lastScanned, setLastScanned] = useState<StudentData | null>(null);

    const scannerRef = useRef<any>(null);
    const readerId = "qr-reader";
    const today = new Date().toISOString().split('T')[0];

    const todaysAttendance = useMemo(() => {
        const map = new Map<string, 'present' | 'absent' | 'leave'>();
        attendanceRecords.forEach(rec => {
            if (rec.date === today) {
                map.set(rec.studentId, rec.status);
            }
        });
        return map;
    }, [attendanceRecords, today]);

    useEffect(() => {
        if (isScanning) {
            const scanner = new Html5QrcodeScanner(
                readerId,
                {
                    fps: 10,
                    qrbox: { width: 250, height: 250 },
                    supportedScanTypes: [0], // 0 means QR_CODE
                    // New configuration to default to the rear camera ('environment')
                    videoConstraints: {
                        facingMode: "environment"
                    }
                },
                false // verbose
            );
            scannerRef.current = scanner;

            const onScanSuccess = (decodedText: string) => {
                const student = students.find(s => s.uniqueId === decodedText);

                if (!student) {
                    addToast(`ID "${decodedText}" সহ কোনো শিক্ষার্থী পাওয়া যায়নি!`, 'error');
                    return;
                }

                if (student.status === 'পেন্ডিং') {
                    addToast(`শিক্ষার্থী "${student.nameBn}" এর আবেদনটি এখনও পেন্ডিং আছে।`, 'error');
                    return;
                }

                if (todaysAttendance.get(student.id) === 'present') {
                    setLastScanned(student);
                    return; // Already marked, just show info
                }
                
                const newRecord = { id: `${student.id}-${today}`, studentId: student.id, date: today, status: 'present' as 'present' };
                // Ensure no duplicates for the same student on the same day
                const otherRecords = attendanceRecords.filter(rec => !(rec.studentId === student.id && rec.date === today));
                setAttendanceRecords([...otherRecords, newRecord]);
                
                setLastScanned(student);
                playSuccessSound();
            };
            
            scanner.render(onScanSuccess, (error: any) => {});
        } else {
            if (scannerRef.current) {
                scannerRef.current.clear().catch((err: any) => {});
                scannerRef.current = null;
            }
        }

        return () => {
             if (scannerRef.current) {
                scannerRef.current.clear().catch((err: any) => {});
             }
        };
    }, [isScanning, students, addToast, setAttendanceRecords, todaysAttendance]);

    const toggleScanning = () => {
        setIsScanning(!isScanning);
        setLastScanned(null);
    };

    const attendedStudentsToday = useMemo(() => {
        const attended = new Map<string, StudentData>();
        attendanceRecords.forEach(rec => {
            if (rec.date === today && rec.status === 'present') {
                const student = students.find(s => s.id === rec.studentId && s.status !== 'পেন্ডিং');
                if (student) {
                    attended.set(student.id, student);
                }
            }
        });
        return Array.from(attended.values());
    }, [attendanceRecords, students, today]);

    const groupedStudents = useMemo(() => {
        const groups: Record<string, Record<string, StudentData[]>> = {};
        attendedStudentsToday.forEach(student => {
            const classKey = student.classLevel || 'N/A';
            const sectionKey = student.section || 'N/A';
            if (!groups[classKey]) groups[classKey] = {};
            if (!groups[classKey][sectionKey]) groups[classKey][sectionKey] = [];
            groups[classKey][sectionKey].push(student);
        });
        // Sort students by roll in each group
        for (const classKey in groups) {
            for (const sectionKey in groups[classKey]) {
                groups[classKey][sectionKey].sort((a, b) => (a.roll || 999) - (b.roll || 999));
            }
        }
        return groups;
    }, [attendedStudentsToday]);

    return (
        <div>
            <PageHeader icon="🔳" title="QR কোড দ্বারা হাজিরা" />
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white p-6 rounded-xl shadow-md">
                    <div className="flex flex-wrap items-center gap-4 mb-4">
                        <button onClick={toggleScanning} className={`px-6 py-2 font-semibold rounded-lg shadow-md text-white w-full sm:w-auto ${isScanning ? 'bg-red-500 hover:bg-red-600' : 'bg-teal-600 hover:bg-teal-700'}`}>
                            {isScanning ? 'স্ক্যান বন্ধ করুন' : 'স্ক্যান শুরু করুন'}
                        </button>
                    </div>

                    {isScanning ? (
                        <div className="space-y-4">
                            <div id={readerId} className="w-full border-2 border-dashed rounded-lg bg-gray-100 min-h-[300px]"></div>
                            {lastScanned && (
                                <div className="p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-4 animate-pulse-once">
                                    <img src={lastScanned.photoUrl || 'https://via.placeholder.com/64x64?text=S'} alt={lastScanned.nameBn} className="w-16 h-16 rounded-full object-cover" />
                                    <div>
                                        <p className="font-bold text-lg text-green-800">{lastScanned.nameBn}</p>
                                        <p className="text-sm text-gray-600">শ্রেণি: {lastScanned.classLevel} ({lastScanned.section}) | রোল: {lastScanned.roll}</p>
                                        <p className="font-semibold text-green-700 flex items-center gap-1"><CheckCircleIcon className="w-5 h-5" /> হাজিরা সম্পন্ন!</p>
                                    </div>
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="text-center py-20 text-gray-500 bg-gray-50 rounded-lg">
                            <p>শিক্ষার্থীদের আইডি কার্ডে থাকা QR কোড স্ক্যান করে হাজিরা নিতে "স্ক্যান শুরু করুন" বাটনে ক্লিক করুন।</p>
                            <p className="text-xs mt-2">সিস্টেমটি স্বয়ংক্রিয়ভাবে শিক্ষার্থীর শ্রেণি সনাক্ত করে হাজিরা নিয়ে নিবে।</p>
                        </div>
                    )}
                </div>

                <div className="lg:col-span-1 bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-lg font-bold text-gray-800 mb-4">আজকের উপস্থিতি ({new Date().toLocaleDateString('bn-BD')}) - মোট: {attendedStudentsToday.length}</h3>
                    <div className="space-y-4 max-h-[60vh] overflow-y-auto">
                        {Object.keys(groupedStudents).length > 0 ? (
                            Object.entries(groupedStudents).map(([className, sections]) => (
                                <div key={className}>
                                    <h4 className="font-bold text-teal-700 bg-teal-50 px-2 py-1 rounded-md">{className}</h4>
                                    {Object.entries(sections).map(([sectionName, studentList]) => (
                                         <div key={sectionName} className="pl-2 mt-1">
                                            <h5 className="font-semibold text-gray-600 text-sm mb-1">সেকশন: {sectionName} ({studentList.length} জন)</h5>
                                            <div className="space-y-1 pl-2 border-l-2 border-teal-100">
                                            {studentList.map(student => (
                                                <div key={student.id} className="flex items-center gap-2 p-1 rounded-md">
                                                    <img src={student.photoUrl || 'https://via.placeholder.com/24x24?text=S'} alt={student.nameBn} className="w-6 h-6 rounded-full object-cover"/>
                                                    <p className="text-sm font-medium text-gray-800">{student.nameBn} <span className="text-xs text-gray-500">(রোল: {student.roll})</span></p>
                                                </div>
                                            ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ))
                        ) : <p className="text-sm text-gray-500 text-center py-10">আজ এখনো কেউ উপস্থিত হয়নি।</p>}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default QrCodeAttendance;
