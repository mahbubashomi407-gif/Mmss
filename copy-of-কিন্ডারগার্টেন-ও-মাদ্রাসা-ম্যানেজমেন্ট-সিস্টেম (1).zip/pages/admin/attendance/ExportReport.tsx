import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';

const ExportReport: React.FC = () => {
    const { students, attendanceRecords, classLevels, sections, academicSessions } = useInstitution();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [monthFilter, setMonthFilter] = useState(currentMonth);

    // Derived data for filters
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) setSectionFilter('');
    }, [availableSections, sectionFilter]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        return students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            .sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter]);
    
    const { days, year, month, monthName } = useMemo(() => {
        if (!monthFilter) return { days: [], year: 0, month: 0, monthName: '' };
        const [y, m] = monthFilter.split('-').map(Number);
        const date = new Date(y, m - 1, 1);
        const daysInMonth = new Date(y, m, 0).getDate();
        const mName = date.toLocaleString('bn-BD', { month: 'long' });
        return { days: Array.from({ length: daysInMonth }, (_, i) => i + 1), year: y, month: m - 1, monthName: mName };
    }, [monthFilter]);

    const attendanceMap = useMemo(() => {
        const map = new Map<string, Map<string, 'present' | 'absent' | 'leave'>>();
        filteredStudents.forEach(student => {
            const studentAttendance = new Map<string, 'present' | 'absent' | 'leave'>();
            attendanceRecords.filter(rec => rec.studentId === student.id && rec.date.startsWith(monthFilter)).forEach(rec => { studentAttendance.set(rec.date, rec.status); });
            map.set(student.id, studentAttendance);
        });
        return map;
    }, [filteredStudents, attendanceRecords, monthFilter]);

    const studentStats = useMemo(() => {
        const stats = new Map<string, { present: number; absent: number; leave: number }>();
        filteredStudents.forEach(student => {
            const studentAttendance = attendanceMap.get(student.id) || new Map();
            const counts = { present: 0, absent: 0, leave: 0 };
            studentAttendance.forEach(status => { counts[status]++; });
            stats.set(student.id, counts);
        });
        return stats;
    }, [filteredStudents, attendanceMap]);
    
    const handleExport = () => {
        if (filteredStudents.length === 0) {
            addToast('রপ্তানি করার জন্য কোনো শিক্ষার্থী নেই।', 'error');
            return;
        }

        const statusMap = { 'present': 'উ', 'absent': 'অ', 'leave': 'ছু' };
        let csvContent = '\uFEFF'; // BOM for Excel
        
        // Header Row
        const header = ['রোল', 'নাম', ...days, 'মোট উপস্থিতি', 'মোট অনুপস্থিতি', 'মোট ছুটি'].join(',');
        csvContent += header + '\r\n';

        // Data Rows
        filteredStudents.forEach(student => {
            const records = attendanceMap.get(student.id);
            const stats = studentStats.get(student.id) || { present: 0, absent: 0, leave: 0 };
            const rowData = [
                student.roll || '',
                student.nameBn,
                ...days.map(day => {
                    const date = `${monthFilter}-${String(day).padStart(2, '0')}`;
                    const status = records?.get(date);
                    return status ? statusMap[status] : '-';
                }),
                stats.present,
                stats.absent,
                stats.leave
            ];
            csvContent += rowData.join(',') + '\r\n';
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute('href', url);
            link.setAttribute('download', `হাজিরা-রিপোর্ট-${classFilter}-${sectionFilter}-${monthName}-${year}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            addToast('রিপোর্ট ডাউনলোড শুরু হয়েছে!', 'success');
        }
    };

    return (
        <div>
            <PageHeader icon="⬆️" title="এক্সপোর্ট রিপোর্ট" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-4xl mx-auto space-y-6">
                <div>
                    <h3 className="text-lg font-bold text-gray-800">রিপোর্টের জন্য ফিল্টার করুন</h3>
                    <p className="text-sm text-gray-500 mb-4">হাজিরা রিপোর্ট এক্সপোর্ট করতে অনুগ্রহ করে নিচের ফিল্টারগুলো পূরণ করুন।</p>
                    <div className="flex flex-wrap items-center gap-3 p-3 bg-gray-50 rounded-lg">
                        <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white"><option disabled>বর্ষ</option>{academicSessions.map(s=><option key={s.id} value={s.name}>{s.name}</option>)}</select></div>
                        <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white"><option value="">শ্রেণি</option>{classLevels.map(cl=><option key={cl.id} value={cl.name}>{cl.name}</option>)}</select></div>
                        <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s=><option key={s} value={s}>{s}</option>)}</select></div>
                        <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><input type="month" value={monthFilter} onChange={e => setMonthFilter(e.target.value)} className="w-full pl-10 pr-4 py-2 border rounded-lg bg-white" /></div>
                        <button onClick={() => { setClassFilter(''); setSectionFilter(''); setMonthFilter(currentMonth); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                    </div>
                </div>

                <div className="border-t pt-6">
                     <h3 className="text-lg font-bold text-gray-800">রিপোর্ট প্রিভিউ</h3>
                     {filteredStudents.length > 0 ? (
                        <>
                            <p className="text-sm text-gray-500 mb-2">{filteredStudents.length} জন শিক্ষার্থীর তথ্য পাওয়া গেছে।</p>
                            <div className="max-h-64 overflow-y-auto border rounded-lg">
                                <table className="w-full text-sm">
                                    <thead className="text-xs uppercase bg-gray-50 sticky top-0"><tr><th className="p-2">রোল</th><th className="p-2 text-left">নাম</th><th className="p-2 text-center text-green-600">উপস্থিত</th><th className="p-2 text-center text-red-600">অনুপস্থিত</th><th className="p-2 text-center text-yellow-600">ছুটি</th></tr></thead>
                                    <tbody>
                                        {filteredStudents.map(student => {
                                            const stats = studentStats.get(student.id) || { present: 0, absent: 0, leave: 0 };
                                            return (<tr key={student.id} className="border-b"><td className="p-2 font-mono text-center">{student.roll}</td><td className="p-2 font-medium">{student.nameBn}</td><td className="p-2 text-center font-semibold text-green-600">{stats.present}</td><td className="p-2 text-center font-semibold text-red-600">{stats.absent}</td><td className="p-2 text-center font-semibold text-yellow-600">{stats.leave}</td></tr>)
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </>
                     ) : (
                         <p className="text-center text-gray-500 py-6">প্রিভিউ দেখার জন্য অনুগ্রহ করে শ্রেণি, সেকশন ও মাস নির্বাচন করুন।</p>
                     )}
                </div>

                <div className="mt-6 flex justify-end">
                    <button onClick={handleExport} disabled={!classFilter || !sectionFilter || filteredStudents.length === 0} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 disabled:cursor-not-allowed">
                        CSV এক্সপোর্ট করুন
                    </button>
                </div>
            </div>
        </div>
    );
};

export default ExportReport;
