
import React, { useState } from 'react';
import { useInstitution, AcademicSessionData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import AcademicSessionModal from '../../../components/AcademicSessionModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';
import PageHeader from '../../../components/PageHeader';

const AcademicYearSetup: React.FC = () => {
    const { academicSessions, setAcademicSessions } = useInstitution();
    const { addToast } = useNotification();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedSession, setSelectedSession] = useState<AcademicSessionData | null>(null);

    const handleAddNew = () => {
        setSelectedSession(null);
        setIsModalOpen(true);
    };

    const handleEdit = (session: AcademicSessionData) => {
        setSelectedSession(session);
        setIsModalOpen(true);
    };
    
    const handleDelete = (session: AcademicSessionData) => {
        setSelectedSession(session);
        setIsDeleteModalOpen(true);
    };
    
    const handleConfirmDelete = () => {
        if (selectedSession) {
            let updatedSessions = academicSessions.filter(s => s.id !== selectedSession.id);
            
            // If the deleted session was active, make the first one active
            if (selectedSession.isActive && updatedSessions.length > 0) {
                updatedSessions[0].isActive = true;
            }

            setAcademicSessions(updatedSessions);
            addToast('শিক্ষা বর্ষ সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedSession(null);
    };

    const handleSave = (sessionData: Omit<AcademicSessionData, 'id'> & { id?: string }) => {
        let updatedSessions = [...academicSessions];
        
        // If this session is set to active, deactivate all others
        if (sessionData.isActive) {
            updatedSessions = updatedSessions.map(s => ({ ...s, isActive: false }));
        }

        if (sessionData.id) { // Editing existing session
            updatedSessions = updatedSessions.map(s => s.id === sessionData.id ? { ...s, ...sessionData } as AcademicSessionData : s);
            addToast('শিক্ষা বর্ষ সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new session
            const newSession: AcademicSessionData = { ...sessionData, id: Date.now().toString() };
            updatedSessions.push(newSession);
            addToast('নতুন শিক্ষা বর্ষ সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        // Ensure at least one session is active if possible
        const hasActiveSession = updatedSessions.some(s => s.isActive);
        if (!hasActiveSession && updatedSessions.length > 0) {
            updatedSessions[0].isActive = true;
        }

        setAcademicSessions(updatedSessions);
        setIsModalOpen(false);
        setSelectedSession(null);
    };


    return (
        <div>
            <PageHeader icon="🏫" title="শিক্ষা বর্ষ সেটআপ">
                 <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন শিক্ষা বর্ষ যোগ করুন
                </button>
            </PageHeader>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">নাম</th>
                                <th scope="col" className="px-6 py-3">শুরুর তারিখ</th>
                                <th scope="col" className="px-6 py-3">শেষের তারিখ</th>
                                <th scope="col" className="px-6 py-3">স্ট্যাটাস</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {academicSessions.length > 0 ? academicSessions.map(session => (
                                <tr key={session.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{session.name}</td>
                                    <td className="px-6 py-4">{session.startDate}</td>
                                    <td className="px-6 py-4">{session.endDate}</td>
                                    <td className="px-6 py-4">
                                        {session.isActive ? (
                                            <span className="px-2 py-1 text-xs font-semibold text-green-800 bg-green-200 rounded-full">সক্রিয়</span>
                                        ) : (
                                             <span className="px-2 py-1 text-xs font-semibold text-gray-800 bg-gray-200 rounded-full">সমাপ্ত</span>
                                        )}
                                    </td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => handleEdit(session)} className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" title="সম্পাদনা">
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button onClick={() => handleDelete(session)} className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors" title="মুছুন" disabled={academicSessions.length <= 1}>
                                            <TrashIcon className={`w-4 h-4 ${academicSessions.length <= 1 ? 'opacity-50 cursor-not-allowed' : ''}`} />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={5} className="text-center py-10 text-gray-500">
                                        <p>কোনো শিক্ষা বর্ষ যোগ করা হয়নি।</p>
                                        <p className="mt-1">শুরু করতে "নতুন শিক্ষা বর্ষ যোগ করুন" বাটনে ক্লিক করুন।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <AcademicSessionModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                sessionToEdit={selectedSession}
            />
            
            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="শিক্ষা বর্ষ মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই শিক্ষা বর্ষটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default AcademicYearSetup;
