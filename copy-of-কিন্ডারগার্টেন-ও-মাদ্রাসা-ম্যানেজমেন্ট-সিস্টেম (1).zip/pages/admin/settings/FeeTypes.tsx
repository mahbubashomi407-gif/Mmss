
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, FeeTypeData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon } from '../../../components/icons';
import FeeTypeModal from '../../../components/FeeTypeModal';

const FeeTypes: React.FC = () => {
    const { feeTypes, setFeeTypes, classLevels } = useInstitution();
    const { addToast } = useNotification();
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedFeeType, setSelectedFeeType] = useState<FeeTypeData | null>(null);

    const handleAddNew = () => {
        setSelectedFeeType(null);
        setIsModalOpen(true);
    };

    const handleEdit = (feeType: FeeTypeData) => {
        setSelectedFeeType(feeType);
        setIsModalOpen(true);
    };
    
    const handleDelete = (feeType: FeeTypeData) => {
        setSelectedFeeType(feeType);
        setIsDeleteModalOpen(true);
    };
    
    const handleConfirmDelete = () => {
        if (selectedFeeType) {
            setFeeTypes(feeTypes.filter(ft => ft.id !== selectedFeeType.id));
            addToast('ফি টাইপ সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedFeeType(null);
    };

    const handleSave = (feeTypeData: Omit<FeeTypeData, 'id'> & { id?: string }) => {
        if (feeTypeData.id) { // Editing
            setFeeTypes(feeTypes.map(ft => ft.id === feeTypeData.id ? { ...ft, ...feeTypeData } : ft));
            addToast('ফি টাইপ সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newFeeType = { ...feeTypeData, id: Date.now().toString() };
            setFeeTypes([...feeTypes, newFeeType]);
            addToast('নতুন ফি টাইপ সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        setIsModalOpen(false);
        setSelectedFeeType(null);
    };

    return (
        <div>
            <PageHeader icon="💰" title="ফি টাইপ ও ক্যাটাগরি">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন ফি টাইপ যোগ করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">ফি-এর নাম</th>
                                <th scope="col" className="px-6 py-3">পরিমাণ (টাকা)</th>
                                <th scope="col" className="px-6 py-3">প্রযোজ্য শ্রেণি</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {feeTypes.length > 0 ? feeTypes.map(feeType => (
                                <tr key={feeType.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{feeType.name}</td>
                                    <td className="px-6 py-4">{feeType.amount.toLocaleString('bn-BD')}</td>
                                    <td className="px-6 py-4">
                                        {feeType.applicableClasses.length === classLevels.length ? 'সকল শ্রেণি' : feeType.applicableClasses.join(', ')}
                                    </td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => handleEdit(feeType)} className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" title="সম্পাদনা">
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button onClick={() => handleDelete(feeType)} className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors" title="মুছুন">
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={4} className="text-center py-10 text-gray-500">
                                        <p>কোনো ফি টাইপ যোগ করা হয়নি।</p>
                                        <p className="mt-1">শুরু করতে "নতুন ফি টাইপ যোগ করুন" বাটনে ক্লিক করুন।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <FeeTypeModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                feeTypeToEdit={selectedFeeType}
                classLevels={classLevels}
            />

            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="ফি টাইপ মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই ফি টাইপটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default FeeTypes;
