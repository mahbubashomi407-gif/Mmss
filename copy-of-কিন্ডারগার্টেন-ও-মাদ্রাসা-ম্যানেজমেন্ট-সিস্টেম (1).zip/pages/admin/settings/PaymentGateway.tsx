
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, PaymentGatewayData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

const ToggleSwitch: React.FC<{
  enabled: boolean;
  onChange: (enabled: boolean) => void;
}> = ({ enabled, onChange }) => (
    <label className="relative inline-flex items-center cursor-pointer">
        <input type="checkbox" checked={enabled} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" />
        <div className="w-11 h-6 bg-gray-200 rounded-full peer peer-focus:ring-2 peer-focus:ring-teal-300 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-0.5 after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-teal-600"></div>
    </label>
);

const PaymentGatewaySettings: React.FC = () => {
  const { paymentGateways, setPaymentGateways, onlineAdmissionFee, setOnlineAdmissionFee, generalSettings } = useInstitution();
  const { addToast } = useNotification();

  const [gateways, setGateways] = useState<PaymentGatewayData[]>(paymentGateways);
  const [fee, setFee] = useState<number>(onlineAdmissionFee);

  const hasUnsavedChanges = JSON.stringify(gateways) !== JSON.stringify(paymentGateways) || fee !== onlineAdmissionFee;

  const handleGatewayChange = (id: string, field: keyof Omit<PaymentGatewayData, 'id'>, value: any) => {
    setGateways(gateways.map(gw => gw.id === id ? { ...gw, [field]: value } : gw));
  };
  
  const handleAddNew = () => {
    const newGateway: PaymentGatewayData = {
        id: Date.now().toString(),
        name: 'নতুন গেটওয়ে',
        apiKey: '',
        instructions: '',
        enabled: false,
    };
    setGateways([...gateways, newGateway]);
  };

  const handleRemove = (id: string) => {
    setGateways(gateways.filter(gw => gw.id !== id));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentGateways(gateways);
    setOnlineAdmissionFee(fee);
    addToast('সেটিংস সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
  };

  return (
    <div>
      <PageHeader icon="💳" title="পেমেন্ট গেটওয়ে সেটিং" />
      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-8">
        <div className="bg-white p-6 rounded-xl shadow-md">
            <h2 className="text-lg font-bold text-gray-800 border-b pb-3 mb-4">অনলাইন ভর্তি ফি</h2>
            <div className="flex items-center gap-4">
                <label htmlFor="admissionFee" className="text-sm font-medium text-gray-700">ভর্তি ফি-এর পরিমাণ নির্ধারণ করুন:</label>
                <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-500">{generalSettings.currencySymbol}</span>
                    <input
                        id="admissionFee"
                        type="number"
                        value={fee}
                        onChange={(e) => setFee(Number(e.target.value))}
                        className="pl-8 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 w-40"
                    />
                </div>
            </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-md">
          <h2 className="text-lg font-bold text-gray-800 border-b pb-3 mb-4">পেমেন্ট গেটওয়ে তালিকা</h2>
          <div className="space-y-6">
            {gateways.map(gw => (
              <div key={gw.id} className="p-4 border rounded-lg relative">
                 <button type="button" onClick={() => handleRemove(gw.id)} className="absolute top-2 right-2 text-red-500 hover:text-red-700" title="মুছে ফেলুন">&times;</button>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                    <div className="space-y-3">
                         <input
                            type="text"
                            value={gw.name}
                            onChange={(e) => handleGatewayChange(gw.id, 'name', e.target.value)}
                            className="text-lg font-semibold border-b-2 border-transparent focus:border-teal-500 outline-none w-full"
                         />
                        <div className="relative">
                            <label className="text-xs text-gray-500">API Key / Merchant ID</label>
                            <input
                                type="text"
                                value={gw.apiKey}
                                onChange={(e) => handleGatewayChange(gw.id, 'apiKey', e.target.value)}
                                className="w-full text-sm mt-1 px-2 py-1 border border-gray-300 rounded-md"
                            />
                        </div>
                    </div>
                    <div className="space-y-3">
                        <div className="flex justify-end items-center gap-2">
                             <span className="text-sm font-medium">সক্রিয়</span>
                             <ToggleSwitch enabled={gw.enabled} onChange={(val) => handleGatewayChange(gw.id, 'enabled', val)} />
                        </div>
                        <div className="relative">
                             <label className="text-xs text-gray-500">ব্যবহারকারীর জন্য নির্দেশনা</label>
                             <textarea
                                value={gw.instructions}
                                onChange={(e) => handleGatewayChange(gw.id, 'instructions', e.target.value)}
                                rows={2}
                                className="w-full text-sm mt-1 px-2 py-1 border border-gray-300 rounded-md"
                             />
                        </div>
                    </div>
                 </div>
              </div>
            ))}
             <button
                type="button"
                onClick={handleAddNew}
                className="mt-4 text-sm text-teal-600 font-semibold hover:underline"
             >
                + নতুন গেটওয়ে যোগ করুন
            </button>
          </div>
        </div>
        
        <div className="flex justify-end gap-3 pt-4">
            <button
                type="submit"
                disabled={!hasUnsavedChanges}
                className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
                সংরক্ষণ করুন
            </button>
        </div>
      </form>
    </div>
  );
};

export default PaymentGatewaySettings;
