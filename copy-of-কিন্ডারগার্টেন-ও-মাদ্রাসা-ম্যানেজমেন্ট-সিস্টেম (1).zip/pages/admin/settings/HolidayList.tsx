
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, HolidayData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon } from '../../../components/icons';
import HolidayModal from '../../../components/HolidayModal';

const HolidayList: React.FC = () => {
  const { holidays, setHolidays } = useInstitution();
  const { addToast } = useNotification();
  
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedHoliday, setSelectedHoliday] = useState<HolidayData | null>(null);

  const handleAddNew = () => {
      setSelectedHoliday(null);
      setIsModalOpen(true);
  };

  const handleEdit = (holiday: HolidayData) => {
      setSelectedHoliday(holiday);
      setIsModalOpen(true);
  };
  
  const handleDelete = (holiday: HolidayData) => {
      setSelectedHoliday(holiday);
      setIsDeleteModalOpen(true);
  };
  
  const handleConfirmDelete = () => {
      if (selectedHoliday) {
          setHolidays(holidays.filter(h => h.id !== selectedHoliday.id));
          addToast('ছুটি সফলভাবে মুছে ফেলা হয়েছে!', 'success');
      }
      setIsDeleteModalOpen(false);
      setSelectedHoliday(null);
  };

  const handleSave = (holidayData: Omit<HolidayData, 'id'> & { id?: string }) => {
      if (holidayData.id) { // Editing
          setHolidays(holidays.map(h => h.id === holidayData.id ? { ...h, ...holidayData } : h));
          addToast('ছুটি সফলভাবে আপডেট করা হয়েছে!', 'success');
      } else { // Adding new
          const newHoliday = { ...holidayData, id: Date.now().toString() };
          setHolidays([...holidays, newHoliday]);
          addToast('নতুন ছুটি সফলভাবে যোগ করা হয়েছে!', 'success');
      }
      
      setIsModalOpen(false);
      setSelectedHoliday(null);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('bn-BD', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  };

  return (
    <div>
      <PageHeader icon="📅" title="ছুটি / ছুটির তালিকা">
        <button
            onClick={handleAddNew}
            className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
        >
            নতুন ছুটি যোগ করুন
        </button>
      </PageHeader>
      
      <div className="bg-white p-6 rounded-xl shadow-md">
          <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-500">
                  <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                      <tr>
                          <th scope="col" className="px-6 py-3">ছুটির নাম</th>
                          <th scope="col" className="px-6 py-3">শুরুর তারিখ</th>
                          <th scope="col" className="px-6 py-3">শেষের তারিখ</th>
                          <th scope="col" className="px-6 py-3">ধরন</th>
                          <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                      </tr>
                  </thead>
                  <tbody>
                      {holidays.length > 0 ? holidays.map(holiday => (
                          <tr key={holiday.id} className="bg-white border-b hover:bg-gray-50">
                              <td className="px-6 py-4 font-medium text-gray-900">{holiday.title}</td>
                              <td className="px-6 py-4">{formatDate(holiday.startDate)}</td>
                              <td className="px-6 py-4">{formatDate(holiday.endDate)}</td>
                              <td className="px-6 py-4">
                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${holiday.type === 'Public' ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}`}>
                                  {holiday.type === 'Public' ? 'সরকারি ছুটি' : 'প্রাতিষ্ঠানিক ছুটি'}
                                </span>
                              </td>
                              <td className="px-6 py-4 text-right space-x-2">
                                  <button onClick={() => handleEdit(holiday)} className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" title="সম্পাদনা">
                                      <PencilIcon className="w-4 h-4" />
                                  </button>
                                  <button onClick={() => handleDelete(holiday)} className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors" title="মুছুন">
                                      <TrashIcon className="w-4 h-4" />
                                  </button>
                              </td>
                          </tr>
                      )) : (
                          <tr>
                              <td colSpan={5} className="text-center py-10 text-gray-500">
                                  <p>কোনো ছুটি যোগ করা হয়নি।</p>
                                  <p className="mt-1">শুরু করতে "নতুন ছুটি যোগ করুন" বাটনে ক্লিক করুন।</p>
                              </td>
                          </tr>
                      )}
                  </tbody>
              </table>
          </div>
      </div>

      <HolidayModal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSave}
          holidayToEdit={selectedHoliday}
      />

      <Modal
          isOpen={isDeleteModalOpen}
          onClose={() => setIsDeleteModalOpen(false)}
          onConfirm={handleConfirmDelete}
          title="ছুটি মুছে ফেলুন"
      >
          <p>আপনি কি নিশ্চিতভাবে এই ছুটিটি তালিকা থেকে মুছে ফেলতে চান?</p>
      </Modal>
    </div>
  );
};

export default HolidayList;
