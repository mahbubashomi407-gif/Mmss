import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, ClassLevelData, SectionData, SubjectData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import ClassLevelModal from '../../../components/ClassLevelModal';
import SubjectModal from '../../../components/SubjectModal';
import SectionModal from '../../../components/SectionModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const ClassSetup: React.FC = () => {
    const { classLevels, setClassLevels, sections, setSections, teachers } = useInstitution();
    const { addToast } = useNotification();
    
    // State for modals
    const [classModal, setClassModal] = useState<{ isOpen: boolean; classToEdit: ClassLevelData | null }>({ isOpen: false, classToEdit: null });
    const [subjectModal, setSubjectModal] = useState<{ isOpen: boolean; classLevel: ClassLevelData | null; subjectToEdit: SubjectData | null }>({ isOpen: false, classLevel: null, subjectToEdit: null });
    const [sectionModal, setSectionModal] = useState<{ isOpen: boolean; sectionToEdit: SectionData | null; preselectedClass: string | null }>({ isOpen: false, sectionToEdit: null, preselectedClass: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; item: any; type: 'class' | 'subject' | 'section' | null; classId?: string; }>({ isOpen: false, item: null, type: null });

    // --- Class Level Handlers ---
    const handleSaveClass = (data: { name: string; id?: string }) => {
        if (data.id) { // Edit
            setClassLevels(classLevels.map(cl => cl.id === data.id ? { ...cl, name: data.name } : cl));
            addToast('শ্রেণির নাম আপডেট করা হয়েছে!', 'success');
        } else { // Add
            const newClass = { id: Date.now().toString(), name: data.name, subjects: [] };
            setClassLevels([...classLevels, newClass]);
            addToast('নতুন শ্রেণি যোগ করা হয়েছে!', 'success');
        }
        setClassModal({ isOpen: false, classToEdit: null });
    };

    // --- Subject Handlers ---
    const handleSaveSubject = (data: { name: string; id?: string }) => {
        const targetClassId = subjectModal.classLevel?.id;
        if (!targetClassId) return;

        const updatedClassLevels = classLevels.map(cl => {
            if (cl.id === targetClassId) {
                let updatedSubjects: SubjectData[];
                if (data.id) { // Edit subject
                    updatedSubjects = cl.subjects.map(sub => sub.id === data.id ? { ...sub, name: data.name } : sub);
                    addToast('বিষয় আপডেট করা হয়েছে!', 'success');
                } else { // Add new subject
                    const newSubject = { id: Date.now().toString(), name: data.name };
                    updatedSubjects = [...cl.subjects, newSubject];
                    addToast('নতুন বিষয় যোগ করা হয়েছে!', 'success');
                }
                return { ...cl, subjects: updatedSubjects };
            }
            return cl;
        });
        setClassLevels(updatedClassLevels);
        setSubjectModal({ isOpen: false, classLevel: null, subjectToEdit: null });
    };

    // --- Section Handlers ---
    const handleSaveSection = (data: Omit<SectionData, 'id' | 'studentCount'> & { id?: string }) => {
        if (data.id) { // Edit
            setSections(sections.map(s => s.id === data.id ? { ...s, ...data } : s));
            addToast('সেকশন আপডেট করা হয়েছে!', 'success');
        } else { // Add
            const newSection = { ...data, id: Date.now().toString(), studentCount: 0 };
            setSections([...sections, newSection]);
            addToast('নতুন সেকশন যোগ করা হয়েছে!', 'success');
        }
        setSectionModal({ isOpen: false, sectionToEdit: null, preselectedClass: null });
    };
    
    // --- Delete Handler ---
    const handleConfirmDelete = () => {
        const { item, type, classId } = deleteModal;
        if (!item || !type) return;

        if (type === 'class') {
            setClassLevels(classLevels.filter(cl => cl.id !== item.id));
            // Also delete associated sections
            setSections(sections.filter(sec => sec.classLevel !== item.name));
            addToast('শ্রেণি এবং এর সেকশনগুলো মুছে ফেলা হয়েছে!', 'success');
        } else if (type === 'subject' && classId) {
             const updatedClassLevels = classLevels.map(cl => {
                if (cl.id === classId) {
                    return { ...cl, subjects: cl.subjects.filter(sub => sub.id !== item.id) };
                }
                return cl;
            });
            setClassLevels(updatedClassLevels);
            addToast('বিষয়টি মুছে ফেলা হয়েছে!', 'success');
        } else if (type === 'section') {
            setSections(sections.filter(s => s.id !== item.id));
            addToast('সেকশনটি মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, item: null, type: null });
    };

    return (
        <div>
            <PageHeader icon="📚" title="শ্রেণি / জামাত সেটিং">
                <button
                    onClick={() => setClassModal({ isOpen: true, classToEdit: null })}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন শ্রেণি যোগ করুন
                </button>
            </PageHeader>
            
            <div className="space-y-6">
                {classLevels.map(cl => (
                    <div key={cl.id} className="bg-white p-4 rounded-xl shadow-md">
                        <div className="flex justify-between items-center border-b pb-3 mb-3">
                            <h3 className="text-xl font-bold text-gray-800">{cl.name}</h3>
                            <div className="space-x-2">
                                <button onClick={() => setClassModal({ isOpen: true, classToEdit: cl })} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button>
                                <button onClick={() => setDeleteModal({ isOpen: true, item: cl, type: 'class' })} className="p-2 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button>
                            </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* Subjects */}
                            <div>
                                <h4 className="font-semibold text-gray-700 mb-2">বিষয়সমূহ</h4>
                                <ul className="space-y-2 text-sm">
                                    {cl.subjects.map(sub => (
                                        <li key={sub.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                                            <span>{sub.name}</span>
                                            <div className="space-x-1">
                                                <button onClick={() => setSubjectModal({ isOpen: true, classLevel: cl, subjectToEdit: sub })} className="p-1 text-blue-500 hover:bg-blue-100 rounded-full"><PencilIcon className="w-3 h-3" /></button>
                                                <button onClick={() => setDeleteModal({ isOpen: true, item: sub, type: 'subject', classId: cl.id })} className="p-1 text-red-500 hover:bg-red-100 rounded-full"><TrashIcon className="w-3 h-3" /></button>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                                <button onClick={() => setSubjectModal({ isOpen: true, classLevel: cl, subjectToEdit: null })} className="mt-2 text-sm text-teal-600 font-semibold hover:underline">+ নতুন বিষয় যোগ করুন</button>
                            </div>
                            {/* Sections */}
                            <div>
                                <h4 className="font-semibold text-gray-700 mb-2">সেকশনসমূহ</h4>
                                <ul className="space-y-2 text-sm">
                                    {sections.filter(s => s.classLevel === cl.name).map(sec => (
                                        <li key={sec.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                                            <span>{sec.name} ({sec.teacherName || 'শিক্ষক নেই'})</span>
                                             <div className="space-x-1">
                                                <button onClick={() => setSectionModal({ isOpen: true, sectionToEdit: sec, preselectedClass: null })} className="p-1 text-blue-500 hover:bg-blue-100 rounded-full"><PencilIcon className="w-3 h-3" /></button>
                                                <button onClick={() => setDeleteModal({ isOpen: true, item: sec, type: 'section' })} className="p-1 text-red-500 hover:bg-red-100 rounded-full"><TrashIcon className="w-3 h-3" /></button>
                                            </div>
                                        </li>
                                    ))}
                                </ul>
                                <button onClick={() => setSectionModal({ isOpen: true, sectionToEdit: null, preselectedClass: cl.name })} className="mt-2 text-sm text-teal-600 font-semibold hover:underline">+ নতুন সেকশন যোগ করুন</button>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Modals */}
            <ClassLevelModal 
                isOpen={classModal.isOpen} 
                onClose={() => setClassModal({ isOpen: false, classToEdit: null })}
                onSave={handleSaveClass}
                classToEdit={classModal.classToEdit}
            />
            <SubjectModal 
                isOpen={subjectModal.isOpen}
                onClose={() => setSubjectModal({ isOpen: false, classLevel: null, subjectToEdit: null })}
                onSave={handleSaveSubject}
                subjectToEdit={subjectModal.subjectToEdit}
                className={subjectModal.classLevel?.name || ''}
            />
            <SectionModal
                isOpen={sectionModal.isOpen}
                onClose={() => setSectionModal({ isOpen: false, sectionToEdit: null, preselectedClass: null })}
                onSave={handleSaveSection}
                sectionToEdit={sectionModal.sectionToEdit}
                classLevels={classLevels}
                teachers={teachers}
                preselectedClass={sectionModal.preselectedClass}
            />
            <Modal
                isOpen={deleteModal.isOpen}
                onClose={() => setDeleteModal({ isOpen: false, item: null, type: null })}
                onConfirm={handleConfirmDelete}
                title="মুছে ফেলা নিশ্চিত করুন"
            >
                আপনি কি নিশ্চিতভাবে এই আইটেমটি মুছে ফেলতে চান? এই কাজটি ফিরিয়ে আনা যাবে না।
            </Modal>
        </div>
    );
};

export default ClassSetup;