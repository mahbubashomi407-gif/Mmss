
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, GeneralSettingsData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

const timezones = [
    'Asia/Dhaka',
    'Asia/Kolkata',
    'Asia/Dubai',
    'Europe/London',
    'America/New_York',
];

const GeneralSettings: React.FC = () => {
  const { generalSettings, setGeneralSettings } = useInstitution();
  const { addToast } = useNotification();
  const [formData, setFormData] = useState<GeneralSettingsData>(generalSettings);

  const hasUnsavedChanges = JSON.stringify(formData) !== JSON.stringify(generalSettings);

  const handleChange = <K extends keyof GeneralSettingsData>(key: K, value: GeneralSettingsData[K]) => {
      setFormData(prev => ({ ...prev, [key]: value }));
  };

  const handleCancel = () => {
      setFormData(generalSettings);
  };

  const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      setGeneralSettings(formData);
      addToast('সাধারণ সেটিংস সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
  };

  return (
    <div>
      <PageHeader icon="🌐" title="সাধারণ সিস্টেম সেটিং" />
      <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          <div>
            <label htmlFor="language" className="block text-sm font-medium text-gray-700 mb-1">সিস্টেমের ভাষা</label>
            <select
              id="language"
              value={formData.language}
              onChange={(e) => handleChange('language', e.target.value as 'bn')}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 bg-gray-100 cursor-not-allowed"
              disabled
            >
              <option value="bn">বাংলা</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">বর্তমানে শুধুমাত্র বাংলা ভাষা সমর্থিত।</p>
          </div>

          <div>
            <label htmlFor="currencySymbol" className="block text-sm font-medium text-gray-700 mb-1">মুদ্রার প্রতীক</label>
            <input
              id="currencySymbol"
              type="text"
              value={formData.currencySymbol}
              onChange={(e) => handleChange('currencySymbol', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              placeholder="৳"
              required
            />
          </div>

          <div>
            <label htmlFor="dateFormat" className="block text-sm font-medium text-gray-700 mb-1">তারিখের ফরম্যাট</label>
            <select
              id="dateFormat"
              value={formData.dateFormat}
              onChange={(e) => handleChange('dateFormat', e.target.value as GeneralSettingsData['dateFormat'])}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="DD-MM-YYYY">DD-MM-YYYY (দিন-মাস-বছর)</option>
              <option value="MM-DD-YYYY">MM-DD-YYYY (মাস-দিন-বছর)</option>
              <option value="YYYY-MM-DD">YYYY-MM-DD (বছর-মাস-দিন)</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="timezone" className="block text-sm font-medium text-gray-700 mb-1">টাইমজোন</label>
            <select
              id="timezone"
              value={formData.timezone}
              onChange={(e) => handleChange('timezone', e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              {timezones.map(tz => (
                <option key={tz} value={tz}>{tz}</option>
              ))}
            </select>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t">
              {hasUnsavedChanges && (
                  <button type="button" onClick={handleCancel} className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition-colors w-full sm:w-auto">বাতিল</button>
              )}
              <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed w-full sm:w-auto">সংরক্ষণ করুন</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default GeneralSettings;
