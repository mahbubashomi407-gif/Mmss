
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentRoleData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { PencilIcon, TrashIcon, CheckCircleIcon } from '../../../components/icons';
import { getPermissionLabel, PERMISSIONS } from '../../../constants/permissions';
import Modal from '../../../components/Modal';
import RoleModal from '../../../components/RoleModal';

const StudentRoles: React.FC = () => {
    const { studentRoles, setStudentRoles } = useInstitution();
    const { addToast } = useNotification();

    const [roleModal, setRoleModal] = useState<{ isOpen: boolean; roleToEdit: StudentRoleData | null }>({ isOpen: false, roleToEdit: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; role: StudentRoleData | null }>({ isOpen: false, role: null });

    const handleSaveRole = (data: { name: string, permissions: string[], id?: string }) => {
        if (data.id) { // Edit
            setStudentRoles(studentRoles.map(r => r.id === data.id ? { ...r, name: data.name, permissions: data.permissions } : r));
            addToast('রোল সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Add
            const newRole = { ...data, id: Date.now().toString() };
            setStudentRoles([...studentRoles, newRole]);
            addToast('নতুন রোল সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        setRoleModal({ isOpen: false, roleToEdit: null });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.role) {
            setStudentRoles(studentRoles.filter(r => r.id !== deleteModal.role!.id));
            addToast('রোল সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, role: null });
    };

    return (
        <div>
            <PageHeader icon="🧒" title="শিক্ষার্থী রোল ও অনুমতি">
                <button
                    onClick={() => setRoleModal({ isOpen: true, roleToEdit: null })}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন রোল যোগ করুন
                </button>
            </PageHeader>
            
            <div className="space-y-4">
                {studentRoles.map(role => (
                    <div key={role.id} className="bg-white p-4 rounded-xl shadow-md">
                        <div className="flex justify-between items-center mb-3">
                            <h3 className="text-lg font-bold text-gray-800">{role.name}</h3>
                            <div className="space-x-2">
                                <button onClick={() => setRoleModal({ isOpen: true, roleToEdit: role })} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button>
                                <button onClick={() => setDeleteModal({ isOpen: true, role: role })} className="p-2 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button>
                            </div>
                        </div>
                        <div>
                            <h4 className="font-semibold text-gray-600 text-sm mb-2">অনুমতিসমূহ:</h4>
                            <div className="flex flex-wrap gap-2">
                                {role.permissions.length > 0 ? role.permissions.map(permKey => (
                                    <span key={permKey} className="flex items-center gap-1 text-xs bg-teal-100 text-teal-800 px-2 py-1 rounded-full">
                                        <CheckCircleIcon className="w-3 h-3"/>
                                        {getPermissionLabel(permKey)}
                                    </span>
                                )) : <p className="text-xs text-gray-500">কোনো অনুমতি দেওয়া হয়নি।</p>}
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <RoleModal 
                isOpen={roleModal.isOpen}
                onClose={() => setRoleModal({ isOpen: false, roleToEdit: null })}
                onSave={handleSaveRole}
                roleToEdit={roleModal.roleToEdit}
                permissionSet={{ studentPortal: PERMISSIONS.studentPortal }}
            />
            
            <Modal
                isOpen={deleteModal.isOpen}
                onClose={() => setDeleteModal({ isOpen: false, role: null })}
                onConfirm={handleConfirmDelete}
                title="রোল মুছে ফেলুন"
            >
                আপনি কি নিশ্চিতভাবে "{deleteModal.role?.name}" রোলটি মুছে ফেলতে চান? এই কাজটি ফিরিয়ে আনা যাবে না।
            </Modal>
        </div>
    );
};

export default StudentRoles;
