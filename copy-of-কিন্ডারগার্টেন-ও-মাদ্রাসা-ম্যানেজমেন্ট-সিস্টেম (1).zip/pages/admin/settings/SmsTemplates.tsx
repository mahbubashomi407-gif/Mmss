
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, SmsTemplatesData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

type TemplateKey = keyof SmsTemplatesData;

const templateInfo: Record<TemplateKey, { label: string; placeholders: string[] }> = {
    studentArrival: { label: 'শিক্ষার্থী আগমন', placeholders: ['{{student_name}}', '{{time}}', '{{institution_name}}'] },
    studentDeparture: { label: 'শিক্ষার্থী প্রস্থান', placeholders: ['{{student_name}}', '{{time}}', '{{institution_name}}'] },
    studentAbsence: { label: 'শিক্ষার্থী অনুপস্থিতি', placeholders: ['{{student_name}}', '{{class}}', '{{date}}', '{{institution_name}}'] },
    newNotice: { label: 'নতুন নোটিশ', placeholders: ['{{institution_name}}'] },
    feeDue: { label: 'ফি বকেয়া', placeholders: ['{{student_name}}', '{{month}}', '{{amount}}', '{{institution_name}}'] },
    feePayment: { label: 'ফি আদায়', placeholders: ['{{student_name}}', '{{amount}}', '{{institution_name}}'] },
    resultsPublished: { label: 'ফলাফল প্রকাশ', placeholders: ['{{exam_name}}', '{{institution_name}}'] },
};

const SmsTemplates: React.FC = () => {
    const { smsTemplates, setSmsTemplates } = useInstitution();
    const { addToast } = useNotification();
    const [templates, setTemplates] = useState<SmsTemplatesData>(smsTemplates);

    const hasUnsavedChanges = useMemo(() => JSON.stringify(templates) !== JSON.stringify(smsTemplates), [templates, smsTemplates]);

    const handleChange = (key: TemplateKey, value: string) => {
        setTemplates(prev => ({ ...prev, [key]: value }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setSmsTemplates(templates);
        addToast('SMS টেমপ্লেট সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };

    return (
        <div>
            <PageHeader icon="✉️" title="SMS টেমপ্লেট" />
            <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-6">
                {Object.entries(templateInfo).map(([key, info]) => (
                    <div key={key} className="bg-white p-4 rounded-xl shadow-md">
                        <h3 className="text-md font-bold text-gray-800 mb-2">{info.label}</h3>
                        <textarea
                            value={templates[key as TemplateKey]}
                            onChange={e => handleChange(key as TemplateKey, e.target.value)}
                            rows={3}
                            className="w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                        <div className="mt-2 text-xs text-gray-500">
                            <span className="font-semibold">ব্যবহারযোগ্য ভেরিয়েবল:</span>
                            <div className="flex flex-wrap gap-x-2 gap-y-1 mt-1">
                                {info.placeholders.map(p => (
                                    <code key={p} className="bg-gray-200 px-1.5 py-0.5 rounded text-gray-700">{p}</code>
                                ))}
                            </div>
                        </div>
                    </div>
                ))}
                <div className="flex justify-end gap-3 pt-4">
                    <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">
                        সংরক্ষণ করুন
                    </button>
                </div>
            </form>
        </div>
    );
};

export default SmsTemplates;
