
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, FundCategoryData, FundHeadData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon, PlusIcon } from '../../../components/icons';
import FundCategoryModal from '../../../components/FundCategoryModal';
import FundHeadModal from '../../../components/FundHeadModal';

type ActiveTab = 'categories' | 'incomeHeads' | 'expenseHeads';

const FundCategory: React.FC = () => {
    const { fundCategories, setFundCategories, fundHeads, setFundHeads } = useInstitution();
    const { addToast } = useNotification();
    
    const [activeTab, setActiveTab] = useState<ActiveTab>('categories');

    // State for FundCategory management
    const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
    const [isDeleteCategoryModalOpen, setIsDeleteCategoryModalOpen] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState<FundCategoryData | null>(null);

    // State for FundHead management
    const [isHeadModalOpen, setIsHeadModalOpen] = useState(false);
    const [isDeleteHeadModalOpen, setIsDeleteHeadModalOpen] = useState(false);
    const [selectedHead, setSelectedHead] = useState<FundHeadData | null>(null);

    const fundCategoryMap = useMemo(() => 
        new Map(fundCategories.map(cat => [cat.id, cat.name])),
        [fundCategories]
    );

    // --- Fund Category Handlers ---
    const handleAddNewCategory = () => {
        setSelectedCategory(null);
        setIsCategoryModalOpen(true);
    };
    const handleEditCategory = (category: FundCategoryData) => {
        setSelectedCategory(category);
        setIsCategoryModalOpen(true);
    };
    const handleDeleteCategory = (category: FundCategoryData) => {
        setSelectedCategory(category);
        setIsDeleteCategoryModalOpen(true);
    };
    const handleConfirmDeleteCategory = () => {
        if (selectedCategory) {
            setFundCategories(fundCategories.filter(fc => fc.id !== selectedCategory.id));
            addToast('ক্যাটাগরি সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteCategoryModalOpen(false);
        setSelectedCategory(null);
    };
    const handleSaveCategory = (categoryData: { name: string; id?: string }) => {
        if (categoryData.id) {
            setFundCategories(fundCategories.map(fc => fc.id === categoryData.id ? { ...fc, ...categoryData } as FundCategoryData : fc));
            addToast('ক্যাটাগরি সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else {
            const newCategory: FundCategoryData = { ...categoryData, id: Date.now().toString() };
            setFundCategories([...fundCategories, newCategory]);
            addToast('নতুন ক্যাটাগরি সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        setIsCategoryModalOpen(false);
        setSelectedCategory(null);
    };

    // --- Fund Head Handlers ---
    const handleAddNewHead = () => {
        setSelectedHead(null);
        setIsHeadModalOpen(true);
    };
    const handleEditHead = (head: FundHeadData) => {
        setSelectedHead(head);
        setIsHeadModalOpen(true);
    };
    const handleDeleteHead = (head: FundHeadData) => {
        setSelectedHead(head);
        setIsDeleteHeadModalOpen(true);
    };
    const handleConfirmDeleteHead = () => {
        if (selectedHead) {
            setFundHeads(fundHeads.filter(fh => fh.id !== selectedHead.id));
            addToast('খাত সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteHeadModalOpen(false);
        setSelectedHead(null);
    };
    const handleSaveHead = (headData: Omit<FundHeadData, 'id'> & { id?: string }) => {
        if (headData.id) {
            setFundHeads(fundHeads.map(fh => fh.id === headData.id ? { ...fh, ...headData } as FundHeadData : fh));
            addToast('খাত সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else {
            const newHead: FundHeadData = { ...headData, id: Date.now().toString() };
            setFundHeads([...fundHeads, newHead]);
            addToast('নতুন খাত সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        setIsHeadModalOpen(false);
        setSelectedHead(null);
    };

    const filteredHeads = useMemo(() => 
        fundHeads.filter(head => head.type === (activeTab === 'incomeHeads' ? 'Income' : 'Expense')),
        [fundHeads, activeTab]
    );

    const getHeaderButton = () => {
        switch (activeTab) {
            case 'categories':
                return <button onClick={handleAddNewCategory} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors flex items-center gap-2"><PlusIcon className="w-5 h-5"/><span>নতুন ক্যাটাগরি যোগ করুন</span></button>;
            case 'incomeHeads':
                return <button onClick={handleAddNewHead} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors flex items-center gap-2"><PlusIcon className="w-5 h-5"/><span>নতুন আয়ের খাত যোগ করুন</span></button>;
            case 'expenseHeads':
                return <button onClick={handleAddNewHead} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors flex items-center gap-2"><PlusIcon className="w-5 h-5"/><span>নতুন ব্যয়ের খাত যোগ করুন</span></button>;
            default:
                return null;
        }
    };

    return (
        <div>
            <PageHeader icon="🏦" title="তহবিল ব্যবস্থাপনা">
                {getHeaderButton()}
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="border-b border-gray-200 mb-4">
                    <nav className="-mb-px flex space-x-6" aria-label="Tabs">
                        <button onClick={() => setActiveTab('categories')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'categories' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>তহবিল ক্যাটাগরি</button>
                        <button onClick={() => setActiveTab('incomeHeads')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'incomeHeads' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>আয়ের খাত</button>
                        <button onClick={() => setActiveTab('expenseHeads')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'expenseHeads' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>ব্যয়ের খাত</button>
                    </nav>
                </div>

                {activeTab === 'categories' && (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">ক্যাটাগরির নাম</th>
                                    <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                                </tr>
                            </thead>
                            <tbody>
                                {fundCategories.length > 0 ? fundCategories.map(category => (
                                    <tr key={category.id} className="bg-white border-b hover:bg-gray-50">
                                        <td className="px-6 py-4 font-medium text-gray-900">{category.name}</td>
                                        <td className="px-6 py-4 text-right space-x-2">
                                            <button onClick={() => handleEditCategory(category)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button>
                                            <button onClick={() => handleDeleteCategory(category)} className="p-2 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button>
                                        </td>
                                    </tr>
                                )) : (
                                    <tr><td colSpan={2} className="text-center py-10 text-gray-500">কোনো তহবিল ক্যাটাগরি যোগ করা হয়নি।</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                )}
                {(activeTab === 'incomeHeads' || activeTab === 'expenseHeads') && (
                     <div className="overflow-x-auto">
                        <table className="w-full text-sm text-left text-gray-500">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th scope="col" className="px-6 py-3">খাতের নাম</th>
                                    <th scope="col" className="px-6 py-3">তহবিল ক্যাটাগরি</th>
                                    <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredHeads.length > 0 ? filteredHeads.map(head => (
                                    <tr key={head.id} className="bg-white border-b hover:bg-gray-50">
                                        <td className="px-6 py-4 font-medium text-gray-900">{head.name}</td>
                                        <td className="px-6 py-4 text-gray-600">{fundCategoryMap.get(head.fundCategoryId) || 'অজানা'}</td>
                                        <td className="px-6 py-4 text-right space-x-2">
                                            <button onClick={() => handleEditHead(head)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button>
                                            <button onClick={() => handleDeleteHead(head)} className="p-2 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button>
                                        </td>
                                    </tr>
                                )) : (
                                    <tr><td colSpan={3} className="text-center py-10 text-gray-500">কোনো {activeTab === 'incomeHeads' ? 'আয়ের' : 'ব্যয়ের'} খাত যোগ করা হয়নি।</td></tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
            
            <FundCategoryModal isOpen={isCategoryModalOpen} onClose={() => setIsCategoryModalOpen(false)} onSave={handleSaveCategory} categoryToEdit={selectedCategory} />
            <Modal isOpen={isDeleteCategoryModalOpen} onClose={() => setIsDeleteCategoryModalOpen(false)} onConfirm={handleConfirmDeleteCategory} title="ক্যাটাগরি মুছে ফেলুন"><p>আপনি কি নিশ্চিতভাবে এই ক্যাটাগরিটি মুছে ফেলতে চান?</p></Modal>
            
            <FundHeadModal 
                isOpen={isHeadModalOpen} 
                onClose={() => setIsHeadModalOpen(false)} 
                onSave={handleSaveHead} 
                headToEdit={selectedHead} 
                fundCategories={fundCategories} 
                defaultType={activeTab === 'incomeHeads' ? 'Income' : 'Expense'} 
                hideTypeSelection={true} 
            />
            <Modal isOpen={isDeleteHeadModalOpen} onClose={() => setIsDeleteHeadModalOpen(false)} onConfirm={handleConfirmDeleteHead} title="খাত মুছে ফেলুন"><p>আপনি কি নিশ্চিতভাবে এই খাতটি মুছে ফেলতে চান?</p></Modal>
        </div>
    );
};

export default FundCategory;
