
import React, { useState, useRef } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { TrashIcon, DownloadIcon, UploadIcon, ExclamationCircleIcon } from '../../../components/icons';
import { useInstitution } from '../../../context/InstitutionContext';
import { MOCK_INSTITUTION_DATA } from '../../../data/mockData';
import { useAuth } from '../../../context/AuthContext';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../../../services/firebase';

// Simple obfuscation using Base64 that supports Unicode characters (like Bengali).
const encryptData = (data: object): string => {
    try {
        const jsonString = JSON.stringify(data);
        // First, encode the string into a percent-encoded UTF-8 sequence.
        // Then, convert this sequence into raw bytes that btoa can process.
        return btoa(encodeURIComponent(jsonString).replace(/%([0-9A-F]{2})/g,
            (match, p1) => String.fromCharCode(parseInt(p1, 16))
        ));
    } catch (error) {
        console.error("Encryption failed:", error);
        return '';
    }
};

const decryptData = (encrypted: string): object | null => {
    try {
        // The reverse process: from Base64 to a byte stream, then to percent-encoding,
        // and finally decode it back to the original UTF-8 string.
        const jsonString = decodeURIComponent(atob(encrypted).split('').map((c) => {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonString);
    } catch (error) {
        console.error("Decryption failed:", error);
        return null;
    }
};


const DatabaseBackup: React.FC = () => {
    const { addToast } = useNotification();
    const institutionData = useInstitution();
    const { user, institutionId } = useAuth();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [resetModalOpen, setResetModalOpen] = useState(false);
    const [restoreModalOpen, setRestoreModalOpen] = useState(false);
    const [uploadedData, setUploadedData] = useState<object | null>(null);

    const handleCreateAndDownloadBackup = () => {
        const dataToBackup: { [key: string]: any } = {};
        Object.keys(MOCK_INSTITUTION_DATA).forEach(key => {
            if (institutionData.hasOwnProperty(key)) {
                dataToBackup[key] = (institutionData as any)[key];
            }
        });
        
        const encryptedData = encryptData(dataToBackup);
        if (!encryptedData) {
            addToast("ব্যাকআপ ফাইল তৈরি করতে ব্যর্থ হয়েছে!", "error");
            return;
        }

        const blob = new Blob([encryptedData], { type: 'application/octet-stream' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        const date = new Date().toISOString().split('T')[0];
        a.download = `backup-${user?.institutionCode || 'data'}-${date}.ebg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        addToast('ব্যাকআপ ফাইল ডাউনলোড হচ্ছে...', 'success');
    };

    const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            if (!file.name.endsWith('.ebg')) {
                addToast('অবৈধ ফাইল টাইপ। শুধুমাত্র .ebg ফাইল আপলোড করুন।', 'error');
                return;
            }
            const reader = new FileReader();
            reader.onload = (e) => {
                const content = e.target?.result as string;
                const decrypted = decryptData(content);
                if (decrypted) {
                    setUploadedData(decrypted);
                    setRestoreModalOpen(true);
                } else {
                    addToast('ব্যাকআপ ফাইলটি অবৈধ বা করাপ্টেড।', 'error');
                }
            };
            reader.readAsText(file);
        }
        // Reset file input to allow re-uploading the same file
        event.target.value = '';
    };

    const handleRestoreFromFile = async () => {
        if (!uploadedData || !institutionId) {
            addToast("পুনরুদ্ধার করার জন্য কোনো ডাটা নেই!", "error");
            return;
        }

        try {
            const docRef = doc(db, 'institutionData', institutionId);
            await setDoc(docRef, uploadedData);
            addToast('ডাটা সফলভাবে পুনরুদ্ধার করা হয়েছে! পৃষ্ঠা রিলোড হচ্ছে...', 'success');
            setTimeout(() => window.location.reload(), 1500);
        } catch (error) {
            console.error("Failed to restore data to Firestore:", error);
            addToast("ডাটা পুনরুদ্ধার করতে ব্যর্থ হয়েছে!", "error");
        }
        setRestoreModalOpen(false);
        setUploadedData(null);
    };

    const handleResetToDefault = async () => {
        if (!institutionId) {
            addToast("প্রতিষ্ঠান সনাক্ত করা যায়নি!", "error");
            return;
        }

        try {
            const docRef = doc(db, 'institutionData', institutionId);
            const resetData = { ...MOCK_INSTITUTION_DATA, lastResetTimestamp: new Date().toISOString() };
            await setDoc(docRef, resetData);
            addToast('ডাটা সফলভাবে রিসেট করা হয়েছে! পৃষ্ঠা রিলোড হচ্ছে...', 'success');
            setTimeout(() => window.location.reload(), 1500);
        } catch (error) {
            console.error("Failed to reset data in Firestore:", error);
            addToast("ডাটা রিসেট করতে ব্যর্থ হয়েছে!", "error");
        }
        setResetModalOpen(false);
    };

    return (
        <div>
            <PageHeader icon="🔄" title="ডাটাবেস ব্যাকআপ / রিস্টোর" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-4xl mx-auto space-y-8">
                
                {/* Section 1: Create & Download Backup */}
                <div className="p-4 border rounded-lg">
                    <h2 className="text-lg font-bold text-gray-800">ব্যাকআপ তৈরি ও ডাউনলোড</h2>
                    <p className="text-sm text-gray-500 my-2">আপনার বর্তমান সকল প্রাতিষ্ঠানিক ডাটার একটি এনক্রিপটেড কপি (.ebg ফাইল) ডাউনলোড করুন। এই ফাইলটি পরবর্তীতে ডাটা পুনরুদ্ধারের জন্য ব্যবহার করা যাবে।</p>
                    <button onClick={handleCreateAndDownloadBackup} className="px-5 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors inline-flex items-center gap-2">
                        <DownloadIcon className="w-5 h-5" />
                        এখনই ব্যাকআপ নিন
                    </button>
                </div>

                {/* Section 2: Restore from Backup File */}
                <div className="p-4 border rounded-lg">
                    <h2 className="text-lg font-bold text-gray-800">ব্যাকআপ থেকে রিস্টোর</h2>
                    <p className="text-sm text-gray-500 my-2">পূর্বে ডাউনলোড করা একটি .ebg ফাইল আপলোড করে আপনার প্রতিষ্ঠানের সকল তথ্য পুনরুদ্ধার করুন।</p>
                    <input type="file" accept=".ebg" ref={fileInputRef} onChange={handleFileSelect} className="hidden" />
                    <button onClick={() => fileInputRef.current?.click()} className="px-5 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors inline-flex items-center gap-2">
                        <UploadIcon className="w-5 h-5" />
                        ফাইল থেকে রিস্টোর করুন
                    </button>
                </div>

                {/* Section 3: Reset Data */}
                <div className="p-4 border border-red-300 bg-red-50 rounded-lg">
                    <h2 className="text-lg font-bold text-red-800 flex items-center gap-2">
                        <ExclamationCircleIcon className="w-6 h-6" />
                        সকল ডাটা রিসেট করুন
                    </h2>
                    <p className="text-sm text-red-700 my-2">সাবধান! এই কাজটি আপনার প্রতিষ্ঠানের সকল ডাটা (শিক্ষার্থী, শিক্ষক, ফি, ফলাফল ইত্যাদি) স্থায়ীভাবে মুছে ফেলবে এবং সিস্টেমটিকে প্রাথমিক অবস্থায় ফিরিয়ে আনবে। শুধুমাত্র ডিফল্ট সেটিংস باقی থাকবে।</p>
                    <button onClick={() => setResetModalOpen(true)} className="px-5 py-2 bg-red-600 text-white font-semibold rounded-lg shadow-md hover:bg-red-700 transition-colors inline-flex items-center gap-2">
                        <TrashIcon className="w-5 h-5" />
                        সব ডাটা রিসেট করুন
                    </button>
                </div>
            </div>
            
            <Modal isOpen={restoreModalOpen} onClose={() => setRestoreModalOpen(false)} onConfirm={handleRestoreFromFile} title="ডাটা পুনরুদ্ধার নিশ্চিত করুন">
                <p className="font-semibold text-red-600">সতর্কতা: এই কাজটি আপনার বর্তমান সকল ডাটা মুছে ফেলে নির্বাচিত ব্যাকআপ ফাইলের ডাটা দিয়ে প্রতিস্থাপন করবে।</p>
                <p className="mt-2">আপনি কি নিশ্চিতভাবে ডাটা পুনরুদ্ধার করতে চান?</p>
            </Modal>
            
            <Modal isOpen={resetModalOpen} onClose={() => setResetModalOpen(false)} onConfirm={handleResetToDefault} title="ডাটা রিসেট নিশ্চিত করুন">
                 <p className="font-semibold text-red-600">সতর্কতা: আপনি কি নিশ্চিতভাবে সকল ডাটা মুছে ফেলতে চান? এই কাজটি ফিরিয়ে আনা যাবে না।</p>
            </Modal>
        </div>
    );
};

export default DatabaseBackup;
