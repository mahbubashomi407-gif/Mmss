
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import ToggleSwitch from '../../../components/ToggleSwitch';
import { useInstitution, NotificationSettingsData, SmsTemplatesData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

type TemplateKey = keyof SmsTemplatesData;

const templateInfo: Record<TemplateKey, { label: string; placeholders: string[] }> = {
    studentArrival: { label: 'শিক্ষার্থী আগমন', placeholders: ['{{student_name}}', '{{time}}', '{{institution_name}}'] },
    studentDeparture: { label: 'শিক্ষার্থী প্রস্থান', placeholders: ['{{student_name}}', '{{time}}', '{{institution_name}}'] },
    studentAbsence: { label: 'শিক্ষার্থী অনুপস্থিতি', placeholders: ['{{student_name}}', '{{class}}', '{{date}}', '{{institution_name}}'] },
    newNotice: { label: 'নতুন নোটিশ', placeholders: ['{{institution_name}}'] },
    feeDue: { label: 'ফি বকেয়া', placeholders: ['{{student_name}}', '{{month}}', '{{amount}}', '{{institution_name}}'] },
    feePayment: { label: 'ফি আদায়', placeholders: ['{{student_name}}', '{{amount}}', '{{institution_name}}'] },
    resultsPublished: { label: 'ফলাফল প্রকাশ', placeholders: ['{{exam_name}}', '{{institution_name}}'] },
};


const AutomaticNotifications: React.FC = () => {
    const { notificationSettings, setNotificationSettings, smsTemplates, setSmsTemplates, appNotificationTemplates, setAppNotificationTemplates } = useInstitution();
    const { addToast } = useNotification();

    const [settings, setSettings] = useState<NotificationSettingsData>(notificationSettings);
    const [sms, setSms] = useState<SmsTemplatesData>(smsTemplates);
    const [app, setApp] = useState<SmsTemplatesData>(appNotificationTemplates);
    
    const hasUnsavedChanges = useMemo(() => 
        JSON.stringify(settings) !== JSON.stringify(notificationSettings) ||
        JSON.stringify(sms) !== JSON.stringify(smsTemplates) ||
        JSON.stringify(app) !== JSON.stringify(appNotificationTemplates), 
    [settings, notificationSettings, sms, smsTemplates, app, appNotificationTemplates]);


    const handleSmsGatewayChange = (field: keyof NotificationSettingsData['smsGateway'], value: any) => {
        setSettings(prev => ({ ...prev, smsGateway: { ...prev.smsGateway, [field]: value } }));
    };

    const handleAutoNotificationChange = (key: TemplateKey, type: 'sms' | 'app', value: boolean) => {
        setSettings(prev => ({
            ...prev,
            automaticNotifications: { ...prev.automaticNotifications, [key]: { ...prev.automaticNotifications[key], [type]: value } }
        }));
    };

    const handleSmsTemplateChange = (key: TemplateKey, value: string) => {
        setSms(prev => ({...prev, [key]: value}));
    };
    
    const handleAppTemplateChange = (key: TemplateKey, value: string) => {
        setApp(prev => ({...prev, [key]: value}));
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setNotificationSettings(settings);
        setSmsTemplates(sms);
        setAppNotificationTemplates(app);
        addToast('সেটিংস সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };
    
    const handleReset = () => {
        setSettings(notificationSettings);
        setSms(smsTemplates);
        setApp(appNotificationTemplates);
        addToast('পরিবর্তন বাতিল করা হয়েছে।', 'error');
    };
    
    return (
        <div>
            <PageHeader icon="💬" title="স্বয়ংক্রিয় SMS ও নোটিফিকেশন" />

            <form onSubmit={handleSubmit} className="max-w-4xl mx-auto space-y-8">
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <h2 className="text-lg font-bold text-gray-800 border-b pb-3 mb-4">SMS গেটওয়ে সেটিংস</h2>
                    <div className="space-y-4">
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <label className="font-medium text-gray-700">SMS গেটওয়ে সক্রিয় করুন</label>
                            <ToggleSwitch enabled={settings.smsGateway.enabled} onChange={value => handleSmsGatewayChange('enabled', value)} />
                        </div>
                        {settings.smsGateway.enabled && (
                            <>
                                <div>
                                    <label htmlFor="apiKey" className="block text-sm font-medium text-gray-700">API Key</label>
                                    <input id="apiKey" type="text" value={settings.smsGateway.apiKey} onChange={e => handleSmsGatewayChange('apiKey', e.target.value)} className="mt-1 w-full p-2 border rounded-md" />
                                </div>
                                <div>
                                    <label htmlFor="senderId" className="block text-sm font-medium text-gray-700">Sender ID</label>
                                    <input id="senderId" type="text" value={settings.smsGateway.senderId} onChange={e => handleSmsGatewayChange('senderId', e.target.value)} className="mt-1 w-full p-2 border rounded-md" />
                                </div>
                            </>
                        )}
                    </div>
                </div>

                {Object.entries(templateInfo).map(([key, info]) => {
                    const typedKey = key as TemplateKey;
                    return (
                        <div key={key} className="bg-white p-6 rounded-xl shadow-md">
                            <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">{info.label}</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                {/* SMS Column */}
                                <div className="space-y-2">
                                    <div className="flex items-center justify-between">
                                        <label className="font-semibold text-gray-700">SMS নোটিফিকেশন</label>
                                        <ToggleSwitch 
                                            enabled={settings.automaticNotifications[typedKey].sms} 
                                            onChange={value => handleAutoNotificationChange(typedKey, 'sms', value)}
                                            disabled={!settings.smsGateway.enabled}
                                        />
                                    </div>
                                    <textarea
                                        value={sms[typedKey]}
                                        onChange={e => handleSmsTemplateChange(typedKey, e.target.value)}
                                        rows={4}
                                        className="w-full p-2 border rounded-md text-sm disabled:bg-gray-100"
                                        disabled={!settings.smsGateway.enabled}
                                    />
                                     <div className="text-xs text-gray-500">
                                        <span className="font-semibold">ভেরিয়েবল:</span>
                                        <div className="flex flex-wrap gap-x-2 gap-y-1 mt-1">
                                            {info.placeholders.map(p => (
                                                <code key={p} className="bg-gray-200 px-1.5 py-0.5 rounded text-gray-700">{p}</code>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                {/* App Notification Column */}
                                <div className="space-y-2">
                                     <div className="flex items-center justify-between">
                                        <label className="font-semibold text-gray-700">App নোটিফিকেশন</label>
                                        <ToggleSwitch 
                                            enabled={settings.automaticNotifications[typedKey].app} 
                                            onChange={value => handleAutoNotificationChange(typedKey, 'app', value)}
                                        />
                                    </div>
                                    <textarea
                                        value={app[typedKey]}
                                        onChange={e => handleAppTemplateChange(typedKey, e.target.value)}
                                        rows={4}
                                        className="w-full p-2 border rounded-md text-sm"
                                    />
                                    <div className="text-xs text-gray-500">
                                        <span className="font-semibold">ভেরিয়েবল:</span>
                                        <div className="flex flex-wrap gap-x-2 gap-y-1 mt-1">
                                             {info.placeholders.map(p => (
                                                <code key={p} className="bg-gray-200 px-1.5 py-0.5 rounded text-gray-700">{p}</code>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    );
                })}

                 <div className="flex justify-end gap-3 pt-4">
                    {hasUnsavedChanges && (
                         <button type="button" onClick={handleReset} className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600">
                            বাতিল
                        </button>
                    )}
                    <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">
                        সংরক্ষণ করুন
                    </button>
                </div>
            </form>
        </div>
    );
};
export default AutomaticNotifications;
