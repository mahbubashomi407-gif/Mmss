import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, LeaveApplicationData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { EyeIcon, CheckCircleIcon, TrashIcon } from '../../../components/icons';

const LeaveApplications: React.FC = () => {
    const { leaveApplications, setLeaveApplications } = useInstitution();
    const { addToast } = useNotification();

    const [filter, setFilter] = useState<'Pending' | 'All'>('Pending');
    const [confirmModal, setConfirmModal] = useState<{ isOpen: boolean; action: 'Approve' | 'Reject'; application: LeaveApplicationData | null }>({ isOpen: false, action: 'Approve', application: null });
    const [viewModal, setViewModal] = useState<{isOpen: boolean, application: LeaveApplicationData | null}>({isOpen: false, application: null});

    const filteredApplications = useMemo(() => {
        const sorted = [...leaveApplications].sort((a, b) => new Date(b.applicationDate).getTime() - new Date(a.applicationDate).getTime());
        if (filter === 'All') return sorted;
        return sorted.filter(app => app.status === filter);
    }, [leaveApplications, filter]);

    const handleStatusChange = () => {
        if (!confirmModal.application) return;
        const newStatus = confirmModal.action === 'Approve' ? 'Approved' : 'Rejected';
        setLeaveApplications(leaveApplications.map(app => 
            app.id === confirmModal.application!.id ? { ...app, status: newStatus } : app
        ));
        addToast(`আবেদনটি সফলভাবে ${newStatus === 'Approved' ? 'অনুমোদিত' : 'প্রত্যাখ্যাত'} হয়েছে!`, 'success');
        setConfirmModal({ isOpen: false, action: 'Approve', application: null });
    };
    
    const getStatusBadge = (status: LeaveApplicationData['status']) => {
        switch (status) {
            case 'Pending':
                return 'bg-yellow-100 text-yellow-800';
            case 'Approved':
                return 'bg-green-100 text-green-800';
            case 'Rejected':
                return 'bg-red-100 text-red-800';
            default:
                return 'bg-gray-100 text-gray-800';
        }
    };
    
    const getStatusText = (status: LeaveApplicationData['status']) => {
        switch (status) {
            case 'Pending': return 'অপেক্ষমান';
            case 'Approved': return 'অনুমোদিত';
            case 'Rejected': return 'প্রত্যাখ্যাত';
        }
    }
    
    const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString('bn-BD');

    return (
        <div>
            <PageHeader icon="📝" title="ছুটি / অনুপস্থিতি আবেদন" />

            <div className="bg-white p-4 rounded-xl shadow-md mb-6 flex items-center justify-between">
                <div className="flex items-center gap-2">
                    <button onClick={() => setFilter('Pending')} className={`px-4 py-2 text-sm font-semibold rounded-lg ${filter === 'Pending' ? 'bg-teal-600 text-white' : 'bg-gray-200 text-gray-700'}`}>অপেক্ষমান ({leaveApplications.filter(a => a.status === 'Pending').length})</button>
                    <button onClick={() => setFilter('All')} className={`px-4 py-2 text-sm font-semibold rounded-lg ${filter === 'All' ? 'bg-teal-600 text-white' : 'bg-gray-200 text-gray-700'}`}>সকল আবেদন</button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-4 py-2">শিক্ষকের নাম</th>
                                <th className="px-4 py-2">আবেদনের তারিখ</th>
                                <th className="px-4 py-2">ছুটির সময়কাল</th>
                                <th className="px-4 py-2">কারণ (সংক্ষিপ্ত)</th>
                                <th className="px-4 py-2">স্ট্যাটাস</th>
                                <th className="px-4 py-2 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredApplications.length > 0 ? filteredApplications.map(app => (
                                <tr key={app.id} className="border-b hover:bg-gray-50">
                                    <td className="px-4 py-2 font-medium">{app.teacherName}</td>
                                    <td className="px-4 py-2">{formatDate(app.applicationDate)}</td>
                                    <td className="px-4 py-2">{formatDate(app.leaveStartDate)} - {formatDate(app.leaveEndDate)}</td>
                                    <td className="px-4 py-2 text-gray-600 truncate max-w-xs">{app.reason}</td>
                                    <td className="px-4 py-2"><span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(app.status)}`}>{getStatusText(app.status)}</span></td>
                                    <td className="px-4 py-2 text-right space-x-1">
                                        <button onClick={() => setViewModal({isOpen: true, application: app})} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="বিস্তারিত দেখুন"><EyeIcon className="w-4 h-4" /></button>
                                        {app.status === 'Pending' && (
                                            <>
                                                <button onClick={() => setConfirmModal({isOpen: true, action: 'Approve', application: app})} className="p-2 text-green-600 hover:bg-green-100 rounded-full" title="অনুমোদন করুন"><CheckCircleIcon className="w-4 h-4" /></button>
                                                <button onClick={() => setConfirmModal({isOpen: true, action: 'Reject', application: app})} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="প্রত্যাখ্যান করুন"><TrashIcon className="w-4 h-4" /></button>
                                            </>
                                        )}
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={6} className="text-center py-10 text-gray-500">কোনো ছুটির আবেদন পাওয়া যায়নি।</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <Modal 
                isOpen={confirmModal.isOpen} 
                onClose={() => setConfirmModal({ isOpen: false, action: 'Approve', application: null })} 
                onConfirm={handleStatusChange}
                title={`আবেদন ${confirmModal.action === 'Approve' ? 'অনুমোদন' : 'প্রত্যাখ্যান'} করুন`}
            >
                <p>আপনি কি নিশ্চিতভাবে এই ছুটির আবেদনটি {confirmModal.action === 'Approve' ? 'অনুমোদন' : 'প্রত্যাখ্যান'} করতে চান?</p>
            </Modal>
            
            {viewModal.isOpen && viewModal.application && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setViewModal({isOpen: false, application: null})}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                        <div className="p-5 border-b"><h3 className="text-lg font-bold">ছুটির আবেদনের বিস্তারিত</h3></div>
                        <div className="p-5 space-y-3 text-sm">
                            <p><strong>শিক্ষক:</strong> {viewModal.application.teacherName}</p>
                            <p><strong>আবেদনের তারিখ:</strong> {formatDate(viewModal.application.applicationDate)}</p>
                            <p><strong>ছুটির সময়কাল:</strong> {formatDate(viewModal.application.leaveStartDate)} থেকে {formatDate(viewModal.application.leaveEndDate)}</p>
                            <div><strong>কারণ:</strong><p className="p-2 bg-gray-50 rounded mt-1 whitespace-pre-wrap">{viewModal.application.reason}</p></div>
                             <p><strong>স্ট্যাটাস:</strong> <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(viewModal.application.status)}`}>{getStatusText(viewModal.application.status)}</span></p>
                        </div>
                        <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                             {viewModal.application.status === 'Pending' && (
                                <>
                                    <button onClick={() => { setViewModal({isOpen: false, application: null}); setConfirmModal({isOpen: true, action: 'Reject', application: viewModal.application}); }} className="px-4 py-2 bg-red-600 text-white font-semibold rounded-lg hover:bg-red-700">প্রত্যাখ্যান</button>
                                    <button onClick={() => { setViewModal({isOpen: false, application: null}); setConfirmModal({isOpen: true, action: 'Approve', application: viewModal.application}); }} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg hover:bg-green-700">অনুমোদন</button>
                                </>
                            )}
                            <button type="button" onClick={() => setViewModal({isOpen: false, application: null})} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বন্ধ করুন</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default LeaveApplications;