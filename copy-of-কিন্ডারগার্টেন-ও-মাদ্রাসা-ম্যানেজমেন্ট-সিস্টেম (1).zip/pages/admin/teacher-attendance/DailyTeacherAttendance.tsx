import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

type AttendanceStatus = 'Present' | 'Absent' | 'On Leave';

const DailyTeacherAttendance: React.FC = () => {
    const { teachers, teacherAttendanceRecords, setTeacherAttendanceRecords } = useInstitution();
    const { addToast } = useNotification();

    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [attendance, setAttendance] = useState<Record<string, AttendanceStatus>>({});
    const [initialAttendance, setInitialAttendance] = useState<Record<string, AttendanceStatus>>({});

    useEffect(() => {
        const recordsForDate = teacherAttendanceRecords.filter(rec => rec.date === selectedDate);
        const newAttendanceState: Record<string, AttendanceStatus> = {};

        teachers.forEach(teacher => {
            const record = recordsForDate.find(rec => rec.teacherId === teacher.id);
            newAttendanceState[teacher.id] = record ? record.status : 'Present';
        });

        setAttendance(newAttendanceState);
        setInitialAttendance(newAttendanceState); // Store initial state for change detection
    }, [selectedDate, teachers, teacherAttendanceRecords]);
    
    const hasUnsavedChanges = useMemo(() => {
        return JSON.stringify(attendance) !== JSON.stringify(initialAttendance);
    }, [attendance, initialAttendance]);

    const handleStatusChange = (teacherId: string, status: AttendanceStatus) => {
        setAttendance(prev => ({ ...prev, [teacherId]: status }));
    };

    const handleMarkAll = (status: AttendanceStatus) => {
        const newAttendanceState: Record<string, AttendanceStatus> = {};
        teachers.forEach(teacher => {
            newAttendanceState[teacher.id] = status;
        });
        setAttendance(newAttendanceState);
    };

    const handleSubmit = () => {
        const otherDateRecords = teacherAttendanceRecords.filter(rec => rec.date !== selectedDate);
        const newRecordsForDate = Object.entries(attendance).map(([teacherId, status]) => ({
            id: `${teacherId}-${selectedDate}`,
            teacherId,
            date: selectedDate,
            status,
        }));
        
        setTeacherAttendanceRecords([...otherDateRecords, ...newRecordsForDate]);
        setInitialAttendance(attendance); // Update initial state after saving
        addToast('শিক্ষকদের হাজিরা সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };

    const attendanceSummary = useMemo(() => {
        let present = 0, absent = 0, onLeave = 0;
        Object.values(attendance).forEach(status => {
            if (status === 'Present') present++;
            if (status === 'Absent') absent++;
            if (status === 'On Leave') onLeave++;
        });
        return { present, absent, onLeave };
    }, [attendance]);
    
    const StatusRadioButton: React.FC<{ teacherId: string; status: AttendanceStatus; label: string; color: string; }> = ({ teacherId, status, label, color }) => (
        <label className="flex items-center cursor-pointer">
            <input
                type="radio"
                name={`attendance-${teacherId}`}
                checked={attendance[teacherId] === status}
                onChange={() => handleStatusChange(teacherId, status)}
                className={`form-radio h-4 w-4 ${color}`}
            />
            <span className={`ml-2 text-sm`}>{label}</span>
        </label>
    );

    return (
        <div>
            <PageHeader icon="📅" title="দৈনিক শিক্ষক হাজিরা">
                {hasUnsavedChanges && (
                    <button onClick={handleSubmit} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700">
                        পরিবর্তন সংরক্ষণ করুন
                    </button>
                )}
            </PageHeader>

            <div className="bg-white p-4 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                        <label htmlFor="attendance-date" className="font-semibold text-sm">তারিখ:</label>
                        <input
                            id="attendance-date"
                            type="date"
                            value={selectedDate}
                            onChange={e => setSelectedDate(e.target.value)}
                            className="p-2 border rounded-md"
                        />
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                        <span>সবাইকে চিহ্নিত করুন:</span>
                        <button onClick={() => handleMarkAll('Present')} className="px-2 py-1 bg-green-100 text-green-700 rounded">উপস্থিত</button>
                        <button onClick={() => handleMarkAll('Absent')} className="px-2 py-1 bg-red-100 text-red-700 rounded">অনুপস্থিত</button>
                        <button onClick={() => handleMarkAll('On Leave')} className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded">ছুটিতে</button>
                    </div>
                </div>
                 <div className="grid grid-cols-3 gap-4 mt-4 text-center border-t pt-4">
                    <div className="p-2 bg-green-50 rounded-lg"><p className="text-sm text-green-600">উপস্থিত</p><p className="text-xl font-bold text-green-700">{attendanceSummary.present}</p></div>
                    <div className="p-2 bg-red-50 rounded-lg"><p className="text-sm text-red-600">অনুপস্থিত</p><p className="text-xl font-bold text-red-700">{attendanceSummary.absent}</p></div>
                    <div className="p-2 bg-yellow-50 rounded-lg"><p className="text-sm text-yellow-600">ছুটিতে</p><p className="text-xl font-bold text-yellow-700">{attendanceSummary.onLeave}</p></div>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {teachers.length > 0 ? (
                    <div className="space-y-3">
                        {teachers.map(teacher => (
                            <div key={teacher.id} className="flex flex-col sm:flex-row items-center justify-between p-3 bg-gray-50 rounded-lg">
                                <div className="flex items-center gap-3 mb-3 sm:mb-0">
                                    <img src={teacher.photoUrl || 'https://via.placeholder.com/40x40?text=T'} alt={teacher.nameBn} className="w-10 h-10 rounded-full object-cover"/>
                                    <div>
                                        <p className="font-semibold text-gray-800">{teacher.nameBn}</p>
                                        <p className="text-xs text-gray-500 font-mono">{teacher.uniqueId}</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-4">
                                    <StatusRadioButton teacherId={teacher.id} status="Present" label="উপস্থিত" color="text-green-600" />
                                    <StatusRadioButton teacherId={teacher.id} status="Absent" label="অনুপস্থিত" color="text-red-600" />
                                    <StatusRadioButton teacherId={teacher.id} status="On Leave" label="ছুটিতে" color="text-yellow-600" />
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">কোনো শিক্ষক যোগ করা হয়নি। অনুগ্রহ করে প্রথমে শিক্ষক যোগ করুন।</p>
                )}
            </div>
        </div>
    );
};

export default DailyTeacherAttendance;