
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, calculateGradeInfo, ExamData, GradeData, SubjectData } from '../../../context/InstitutionContext';
import { RefreshIcon, ChevronDownIcon, CalendarIcon }
 from '../../../components/icons';
import { useLocation } from 'react-router-dom';

const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        '.': '.', '%': '%'
    };
    return num.replace(/[0-9.%]/g, (match) => map[match] || match);
};

// Interfaces for report data structure
interface StudentResult {
    studentId: string;
    name: string;
    roll: number | '';
    classLevel: string;
    section: string;
    totalObtained: number;
    grade: string;
    gpa: number;
    rank: number;
    resultStatus: 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত' | 'Passed' | 'Failed';
    failedSubjectsCount: number;
    marksGivenCount: number; // New for Madrasa mode
}

interface ClassSummary {
    className: string;
    topStudents: StudentResult[];
    gradeCounts: Record<string, number>;
}

interface ReportData {
    overallGradeCounts: Record<string, number>;
    classSummaries: ClassSummary[];
    overallTopStudents: StudentResult[]; // Added for overall ranking
}

const ResultSummary: React.FC = () => {
    const location = useLocation();
    const isMadrasaMode = location.pathname.includes('madrasa-result');

    const { students, classLevels, exams, markRecords, institutionName, grades, logoUrl, address, academicSessions, madrasaGrades, madrasaResultSettings, madrasaExamTypes, setExams, managerInfo } = useInstitution();
    
    const currentGrades = isMadrasaMode ? madrasaGrades : grades;

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [examFilter, setExamFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState(''); // For Madrasa mode

    // State to hold the ID of the generic "মাদরাসা পরীক্ষা"
    const [madrasaExamId, setMadrasaExamId] = useState<string | null>(null);

    // Effect to ensure the generic "মাদরাসা পরীক্ষা" exists and its ID is set in madrasaExamId
    useEffect(() => {
        if (isMadrasaMode && academicYearFilter) {
            const genericMadrasaExamName = 'মাদরাসা পরীক্ষা';
            const existingMadrasaExam = exams.find(e => e.academicYear === academicYearFilter && e.name === genericMadrasaExamName);

            if (existingMadrasaExam) {
                setMadrasaExamId(existingMadrasaExam.id);
            } else {
                const newExam = {
                    id: `exam-madrasa-${academicYearFilter.replace(/[^0-9]/g, '')}-${Date.now()}`,
                    name: genericMadrasaExamName,
                    academicYear: academicYearFilter,
                    classLevels: classLevels.map(cl => cl.name),
                };
                // Use a functional update to ensure we're adding to the latest state
                setExams(prevExams => [...prevExams, newExam]);
                setMadrasaExamId(newExam.id);
            }
        } else {
            setMadrasaExamId(null); // Clear madrasaExamId if not in madrasa mode or year is not set
        }
    }, [isMadrasaMode, academicYearFilter, exams, setExams, classLevels]);

    // Effect to synchronize examFilter with madrasaExamId in madrasa mode
    useEffect(() => {
        if (isMadrasaMode && madrasaExamId) {
            setExamFilter(madrasaExamId);
        } else if (!isMadrasaMode && examFilter.startsWith('exam-madrasa')) {
            // If we switch away from madrasa mode and the madrasa exam was selected, clear it.
            setExamFilter('');
        }
    }, [isMadrasaMode, madrasaExamId, examFilter]);


    const availableExams = useMemo(() => {
        if (!academicYearFilter) return [];
        return exams.filter(e => e.academicYear === academicYearFilter);
    }, [academicYearFilter, exams]);

    const allFiltersSelected = academicYearFilter && (!isMadrasaMode || (madrasaExamId && examTypeFilter)) && (isMadrasaMode || examFilter);

    const reportData = useMemo<ReportData | null>(() => {
        if (!allFiltersSelected) return null;

        const selectedExam = exams.find(e => e.id === examFilter);
        if (!selectedExam) return null;
        
        const failGrade = currentGrades.find(g => g.gpa === 0);
        const failGradeName = failGrade?.name || (isMadrasaMode ? 'রাসিব' : 'F');


        const allStudentResults: StudentResult[] = [];

        students.forEach(student => {
            if (student.academicYear !== academicYearFilter || !selectedExam.classLevels.includes(student.classLevel) || student.status === 'পেন্ডিং') {
                return;
            }

            const allSubjectsForClass = classLevels.find(cl => cl.name === student.classLevel)?.subjects || [];
            
            const assignedSubjects = isMadrasaMode 
                ? selectedExam.madrasaSubjectAssignments?.[student.classLevel]?.[examTypeFilter]
                : selectedExam.subjectAssignments?.[student.classLevel];
            
            const relevantSubjects = Array.isArray(assignedSubjects) 
                ? allSubjectsForClass.filter(s => assignedSubjects.some((as: any) => as.subjectId === s.id))
                : [];

            if (relevantSubjects.length === 0) return;

            const studentMarks = markRecords.filter(m => 
                m.studentId === student.id && 
                m.examId === examFilter &&
                (isMadrasaMode ? m.examTypeId === examTypeFilter : true)
            );
            
            let totalObtained = 0;
            let totalMarks = 0;
            let marksGivenCount = 0;
            let failedSubjectsCount = 0;

            relevantSubjects.forEach(subject => {
                const mark = studentMarks.find(m => m.subjectId === subject.id);
                const obtained = mark?.marksObtained ?? null;
                
                let total = 100; // default
                if (isMadrasaMode) {
                    total = madrasaExamTypes.find(et => et.id === examTypeFilter)?.totalMarks || 100;
                } else if(assignedSubjects){
                    const assignment = (assignedSubjects as any[]).find(a => a.subjectId === subject.id);
                    total = assignment?.totalMarks || selectedExam?.defaultMarks || 100;
                }

                if (obtained !== null) {
                    marksGivenCount++;
                    totalObtained += obtained;
                    totalMarks += total;
                    const percentage = total > 0 ? (obtained / total) * 100 : 0;
                    if (calculateGradeInfo(percentage, currentGrades).gpa === 0) {
                        failedSubjectsCount++;
                    }
                }
            });
            
            let resultStatus: StudentResult['resultStatus'] = 'কৃতকার্য';
            let finalGrade = '';
            let finalGpa = 0;

            if (isMadrasaMode) {
                if (madrasaResultSettings.enableAbsentStatus && marksGivenCount === 0) {
                    resultStatus = 'অনুপস্থিত';
                    finalGrade = 'অনুপস্থিত';
                    finalGpa = 0;
                } else if (madrasaResultSettings.enableSuspendedStatus && marksGivenCount > 0 && marksGivenCount < relevantSubjects.length) {
                    resultStatus = 'স্থগিত';
                    finalGrade = 'স্থগিত';
                    finalGpa = 0;
                } else {
                    const overallPercentage = totalMarks > 0 ? (totalObtained / totalMarks) * 100 : 0;
                    const avgGradeInfo = calculateGradeInfo(overallPercentage, currentGrades);
                    // Base grade is determined by average
                    finalGrade = avgGradeInfo.grade;
                    finalGpa = avgGradeInfo.gpa;
                    resultStatus = avgGradeInfo.gpa > 0 ? 'কৃতকার্য' : 'অকৃতকার্য';
            
                    // Override with "Maqbul" if setting is on and conditions are met
                    const maqbulGradeInfo = currentGrades.find(g => g.name === 'মকবুল');
                    if (madrasaResultSettings.enableMaqbulOnSingleFail && failedSubjectsCount > 0 && avgGradeInfo.gpa > 0 && maqbulGradeInfo) {
                        finalGrade = maqbulGradeInfo.name;
                        finalGpa = maqbulGradeInfo.gpa;
                        resultStatus = 'কৃতকার্য'; // Maqbul is a pass
                    }
                }
            } else { // Academic Mode
                if (marksGivenCount === 0) {
                    resultStatus = 'অনুপস্থিত';
                    finalGrade = 'অনুপস্থিত';
                    finalGpa = 0;
                    failedSubjectsCount = relevantSubjects.length;
                } else {
                    const isFail = failedSubjectsCount > 0;
                    const avgGradeInfo = calculateGradeInfo(totalMarks > 0 ? (totalObtained / totalMarks) * 100 : 0, currentGrades);
                    resultStatus = isFail ? 'Failed' : 'Passed';
                    finalGrade = isFail ? failGradeName : avgGradeInfo.grade;
                    finalGpa = isFail ? 0 : avgGradeInfo.gpa;
                }
            }

            allStudentResults.push({
                studentId: student.id,
                name: student.nameBn,
                roll: student.roll,
                classLevel: student.classLevel,
                section: student.section,
                totalObtained,
                grade: finalGrade,
                gpa: finalGpa,
                resultStatus,
                rank: 0,
                failedSubjectsCount,
                marksGivenCount,
            });
        });

        const resultsByClass = new Map<string, StudentResult[]>();
        allStudentResults.forEach(res => {
            if (!resultsByClass.has(res.classLevel)) {
                resultsByClass.set(res.classLevel, []);
            }
            resultsByClass.get(res.classLevel)!.push(res);
        });

        resultsByClass.forEach((classResults) => {
            const sorted = classResults.sort((a, b) => {
                const statusOrder = { 'কৃতকার্য': 1, 'Passed': 1, 'অকৃতকার্য': 2, 'Failed': 2, 'স্থগিত': 3, 'অনুপস্থিত': 4 };
                const statusA = statusOrder[a.resultStatus] || 5;
                const statusB = statusOrder[b.resultStatus] || 5;
                if (statusA !== statusB) return statusA - statusB;
                if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
                return (a.roll || 999) - (b.roll || 999);
            });
            
            let rank = 0;
            let lastScore = -1;
            sorted.forEach((student, index) => {
                const studentGradeInfo = currentGrades.find(g => g.name === student.grade);
                const isEligibleForRank = (student.resultStatus === 'কৃতকার্য' || student.resultStatus === 'Passed') && 
                                          (!isMadrasaMode || (studentGradeInfo?.isRankable ?? false));

                if (isEligibleForRank) {
                    if (student.totalObtained !== lastScore) {
                        rank = index + 1;
                        lastScore = student.totalObtained;
                    }
                    student.rank = rank;
                }
            });
        });
        
        const overallGradeCounts: Record<string, number> = {};
        currentGrades.forEach(g => overallGradeCounts[g.name] = 0);

        const classSummaries: ClassSummary[] = [];
        
        resultsByClass.forEach((classResults, className) => {
            const gradeCounts: Record<string, number> = {};
            currentGrades.forEach(g => gradeCounts[g.name] = 0);

            classResults.forEach(res => {
                if (overallGradeCounts.hasOwnProperty(res.grade)) {
                    overallGradeCounts[res.grade]++;
                }
                if (gradeCounts.hasOwnProperty(res.grade)) {
                    gradeCounts[res.grade]++;
                }
            });
            
            const topStudents = classResults
                .filter(s => s.rank > 0 && s.rank <= 3)
                .sort((a,b) => a.rank - b.rank);

            classSummaries.push({
                className,
                topStudents,
                gradeCounts,
            });
        });
        
        classSummaries.sort((a, b) => {
            const indexA = classLevels.findIndex(cl => cl.name === a.className);
            const indexB = classLevels.findIndex(cl => cl.name === b.className);
            return indexA - indexB;
        });

        // --- NEW: Overall Ranking Calculation ---
        const overallRankableStudents: StudentResult[] = allStudentResults.filter(s => {
            const studentGradeInfo = currentGrades.find(g => g.name === s.grade);
            const isEligibleForRank = (s.resultStatus === 'কৃতকার্য' || s.resultStatus === 'Passed') &&
                                      (!isMadrasaMode || (studentGradeInfo?.isRankable ?? false));
            return isEligibleForRank;
        }).sort((a, b) => {
            if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
            return (a.roll || 999) - (b.roll || 999);
        });

        let overallRank = 0;
        let lastOverallScore = -1;
        overallRankableStudents.forEach((student, index) => {
            if (student.totalObtained !== lastOverallScore) {
                overallRank = index + 1;
                lastOverallScore = student.totalObtained;
            }
            student.rank = overallRank;
        });

        const overallTopStudents = overallRankableStudents.filter(s => s.rank > 0 && s.rank <= 3);

        return { overallGradeCounts, classSummaries, overallTopStudents };

    }, [academicYearFilter, examFilter, examTypeFilter, isMadrasaMode, exams, students, currentGrades, classLevels, markRecords, madrasaResultSettings, madrasaExamTypes, madrasaExamId]);
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-summary');
        if (!printContent) return;

        const examName = isMadrasaMode ? madrasaExamTypes.find(et => et.id === examTypeFilter)?.name || '' : exams.find(e => e.id === examFilter)?.name || '';
        const reportTitle = `ফলাফল সারসংক্ষেপ`;
        const subTitle = `পরীক্ষা: ${examName} | শিক্ষাবর্ষ: ${toBengaliNumber(academicYearFilter)}`;
        
        const printWindow = window.open('', '', 'height=800,width=1200');
        if (printWindow) {
            printWindow.document.write('<html><head>');
            printWindow.document.write(`<title>${reportTitle}</title>`);
            printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
            printWindow.document.write(`
                <style>
                    body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                    @page { size: A4 portrait; margin: 0.75in; }
                    .print-header { text-align: center; margin-bottom: 1.5rem; }
                    .print-header img { height: 60px; width: 60px; margin: 0 auto 0.5rem; border-radius: 9999px; object-fit: cover; }
                    .print-header h1 { font-size: 1.5rem; font-weight: bold; }
                    .print-header p { margin: 0.1rem 0; font-size: 0.8rem; }
                    .print-section { page-break-inside: avoid; margin-bottom: 1.5rem; }
                    h1, h2, h3, h4 { font-weight: bold; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border: 1px solid #ddd; padding: 4px; font-size: 12px; }
                    th { background-color: #f2f2f2 !important; text-align: center; }
                </style>
            `);
            printWindow.document.write('</head><body>');
            printWindow.document.write(`<div class="print-header">
                        ${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}
                        <h1>${institutionName}</h1>
                        <p>${`${address.upazila}, ${address.district}`}</p>
                        <h2>${reportTitle}</h2>
                        <p>${subTitle}</p>
                    </div>`);
            printWindow.document.write(printContent.innerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            setTimeout(() => {
                printWindow.focus();
                printWindow.print();
                printWindow.close();
            }, 750);
        }
    };
    
    const gradeColors: { [key: string]: string } = {
        'মুমতাজ': 'bg-green-100 text-green-800', 'জায়্যিদ জিদ্দান': 'bg-blue-100 text-blue-800',
        'জায়্যিদ': 'bg-teal-100 text-teal-800', 'মকবুল': 'bg-orange-100 text-orange-800',
        'রাসিব': 'bg-red-110 text-red-800', 'A+': 'bg-green-100 text-green-800', 
        'A': 'bg-blue-100 text-blue-800', 'A-': 'bg-teal-100 text-teal-800', 
        'B': 'bg-indigo-100 text-indigo-800', 'C': 'bg-purple-100 text-purple-800', 
        'D': 'bg-yellow-100 text-yellow-800', 'F': 'bg-red-100 text-red-800',
        'অনুপস্থিত': 'bg-gray-100 text-gray-800', 'স্থগিত': 'bg-yellow-100 text-yellow-800',
    };

    return (
        <div>
            <PageHeader icon="📈" title={isMadrasaMode ? "মাদরাসা ফলাফল সামারি" : "ফলাফল সামারি"} />
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                 <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    {isMadrasaMode ? null : ( // Removed the select dropdown for madrasa mode entirely
                        <div className="relative flex-grow">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span>
                            <select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!academicYearFilter}><option value="">পরীক্ষা নির্বাচন করুন</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
                            <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span>
                        </div>
                    )}
                    {isMadrasaMode && (
                        <div className="relative flex-grow">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span>
                            <select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!madrasaExamId}>
                                <option value="">পরীক্ষার ধরণ নির্বাচন করুন</option>
                                {madrasaExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}
                            </select>
                            <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span>
                        </div>
                    )}
                </div>
            </div>

            {allFiltersSelected && reportData ? (
                 <div className="bg-white p-6 rounded-xl shadow-md text-center">
                    <h3 className="text-xl font-bold text-green-600">ফলাফল সারসংক্ষেপ তৈরী হয়েছে।</h3>
                    <p className="text-gray-600 my-4">প্রিন্ট করতে নিচের বাটনে ক্লিক করুন।</p>
                    <button onClick={handlePrint} className="px-6 py-3 bg-teal-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-teal-700">
                        সারসংক্ষেপ প্রিন্ট করুন
                    </button>
                </div>
            ) : (
                <div className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">
                    <p>
                        সারসংক্ষেপ দেখতে অনুগ্রহ করে বর্ষ
                        {isMadrasaMode ? ' এবং পরীক্ষার ধরণ' : ' ও পরীক্ষা'}
                        নির্বাচন করুন।
                    </p>
                </div>
            )}
            
            {/* Hidden content for printing */}
            {reportData && (
                <div id="printable-summary" className="hidden">
                    <div className="print-section">
                        <h4>সার্বিক গ্রেড পরিসংখ্যান</h4>
                        <table className="mt-2">
                            <thead><tr>{currentGrades.map(g => <th key={g.id}>{g.name}</th>)}</tr></thead>
                            <tbody><tr>{currentGrades.map(g => <td key={g.id} className="text-center">{toBengaliNumber(reportData.overallGradeCounts[g.name] || 0)}</td>)}</tr></tbody>
                        </table>
                    </div>
                    {/* NEW: Overall Top Students Section */}
                    <div className="print-section">
                        <h4>সার্বিক মেধাতালিকা (প্রথম, দ্বিতীয় ও তৃতীয়)</h4>
                        <table className="mt-2">
                            <thead><tr><th>মেধা স্থান</th><th>রোল</th><th>নাম</th><th>শ্রেণি</th><th>মোট নম্বর</th><th>গ্রেড</th></tr></thead>
                            <tbody>
                                {reportData.overallTopStudents.length > 0 ? reportData.overallTopStudents.map(s => (
                                    <tr key={s.studentId}>
                                        <td className="text-center">{toBengaliNumber(s.rank)}</td>
                                        <td className="text-center">{toBengaliNumber(s.roll)}</td>
                                        <td>{s.name}</td>
                                        <td>{s.classLevel}</td>
                                        <td className="text-center">{toBengaliNumber(s.totalObtained)}</td>
                                        <td className={`text-center font-bold ${gradeColors[s.grade] || ''}`}>{s.grade}</td>
                                    </tr>
                                )) : <tr><td colSpan={6} className="text-center">কোনো কৃতকার্য শিক্ষার্থী নেই।</td></tr>}
                            </tbody>
                        </table>
                    </div>
                    <div className="print-section">
                        <h4>শ্রেণি ভিত্তিক মেধাতালিকা (প্রথম, দ্বিতীয় ও তৃতীয়)</h4>
                        {reportData.classSummaries.map(summary => (
                            <div key={summary.className} className="mt-4">
                                <h5 className="font-bold text-base mb-1">{summary.className}</h5>
                                <table>
                                    <thead><tr><th>মেধা স্থান</th><th>রোল</th><th>নাম</th><th>মোট নম্বর</th><th>গ্রেড</th></tr></thead>
                                    <tbody>
                                        {summary.topStudents.length > 0 ? summary.topStudents.map(s => (
                                            <tr key={s.studentId}>
                                                <td className="text-center">{toBengaliNumber(s.rank)}</td>
                                                <td className="text-center">{toBengaliNumber(s.roll)}</td>
                                                <td>{s.name}</td>
                                                <td className="text-center">{toBengaliNumber(s.totalObtained)}</td>
                                                <td className={`text-center font-bold ${gradeColors[s.grade] || ''}`}>{s.grade}</td>
                                            </tr>
                                        )) : <tr><td colSpan={5} className="text-center">কোনো কৃতকার্য শিক্ষার্থী নেই।</td></tr>}
                                    </tbody>
                                </table>
                            </div>
                        ))}
                    </div>
                    <div className="print-section">
                        <h4>শ্রেণি ভিত্তিক গ্রেড সংখ্যা</h4>
                        <table className="mt-2">
                            <thead><tr><th>শ্রেণি</th>{currentGrades.map(g => <th key={g.id}>{g.name}</th>)}</tr></thead>
                            <tbody>
                                {reportData.classSummaries.map(summary => (
                                    <tr key={summary.className}>
                                        <td className="font-semibold">{summary.className}</td>
                                        {currentGrades.map(g => <td key={g.id} className="text-center">{toBengaliNumber(summary.gradeCounts[g.name] || 0)}</td>)}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ResultSummary;
