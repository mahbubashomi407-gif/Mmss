
import React, { useState, useMemo, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, ExamData, SubjectData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, CalendarIcon, ChevronDownIcon, RefreshIcon } from '../../../components/icons';

// Utility to convert numbers to Bengali
const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '';
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match]);
};


// Sub-component for a single number sheet
const STUDENTS_PER_SHEET = 25; // Adjusted from 30 to 25 to provide more vertical space

interface NombroPotroSheetProps {
    students: StudentData[];
    examName: string;
    subjectName: string;
    academicYear: string;
    classLevel: string;
}

const NombroPotroSheet: React.FC<NombroPotroSheetProps> = ({ students, examName, subjectName, academicYear, classLevel }) => {
    const { institutionName, address } = useInstitution();
    const allRows = Array.from({ length: STUDENTS_PER_SHEET }, (_, i) => students[i] || null);

    return (
        <div className="border border-black p-1.5 flex flex-col h-full text-sm"> {/* Adjusted p-2 to p-1.5 */}
            <header className="text-center">
                <h1 className="text-xl font-bold">{institutionName}</h1>
                <p className="text-xs">{`${address.village}, ${address.upazila}, ${address.district}`}</p>
                <p className="font-semibold text-sm">{examName} | শ্রেণিঃ {classLevel} | শিক্ষাবর্ষ: {toBengaliNumber(academicYear)}</p>
                <div className="flex justify-between items-end mt-0.5 text-xs px-2"> {/* Adjusted mt-1 to mt-0.5 */}
                    <p className="border-b border-dotted border-black flex-grow-0 w-2/3 text-left">পরীক্ষকের নামঃ ..........................................</p>
                    <p className="text-right">বিষয়ঃ {subjectName}</p>
                </div>
                <h2 className="font-bold text-base border border-black inline-block px-8 py-0.5 my-0.5">নম্বর পত্র</h2> {/* Adjusted my-1 to my-0.5 */}
            </header>
            <main className="flex-grow flex flex-col">
                {/* Grid-based Table Header */}
                <div className="grid grid-cols-[3rem_4rem_1fr_5rem] bg-gray-100 text-xs font-bold border-t border-x border-black">
                    <div className="border-r border-black p-0.5 text-center">রোল</div>
                    <div className="border-r border-black p-0.5 text-center">আইডি</div>
                    <div className="border-r border-black p-0.5 text-left">নাম</div>
                    <div className="p-0.5 text-center">নম্বর</div>
                </div>
                {/* Grid-based Table Body */}
                <div 
                    className="flex-grow grid grid-cols-[3rem_4rem_1fr_5rem] border-x border-b border-black text-xs" 
                    style={{ gridTemplateRows: `repeat(${STUDENTS_PER_SHEET}, 1fr)` }}
                >
                    {allRows.map((s, index) => (
                        <React.Fragment key={s ? s.id : `empty-${index}`}>
                            <div className="border-r border-t border-black p-0.5 text-center flex items-center justify-center">{s ? toBengaliNumber(s.roll) : <>&nbsp;</>}</div>
                            <div className="border-r border-t border-black p-0.5 text-center flex items-center justify-center">{s ? toBengaliNumber(s.uniqueId) : <>&nbsp;</>}</div>
                            <div className="border-r border-t border-black p-0.5 text-left flex items-center">{s ? s.nameBn : <>&nbsp;</>}</div>
                            <div className="border-t border-black p-0.5 flex items-center">&nbsp;</div>
                        </React.Fragment>
                    ))}
                </div>
            </main>
            <footer className="flex justify-between items-center mt-1 text-xs px-2"> {/* Adjusted mt-2 to mt-1 */}
                <p>মোট পরীক্ষার্থীঃ {toBengaliNumber(students.length)}</p>
                <p className="border-b border-dotted border-black w-2/3 text-left">স্বাক্ষরঃ ..........................................</p>
            </footer>
        </div>
    );
};

// Main page component
const NombroPotro: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams } = useInstitution();
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    const [subjectFilter, setSubjectFilter] = useState('');
    
    // Data to be printed
    const [printData, setPrintData] = useState<{ chunks: StudentData[][]; examName: string; subjectName: string } | null>(null);
    
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => classFilter ? exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter)) : [], [classFilter, academicYearFilter, exams]);
    const availableSubjects = useMemo(() => {
        if (!classFilter || !examFilter) return [];
        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        const selectedExam = exams.find(e => e.id === examFilter);
        if (!selectedExam) return [];
        const assignedSubjects = selectedExam.subjectAssignments?.[classFilter];
        if (!Array.isArray(assignedSubjects)) return [];
        const assignedSubjectIds = assignedSubjects.map(a => a.subjectId);
        return allSubjectsForClass.filter(subject => assignedSubjectIds.includes(subject.id));
    }, [classFilter, examFilter, exams, classLevels]);
    
    useEffect(() => { setSectionFilter(''); setExamFilter(''); setSubjectFilter(''); }, [classFilter]);

    const handleGenerate = () => {
        const studentsToPrint = students
            .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            .sort((a, b) => (a.roll || 999) - (b.roll || 999));
        
        const examName = exams.find(e => e.id === examFilter)?.name || '';
        const subjectName = availableSubjects.find(s => s.id === subjectFilter)?.name || '';

        const chunks = [];
        for (let i = 0; i < studentsToPrint.length; i += STUDENTS_PER_SHEET) {
            chunks.push(studentsToPrint.slice(i, i + STUDENTS_PER_SHEET));
        }

        setPrintData({ chunks, examName, subjectName });
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-area');
            if (printContent) {
                const printWindow = window.open('', '', 'height=800,width=1200');
                if (printWindow) {
                    printWindow.document.write('<html><head><title>নম্বর পত্র</title>');
                    printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                    printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                    printWindow.document.write(`
                        <style>
                            body { font-family: "SolaimanLipi", sans-serif !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                            @page { size: A4 portrait; margin: 0.3cm; } /* Adjusted margin to 0.3cm */
                            .print-page { 
                                display: flex; 
                                flex-direction: row; 
                                gap: 0.6cm; /* Adjusted gap to 0.6cm */
                                page-break-after: always; 
                                height: 98%; 
                            }
                            .print-page:last-child { page-break-after: avoid; }
                            .sheet-container { width: 48%; page-break-inside: avoid; }
                        </style>`);
                    printWindow.document.write('</head><body>');
                    printWindow.document.write(printContent.innerHTML);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 750);
                }
            }
        }, 500);
    };

    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter && subjectFilter;
    const canSelectSubject = classFilter && examFilter;

    return (
        <div>
            <PageHeader icon="📝" title="নম্বর পত্র" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                 <div className="flex flex-wrap items-center gap-3">
                    <select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="p-2 border rounded-md bg-white">
                        <option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                    </select>
                    <select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="p-2 border rounded-md bg-white">
                        <option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}
                    </select>
                    <select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="p-2 border rounded-md bg-white" disabled={!classFilter}>
                        <option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="p-2 border rounded-md bg-white" disabled={!classFilter}>
                        <option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                    </select>
                     <select value={subjectFilter} onChange={e => setSubjectFilter(e.target.value)} className="p-2 border rounded-md bg-white" disabled={!examFilter}>
                        <option value="">বিষয়</option>{availableSubjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                    </select>
                </div>
            </div>
            
            {canSelectSubject && availableSubjects.length === 0 && (
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg shadow-md mb-6">
                    <p className="font-bold text-yellow-800">কোনো বিষয় পাওয়া যায়নি!</p>
                    <p className="text-sm text-yellow-700">
                        এই পরীক্ষার জন্য "{classFilter}" শ্রেণিতে কোনো বিষয় বরাদ্দ করা হয়নি। অনুগ্রহ করে 
                        <Link to="/admin/exams/subject-assignment" className="font-bold underline hover:text-yellow-900"> বিষয় অ্যাসাইনমেন্ট </Link> 
                        পেজ থেকে বিষয় বরাদ্দ করুন।
                    </p>
                </div>
            )}

            <div className="bg-white p-6 rounded-xl shadow-md text-center">
                <button onClick={handleGenerate} disabled={!allFiltersSelected} className="px-8 py-3 bg-teal-600 text-white font-bold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 text-lg">
                    নম্বর পত্র জেনারেট ও প্রিন্ট করুন
                </button>
                {!allFiltersSelected && <p className="text-sm text-gray-500 mt-4">অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p>}
            </div>

            {/* Hidden printable area */}
            <div id="printable-area" className="hidden">
                {printData && (() => {
                    const chunks = printData.chunks;
                    if (chunks.length === 0) return null;

                    const pages = [];
                    // If there is only one chunk (<= 30 students), create a page with two identical sheets.
                    if (chunks.length === 1) {
                        pages.push([chunks[0], chunks[0]]);
                    } else {
                        // Otherwise, pair them up for each page.
                        for (let i = 0; i < chunks.length; i += 2) {
                            pages.push([chunks[i], chunks[i + 1]]); // The second element can be undefined for the last page
                        }
                    }

                    return pages.map((pageChunks, pageIndex) => (
                        <div key={pageIndex} className="print-page">
                            <div className="sheet-container">
                                {pageChunks[0] && <NombroPotroSheet students={pageChunks[0]} examName={printData.examName} subjectName={printData.subjectName} academicYear={academicYearFilter} classLevel={classFilter} />}
                            </div>
                            <div className="sheet-container">
                                {pageChunks[1] && <NombroPotroSheet students={pageChunks[1]} examName={printData.examName} subjectName={printData.subjectName} academicYear={academicYearFilter} classLevel={classFilter} />}
                            </div>
                        </div>
                    ));
                })()}
            </div>
        </div>
    );
};

export default NombroPotro;