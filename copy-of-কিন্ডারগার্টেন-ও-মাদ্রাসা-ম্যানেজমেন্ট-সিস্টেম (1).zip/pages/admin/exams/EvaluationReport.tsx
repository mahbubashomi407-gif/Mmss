
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, calculateGradeInfo, ExamData, GradeData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';
import { useLocation } from 'react-router-dom';
import { ReportCardContent, ReportData } from '../../../components/ReportCardModal';
import { useNotification } from '../../../context/NotificationContext';

declare global {
    interface Window {
        html2pdf: any;
    }
}

const EvaluationReport: React.FC = () => {
    const location = useLocation();
    const isMadrasaMode = location.pathname.includes('madrasa-result');
    
    const { students, classLevels, sections, academicSessions, exams, markRecords, grades, madrasaGrades, madrasaResultSettings, institutionName, logoUrl, madrasaExamTypes, setExams } = useInstitution();
    const { addToast } = useNotification();
    const currentGrades = isMadrasaMode ? madrasaGrades : grades;

    const [studentsToPrint, setStudentsToPrint] = useState<ReportData[]>([]);
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState('');

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => {
        if (!classFilter) return [];
        return exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter));
    }, [classFilter, academicYearFilter, exams]);
    
    useEffect(() => {
        if (isMadrasaMode && availableExams.length > 0) {
            const madrasaExam = availableExams.find(e => e.name === 'মাদরাসা পরীক্ষা');
            if (madrasaExam) setExamFilter(madrasaExam.id);
        } else if (!isMadrasaMode) {
            setExamFilter('');
        }
        setSectionFilter('');
        setExamTypeFilter('');
    }, [classFilter, academicYearFilter, isMadrasaMode, availableExams]);

    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter && (!isMadrasaMode || examTypeFilter);
    
    const generateAllReportData = (): ReportData[] => {
        const results = generateReportData();
        return results.map(studentResult => formatStudentReport(studentResult, results));
    };

    const generateReportData = () => {
        if (!allFiltersSelected) return [];

        const failGrade = currentGrades.find(g => g.gpa === 0);
        const failGradeName = failGrade?.name || (isMadrasaMode ? 'রাসিব' : 'F');

        const studentsInSection = students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');
        const selectedExam = exams.find(e => e.id === examFilter);
        if (!selectedExam) return [];

        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        const assignedSubjects = isMadrasaMode 
            ? selectedExam.madrasaSubjectAssignments?.[classFilter]?.[examTypeFilter]
            : selectedExam.subjectAssignments?.[classFilter];
        
        const relevantSubjects = Array.isArray(assignedSubjects) 
            ? allSubjectsForClass.filter(s => assignedSubjects.some((as: any) => as.subjectId === s.id))
            : [];
        
        if(relevantSubjects.length === 0) return [];

        const results = studentsInSection.map(student => {
            const studentMarks = markRecords.filter(m => 
                m.studentId === student.id && 
                m.examId === examFilter &&
                (isMadrasaMode ? m.examTypeId === examTypeFilter : true)
            );
            
            const marksBySubject: { [key: string]: { obtained: number | null; total: number } } = {};
            let totalObtained = 0;
            let totalMarks = 0;
            let marksGivenCount = 0;
            let failedSubjectsCount = 0;

            relevantSubjects.forEach(subject => {
                const mark = studentMarks.find(m => m.subjectId === subject.id);
                const obtained = mark?.marksObtained ?? null;
                
                let total = 100; // default
                if (isMadrasaMode) {
                    total = madrasaExamTypes.find(et => et.id === examTypeFilter)?.totalMarks || 100;
                } else if(assignedSubjects){
                    const assignment = (assignedSubjects as any[]).find(a => a.subjectId === subject.id);
                    total = assignment?.totalMarks || selectedExam?.defaultMarks || 100;
                }

                marksBySubject[subject.id] = { obtained, total };

                if (obtained !== null) {
                    marksGivenCount++;
                    totalObtained += obtained;
                    totalMarks += total;
                    const subjectPercentage = total > 0 ? (obtained / total) * 100 : 0;
                    if (calculateGradeInfo(subjectPercentage, currentGrades).gpa === 0) {
                        failedSubjectsCount++;
                    }
                }
            });

            const overallPercentage = totalMarks > 0 ? (totalObtained / totalMarks) * 100 : 0;
            let resultStatus: 'Passed' | 'Failed' | 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত' = 'কৃতকার্য';
            let finalGrade = '';
            let finalGpa = 0;

            if (isMadrasaMode) {
                if (madrasaResultSettings.enableAbsentStatus && marksGivenCount === 0) {
                    resultStatus = 'অনুপস্থিত';
                    finalGrade = 'অনুপস্থিত';
                    finalGpa = 0;
                } else if (madrasaResultSettings.enableSuspendedStatus && marksGivenCount > 0 && marksGivenCount < relevantSubjects.length) {
                    resultStatus = 'স্থগিত';
                    finalGrade = 'স্থগিত';
                    finalGpa = 0;
                } else {
                    const avgGradeInfo = calculateGradeInfo(overallPercentage, currentGrades);
                    // Base grade is determined by average
                    finalGrade = avgGradeInfo.grade;
                    finalGpa = avgGradeInfo.gpa;
                    resultStatus = avgGradeInfo.gpa > 0 ? 'কৃতকার্য' : 'অকৃতকার্য';
            
                    // Override with "Maqbul" if setting is on and conditions are met
                    const maqbulGradeInfo = currentGrades.find(g => g.name === 'মকবুল');
                    if (madrasaResultSettings.enableMaqbulOnSingleFail && failedSubjectsCount > 0 && avgGradeInfo.gpa > 0 && maqbulGradeInfo) {
                        finalGrade = maqbulGradeInfo.name;
                        finalGpa = maqbulGradeInfo.gpa;
                        resultStatus = 'কৃতকার্য'; // Maqbul is a pass
                    }
                }
            } else { // Academic Mode
                if (marksGivenCount === 0) {
                    resultStatus = 'অনুপস্থিত';
                    finalGrade = 'অনুপস্থিত';
                    finalGpa = 0;
                    failedSubjectsCount = relevantSubjects.length;
                } else {
                    const isFail = failedSubjectsCount > 0;
                    const avgGradeInfo = calculateGradeInfo(overallPercentage, currentGrades);
                    resultStatus = isFail ? 'Failed' : 'Passed';
                    finalGrade = isFail ? failGradeName : avgGradeInfo.grade;
                    finalGpa = isFail ? 0 : avgGradeInfo.gpa;
                }
            }
            
            return { ...student, totalObtained, grade: finalGrade, gpa: finalGpa, resultStatus, marksBySubject, failedSubjectsCount, totalMarks, overallPercentage, relevantSubjects };
        });

        const sorted = results.sort((a, b) => {
            const statusOrder: { [key: string]: number } = { 'কৃতকার্য': 1, 'Passed': 1, 'অকৃতকার্য': 2, 'Failed': 2, 'স্থগিত': 3, 'অনুপস্থিত': 4 };
            const statusA = statusOrder[a.resultStatus] || 5;
            const statusB = statusOrder[b.resultStatus] || 5;
            if (statusA !== statusB) return statusA - statusB;
            if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
            return (a.roll || 999) - (b.roll || 999);
        });

        let rank = 0;
        let lastScore = -1;
        const finalRankedResults = sorted.map((s, index) => {
            let currentRank: number | '-' = '-';
            const studentGradeInfo = currentGrades.find(g => g.name === s.grade);
            const isEligibleForRank = (s.resultStatus === 'কৃতকার্য' || s.resultStatus === 'Passed') && (!isMadrasaMode || (studentGradeInfo?.isRankable ?? false));
            if (isEligibleForRank) {
                if (s.totalObtained !== lastScore) {
                    rank = index + 1;
                    lastScore = s.totalObtained;
                }
                currentRank = rank;
            }
            return { ...s, rank: currentRank };
        });
        
        return finalRankedResults;
    };
    
    const formatStudentReport = (studentResult: any, allResults: any[]): ReportData => {
        const selectedExam = exams.find(e => e.id === examFilter)!;
        let exam = selectedExam;
        if (isMadrasaMode) {
            const examTypeName = madrasaExamTypes.find(et => et.id === examTypeFilter)?.name || '';
            if (examTypeName) exam = { ...exam, name: examTypeName };
        }

        const highestMarksBySubject: Record<string, number> = {};
        studentResult.relevantSubjects.forEach((subject: any) => {
            const marksForThisSubject = allResults.map(res => res.marksBySubject[subject.id]?.obtained).filter((mark): mark is number => typeof mark === 'number');
            highestMarksBySubject[subject.id] = marksForThisSubject.length > 0 ? Math.max(...marksForThisSubject) : 0;
        });

        const subjectRows = studentResult.relevantSubjects.map((subject: any) => {
            const markInfo = studentResult.marksBySubject[subject.id];
            const obtained = markInfo?.obtained; 
            const total = markInfo?.total ?? 100;
            const gradeInfo = (obtained !== null && obtained !== undefined) ? calculateGradeInfo((obtained / total) * 100, currentGrades) : { grade: 'N/A', gpa: 0 };
            return { name: subject.name, fullMarks: total, highestMark: highestMarksBySubject[subject.id], totalMarks: obtained, letterGrade: gradeInfo.grade, gradePoint: gradeInfo.gpa.toFixed(2) };
        });
        
        const totalFullMarks = subjectRows.reduce((sum: number, r: { fullMarks: any; }) => sum + r.fullMarks, 0);

        // Ensure resultStatus is correctly typed for ReportData
        const finalResultStatus = studentResult.resultStatus as 'Passed' | 'Failed' | 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত';

        return { 
            student: { ...studentResult, resultStatus: finalResultStatus }, 
            exam, 
            subjectRows, 
            failedSubjectsCount: studentResult.failedSubjectsCount, 
            totalFullMarks 
        };
    };

    
    const handlePrint = () => {
        const data = generateAllReportData();
        if (data.length === 0) {
            addToast('প্রিন্ট করার জন্য কোনো শিক্ষার্থীর তথ্য পাওয়া যায়নি।', 'error');
            return;
        }
        setStudentsToPrint(data);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-area');
            if(!printContent) return;

            const printWindow = window.open('', '', 'height=800,width=1200');
            if(!printWindow) return;

            printWindow.document.write('<html><head><title>Marksheets</title>');
            printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
            printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');

            printWindow.document.write(`<style>
                body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                @page { size: A4 landscape; margin: 0.6cm; }
                .print-page { 
                    page-break-after: always; 
                    display: flex; 
                    flex-direction: row; 
                    gap: 1.2cm; 
                    width: 100%; 
                    height: 100%;
                    align-items: flex-start;
                }
                .marksheet-container {
                    flex: 1;
                    box-sizing: border-box;
                    overflow: hidden;
                }
            </style>`);
            
            printWindow.document.write('</head><body>');
            printWindow.document.write(printContent.innerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 750);
        }, 500);
    };

    const handlePdfDownload = () => {
        const data = generateAllReportData();
        if (data.length === 0) {
            addToast('পিডিএফ তৈরি করার জন্য কোনো তথ্য পাওয়া যায়নি।', 'error');
            return;
        }
        setStudentsToPrint(data);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-area');
            if(!printContent) return;

            const exam = exams.find(e => e.id === examFilter);
            let examName = exam?.name || 'exam';
            if (isMadrasaMode) {
                const examType = madrasaExamTypes.find(et => et.id === examTypeFilter);
                if(examType) examName = examType.name;
            }

            const filename = `Marksheets_${classFilter}_${sectionFilter}_${examName.replace(/\s/g, '-')}.pdf`;
            
            const opt = {
                margin:       [0.6, 0.6, 0.6, 0.6], // in cm
                filename:     filename,
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'cm', format: 'a4', orientation: 'landscape' }
            };

            const fullHtml = `
                <html><head><title>Marksheets</title>
                <script src="https://cdn.tailwindcss.com"></script>
                <link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">
                <style>
                    body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                    .print-page { 
                        page-break-after: always; 
                        display: flex; 
                        flex-direction: row; 
                        gap: 1.2cm; 
                        width: 100%; 
                        height: 100%;
                        align-items: flex-start;
                    }
                    .marksheet-container {
                        flex: 1;
                        box-sizing: border-box;
                        overflow: hidden;
                    }
                </style>
                </head><body>
                ${printContent.innerHTML}
                </body></html>`;

            (window as any).html2pdf().from(fullHtml).set(opt).save();
        }, 500);
    };

    return (
        <div>
            <PageHeader icon="📜" title={isMadrasaMode ? "মাদরাসা মার্কশীট" : "মার্কশীট"} />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    {!isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>}
                    {isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষার ধরণ</option>{madrasaExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500"/></span></div>}
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamFilter(''); setExamTypeFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {allFiltersSelected ? (
                    <div className="text-center">
                        <h3 className="text-xl font-bold text-green-600">মার্কশীট তৈরী হয়েছে।</h3>
                        <p className="text-gray-600 my-4">প্রিন্ট বা পিডিএফ ডাউনলোড করতে নিচের বাটনে ক্লিক করুন।</p>
                        <div className="flex justify-center gap-4">
                            <button onClick={handlePrint} className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-blue-700">
                                প্রিন্ট করুন
                            </button>
                            <button onClick={handlePdfDownload} className="px-6 py-3 bg-green-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-green-700">
                                পিডিএফ ডাউনলোড
                            </button>
                        </div>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">মার্কশীট তৈরি করতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p>
                )}
            </div>
            
            <div id="printable-area" className="hidden">
            {
                Array.from({ length: Math.ceil(studentsToPrint.length / 2) }, (_, i) => studentsToPrint.slice(i * 2, i * 2 + 2))
                    .map((pair, pageIndex) => (
                        <div key={pageIndex} className="print-page">
                            {pair[0] && <ReportCardContent key={pair[0].student.id} reportData={pair[0]} isMadrasaMode={isMadrasaMode} />}
                            {pair[1] ? <ReportCardContent key={pair[1].student.id} reportData={pair[1]} isMadrasaMode={isMadrasaMode} /> : <div className="marksheet-container"></div>}
                        </div>
                    ))
            }
            </div>
        </div>
    );
};

export default EvaluationReport;
