
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, MarkRecordData, SubjectData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';
import { useLocation } from 'react-router-dom';

interface MarkInput {
    studentId: string;
    studentName: string;
    roll: number | '';
    marksObtained: number | '';
}

const MarkEntry: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams, setExams, markRecords, setMarkRecords, madrasaExamTypes } = useInstitution();
    const { addToast } = useNotification();
    const location = useLocation();
    const isMadrasaMode = location.pathname.includes('madrasa-result');

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    const [subjectFilter, setSubjectFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState(''); // For Madrasa

    const [marksData, setMarksData] = useState<MarkInput[]>([]);
    const [initialMarksData, setInitialMarksData] = useState<MarkInput[]>([]);

    // Auto-create/select generic Madrasa Exam
    useEffect(() => {
        if (isMadrasaMode && academicYearFilter) {
            const genericMadrasaExamName = 'মাদরাসা পরীক্ষা';
            const madrasaExam = exams.find(e => e.academicYear === academicYearFilter && e.name === genericMadrasaExamName);
            if (madrasaExam) {
                setExamFilter(madrasaExam.id);
            } else {
                const newExam = {
                    id: `exam-madrasa-${academicYearFilter.replace(/[^0-9]/g, '')}-${Date.now()}`,
                    name: genericMadrasaExamName,
                    academicYear: academicYearFilter,
                    classLevels: classLevels.map(cl => cl.name),
                };
                setExams(prevExams => [...prevExams, newExam]);
                setExamFilter(newExam.id);
            }
        }
    }, [isMadrasaMode, academicYearFilter, exams, setExams, classLevels]);


    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => classFilter ? exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter)) : [], [classFilter, academicYearFilter, exams]);
    
    const availableSubjects = useMemo(() => {
        if (!classFilter || !examFilter) return [];
        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        const selectedExam = exams.find(e => e.id === examFilter);
        if (!selectedExam) return [];

        if (isMadrasaMode) {
            if (!examTypeFilter) return [];
            const assignedSubjectIds = selectedExam.madrasaSubjectAssignments?.[classFilter]?.[examTypeFilter]?.map(a => a.subjectId) || [];
            return allSubjectsForClass.filter(subject => assignedSubjectIds.includes(subject.id));
        } else { // Academic Mode
            const assignedSubjects = selectedExam.subjectAssignments?.[classFilter];
            if (Array.isArray(assignedSubjects)) {
                const assignedSubjectIds = assignedSubjects.map(a => a.subjectId);
                return allSubjectsForClass.filter(subject => assignedSubjectIds.includes(subject.id));
            }
            return [];
        }
    }, [classFilter, examFilter, examTypeFilter, isMadrasaMode, exams, classLevels]);

    
    const subjectTotalMarks = useMemo(() => {
        if (isMadrasaMode) {
            return madrasaExamTypes.find(et => et.id === examTypeFilter)?.totalMarks ?? null;
        }
        if (!examFilter || !classFilter || !subjectFilter) return null;
        const exam = exams.find(e => e.id === examFilter);
        const assignment = exam?.subjectAssignments?.[classFilter]?.find(a => a.subjectId === subjectFilter);
        return assignment?.totalMarks ?? exam?.defaultMarks ?? 100;
    }, [examFilter, classFilter, subjectFilter, examTypeFilter, isMadrasaMode, exams, madrasaExamTypes]);

    useEffect(() => {
        setSectionFilter('');
        if (!isMadrasaMode) {
            setExamFilter('');
        }
        setSubjectFilter('');
        setExamTypeFilter('');
    }, [classFilter, isMadrasaMode]);


    useEffect(() => {
        if (subjectFilter && !availableSubjects.some(s => s.id === subjectFilter)) {
            setSubjectFilter('');
        }
    }, [availableSubjects, subjectFilter]);
    
    useEffect(() => {
        const canRun = academicYearFilter && classFilter && sectionFilter && examFilter && subjectFilter;
        if (canRun) {
            if (isMadrasaMode && !examTypeFilter) {
                setMarksData([]);
                setInitialMarksData([]);
                return;
            }

            const existingRecordsForSubject = markRecords.filter(m => {
                const baseMatch = m.examId === examFilter && m.subjectId === subjectFilter;
                return isMadrasaMode ? (baseMatch && m.examTypeId === examTypeFilter) : baseMatch;
            });
            
            const filteredStudents = students
                .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
                .sort((a, b) => (a.roll || 999) - (b.roll || 999));

            const newMarksData = filteredStudents.map(student => {
                const existingRecord = existingRecordsForSubject.find(m => m.studentId === student.id);
                return {
                    studentId: student.id,
                    studentName: student.nameBn,
                    roll: student.roll,
                    marksObtained: existingRecord?.marksObtained ?? '',
                };
            });
            setMarksData(newMarksData);
            setInitialMarksData(JSON.parse(JSON.stringify(newMarksData)));
        } else {
            setMarksData([]);
            setInitialMarksData([]);
        }
    }, [academicYearFilter, classFilter, sectionFilter, examFilter, subjectFilter, examTypeFilter, isMadrasaMode, students, markRecords]);
    
    const hasUnsavedChanges = JSON.stringify(marksData) !== JSON.stringify(initialMarksData);
    
    const handleMarkChange = (studentId: string, value: string) => {
        const numValue: number | '' = value === '' ? '' : Number(value);
        const maxMarks = subjectTotalMarks ?? 100;
    
        if (numValue !== '' && (numValue < 0 || numValue > maxMarks)) {
            addToast(`প্রাপ্ত নম্বর পূর্ণমানের (${maxMarks}) চেয়ে বেশি হতে পারে না।`, 'error');
            setMarksData(prev => prev.map(m => m.studentId === studentId ? { ...m, marksObtained: '' } : m));
        } else {
            setMarksData(prev => prev.map(m => m.studentId === studentId ? { ...m, marksObtained: numValue } : m));
        }
    };
    
    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, currentIndex: number) => {
        if (e.key === 'ArrowDown' || e.key === 'Enter') {
            e.preventDefault();
            const nextIndex = currentIndex + 1;
            if (nextIndex < marksData.length) {
                const nextInput = document.getElementById(`mark-input-${nextIndex}`);
                nextInput?.focus();
            }
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            const prevIndex = currentIndex - 1;
            if (prevIndex >= 0) {
                const prevInput = document.getElementById(`mark-input-${prevIndex}`);
                prevInput?.focus();
            }
        }
    };

    const handleSaveChanges = () => {
        const maxMarks = subjectTotalMarks ?? 100;
        const invalidEntry = marksData.find(md => md.marksObtained !== '' && (Number(md.marksObtained) > maxMarks || Number(md.marksObtained) < 0));
        if (invalidEntry) {
            addToast(`শিক্ষার্থী "${invalidEntry.studentName}"-এর নম্বর (${invalidEntry.marksObtained}) সঠিক নয়।`, 'error');
            return;
        }

        const studentIdsInView = new Set(marksData.map(md => md.studentId));
        const otherRecords = markRecords.filter(rec => {
            const isThisRecordContext = rec.examId === examFilter && rec.subjectId === subjectFilter && studentIdsInView.has(rec.studentId);
            if (isMadrasaMode) {
                return !(isThisRecordContext && rec.examTypeId === examTypeFilter);
            }
            return !isThisRecordContext;
        });
        
        const newRecords = marksData
            .filter(md => md.marksObtained !== '')
            .map(md => {
                const recordId = isMadrasaMode 
                    ? `${md.studentId}-${examFilter}-${subjectFilter}-${examTypeFilter}`
                    : `${md.studentId}-${examFilter}-${subjectFilter}`;
                
                const newRecord: MarkRecordData = {
                    id: recordId,
                    studentId: md.studentId,
                    examId: examFilter,
                    subjectId: subjectFilter,
                    marksObtained: Number(md.marksObtained),
                    totalMarks: Number(maxMarks),
                };

                if (isMadrasaMode) {
                    newRecord.examTypeId = examTypeFilter;
                }
                
                return newRecord;
            });
            
        setMarkRecords([...otherRecords, ...newRecords]);
        setInitialMarksData(JSON.parse(JSON.stringify(marksData)));
        addToast('ফলাফল সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };

    const allFiltersSelected = isMadrasaMode
        ? academicYearFilter && classFilter && sectionFilter && examFilter && subjectFilter && examTypeFilter
        : academicYearFilter && classFilter && sectionFilter && examFilter && subjectFilter;

    return (
        <div>
            <PageHeader icon="🧒" title={isMadrasaMode ? "মাদরাসা শিক্ষার্থী ফলাফল এন্ট্রি" : "শিক্ষার্থী ফলাফল এন্ট্রি"} />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    {!isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>}
                    {isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষার ধরণ</option>{madrasaExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>}
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={subjectFilter} onChange={e => setSubjectFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter || !examFilter || (isMadrasaMode && !examTypeFilter)}><option value="">বিষয়</option>{availableSubjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); if (!isMadrasaMode) setExamFilter(''); setSubjectFilter('') }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {allFiltersSelected ? (
                    marksData.length > 0 ? (
                        <div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                                        <tr>
                                            <th className="p-3 text-center">রোল</th>
                                            <th className="p-3 text-left">শিক্ষার্থীর নাম</th>
                                            <th className="p-3 w-40 text-center">প্রাপ্ত নম্বর / {subjectTotalMarks || '...'}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {marksData.map((s, index) => (
                                            <tr key={s.studentId} className="border-b hover:bg-gray-50/50 transition-colors">
                                                <td className="px-4 py-3 text-center font-mono">{s.roll}</td>
                                                <td className="px-4 py-3 font-medium">{s.studentName}</td>
                                                <td className="p-1 w-40">
                                                    <input
                                                        id={`mark-input-${index}`}
                                                        type="number"
                                                        value={s.marksObtained}
                                                        onChange={e => handleMarkChange(s.studentId, e.target.value)}
                                                        onKeyDown={e => handleKeyDown(e, index)}
                                                        className="w-full h-full text-center text-base p-2 border-0 rounded-md bg-transparent focus:bg-teal-50 focus:ring-2 focus:ring-teal-500 focus:outline-none transition-all duration-200"
                                                        placeholder="N/A"
                                                    />
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                             <div className="mt-6 flex justify-end">
                                <button onClick={handleSaveChanges} disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">
                                    ফলাফল সংরক্ষণ করুন
                                </button>
                            </div>
                        </div>
                    ) : ( <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p> )
                ) : ( <p className="text-center text-gray-500 py-10">ফলাফল এন্ট্রি করতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p> )}
            </div>
        </div>
    );
};

export default MarkEntry;
