
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, ExamData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { useNavigate } from 'react-router-dom';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const ExamList: React.FC = () => {
    const { exams, setExams, academicSessions } = useInstitution();
    const { addToast } = useNotification();
    const navigate = useNavigate();

    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; exam: ExamData | null }>({ isOpen: false, exam: null });
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const [yearFilter, setYearFilter] = useState(activeSession?.name || '');

    const filteredExams = useMemo(() => {
        return exams
            .filter(e => e.academicYear === yearFilter)
            .sort((a, b) => a.name.localeCompare(b.name, 'bn'));
    }, [exams, yearFilter]);

    const handleDelete = (exam: ExamData) => {
        setDeleteModal({ isOpen: true, exam });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.exam) {
            setExams(exams.filter(e => e.id !== deleteModal.exam!.id));
            addToast('পরীক্ষা সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, exam: null });
    };

    return (
        <div>
            <PageHeader icon="📋" title="পরীক্ষা তালিকা">
                <button
                    onClick={() => navigate('/app/exams/create')}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700"
                >
                    নতুন পরীক্ষা তৈরি করুন
                </button>
            </PageHeader>
            
             <div className="bg-white p-4 rounded-xl shadow-md mb-6 max-w-sm">
                <label htmlFor="yearFilter" className="block text-sm font-medium text-gray-700">শিক্ষা বর্ষ অনুযায়ী ফিল্টার করুন</label>
                <select
                    id="yearFilter"
                    value={yearFilter}
                    onChange={e => setYearFilter(e.target.value)}
                    className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm bg-white"
                >
                    {academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                </select>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-6 py-3">পরীক্ষার নাম</th>
                                <th className="px-6 py-3">শিক্ষা বর্ষ</th>
                                <th className="px-6 py-3">প্রযোজ্য শ্রেণি</th>
                                <th className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredExams.length > 0 ? filteredExams.map(exam => (
                                <tr key={exam.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{exam.name}</td>
                                    <td className="px-6 py-4">{exam.academicYear}</td>
                                    <td className="px-6 py-4">{exam.classLevels.join(', ')}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => navigate(`/app/exams/create?id=${exam.id}`)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleDelete(exam)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={4} className="text-center py-10 text-gray-500">
                                        <p>এই শিক্ষা বর্ষের জন্য কোনো পরীক্ষা তৈরি করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <Modal
                isOpen={deleteModal.isOpen}
                onClose={() => setDeleteModal({ isOpen: false, exam: null })}
                onConfirm={handleConfirmDelete}
                title="পরীক্ষা মুছে ফেলুন"
            >
                আপনি কি নিশ্চিতভাবে "{deleteModal.exam?.name}" পরীক্ষাটি মুছে ফেলতে চান?
            </Modal>
        </div>
    );
};

export default ExamList;