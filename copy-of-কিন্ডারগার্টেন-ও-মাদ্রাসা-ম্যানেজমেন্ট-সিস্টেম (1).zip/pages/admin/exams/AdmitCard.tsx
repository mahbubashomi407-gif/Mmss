import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, ExamData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, CalendarIcon, ChevronDownIcon } from '../../../components/icons';

const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        ':': ':'
    };
    return num.replace(/[0-9:]/g, (match) => map[match] || match);
};


// --- Admit Card Component ---
const AdmitCardView: React.FC<{ student: StudentData, exam: ExamData | undefined }> = ({ student, exam }) => {
    const { institutionName, logoUrl, address, examRoutineSlots, classLevels, managerInfo } = useInstitution();
    
    const routine = useMemo(() => {
        if (!exam || !student) return [];
        
        const studentClass = classLevels.find(cl => cl.name === student.classLevel);
        if (!studentClass) return [];
        
        const slots = examRoutineSlots.filter(s => s.examId === exam.id && s.classLevelId === studentClass.id);
        
        const groupedByDate: { [key: string]: { date: Date, morningSubject?: string, afternoonSubject?: string } } = {};

        slots.forEach(slot => {
            const date = new Date(slot.date + 'T00:00:00'); // Treat as local date
            const dateStr = slot.date;
            const subject = studentClass.subjects.find(s => s.id === slot.subjectId);

            if (!groupedByDate[dateStr]) {
                groupedByDate[dateStr] = { date };
            }
            if (slot.session === 'Morning') {
                groupedByDate[dateStr].morningSubject = subject?.name;
            } else if (slot.session === 'Afternoon') {
                groupedByDate[dateStr].afternoonSubject = subject?.name;
            }
        });

        return Object.values(groupedByDate).sort((a,b) => a.date.getTime() - b.date.getTime());
    }, [exam, student, examRoutineSlots, classLevels]);

    const issueDate = new Date().toLocaleDateString('bn-BD');

    return (
        <div className="w-[19cm] h-[13.2cm] bg-white p-1 relative flex flex-col border-2 border-black" style={{ fontFamily: "'SolaimanLipi', sans-serif" }}>
            {/* Watermark Logo */}
            {logoUrl && <img src={logoUrl} alt="watermark" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 opacity-10" />}

            {/* Header */}
            <header className="text-center relative z-10 border-b-2 border-black pb-1">
                <div className="flex justify-between items-center">
                    <img src={logoUrl || ''} className="w-20 h-20"/>
                    <div className="flex-grow">
                        <h1 className="text-4xl font-bold">{institutionName}</h1>
                        <p className="text-sm">{`${address.village}, ${address.upazila}, ${address.district}`}</p>
                    </div>
                    <div className="w-24 h-28 border-2 border-gray-400 flex items-center justify-center text-gray-400">ছবি</div>
                </div>
                <div className="inline-block bg-gray-200 px-8 py-1 text-lg font-semibold rounded mt-1 shadow-sm border border-gray-400">প্রবেশপত্র</div>
            </header>

            {/* Body Info */}
            <section className="text-base mt-1 relative z-10">
                <p className="text-center font-semibold mb-1">{exam?.name} - {toBengaliNumber(exam?.academicYear || '')}, শ্রেণি/জামাতঃ {student.classLevel}</p>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5">
                    <p className="flex items-end"><strong className="w-32 shrink-0">পরীক্ষার্থীর নামঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{student.nameBn}</span></p>
                    <p className="flex items-end"><strong className="w-32 shrink-0">পিতার নামঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{student.fatherNameBn}</span></p>
                    <p className="flex items-end"><strong className="w-32 shrink-0">রোল/সীট নংঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{toBengaliNumber(student.roll || '')}</span></p>
                    <p className="flex items-end"><strong className="w-32 shrink-0">রেজি/দাখেলা নংঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{toBengaliNumber(student.uniqueId)}</span></p>
                </div>
            </section>
            
            <section className="flex-grow mt-2 relative z-10">
                <p className="text-center font-semibold mb-1">পরীক্ষার রুটিন</p>
                <table className="w-full text-sm border-collapse border border-black">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="border border-black p-1 w-24">সময়</th>
                             {routine.map(r => <th key={r.date.toISOString()} className="border border-black p-1">{r.date.toLocaleDateString('bn-BD', { day: 'numeric', month: 'long' })}<br/>{r.date.toLocaleDateString('bn-BD', { weekday: 'long' })}</th>)}
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td className="border border-black p-1 font-semibold text-center">সকাল</td>
                            {routine.map(r => <td key={r.date.toISOString()} className="border border-black p-1 text-center font-semibold">{r.morningSubject || '*'}</td>)}
                        </tr>
                        <tr>
                            <td className="border border-black p-1 font-semibold text-center">বিকাল</td>
                            {routine.map(r => <td key={r.date.toISOString()} className="border border-black p-1 text-center font-semibold">{r.afternoonSubject || '*'}</td>)}
                        </tr>
                    </tbody>
                </table>
                 {routine.length === 0 && <p className="text-center text-red-500 mt-2">এই পরীক্ষার জন্য কোনো রুটিন তৈরি করা হয়নি।</p>}
            </section>

            {/* Footer */}
            <footer className="mt-auto pt-1 flex justify-between items-end relative z-10 text-sm">
                <div className="text-center w-56">
                    <p className="border-t border-dotted border-black pt-1">নাজেমে তা'লীমাতের স্বাক্ষর</p>
                </div>
                <div className="text-center">
                    <p>ইস্যু: {toBengaliNumber(issueDate)}</p>
                </div>
                <div className="text-center w-56">
                     {managerInfo.signatureUrl ? (
                        <img src={managerInfo.signatureUrl} alt="Signature" className="h-8 mx-auto object-contain" />
                    ) : <div className="h-8"></div> }
                    <p className="border-t border-dotted border-black pt-1">মুহতামিমের স্বাক্ষর</p>
                </div>
            </footer>
        </div>
    );
};


// --- Main Page Component ---
const GenerateAdmitCard: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    
    // Student Selection
    const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(new Set());
    const [studentsToPrint, setStudentsToPrint] = useState<StudentData[]>([]);

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => classFilter ? exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter)) : [], [classFilter, academicYearFilter, exams]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        return students
            .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            .sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter]);
    
    useEffect(() => {
        setSelectedStudentIds(new Set());
    }, [classFilter, sectionFilter, academicYearFilter, examFilter]);
    
    const selectedExam = useMemo(() => exams.find(e => e.id === examFilter), [exams, examFilter]);

    const handleSelectStudent = (id: string, checked: boolean) => {
        setSelectedStudentIds(prev => {
            const newSet = new Set(prev);
            if (checked) newSet.add(id); else newSet.delete(id);
            return newSet;
        });
    };

    const handleSelectAll = (checked: boolean) => {
        setSelectedStudentIds(checked ? new Set(filteredStudents.map(s => s.id)) : new Set());
    };
    
    const handleGenerate = () => {
        const toPrint = students.filter(s => selectedStudentIds.has(s.id));
        setStudentsToPrint(toPrint);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-admit-cards');
            if (printContent) {
                const printWindow = window.open('', '', 'height=800,width=1200');
                if (printWindow) {
                    printWindow.document.write('<html><head><title>প্রবেশপত্র</title>');
                    printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                    printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                    printWindow.document.write(`
                        <style>
                            body { 
                                font-family: "SolaimanLipi", sans-serif !important; 
                                -webkit-print-color-adjust: exact !important; 
                                print-color-adjust: exact !important;
                             } 
                            @page { 
                                size: A4 portrait; 
                                margin: 0.8cm; 
                            } 
                            .print-page { 
                                display: flex;
                                flex-direction: column;
                                align-items: center;
                                gap: 1.7cm;
                                page-break-after: always;
                            }
                            .print-page:last-child {
                                page-break-after: avoid;
                            }
                            .card-wrapper { 
                                page-break-inside: avoid;
                            }
                        </style>`);
                    printWindow.document.write('</head><body>');
                    printWindow.document.write(printContent.innerHTML);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    
                    setTimeout(() => {
                        printWindow.focus();
                        printWindow.print();
                        printWindow.close();
                    }, 750);
                }
            }
        }, 500);
    };

    const allFiltersSelected = classFilter && sectionFilter && examFilter;

    return (
        <div>
            <PageHeader icon="💳" title="প্রবেশপত্র" />
            
             <div className="space-y-6">
                <div className="bg-white p-6 rounded-xl shadow-md">
                     <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                        <select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="p-2 border rounded-md bg-white w-full"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id}>{cl.name}</option>)}</select>
                        <select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="p-2 border rounded-md bg-white w-full" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s}>{s}</option>)}</select>
                        <select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="p-2 border rounded-md bg-white w-full sm:col-span-2 lg:col-span-1" disabled={!classFilter}><option value="">পরীক্ষা নির্বাচন</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select>
                    </div>
                </div>

                {allFiltersSelected ? (
                    <div className="bg-white p-6 rounded-xl shadow-md">
                         <div className="border rounded-lg overflow-hidden max-h-80 overflow-y-auto">
                            <table className="w-full text-sm">
                                <thead className="bg-gray-100 sticky top-0">
                                    <tr>
                                        <th className="p-2 w-10"><input type="checkbox" onChange={e => handleSelectAll(e.target.checked)} checked={filteredStudents.length > 0 && selectedStudentIds.size === filteredStudents.length} /></th>
                                        <th className="p-2 text-left">রোল</th>
                                        <th className="p-2 text-left">নাম</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredStudents.map(s => (
                                        <tr key={s.id} className="border-t hover:bg-gray-50">
                                            <td className="p-2"><input type="checkbox" checked={selectedStudentIds.has(s.id)} onChange={e => handleSelectStudent(s.id, e.target.checked)} /></td>
                                            <td className="p-2">{toBengaliNumber(s.roll || '')}</td>
                                            <td className="p-2">{s.nameBn}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                ) : (
                     <p className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">শিক্ষার্থী তালিকা দেখতে শ্রেণি, সেকশন ও পরীক্ষা নির্বাচন করুন।</p>
                )}
                
                {allFiltersSelected && (
                    <div className="bg-white p-6 rounded-xl shadow-md text-center">
                        <h3 className="text-lg font-bold text-gray-800">প্রবেশপত্র তৈরী হয়েছে</h3>
                        <p className="text-sm text-gray-600 my-2">{toBengaliNumber(selectedStudentIds.size)} জন শিক্ষার্থী নির্বাচন করা হয়েছে।</p>
                        <button onClick={handleGenerate} disabled={selectedStudentIds.size === 0} className="px-8 py-3 bg-teal-600 text-white font-bold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 text-lg">
                            প্রবেশপত্র প্রিন্ট করুন
                        </button>
                    </div>
                )}
            </div>
            
            <div id="printable-admit-cards" className="hidden">
                {Array.from({ length: Math.ceil(studentsToPrint.length / 2) }).map((_, index) => {
                    const pair = studentsToPrint.slice(index * 2, index * 2 + 2);
                    return (
                        <div key={index} className="print-page">
                            {pair.map(student => (
                                <div key={student.id} className="card-wrapper">
                                    <AdmitCardView student={student} exam={selectedExam} />
                                </div>
                            ))}
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default GenerateAdmitCard;
