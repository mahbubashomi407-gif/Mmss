import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, calculateGradeInfo } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';

const GradeReport: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams, markRecords, institutionName, grades } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    const [subjectFilter, setSubjectFilter] = useState('');

    // Derived data for filters
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => classFilter ? exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter)) : [], [classFilter, academicYearFilter, exams]);
    const availableSubjects = useMemo(() => {
        if (!classFilter || !examFilter) return [];
        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        const selectedExam = exams.find(e => e.id === examFilter);
        if (selectedExam) {
            const assignedSubjects = selectedExam.subjectAssignments?.[classFilter];
            if (Array.isArray(assignedSubjects)) {
                const assignedSubjectIds = assignedSubjects.map(a => a.subjectId);
                return allSubjectsForClass.filter(subject => assignedSubjectIds.includes(subject.id));
            }
        }
        return [];
    }, [classFilter, examFilter, exams, classLevels]);
    
    // Reset dependent filters on change
    useEffect(() => { setSectionFilter(''); setExamFilter(''); setSubjectFilter(''); }, [classFilter]);

    // Calculate marks data
    const studentMarksData = useMemo(() => {
        if (!classFilter || !sectionFilter || !examFilter || !subjectFilter) return [];
        
        const studentsInSection = students.filter(s => 
            s.academicYear === academicYearFilter && 
            s.classLevel === classFilter && 
            s.section === sectionFilter &&
            s.status !== 'পেন্ডিং'
        );
        
        const selectedExam = exams.find(e => e.id === examFilter);

        return studentsInSection.map(student => {
            const mark = markRecords.find(m => m.studentId === student.id && m.examId === examFilter && m.subjectId === subjectFilter);
            const marksObtained = mark?.marksObtained ?? null;
            
            let totalMarks = selectedExam?.defaultMarks ?? 100;
            if (mark?.totalMarks) {
                totalMarks = mark.totalMarks;
            } else if (selectedExam?.subjectAssignments?.[classFilter]) {
                const assignment = selectedExam.subjectAssignments[classFilter].find(a => a.subjectId === subjectFilter);
                if(assignment) totalMarks = assignment.totalMarks;
            }

            const percentage = (marksObtained !== null && totalMarks > 0) ? (marksObtained / totalMarks) * 100 : null;
            const grade = percentage !== null ? calculateGradeInfo(percentage, grades).grade : null;
            
            return { ...student, marksObtained, totalMarks, percentage, grade };
        }).sort((a, b) => (a.roll || 999) - (b.roll || 999));

    }, [academicYearFilter, classFilter, sectionFilter, examFilter, subjectFilter, students, markRecords, grades, exams]);
    
    const failGradeName = useMemo(() => grades.find(g => g.gpa === 0)?.name || 'F', [grades]);

    // Calculate grade statistics
    const gradeStats = useMemo(() => {
        const stats: { [key: string]: number } = {};
        grades.forEach(g => stats[g.name] = 0);

        let totalStudentsWithMarks = 0;
        studentMarksData.forEach(s => {
            if (s.grade && stats.hasOwnProperty(s.grade)) {
                stats[s.grade]++;
                totalStudentsWithMarks++;
            }
        });

        const failedCount = stats[failGradeName] || 0;
        const passed = totalStudentsWithMarks - failedCount;
        const passRate = totalStudentsWithMarks > 0 ? ((passed / totalStudentsWithMarks) * 100).toFixed(2) : '0.00';
        return { stats, totalStudentsWithMarks, passed, failed: failedCount, passRate };
    }, [studentMarksData, grades, failGradeName]);
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-grade-report');
        if (printContent) {
            const examName = exams.find(e => e.id === examFilter)?.name || '';
            const subjectName = availableSubjects.find(s => s.id === subjectFilter)?.name || '';
            const printTitle = `গ্রেড রিপোর্ট - ${classFilter} (${sectionFilter}) - ${examName} - ${subjectName}`;
            
            const printWindow = window.open('', '', 'height=800,width=1200');
            if(printWindow){
                printWindow.document.write('<html><head>');
                printWindow.document.write(`<title>${printTitle}</title>`);
                printWindow.document.write('<link href="https://cdn.tailwindcss.com" rel="stylesheet">');
                printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                printWindow.document.write('<style>body { font-family: "SolaimanLipi", sans-serif; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ddd; padding: 8px; text-align: left; } th { background-color: #f2f2f2; } @page { size: A4; margin: 20px; } .no-print { display: none !important; } </style>');
                printWindow.document.write('</head><body>');
                printWindow.document.write(`<div class="text-center mb-4"><h1 class="text-2xl font-bold">${institutionName}</h1><h2 class="text-xl">${printTitle}</h2></div>`);
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 500);
            }
        }
    };
    
    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter && subjectFilter;

    const gradeColors: { [key: string]: string } = {
        'A+': 'bg-green-100 text-green-800', 'A': 'bg-blue-100 text-blue-800',
        'A-': 'bg-teal-100 text-teal-800', 'B': 'bg-indigo-100 text-indigo-800',
        'C': 'bg-purple-100 text-purple-800', 'D': 'bg-yellow-100 text-yellow-800',
        'F': 'bg-red-100 text-red-800',
    };

    return (
        <div>
            <PageHeader icon="📊" title="গ্রেড / মার্কস রিপোর্ট" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                {/* Filters */}
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={subjectFilter} onChange={e => setSubjectFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter || !examFilter}><option value="">বিষয়</option>{availableSubjects.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamFilter(''); setSubjectFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            {allFiltersSelected ? (
                 <div id="printable-grade-report">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 text-center">
                        <div className="p-3 bg-blue-50 rounded-lg"><p className="text-sm text-blue-600">মোট পরীক্ষার্থী</p><p className="text-2xl font-bold text-blue-700">{gradeStats.totalStudentsWithMarks}</p></div>
                        <div className="p-3 bg-green-50 rounded-lg"><p className="text-sm text-green-600">কৃতকার্য</p><p className="text-2xl font-bold text-green-700">{gradeStats.passed}</p></div>
                        <div className="p-3 bg-red-50 rounded-lg"><p className="text-sm text-red-600">অকৃতকার্য</p><p className="text-2xl font-bold text-red-700">{gradeStats.failed}</p></div>
                        <div className="p-3 bg-teal-50 rounded-lg"><p className="text-sm text-teal-600">পাশের হার</p><p className="text-2xl font-bold text-teal-700">{gradeStats.passRate}%</p></div>
                    </div>

                    <div className="bg-white p-6 rounded-xl shadow-md mb-6">
                        <h3 className="text-lg font-bold text-gray-800 mb-4">গ্রেড ভিত্তিক পরিসংখ্যান</h3>
                        <div className="flex flex-wrap gap-3 justify-center">
                            {Object.entries(gradeStats.stats).map(([grade, count]) => (
                                <div key={grade} className={`px-4 py-2 rounded-lg text-center ${gradeColors[grade] || 'bg-gray-100 text-gray-800'}`}>
                                    <p className="text-2xl font-bold">{grade}</p>
                                    <p className="text-sm font-semibold">{count} জন</p>
                                </div>
                            ))}
                        </div>
                    </div>
                 
                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <div className="flex justify-between items-center mb-4">
                            <h3 className="text-lg font-bold text-gray-800">বিস্তারিত ফলাফল</h3>
                            <button onClick={handlePrint} className="no-print px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg text-sm" disabled={studentMarksData.length === 0}>প্রিন্ট করুন</button>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="bg-gray-100"><tr><th className="p-2">রোল</th><th className="p-2 text-left">শিক্ষার্থীর নাম</th><th className="p-2">প্রাপ্ত নম্বর</th><th className="p-2">পূর্ণমান</th><th className="p-2">শতকরা হার</th><th className="p-2">গ্রেড</th></tr></thead>
                                <tbody>
                                    {studentMarksData.map(s => (
                                        <tr key={s.id} className="border-b">
                                            <td className="p-2 text-center">{s.roll}</td>
                                            <td className="p-2 font-medium">{s.nameBn}</td>
                                            <td className="p-2 text-center">{s.marksObtained ?? 'N/A'}</td>
                                            <td className="p-2 text-center">{s.totalMarks}</td>
                                            <td className="p-2 text-center">{s.percentage !== null ? `${s.percentage.toFixed(2)}%` : 'N/A'}</td>
                                            <td className="p-2 text-center font-bold"><span className={`px-2 py-1 rounded-full text-xs ${s.grade ? gradeColors[s.grade] : ''}`}>{s.grade ?? 'N/A'}</span></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            ) : (
                <div className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">
                    <p>রিপোর্ট দেখতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p>
                </div>
            )}

        </div>
    );
};

export default GradeReport;