import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, ExamData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, CalendarIcon, ChevronDownIcon, RefreshIcon } from '../../../components/icons';

const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        '.': '.',
    };
    return num.replace(/[0-9.]/g, (match) => map[match] || match);
};

const SeatCard: React.FC<{ student: StudentData; examName: string }> = ({ student, examName }) => {
    const { institutionName, logoUrl, address } = useInstitution();

    return (
        <div className="flex-1 p-[0.4cm]">
            <div className="border border-gray-400 p-3 w-full h-full relative overflow-hidden">
                {/* Watermark Logo */}
                {logoUrl && <img src={logoUrl} alt="watermark" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 opacity-10 z-0" />}

                <div className="relative z-10">
                    {/* Header */}
                    <div className="flex items-center gap-3 text-center border-b border-gray-300 pb-2">
                        {logoUrl && <img src={logoUrl} alt="Logo" className="w-12 h-12" />}
                        <div className="flex-grow">
                            <h2 className="font-bold text-lg">{institutionName}</h2>
                            <p className="text-xs">{`${address.village}, ${address.upazila}, ${address.district}`}</p>
                        </div>
                    </div>

                    {/* Ribbon */}
                    <div className="text-center my-2">
                        <div className="bg-gray-600 text-white font-bold py-1 px-6 inline-block text-sm">
                            আসন বিন্যাস
                        </div>
                        <p className="text-xs font-semibold mt-1">{examName}</p>
                    </div>
                    <hr className="border-gray-300"/>

                    {/* Details */}
                    <div className="flex justify-between text-sm mt-2">
                        <div className="space-y-1">
                            <p><strong className="w-16 inline-block">নাম</strong>: {student.nameBn}</p>
                            <p><strong className="w-16 inline-block">শ্রেণি</strong>: {student.classLevel}</p>
                            <p><strong className="w-16 inline-block">রোল</strong>: {toBengaliNumber(student.roll || '')}</p>
                        </div>
                        <div className="space-y-1">
                            <p><strong className="w-20 inline-block">আইডি নং</strong>: {toBengaliNumber(student.uniqueId)}</p>
                            <p><strong className="w-20 inline-block">শাখা</strong>: {student.section}</p>
                            <p><strong className="w-20 inline-block">সিট নং</strong>: </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};


const SeatPlan: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    
    const [studentsToPrint, setStudentsToPrint] = useState<StudentData[]>([]);

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => classFilter ? exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter)) : [], [classFilter, academicYearFilter, exams]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        return students
            .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            .sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter]);
    
    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) {
            setSectionFilter('');
        }
        setExamFilter('');
    }, [classFilter]);

    const selectedExam = useMemo(() => exams.find(e => e.id === examFilter), [exams, examFilter]);

    const handlePrint = () => {
        setStudentsToPrint(filteredStudents);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-area');
            if (printContent) {
                const printWindow = window.open('', '', 'height=800,width=1200');
                if (printWindow) {
                    printWindow.document.write('<html><head><title>Seat Plan</title>');
                    printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                    printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                    printWindow.document.write(`
                        <style>
                            body { 
                                font-family: "SolaimanLipi", sans-serif !important; 
                                -webkit-print-color-adjust: exact !important; 
                                print-color-adjust: exact !important;
                             } 
                            @page { size: A4 portrait; margin: 0.4cm; } 
                            .print-row { page-break-inside: avoid !important; }
                        </style>`);
                    printWindow.document.write('</head><body>');
                    printWindow.document.write(printContent.innerHTML);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    
                    setTimeout(() => {
                        printWindow.focus();
                        printWindow.print();
                        printWindow.close();
                    }, 750);
                }
            }
        }, 500);
    };

    const allFiltersSelected = classFilter && sectionFilter && examFilter;

    return (
        <div>
            <PageHeader icon="🪑" title="আসন বিন্যাস" />
            
            <div className="space-y-6">
                <div className="bg-white p-6 rounded-xl shadow-md">
                     <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
                        <div className="lg:col-span-1"><label className="block text-sm font-medium text-gray-700 mb-1">শিক্ষা বর্ষ</label><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="p-2 border rounded-md bg-white w-full"><option value="">বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select></div>
                        <div className="lg:col-span-1"><label className="block text-sm font-medium text-gray-700 mb-1">শ্রেণি</label><select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="p-2 border rounded-md bg-white w-full"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select></div>
                        <div className="lg:col-span-1"><label className="block text-sm font-medium text-gray-700 mb-1">সেকশন</label><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="p-2 border rounded-md bg-white w-full" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s}>{s}</option>)}</select></div>
                        <div className="lg:col-span-1"><label className="block text-sm font-medium text-gray-700 mb-1">পরীক্ষা</label><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="p-2 border rounded-md bg-white w-full" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select></div>
                        <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamFilter(''); setAcademicYearFilter(activeSession?.name || '') }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 h-10 w-10"><RefreshIcon className="w-5 h-5" /></button>
                    </div>
                </div>

                {allFiltersSelected ? (
                    <div className="bg-white p-6 rounded-xl shadow-md text-center">
                        <h3 className="text-xl font-bold text-green-600">আসন বিন্যাস তৈরী হয়েছে।</h3>
                        <p className="text-gray-600 my-4">এই সেকশনের সকল ({filteredStudents.length}) শিক্ষার্থীর জন্য আসন বিন্যাস তৈরি করা হবে। প্রিন্ট করতে নিচের বাটনে ক্লিক করুন।</p>
                        <button onClick={handlePrint} disabled={filteredStudents.length === 0} className="px-8 py-3 bg-teal-600 text-white font-bold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 text-lg">
                            আসন বিন্যাস প্রিন্ট করুন
                        </button>
                    </div>
                ) : (
                    <div className="bg-white p-10 rounded-xl shadow-md text-center text-gray-500">
                        <p>আসন বিন্যাস তৈরি করতে অনুগ্রহ করে উপরের ফিল্টার (বর্ষ, শ্রেণি, সেকশন ও পরীক্ষা) পূরণ করুন।</p>
                    </div>
                )}
            </div>
            
            <div id="printable-area" className="hidden">
                {Array.from({ length: Math.ceil(studentsToPrint.length / 2) }).map((_, index) => {
                    const pair = studentsToPrint.slice(index * 2, index * 2 + 2);
                    return (
                        <div key={index} className="w-full print-row">
                            <div className="flex items-stretch">
                                {pair[0] && <SeatCard student={pair[0]} examName={selectedExam?.name || ''} />}
                                {pair[1] ? <SeatCard student={pair[1]} examName={selectedExam?.name || ''} /> : <div className="flex-1 p-[0.4cm]"></div>}
                            </div>
                            <hr className="my-2 border-gray-400 border-dashed" />
                        </div>
                    );
                })}
            </div>
        </div>
    );
};

export default SeatPlan;
