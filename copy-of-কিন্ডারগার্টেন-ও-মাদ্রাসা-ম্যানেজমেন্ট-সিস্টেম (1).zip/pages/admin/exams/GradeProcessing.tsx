
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, GradeData, MadrasaResultSettings } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import GradeModal from '../../../components/GradeModal';
import { PencilIcon, TrashIcon, CheckCircleIcon } from '../../../components/icons';
import { useLocation } from 'react-router-dom';
import ToggleSwitch from '../../../components/ToggleSwitch';

const GradeProcessing: React.FC = () => {
    const location = useLocation();
    const isMadrasaMode = location.pathname.includes('madrasa-result');
    
    const { grades, setGrades, madrasaGrades, setMadrasaGrades, madrasaResultSettings, setMadrasaResultSettings } = useInstitution();
    const { addToast } = useNotification();

    const currentGrades = isMadrasaMode ? madrasaGrades : grades;
    const setGradeSystem = isMadrasaMode ? setMadrasaGrades : setGrades;

    const [modal, setModal] = useState<{ isOpen: boolean; grade: GradeData | null }>({ isOpen: false, grade: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; grade: GradeData | null }>({ isOpen: false, grade: null });

    const sortedGrades = useMemo(() => {
        return [...currentGrades].sort((a, b) => b.minPercentage - a.minPercentage);
    }, [currentGrades]);

    const handleSave = (gradeData: Omit<GradeData, 'id'> & { id?: string }) => {
        if (gradeData.id) { // Edit
            setGradeSystem(currentGrades.map(g => g.id === gradeData.id ? { ...g, ...gradeData } as GradeData : g));
            addToast('গ্রেড সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Add new
            const newGrade: GradeData = { ...gradeData, id: `g-${Date.now()}` };
            setGradeSystem([...currentGrades, newGrade]);
            addToast('নতুন গ্রেড সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        setModal({ isOpen: false, grade: null });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.grade) {
            setGradeSystem(currentGrades.filter(g => g.id !== deleteModal.grade!.id));
            addToast('গ্রেড সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, grade: null });
    };

    const handleSettingsChange = (key: keyof MadrasaResultSettings, value: boolean) => {
        const newSettings = { ...madrasaResultSettings, [key]: value };
        setMadrasaResultSettings(newSettings);
        addToast('সেটিংস আপডেট করা হয়েছে!', 'success');
    };

    return (
        <div>
            <PageHeader icon="⚙️" title={isMadrasaMode ? "মাদরাসা গ্রেড সিস্টেম" : "একাডেমিক গ্রেড সিস্টেম"}>
                <button onClick={() => setModal({ isOpen: true, grade: null })} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                    নতুন গ্রেড যোগ করুন
                </button>
            </PageHeader>
            
            {isMadrasaMode && (
                <div className="bg-white p-6 rounded-xl shadow-md mb-6">
                    <h3 className="text-lg font-bold text-gray-800 border-b pb-3 mb-4">ফলাফল প্রক্রিয়াকরণ নিয়মাবলী</h3>
                    <div className="space-y-4">
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                                <h4 className="font-semibold">"অনুপস্থিত" স্ট্যাটাস</h4>
                                <p className="text-sm text-gray-600">শিক্ষার্থী কোনো বিষয়েই পরীক্ষা না দিলে তার ফলাফল "অনুপস্থিত" দেখানো হবে।</p>
                            </div>
                            <ToggleSwitch 
                                enabled={madrasaResultSettings.enableAbsentStatus}
                                onChange={(value) => handleSettingsChange('enableAbsentStatus', value)}
                            />
                        </div>
                        <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                                <h4 className="font-semibold">"স্থগিত" স্ট্যাটাস</h4>
                                <p className="text-sm text-gray-600">শিক্ষার্থী কিছু বিষয়ে অনুপস্থিত থাকলে তার ফলাফল "স্থগিত" দেখানো হবে।</p>
                            </div>
                            <ToggleSwitch 
                                enabled={madrasaResultSettings.enableSuspendedStatus}
                                onChange={(value) => handleSettingsChange('enableSuspendedStatus', value)}
                            />
                        </div>
                         <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                            <div>
                                <h4 className="font-semibold">"মকবুল" গ্রেড</h4>
                                <p className="text-sm text-gray-600">শিক্ষার্থী কোনো বিষয়ে ফেল করলেও গড় নম্বরে পাশ করলে তাকে "মকবুল" গ্রেড দেওয়া হবে।</p>
                            </div>
                           <ToggleSwitch 
                                enabled={madrasaResultSettings.enableMaqbulOnSingleFail}
                                onChange={(value) => handleSettingsChange('enableMaqbulOnSingleFail', value)}
                            />
                        </div>
                    </div>
                </div>
            )}

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">গ্রেডের নাম</th>
                                {isMadrasaMode ? (
                                    <th scope="col" className="px-6 py-3">গড় নাম্বার</th>
                                ) : (
                                    <>
                                        <th scope="col" className="px-6 py-3">জিপিএ</th>
                                        <th scope="col" className="px-6 py-3">শতাংশ পরিসর</th>
                                    </>
                                )}
                                <th scope="col" className="px-6 py-3">মন্তব্য</th>
                                {isMadrasaMode && <th scope="col" className="px-6 py-3 text-center">মেধাস্থান যোগ্য</th>}
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedGrades.length > 0 ? sortedGrades.map(grade => (
                                <tr key={grade.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{grade.name}</td>
                                    {isMadrasaMode ? (
                                        <td className="px-6 py-4">{grade.minPercentage}% - {grade.maxPercentage}%</td>
                                    ) : (
                                        <>
                                            <td className="px-6 py-4">{grade.gpa.toFixed(2)}</td>
                                            <td className="px-6 py-4">{grade.minPercentage}% - {grade.maxPercentage}%</td>
                                        </>
                                    )}
                                    <td className="px-6 py-4">{grade.comment}</td>
                                    {isMadrasaMode && (
                                        <td className="px-6 py-4 text-center">
                                            {grade.isRankable ? 
                                                <CheckCircleIcon className="w-5 h-5 text-green-500 mx-auto" /> 
                                                : <span className="text-red-500 font-bold text-lg">&times;</span>}
                                        </td>
                                    )}
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => setModal({ isOpen: true, grade })} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => setDeleteModal({ isOpen: true, grade })} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={5} className="text-center py-10 text-gray-500">
                                        <p>কোনো গ্রেড যোগ করা হয়নি।</p>
                                        <p className="mt-1 text-sm">শুরু করতে "নতুন গ্রেড যোগ করুন" বাটনে ক্লিক করুন।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
            <GradeModal 
                isOpen={modal.isOpen} 
                onClose={() => setModal({ isOpen: false, grade: null })} 
                onSave={handleSave} 
                gradeToEdit={modal.grade} 
                existingGrades={currentGrades}
                isMadrasaMode={isMadrasaMode}
            />
            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({ isOpen: false, grade: null })} onConfirm={handleConfirmDelete} title="গ্রেড মুছে ফেলুন">
                আপনি কি নিশ্চিতভাবে "{deleteModal.grade?.name}" গ্রেডটি মুছে ফেলতে চান?
            </Modal>
        </div>
    );
};
export default GradeProcessing;
