
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { ReportCardModal, ReportData, ReportCardContent } from '../../../components/ReportCardModal';
import { useInstitution, StudentData, calculateGradeInfo, ExamData, GradeData, SubjectData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, EyeIcon } from '../../../components/icons';
import { useLocation } from 'react-router-dom';
import { useNotification } from '../../../context/NotificationContext';

declare global {
    interface Window {
        html2pdf: any;
    }
}

// Helper functions for Bengali numbers and status text
const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        '.': '.',
    };
    return num.replace(/[0-9.]/g, (match) => map[match] || match);
};

// Interface for table row data
interface ResultRowData extends StudentData {
    totalObtained: number;
    totalMarks: number;
    overallPercentage: number;
    grade: string;
    gpa: number;
    resultStatus: 'Passed' | 'Failed' | 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত';
    rank: number | '-';
    marksBySubject: Record<string, { obtained: number | null; total: number }>;
    failedSubjectsCount: number;
}

const getStatusText = (status: ResultRowData['resultStatus']) => {
    switch(status) {
        case 'Passed': return 'কৃতকার্য';
        case 'Failed': return 'অকৃতকার্য';
        default: return status;
    }
};


const ClassResult: React.FC<{ showPageHeader?: boolean }> = ({ showPageHeader = true }) => {
    const location = useLocation();
    const isMadrasaMode = location.pathname.includes('madrasa-result');
    
    const { students, classLevels, sections, academicSessions, exams, markRecords, grades, madrasaGrades, madrasaResultSettings, institutionName, logoUrl, address, madrasaExamTypes, setExams, managerInfo } = useInstitution();
    const { addToast } = useNotification();
    const currentGrades = isMadrasaMode ? madrasaGrades : grades;

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState('');
    
    const [reportModal, setReportModal] = useState<{ isOpen: boolean; student: StudentData | null; reportData: ReportData | null }>({ isOpen: false, student: null, reportData: null });
    
    // Derived data for filters
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => {
        if (!classFilter) return [];
        return exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter));
    }, [classFilter, academicYearFilter, exams]);
    const selectedExam = useMemo(() => exams.find(e => e.id === examFilter), [exams, examFilter]);

    useEffect(() => {
        if (isMadrasaMode && availableExams.length > 0) {
            const madrasaExam = availableExams.find(e => e.name === 'মাদরাসা পরীক্ষা');
            if (madrasaExam) setExamFilter(madrasaExam.id);
        } else {
            setExamFilter('');
        }
        setSectionFilter('');
        setExamTypeFilter('');
    }, [classFilter, academicYearFilter, isMadrasaMode, availableExams]);


    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter && (!isMadrasaMode || examTypeFilter);

    const { rankedResults, subjectsForClass } = useMemo(() => {
        if (!allFiltersSelected) return { rankedResults: [], subjectsForClass: [] };
        
        const failGrade = currentGrades.find(g => g.gpa === 0);
        const failGradeName = failGrade?.name || (isMadrasaMode ? 'রাসিব' : 'F');

        const studentsInSection = students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');
        const selectedExam = exams.find(e => e.id === examFilter);
        if (!selectedExam) return { rankedResults: [], subjectsForClass: [] };

        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        
        const assignedSubjects = isMadrasaMode 
            ? selectedExam.madrasaSubjectAssignments?.[classFilter]?.[examTypeFilter]
            : selectedExam.subjectAssignments?.[classFilter];
        
        const relevantSubjects = Array.isArray(assignedSubjects) 
            ? allSubjectsForClass.filter(s => assignedSubjects.some((as: any) => as.subjectId === s.id))
            : [];
            
        if(relevantSubjects.length === 0) return { rankedResults: [], subjectsForClass: [] };

        const results = studentsInSection.map(student => {
            const studentMarks = markRecords.filter(m => 
                m.studentId === student.id && 
                m.examId === examFilter &&
                (isMadrasaMode ? m.examTypeId === examTypeFilter : true)
            );
            
            let totalObtained = 0;
            let totalMarks = 0;
            let marksGivenCount = 0;
            let failedSubjectsCount = 0;
            const marksBySubject: ResultRowData['marksBySubject'] = {};

            relevantSubjects.forEach(subject => {
                const mark = studentMarks.find(m => m.subjectId === subject.id);
                const obtained = mark?.marksObtained ?? null;
                
                let total = 100; // default
                if (isMadrasaMode) {
                    total = madrasaExamTypes.find(et => et.id === examTypeFilter)?.totalMarks || 100;
                } else if(assignedSubjects){
                    const assignment = (assignedSubjects as any[]).find(a => a.subjectId === subject.id);
                    total = assignment?.totalMarks || selectedExam?.defaultMarks || 100;
                }

                marksBySubject[subject.id] = { obtained, total };

                if (obtained !== null) {
                    marksGivenCount++;
                    totalObtained += obtained;
                    totalMarks += total;
                    const percentage = total > 0 ? (obtained / total) * 100 : 0;
                    if (calculateGradeInfo(percentage, currentGrades).gpa === 0) {
                        failedSubjectsCount++;
                    }
                }
            });

            const overallPercentage = totalMarks > 0 ? (totalObtained / totalMarks) * 100 : 0;
            let resultStatus: ResultRowData['resultStatus'] = 'কৃতকার্য';
            let finalGrade = '';
            let finalGpa = 0;

            if (isMadrasaMode) {
                if (madrasaResultSettings.enableAbsentStatus && marksGivenCount === 0) {
                    resultStatus = 'অনুপস্থিত';
                    finalGrade = 'অনুপস্থিত';
                    finalGpa = 0;
                } else if (madrasaResultSettings.enableSuspendedStatus && marksGivenCount > 0 && marksGivenCount < relevantSubjects.length) {
                    resultStatus = 'স্থগিত';
                    finalGrade = 'স্থগিত';
                    finalGpa = 0;
                } else {
                    const avgGradeInfo = calculateGradeInfo(overallPercentage, currentGrades);
                    // Base grade is determined by average
                    finalGrade = avgGradeInfo.grade;
                    finalGpa = avgGradeInfo.gpa;
                    resultStatus = avgGradeInfo.gpa > 0 ? 'কৃতকার্য' : 'অকৃতকার্য';
            
                    // Override with "Maqbul" if setting is on and conditions are met
                    const maqbulGradeInfo = currentGrades.find(g => g.name === 'মকবুল');
                    if (madrasaResultSettings.enableMaqbulOnSingleFail && failedSubjectsCount > 0 && avgGradeInfo.gpa > 0 && maqbulGradeInfo) {
                        finalGrade = maqbulGradeInfo.name;
                        finalGpa = maqbulGradeInfo.gpa;
                        resultStatus = 'কৃতকার্য'; // Maqbul is a pass
                    }
                }
            } else { // Academic Mode
                if (marksGivenCount === 0) {
                    resultStatus = 'অনুপস্থিত';
                    finalGrade = 'অনুপস্থিত';
                    finalGpa = 0;
                    failedSubjectsCount = relevantSubjects.length;
                } else {
                    const isFail = failedSubjectsCount > 0;
                    const avgGradeInfo = calculateGradeInfo(totalMarks > 0 ? (totalObtained / totalMarks) * 100 : 0, currentGrades);
                    resultStatus = isFail ? 'Failed' : 'Passed';
                    finalGrade = isFail ? failGradeName : avgGradeInfo.grade;
                    finalGpa = isFail ? 0 : avgGradeInfo.gpa;
                }
            }
            
            return { ...student, totalObtained, grade: finalGrade, gpa: finalGpa, resultStatus, marksBySubject, failedSubjectsCount, totalMarks, overallPercentage };
        });

        const sortedByMarks = results.sort((a, b) => {
            const statusOrder = { 'কৃতকার্য': 1, 'Passed': 1, 'অকৃতকার্য': 2, 'Failed': 2, 'স্থগিত': 3, 'অনুপস্থিত': 4 };
            const statusA = statusOrder[a.resultStatus as keyof typeof statusOrder] || 5;
            const statusB = statusOrder[b.resultStatus as keyof typeof statusOrder] || 5;
            if (statusA !== statusB) return statusA - statusB;
            if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
            return (a.roll || 999) - (b.roll || 999);
        });

        let rank = 0;
        let lastScore = -1;
        const finalRankedResults = sortedByMarks.map((s, index) => {
            let currentRank: number | '-' = '-';
            const studentGradeInfo = currentGrades.find(g => g.name === s.grade);
            
            const isEligibleForRank = (s.resultStatus === 'কৃতকার্য' || s.resultStatus === 'Passed') && 
                                          (!isMadrasaMode || (studentGradeInfo?.isRankable ?? false));

            if (isEligibleForRank) {
                if (s.totalObtained !== lastScore) {
                    rank = index + 1;
                    lastScore = s.totalObtained;
                }
                currentRank = rank;
            }
            return { ...s, rank: currentRank };
        });
        
        const rollSortedResults = [...finalRankedResults].sort((a, b) => (a.roll || 999) - (b.roll || 999));

        return { rankedResults: rollSortedResults as ResultRowData[], subjectsForClass: relevantSubjects };

    }, [students, academicYearFilter, classFilter, sectionFilter, examFilter, examTypeFilter, markRecords, classLevels, exams, grades, madrasaGrades, isMadrasaMode, madrasaResultSettings, currentGrades, madrasaExamTypes, selectedExam]);
    
    const highestMarksBySubject = useMemo(() => {
        const highest: Record<string, number> = {};
        if (!allFiltersSelected || subjectsForClass.length === 0) return highest;

        subjectsForClass.forEach(subject => {
            const marksForThisSubject = rankedResults
                .map(res => res.marksBySubject[subject.id]?.obtained)
                .filter(mark => typeof mark === 'number') as number[];
            
            highest[subject.id] = marksForThisSubject.length > 0 ? Math.max(...marksForThisSubject) : 0;
        });
        return highest;
    }, [rankedResults, subjectsForClass, allFiltersSelected]);


    const generateSingleReportData = (student: StudentData): ReportData | null => {
        if (!allFiltersSelected) return null;
        let exam = exams.find(e => e.id === examFilter);
        if (!exam) return null;

        if (isMadrasaMode) {
            const examTypeName = madrasaExamTypes.find(et => et.id === examTypeFilter)?.name || '';
            if (examTypeName) {
                 exam = { ...exam, name: examTypeName };
            }
        }

        const studentReport = rankedResults.find(r => r.id === student.id);
        if (!studentReport) return null;

        const subjectRows = subjectsForClass.map(subject => {
            const markInfo = studentReport.marksBySubject[subject.id];
            const obtained = markInfo?.obtained; 
            const total = markInfo?.total ?? 100;
            const gradeInfo = (obtained !== null && obtained !== undefined) ? calculateGradeInfo((obtained / total) * 100, currentGrades) : { grade: 'N/A', gpa: 0 };
            return { name: subject.name, fullMarks: total, highestMark: highestMarksBySubject[subject.id] || 0, // Use memoized value
                totalMarks: obtained, letterGrade: gradeInfo.grade, gradePoint: gradeInfo.gpa.toFixed(2) };
        });
        const totalFullMarks = subjectRows.reduce((sum, r) => sum + (r.fullMarks || 0), 0);

        return { 
            student: studentReport, 
            exam, 
            subjectRows, 
            failedSubjectsCount: studentReport.failedSubjectsCount, 
            totalFullMarks 
        };
    };

    const handleViewReportCard = (studentData: ResultRowData, e: React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();

        const student = students.find(s => s.id === studentData.id);
        const reportData = generateSingleReportData(studentData);
        if (reportData && student) {
            setReportModal({ isOpen: true, student, reportData });
        }
    };

    const generatePrintableHtml = (): string => {
        const tableBody = document.getElementById('result-sheet-table-content')?.querySelector('tbody');
        if (!tableBody || !selectedExam) return '';

        const clonedBody = tableBody.cloneNode(true) as HTMLTableSectionElement;
        clonedBody.querySelectorAll('.no-print').forEach(el => el.remove());
        const tableBodyHtml = clonedBody.innerHTML;

        let examName = selectedExam.name;
        if (isMadrasaMode && examTypeFilter) {
            examName = madrasaExamTypes.find(et => et.id === examTypeFilter)?.name || examName;
        }

        const reportTitle = "রেজাল্ট শিট";
        const subTitle = `পরীক্ষা: ${examName} | শ্রেণি: ${classFilter} | শাখা: ${sectionFilter}`;

        const sortedGradesForMerit = [...currentGrades].sort((a, b) => b.minPercentage - a.minPercentage);
        const meritDivisionHtml = `
            <div style="flex-shrink: 0; width: 130px; border: 1px solid #000; font-size: 9px; font-family: 'SolaimanLipi', sans-serif;">
                <h3 style="font-weight: bold; text-align: center; background-color: #f2f2f2 !important; border-bottom: 1px solid #000; padding: 2px;">মেধা বিভাগ</h3>
                <ul style="list-style: none; padding: 4px; margin: 0;">
                    ${sortedGradesForMerit.map(g => `
                        <li key="${g.id}" style="display: flex; justify-content: space-between; padding: 1px 0;">
                            <span>${g.name}</span>
                            <span>${toBengaliNumber(g.minPercentage)}-${toBengaliNumber(g.maxPercentage)}%</span>
                        </li>
                    `).join('')}
                </ul>
            </div>
        `;

        const tableHeaderHtml = `
            <tr>
                <th class="p-1 border">রোল</th>
                <th class="p-1 border">আইডি নং</th>
                <th class="p-1 border text-left">নাম</th>
                ${subjectsForClass.map(s => `<th key="${s.id}" class="p-1 border">${s.name}</th>`).join('')}
                <th class="p-1 border">মোট প্রাপ্ত</th>
                <th class="p-1 border">গ্রেড</th>
                <th class="p-1 border">মেধা স্থান</th>
            </tr>
        `;
        
        const fullHtml = `
            <html><head>
                <title>${reportTitle}</title>
                <script src="https://cdn.tailwindcss.com"></script>
                <link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">
                <style>
                    body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                    @page { size: A4 landscape; margin: 0.7cm; }
                    table { width: 100%; border-collapse: collapse; }
                    th, td { border: 1px solid #ddd; padding: 4px; font-size: 14px; word-wrap: break-word; }
                    th { background-color: #f2f2f2 !important; font-weight: bold; }
                    thead { display: table-header-group; }
                    tfoot { display: table-footer-group; }
                    .no-print { display: none !important; }
                </style>
            </head><body>
                <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
                    <div style="flex-shrink: 0; width: 50px;">
                        ${logoUrl ? `<img src="${logoUrl}" alt="Logo" style="height: 50px; width: 50px; object-fit: cover;" />` : ''}
                    </div>
                    <div style="flex-grow: 1; text-align: center; font-family: 'SolaimanLipi', sans-serif;">
                        <h1 style="font-size: 1.8rem; font-weight: bold; margin: 0;">${institutionName}</h1>
                        <p style="font-size: 0.9rem; margin: 0 0 5px;">${address.village}, ${address.upazila}, ${address.district}</p>
                        <h2 style="font-size: 1.3rem; margin-top: 0.5rem; margin-bottom: 0;">${reportTitle}</h2>
                        <p style="font-size: 1rem; margin-top: 0;">${subTitle}</p>
                    </div>
                    ${meritDivisionHtml}
                </div>
                <table class="w-full">
                    <thead>
                        ${tableHeaderHtml}
                    </thead>
                    <tbody>
                        ${tableBodyHtml}
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="${7 + subjectsForClass.length}" style="border: none; padding-top: 50px;">
                                <div class="flex justify-between items-center text-sm pt-4">
                                    <p class="border-t border-black pt-1">শিক্ষাসচিববের স্বাক্ষর</p>
                                    <p class="text-xs">তৈরী করেছে ${managerInfo.name || 'ওয়ালিউল্লাহ রাববানী'} | ইস্যু: ${new Date().toLocaleDateString('bn-BD')}</p>
                                    <p class="border-t border-black pt-1">প্রিন্সিপালের স্বাক্ষর</p>
                                </div>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </body></html>`;
        return fullHtml;
    };
    
    const handlePrintResultSheet = () => {
        const fullHtml = generatePrintableHtml();
        if (!fullHtml) {
            addToast('প্রিন্ট করার জন্য কোনো তথ্য নেই।', 'error');
            return;
        };
        
        const printWindow = window.open('', '', 'height=800,width=1200');
        if (printWindow) {
            printWindow.document.write(fullHtml);
            printWindow.document.close();
            printWindow.focus();
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 750);
        }
    };
    
    // Removed handleDownloadResultSheetPdf function entirely.

    return (
        <div>
            {showPageHeader && <PageHeader icon="📊" title={isMadrasaMode ? "মাদরাসা রেজাল্ট শিট" : "রেজাল্ট শিট"} />}

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    {!isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>}
                    {isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষার ধরণ</option>{madrasaExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>}
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamFilter(''); setExamTypeFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon/></button>
                </div>
            </div>

            {allFiltersSelected && (
                <div className="bg-white p-4 rounded-xl shadow-md mb-6">
                    <div className="text-center text-green-600 py-4">
                        <h3 className="text-xl font-bold">ফলাফল শিট তৈরি হয়েছে!</h3>
                        <p className="mt-2 text-gray-700">আপনি এখন উপরের বাটন ব্যবহার করে প্রিন্ট করতে পারেন।</p>
                    </div>
                    <div className="flex flex-wrap justify-end items-center gap-3 mt-4">
                        <button onClick={handlePrintResultSheet} disabled={rankedResults.length === 0} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 disabled:bg-gray-400">রেজাল্ট শিট প্রিন্ট করুন</button>
                    </div>
                </div>
            )}
            
            {/* The on-screen table is now removed as per user request */}
            <div className="bg-white p-6 rounded-xl shadow-md">
                {!allFiltersSelected ? (
                    <p className="text-center text-gray-500 py-10">ফলাফল দেখতে অনুগ্রহ করে সকল ফিল্টার পূরণ করুন।</p>
                ) : rankedResults.length === 0 ? (
                    <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি বা ফলাফল এখনও তৈরি হয়নি।</p>
                ) : null} {/* This block is empty if all filters are selected and results are found, as the message is now above the buttons */}
            </div>

            {/* Hidden div for printing the full table data, only used by generatePrintableHtml */}
            <div id="result-sheet-table-content" className="hidden">
                <table className="w-full text-sm">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th className="p-2">রোল</th>
                            <th className="p-2">আইডি নং</th>
                            <th className="p-2 text-left">নাম</th>
                            {subjectsForClass.map(s => <th key={s.id} className="p-2">{s.name}</th>)}
                            <th className="p-2">মোট প্রাপ্ত</th>
                            <th className="p-2">গ্রেড</th>
                            <th className="p-2">মেধা স্থান</th>
                            <th className="p-2 no-print">পদক্ষেপ</th>
                        </tr>
                    </thead>
                    <tbody>
                        {rankedResults.map(s => (
                            <tr key={s.id} className="border-b">
                                <td className="p-2 text-center">{toBengaliNumber(s.roll)}</td>
                                <td className="p-2 text-center">{toBengaliNumber(s.uniqueId)}</td>
                                <td className="p-2 font-medium text-left">{s.nameBn}</td>
                                {subjectsForClass.map(sub => (
                                    <td key={sub.id} className="p-2 text-center">
                                        {toBengaliNumber(s.marksBySubject[sub.id]?.obtained)}
                                    </td>
                                ))}
                                <td className="p-2 text-center font-semibold">{toBengaliNumber(s.totalObtained)}</td>
                                <td className="p-2 text-center font-bold">{s.grade}</td>
                                <td className="p-2 text-center font-bold">{toBengaliNumber(s.rank)}</td>
                                <td className="p-2 text-center no-print">
                                    <button onClick={(e) => handleViewReportCard(s, e)} className="p-1 text-teal-600 hover:bg-teal-100 rounded-full" title="মার্কশীট দেখুন"><EyeIcon/></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>


            <ReportCardModal 
                isOpen={reportModal.isOpen}
                onClose={() => setReportModal({isOpen: false, student: null, reportData: null})}
                student={reportModal.student}
                reportData={reportModal.reportData}
                isMadrasaMode={isMadrasaMode}
            />
        </div>
    );
};

export default ClassResult;
