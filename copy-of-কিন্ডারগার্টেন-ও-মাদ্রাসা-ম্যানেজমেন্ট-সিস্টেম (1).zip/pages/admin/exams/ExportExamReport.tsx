
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, calculateGradeInfo } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';
import { useLocation } from 'react-router-dom';

const ExportExamReport: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams, markRecords, institutionName, grades, madrasaGrades, madrasaExamTypes, setExams, madrasaResultSettings } = useInstitution();
    const { addToast } = useNotification();
    const location = useLocation();
    const isMadrasaMode = location.pathname.includes('madrasa-result');

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const currentGrades = isMadrasaMode ? madrasaGrades : grades;
    const failGradeName = useMemo(() => currentGrades.find(g => g.gpa === 0)?.name || (isMadrasaMode ? 'রাসিব' : 'F'), [currentGrades, isMadrasaMode]);
    const maqbulGrade = isMadrasaMode ? currentGrades.find(g => g.name === 'মকবুল') : null;


    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState(''); // For Madrasa mode

    // Auto-create/select generic Madrasa Exam
    useEffect(() => {
        if (isMadrasaMode && academicYearFilter) {
            const genericMadrasaExamName = 'মাদরাসা পরীক্ষা';
            const madrasaExam = exams.find(e => e.academicYear === academicYearFilter && e.name === genericMadrasaExamName);
            if (madrasaExam) {
                setExamFilter(madrasaExam.id);
            } else {
                const newExam = {
                    id: `exam-madrasa-${academicYearFilter.replace(/[^0-9]/g, '')}-${Date.now()}`,
                    name: genericMadrasaExamName,
                    academicYear: academicYearFilter,
                    classLevels: classLevels.map(cl => cl.name),
                };
                setExams(prevExams => [...prevExams, newExam]);
                setExamFilter(newExam.id);
            }
        }
    }, [isMadrasaMode, academicYearFilter, exams, setExams, classLevels]);


    // Derived data for filters
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => {
        if (!academicYearFilter || !classFilter) return [];
        return exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter));
    }, [academicYearFilter, classFilter, exams]);
    
    useEffect(() => { 
        setSectionFilter(''); 
        if (!isMadrasaMode) {
            setExamFilter(''); 
        }
        setExamTypeFilter(''); 
    }, [classFilter, isMadrasaMode]);


    // Data processing for the report
    const { subjectsForClass, reportData } = useMemo(() => {
        const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter && (!isMadrasaMode || examTypeFilter);

        if (!allFiltersSelected) {
            return { subjectsForClass: [], reportData: [] };
        }

        const selectedExam = exams.find(e => e.id === examFilter);
        if (!selectedExam) return { subjectsForClass: [], reportData: [] };

        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        
        const assignedSubjects = isMadrasaMode 
            ? selectedExam.madrasaSubjectAssignments?.[classFilter]?.[examTypeFilter]
            : selectedExam.subjectAssignments?.[classFilter];
        
        const subjects = Array.isArray(assignedSubjects)
            ? allSubjectsForClass.filter(s => assignedSubjects.some((as: any) => as.subjectId === s.id))
            : [];
            
        if(subjects.length === 0) return { subjectsForClass: [], reportData: [] };

        const studentsInSection = students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');

        const data = studentsInSection.map(student => {
            let totalObtained = 0;
            let totalMarks = 0;
            let marksGivenCount = 0;
            let failedSubjectsCount = 0;
            const subjectMarks: Record<string, number | null> = {};

            subjects.forEach(subject => {
                const mark = markRecords.find(m => 
                    m.studentId === student.id && 
                    m.examId === examFilter && 
                    m.subjectId === subject.id &&
                    (isMadrasaMode ? m.examTypeId === examTypeFilter : true)
                );
                const obtained = mark?.marksObtained ?? null;
                
                let total = 100; // default
                if (isMadrasaMode) {
                    total = madrasaExamTypes.find(et => et.id === examTypeFilter)?.totalMarks || 100;
                } else if(assignedSubjects){
                    const assignment = (assignedSubjects as any[]).find(a => a.subjectId === subject.id);
                    total = assignment?.totalMarks || selectedExam?.defaultMarks || 100;
                }

                subjectMarks[subject.id] = obtained;

                if (obtained !== null) {
                    marksGivenCount++;
                    totalObtained += obtained;
                    totalMarks += total;
                    const percentage = total > 0 ? (obtained / total) * 100 : 0;
                    if (calculateGradeInfo(percentage, currentGrades).gpa === 0) {
                        failedSubjectsCount++;
                    }
                }
            });

            const overallPercentage = totalMarks > 0 ? (totalObtained / totalMarks) * 100 : 0;
            let finalGrade = '';

            if (isMadrasaMode) {
                if (madrasaResultSettings.enableAbsentStatus && marksGivenCount === 0) {
                    finalGrade = 'অনুপস্থিত';
                } 
                else if (madrasaResultSettings.enableSuspendedStatus && marksGivenCount > 0 && marksGivenCount < subjects.length) {
                    finalGrade = 'স্থগিত';
                }
                else {
                    const avgGradeInfo = calculateGradeInfo(overallPercentage, currentGrades);
                    // Base grade is determined by average
                    finalGrade = avgGradeInfo.grade;

                    // Override with "Maqbul" if setting is on and conditions are met
                    const maqbulGradeInfo = currentGrades.find(g => g.name === 'মকবুল');
                    if (madrasaResultSettings.enableMaqbulOnSingleFail && failedSubjectsCount > 0 && avgGradeInfo.gpa > 0 && maqbulGradeInfo) {
                        finalGrade = maqbulGradeInfo.name;
                    }
                }
            } else { // Academic Mode
                if (marksGivenCount === 0) {
                    finalGrade = 'অনুপস্থিত';
                } else {
                    const isOverallFail = failedSubjectsCount > 0 || calculateGradeInfo(overallPercentage, currentGrades).gpa === 0;
                    finalGrade = isOverallFail ? failGradeName : calculateGradeInfo(overallPercentage, currentGrades).grade;
                }
            }

            return {
                id: student.id,
                roll: student.roll,
                name: student.nameBn,
                marks: subjectMarks,
                totalObtained,
                totalMarks,
                grade: finalGrade,
            };
        }).sort((a, b) => (a.roll || 999) - (b.roll || 999));

        return { subjectsForClass: subjects, reportData: data };

    }, [academicYearFilter, classFilter, sectionFilter, examFilter, examTypeFilter, isMadrasaMode, students, classLevels, markRecords, currentGrades, exams, failGradeName, madrasaExamTypes, madrasaResultSettings, maqbulGrade]);
    
    const handleExport = () => {
        if (reportData.length === 0) {
            addToast('রপ্তানি করার জন্য কোনো তথ্য নেই।', 'error');
            return;
        }

        let csvContent = '\uFEFF'; // BOM for Excel compatibility
        
        // Header Row
        const headers = ['রোল', 'নাম', ...subjectsForClass.map(s => s.name), 'মোট প্রাপ্ত', 'মোট নম্বর', 'গ্রেড'];
        csvContent += headers.join(',') + '\r\n';

        // Data Rows
        reportData.forEach(student => {
            const row = [
                student.roll || '',
                `"${student.name}"`, // Enclose name in quotes to handle commas
                ...subjectsForClass.map(s => student.marks[s.id] ?? 'N/A'),
                student.totalObtained,
                student.totalMarks,
                student.grade,
            ];
            csvContent += row.join(',') + '\r\n';
        });

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const examName = isMadrasaMode ? madrasaExamTypes.find(et => et.id === examTypeFilter)?.name || 'Madrasa-Exam' : exams.find(e => e.id === examFilter)?.name || 'Exam';
        const filename = `ফলাফল-${classFilter}-${sectionFilter}-${examName.replace(/\s+/g, '-')}.csv`;
        
        link.href = URL.createObjectURL(blob);
        link.download = filename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(link.href);
        addToast('রিপোর্ট ডাউনলোড শুরু হয়েছে!', 'success');
    };

    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter && (!isMadrasaMode || examTypeFilter);

    return (
        <div>
            <PageHeader icon="⬆️" title={isMadrasaMode ? "মাদরাসা ফলাফল রিপোর্ট" : "ফলাফল রিপোর্ট এক্সপোর্ট"} />

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    {!isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>}
                    {isMadrasaMode && <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষার ধরণ</option>{madrasaExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500"/></span></div>}
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); if (!isMadrasaMode) setExamFilter(''); setExamTypeFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {allFiltersSelected ? (
                    reportData.length > 0 ? (
                        <>
                            <div className="flex justify-between items-center mb-4">
                                <h3 className="text-lg font-bold text-gray-800">রিপোর্ট প্রিভিউ ({reportData.length} জন শিক্ষার্থী)</h3>
                                <button onClick={handleExport} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg text-sm">CSV এক্সপোর্ট করুন</button>
                            </div>
                            <div className="overflow-x-auto max-h-96">
                                <table className="w-full text-sm">
                                    <thead className="text-xs text-gray-700 uppercase bg-gray-50 sticky top-0">
                                        <tr>
                                            <th className="p-2">রোল</th><th className="p-2 text-left">নাম</th>
                                            {subjectsForClass.map(s => <th key={s.id} className="p-2">{s.name}</th>)}
                                            <th className="p-2">মোট প্রাপ্ত</th><th className="p-2">মোট নম্বর</th><th className="p-2">গ্রেড</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {reportData.map(s => (
                                            <tr key={s.id} className="border-b hover:bg-gray-50">
                                                <td className="p-2 text-center">{s.roll}</td>
                                                <td className="p-2 font-medium">{s.name}</td>
                                                {subjectsForClass.map(sub => <td key={sub.id} className="p-2 text-center">{s.marks[sub.id] ?? '-'}</td>)}
                                                <td className="p-2 text-center font-semibold">{s.totalObtained}</td>
                                                <td className="p-2 text-center">{s.totalMarks}</td>
                                                <td className="p-2 text-center font-bold">{s.grade}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </>
                    ) : ( <p className="text-center text-gray-500 py-10">এই ফিল্টারে কোনো শিক্ষার্থীর ফলাফল পাওয়া যায়নি।</p> )
                ) : (
                    <p className="text-center text-gray-500 py-10">রিপোর্ট দেখতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p>
                )}
            </div>
        </div>
    );
};

export default ExportExamReport;
