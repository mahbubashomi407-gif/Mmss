
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, ExamData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { useNavigate, useSearchParams } from 'react-router-dom';

const CreateExam: React.FC = () => {
    const { exams, setExams, academicSessions, classLevels } = useInstitution();
    const { addToast } = useNotification();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const examId = searchParams.get('id');
    const isEditMode = Boolean(examId);

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    const [name, setName] = useState('');
    const [academicYear, setAcademicYear] = useState(activeSession?.name || '');
    const [selectedClasses, setSelectedClasses] = useState<string[]>([]);
    
    const allClassNames = useMemo(() => classLevels.map(cl => cl.name), [classLevels]);

    useEffect(() => {
        if (isEditMode) {
            const examToEdit = exams.find(e => e.id === examId);
            if (examToEdit) {
                setName(examToEdit.name);
                setAcademicYear(examToEdit.academicYear);
                setSelectedClasses(examToEdit.classLevels);
            } else {
                addToast('সম্পাদনার জন্য পরীক্ষাটি খুঁজে পাওয়া যায়নি!', 'error');
                navigate('/app/exams/list');
            }
        } else {
            // Reset form for new entry
            setName('');
            setAcademicYear(activeSession?.name || '');
            setSelectedClasses([]);
        }
    }, [examId, isEditMode, exams, navigate, addToast, activeSession]);

    const handleClassChange = (className: string, checked: boolean) => {
        setSelectedClasses(prev => 
            checked ? [...prev, className] : prev.filter(c => c !== className)
        );
    };
  
    const handleSelectAllClasses = (checked: boolean) => {
        setSelectedClasses(checked ? allClassNames : []);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim() || !academicYear || selectedClasses.length === 0) {
            addToast('অনুগ্রহ করে সকল আবশ্যক ফিল্ড পূরণ করুন।', 'error');
            return;
        }

        if (isEditMode) {
            const examToEdit = exams.find(e => e.id === examId);
            if (!examToEdit) {
                addToast('সম্পাদনার জন্য পরীক্ষা খুঁজে পাওয়া যায়নি।', 'error');
                return;
            }
            const { defaultMarks, ...restOfExam } = examToEdit; // Remove defaultMarks
            const updatedExam: ExamData = { 
                ...restOfExam,
                name, 
                academicYear, 
                classLevels: selectedClasses
            };
            setExams(exams.map(e => e.id === examId ? updatedExam : e));
            addToast('পরীক্ষা সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else {
            const newExam: ExamData = {
                id: `exam-${Date.now()}`,
                name,
                academicYear,
                classLevels: selectedClasses,
            };
            setExams([...exams, newExam]);
            addToast('নতুন পরীক্ষা সফলভাবে তৈরি করা হয়েছে!', 'success');
        }
        
        navigate('/app/exams/list');
    };

    return (
        <div>
            <PageHeader icon={isEditMode ? "✏️" : "➕"} title={isEditMode ? "পরীক্ষা সম্পাদনা করুন" : "নতুন পরীক্ষা / মূল্যায়ন তৈরি"} />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                        <label htmlFor="examName" className="block text-sm font-medium text-gray-700">পরীক্ষার নাম<span className="text-red-500">*</span></label>
                        <input
                            id="examName"
                            type="text"
                            value={name}
                            onChange={e => setName(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                            placeholder="উদাহরণ: প্রথম সাময়িক পরীক্ষা"
                            required
                        />
                    </div>

                    <div>
                        <label htmlFor="academicYear" className="block text-sm font-medium text-gray-700">শিক্ষা বর্ষ<span className="text-red-500">*</span></label>
                        <select
                            id="academicYear"
                            value={academicYear}
                            onChange={e => setAcademicYear(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 bg-white"
                            required
                        >
                            <option value="" disabled>শিক্ষা বর্ষ নির্বাচন করুন</option>
                            {academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                        </select>
                    </div>
                    

                    <div>
                        <label className="block text-sm font-medium text-gray-700">প্রযোজ্য শ্রেণি<span className="text-red-500">*</span></label>
                        <div className="mt-2 p-3 border border-gray-200 rounded-md max-h-48 overflow-y-auto">
                            <div className="flex items-center justify-between border-b pb-2 mb-2">
                                <span className="text-xs font-semibold text-gray-500">শ্রেণি নির্বাচন করুন</span>
                                <label className="flex items-center space-x-2 text-xs cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={selectedClasses.length === allClassNames.length && allClassNames.length > 0}
                                        onChange={(e) => handleSelectAllClasses(e.target.checked)}
                                        className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                                    />
                                    <span>সবাই</span>
                                </label>
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                {classLevels.map(cl => (
                                    <label key={cl.id} className="flex items-center space-x-2 text-sm p-1 rounded cursor-pointer hover:bg-gray-50">
                                        <input
                                            type="checkbox"
                                            checked={selectedClasses.includes(cl.name)}
                                            onChange={(e) => handleClassChange(cl.name, e.target.checked)}
                                            className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                                        />
                                        <span className="text-gray-700">{cl.name}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                         {selectedClasses.length === 0 && <p className="text-xs text-red-500 mt-1">অনুগ্রহ করে অন্তত একটি শ্রেণি নির্বাচন করুন।</p>}
                    </div>

                    <div className="flex justify-end gap-3 pt-4 border-t">
                        <button
                            type="button"
                            onClick={() => navigate('/app/exams/list')}
                            className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300"
                        >
                            বাতিল
                        </button>
                        <button
                            type="submit"
                            className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700"
                        >
                            {isEditMode ? 'আপডেট করুন' : 'পরীক্ষা তৈরি করুন'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default CreateExam;