import React from 'react';
import PageHeader from '../../../components/PageHeader';

const ExamSummary: React.FC = () => {
  return (
    <div>
      <PageHeader icon="📅" title="টার্ম / মাসিক / সাপ্তাহিক সারসংক্ষেপ" />
      <div className="bg-white p-6 rounded-xl shadow-md">
        <p className="text-center text-gray-500">এই পেজের কাজ চলছে।</p>
      </div>
    </div>
  );
};

export default ExamSummary;