
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, ExamData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, CalendarIcon, ChevronDownIcon } from '../../../components/icons';
import { useLocation } from 'react-router-dom';

const ExamSubjectAssignment: React.FC = () => {
    const { exams, setExams, academicSessions, classLevels, madrasaExamTypes } = useInstitution();
    const { addToast } = useNotification();
    const location = useLocation();
    const isMadrasaMode = location.pathname.includes('madrasa-result');

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [examFilter, setExamFilter] = useState(''); // Will be set automatically in Madrasa mode
    const [examTypeFilter, setExamTypeFilter] = useState(''); // For Madrasa mode

    // State for assignments
    const [assignments, setAssignments] = useState<Map<string, number | ''>>(new Map());
    const [initialAssignments, setInitialAssignments] = useState<Map<string, number | ''>>(new Map());

    // New useEffect to handle automatic exam selection/creation for Madrasa mode
    useEffect(() => {
        if (isMadrasaMode && academicYearFilter) {
            const genericMadrasaExamName = 'মাদরাসা পরীক্ষা';
            const madrasaExam = exams.find(e => e.academicYear === academicYearFilter && e.name === genericMadrasaExamName);

            if (madrasaExam) {
                setExamFilter(madrasaExam.id);
            } else {
                // Create the generic exam if it doesn't exist
                const allClassNames = classLevels.map(cl => cl.name);
                const newExam: ExamData = {
                    id: `exam-madrasa-${academicYearFilter.replace(/[^0-9]/g, '')}-${Date.now()}`,
                    name: genericMadrasaExamName,
                    academicYear: academicYearFilter,
                    classLevels: allClassNames, // Applicable for all classes in that year
                };
                setExams(prevExams => [...prevExams, newExam]);
                setExamFilter(newExam.id);
            }
        }
    }, [isMadrasaMode, academicYearFilter, exams, setExams, classLevels]);

    // Derived data for filters
    const availableExams = useMemo(() => {
        if (!academicYearFilter || !classFilter) return [];
        return exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter));
    }, [academicYearFilter, classFilter, exams]);

    const subjectsForClass = useMemo(() => {
        if (!classFilter) return [];
        return classLevels.find(cl => cl.name === classFilter)?.subjects || [];
    }, [classFilter, classLevels]);
    
    // Effect to reset filters and state when a parent filter changes
    useEffect(() => { 
        if (!isMadrasaMode) {
            setExamFilter('');
        }
        setExamTypeFilter(''); 
    }, [academicYearFilter, classFilter, isMadrasaMode]);
    
    // Effect to load existing assignments when an exam is selected
    useEffect(() => {
        if (examFilter && classFilter) {
            const exam = exams.find(e => e.id === examFilter);
            if (isMadrasaMode) {
                if(examTypeFilter) {
                    const existingAssignments = exam?.madrasaSubjectAssignments?.[classFilter]?.[examTypeFilter] || [];
                    const newAssignmentsMap = new Map<string, number | ''>();
                    const examType = madrasaExamTypes.find(et => et.id === examTypeFilter);
                    const marks = examType ? examType.totalMarks : 100;
                    existingAssignments.forEach(a => newAssignmentsMap.set(a.subjectId, marks));
                    setAssignments(newAssignmentsMap);
                    setInitialAssignments(new Map(newAssignmentsMap));
                } else {
                     setAssignments(new Map());
                     setInitialAssignments(new Map());
                }
            } else { // Academic Mode
                const existingAssignments = exam?.subjectAssignments?.[classFilter] || [];
                const newAssignmentsMap = new Map<string, number | ''>();
                existingAssignments.forEach(a => newAssignmentsMap.set(a.subjectId, a.totalMarks));
                setAssignments(newAssignmentsMap);
                setInitialAssignments(new Map(newAssignmentsMap));
            }
        } else {
            setAssignments(new Map());
            setInitialAssignments(new Map());
        }
    }, [examFilter, classFilter, exams, isMadrasaMode, examTypeFilter, madrasaExamTypes]);
    
    const hasUnsavedChanges = useMemo(() => {
       if (assignments.size !== initialAssignments.size) return true;
       for (const [key, value] of assignments) {
           if (initialAssignments.get(key) !== value) return true;
       }
       return false;
    }, [assignments, initialAssignments]);

    const handleAssignmentChange = (subjectId: string, checked: boolean, value?: string) => {
        setAssignments(prev => {
            const newMap = new Map(prev);
            if (checked) {
                if (isMadrasaMode) {
                    const examType = madrasaExamTypes.find(et => et.id === examTypeFilter);
                    newMap.set(subjectId, examType?.totalMarks || 100);
                } else {
                     newMap.set(subjectId, value !== undefined ? (value === '' ? '' : Number(value)) : (prev.get(subjectId) || 100));
                }
            } else {
                newMap.delete(subjectId);
            }
            return newMap;
        });
    };
    
    const handleSelectAll = (checked: boolean) => {
        const newMap = new Map<string, number | ''>();
        if (checked) {
            const defaultMarks = isMadrasaMode ? (madrasaExamTypes.find(et => et.id === examTypeFilter)?.totalMarks || 100) : 100;
            subjectsForClass.forEach(s => {
                newMap.set(s.id, defaultMarks);
            });
        }
        setAssignments(newMap);
    };

    const handleSaveChanges = () => {
        if (!examFilter || !classFilter) return;

        if (isMadrasaMode) {
            if (!examTypeFilter) { addToast('পরীক্ষার ধরণ নির্বাচন করুন।', 'error'); return; }
        } else {
            for (const [subjectId, marks] of assignments) {
                if (marks === '' || Number(marks) <= 0) {
                    const subject = subjectsForClass.find(s => s.id === subjectId);
                    addToast(`"${subject?.name}" বিষয়ের জন্য একটি সঠিক পূর্ণমান দিন।`, 'error');
                    return;
                }
            }
        }

        const updatedExams = exams.map(exam => {
            if (exam.id === examFilter) {
                if (isMadrasaMode) {
                    const newAssignmentsForType = Array.from(assignments.keys()).map(subjectId => ({ subjectId }));
                    const newMadrasaAssignments = JSON.parse(JSON.stringify(exam.madrasaSubjectAssignments || {}));
                    if (!newMadrasaAssignments[classFilter]) newMadrasaAssignments[classFilter] = {};
                    newMadrasaAssignments[classFilter][examTypeFilter] = newAssignmentsForType;
                    return { ...exam, madrasaSubjectAssignments: newMadrasaAssignments };
                } else {
                     const newAssignmentsForClass = Array.from(assignments.entries()).map(([subjectId, totalMarks]) => ({ subjectId, totalMarks: Number(totalMarks) }));
                     const updatedAssignments = { ...(exam.subjectAssignments || {}), [classFilter]: newAssignmentsForClass };
                     return { ...exam, subjectAssignments: updatedAssignments };
                }
            }
            return exam;
        });
        setExams(updatedExams as ExamData[]);
        setInitialAssignments(new Map(assignments));
        addToast('বিষয় অ্যাসাইনমেন্ট সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };
    
    const subjectTotalMarks = useMemo(() => {
        if (isMadrasaMode && examTypeFilter) {
            return madrasaExamTypes.find(et => et.id === examTypeFilter)?.totalMarks;
        }
        return null;
    }, [isMadrasaMode, examTypeFilter, madrasaExamTypes]);

    const allFiltersSelected = academicYearFilter && classFilter && (!isMadrasaMode ? examFilter : examFilter && examTypeFilter);

    return (
        <div>
            <PageHeader icon="📚" title={isMadrasaMode ? "মাদরাসা বিষয় অ্যাসাইনমেন্ট" : "একাডেমিক বিষয় অ্যাসাইনমেন্ট"} />
            <div className="bg-white p-4 rounded-xl shadow-md mb-6">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                        <label className="block text-sm font-medium">শিক্ষা বর্ষ</label>
                        <select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full p-2 border rounded-md bg-white mt-1">
                            <option value="" disabled>বর্ষ</option>
                            {academicSessions.map(s=><option key={s.id}>{s.name}</option>)}
                        </select>
                    </div>
                    <div>
                        <label className="block text-sm font-medium">শ্রেণি</label>
                        <select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full p-2 border rounded-md bg-white mt-1">
                            <option value="">শ্রেণি</option>
                            {classLevels.map(cl=><option key={cl.id}>{cl.name}</option>)}
                        </select>
                    </div>
                    
                    {!isMadrasaMode && (
                         <div>
                            <label className="block text-sm font-medium">পরীক্ষা</label>
                            <select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full p-2 border rounded-md bg-white mt-1" disabled={!classFilter}>
                                <option value="">পরীক্ষা</option>
                                {availableExams.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}
                            </select>
                        </div>
                    )}

                    {isMadrasaMode && (
                        <div>
                            <label className="block text-sm font-medium">পরীক্ষার ধরণ</label>
                            <select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full p-2 border rounded-md bg-white mt-1" disabled={!classFilter}>
                                <option value="">ধরণ</option>
                                {madrasaExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}
                            </select>
                        </div>
                    )}
                </div>
            </div>

            {(allFiltersSelected) ? (
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-lg font-bold text-gray-800 mb-4">"{classLevels.find(c=>c.name===classFilter)?.name}" শ্রেণির জন্য বিষয় {isMadrasaMode ? 'নির্বাচন' : 'ও নম্বর নির্ধারণ'} করুন {subjectTotalMarks && `(পূর্ণমান: ${subjectTotalMarks})`}</h3>
                    {subjectsForClass.length > 0 ? (
                        <div className="space-y-3">
                            <div className="flex items-center justify-end border-b pb-2"><label className="flex items-center space-x-2 text-sm cursor-pointer"><input type="checkbox" checked={assignments.size === subjectsForClass.length && subjectsForClass.length > 0} onChange={e => handleSelectAll(e.target.checked)} className="h-4 w-4 text-teal-600"/><span>সবাইকে নির্বাচন করুন</span></label></div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                                {subjectsForClass.map(subject => {
                                    const isSelected = assignments.has(subject.id);
                                    return (
                                        <div key={subject.id} className={`p-3 rounded-lg border transition-all ${isSelected ? 'bg-teal-50 border-teal-300' : 'bg-gray-50'}`}>
                                            <label className="flex items-center space-x-2 cursor-pointer"><input type="checkbox" checked={isSelected} onChange={e => handleAssignmentChange(subject.id, e.target.checked)} className="h-4 w-4 text-teal-600"/><span className="font-medium">{subject.name}</span></label>
                                            {!isMadrasaMode && isSelected && (
                                                <div className="mt-2"><label className="text-xs">পূর্ণমান</label><input type="number" value={assignments.get(subject.id) || ''} onChange={e => handleAssignmentChange(subject.id, true, e.target.value)} disabled={!isSelected} className="w-full p-1 border rounded-md text-sm mt-1"/></div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                             <div className="flex justify-end pt-4 border-t mt-4"><button onClick={handleSaveChanges} disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">সংরক্ষণ করুন</button></div>
                        </div>
                    ) : ( <p className="text-center text-gray-500 py-10">এই শ্রেণির জন্য কোনো বিষয় যোগ করা হয়নি।</p> )}
                </div>
            ) : ( <div className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md"><p>বিষয় নির্ধারণ করতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p></div> )}
        </div>
    );
};

export default ExamSubjectAssignment;
