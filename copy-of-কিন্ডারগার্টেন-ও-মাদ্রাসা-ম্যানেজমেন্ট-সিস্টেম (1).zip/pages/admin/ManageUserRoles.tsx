
import React from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';
import { useInstitution } from '../../context/InstitutionContext';

const ActionCard: React.FC<{ icon: string; title: string }> = ({ icon, title }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className="bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};

const ManageUserRoles: React.FC = () => {
    const actions = [
      { icon: '➕', title: 'ইউজার তৈরী', to: 'create' },
      { icon: '📋', title: 'ইউজার তালিকা', to: 'list' },
      { icon: '🔐', title: 'ইউজার পারমিশন', to: 'permissions' },
    ];

    return (
        <div>
            <PageHeader icon="👥" title="ইউজার রোল কন্ট্রোল" />
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {actions.map((action, index) => (
                    <Link to={action.to} key={index} className="no-underline h-full">
                        <ActionCard icon={action.icon} title={action.title} />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default ManageUserRoles;
