import React from 'react';
import PageHeader from '../../../components/PageHeader';

const EditProgress: React.FC = () => {
  return (
    <div>
      <PageHeader icon="🔄" title="হোমওয়ার্ক / অগ্রগতি সংশোধন" />
      <div className="bg-white p-6 rounded-xl shadow-md">
        <p className="text-center text-gray-500">এই পেজের কাজ চলছে।</p>
      </div>
    </div>
  );
};

export default EditProgress;