import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, TeacherData, SectionData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon } from '../../../components/icons';

const ClassAllocation: React.FC = () => {
    const { sections, setSections, teachers, classLevels } = useInstitution();
    const { addToast } = useNotification();

    const [modifiedSections, setModifiedSections] = useState<SectionData[]>([]);
    const [classFilter, setClassFilter] = useState('');

    useEffect(() => {
        // Deep copy to avoid mutating context state directly
        setModifiedSections(JSON.parse(JSON.stringify(sections)));
    }, [sections]);

    const hasUnsavedChanges = useMemo(() => {
        return JSON.stringify(sections) !== JSON.stringify(modifiedSections);
    }, [sections, modifiedSections]);

    const handleTeacherChange = (sectionId: string, teacherName: string) => {
        setModifiedSections(prev =>
            prev.map(section =>
                section.id === sectionId ? { ...section, teacherName } : section
            )
        );
    };

    const handleSaveChanges = () => {
        setSections(modifiedSections);
        addToast('শ্রেণি শিক্ষকের দায়িত্ব সফলভাবে আপডেট করা হয়েছে!', 'success');
    };
    
    const handleReset = () => {
        setModifiedSections(JSON.parse(JSON.stringify(sections)));
        addToast('পরিবর্তন বাতিল করা হয়েছে।', 'error');
    };

    const groupedSections = useMemo(() => {
        const groups: { [key: string]: SectionData[] } = {};
        const sectionsToDisplay = classFilter 
            ? modifiedSections.filter(s => s.classLevel === classFilter)
            : modifiedSections;

        sectionsToDisplay.forEach(section => {
            if (!groups[section.classLevel]) {
                groups[section.classLevel] = [];
            }
            groups[section.classLevel].push(section);
        });
        
        // Sort class levels by the order defined in context
        const sortedClassLevels = classLevels.map(cl => cl.name);
        return Object.entries(groups).sort(([a], [b]) => sortedClassLevels.indexOf(a) - sortedClassLevels.indexOf(b));
    }, [modifiedSections, classFilter, classLevels]);
    
    return (
        <div>
            <PageHeader icon="🏫" title="শ্রেণি / সেকশন দায়িত্ব">
                {hasUnsavedChanges && (
                    <div className="flex items-center gap-2">
                        <button onClick={handleReset} className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg shadow-md hover:bg-red-600">বাতিল</button>
                        <button onClick={handleSaveChanges} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700">সংরক্ষণ করুন</button>
                    </div>
                )}
            </PageHeader>
            
            <div className="bg-white p-4 rounded-xl shadow-md mb-6 max-w-sm">
                 <div className="relative">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                        <GraduationCapIcon className="w-5 h-5 text-gray-400" />
                    </span>
                    <select
                        value={classFilter}
                        onChange={e => setClassFilter(e.target.value)}
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                        aria-label="Filter by class"
                    >
                        <option value="">সকল শ্রেণি দেখান</option>
                        {classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}
                    </select>
                </div>
            </div>

            <div className="space-y-6">
                {groupedSections.length > 0 ? groupedSections.map(([classLevel, classSections]) => (
                    <div key={classLevel} className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-xl font-bold text-gray-800 border-b pb-3 mb-4">{classLevel}</h3>
                        <div className="space-y-4">
                            {classSections.map(section => {
                                const originalSection = sections.find(s => s.id === section.id);
                                const isChanged = originalSection?.teacherName !== section.teacherName;
                                return (
                                <div key={section.id} className={`grid grid-cols-1 md:grid-cols-3 items-center gap-4 p-3 rounded-lg ${isChanged ? 'bg-yellow-50 ring-1 ring-yellow-300' : ''}`}>
                                    <label htmlFor={`teacher-${section.id}`} className="font-semibold text-gray-700">
                                        সেকশন: <span className="text-teal-600">{section.name}</span>
                                    </label>
                                    <div className="md:col-span-2">
                                        <select
                                            id={`teacher-${section.id}`}
                                            value={section.teacherName || ''}
                                            onChange={e => handleTeacherChange(section.id, e.target.value)}
                                            className="w-full p-2 border border-gray-300 rounded-md bg-white focus:ring-2 focus:ring-teal-500"
                                        >
                                            <option value="">শ্রেণি শিক্ষক নেই</option>
                                            {teachers.map(teacher => (
                                                <option key={teacher.id} value={teacher.nameBn}>
                                                    {teacher.nameBn} ({teacher.uniqueId})
                                                </option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                            )})
                            }
                        </div>
                    </div>
                )) : (
                     <div className="bg-white p-10 rounded-xl shadow-md text-center">
                        <p className="text-gray-500">কোনো সেকশন পাওয়া যায়নি। অনুগ্রহ করে প্রথমে "সেটিংস" থেকে শ্রেণি ও সেকশন যোগ করুন।</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ClassAllocation;