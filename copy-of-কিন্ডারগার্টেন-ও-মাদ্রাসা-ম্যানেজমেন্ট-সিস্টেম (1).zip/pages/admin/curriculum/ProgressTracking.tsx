import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, ProgressBehaviorData } from '../../../context/InstitutionContext';
import { useAuth } from '../../../context/AuthContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, PencilIcon, TrashIcon, SearchIcon } from '../../../components/icons';
import ProgressBehaviorModal from '../../../components/ProgressBehaviorModal';

const ProgressTracking: React.FC = () => {
    const { students, classLevels, sections, academicSessions, progressBehaviorRecords, setProgressBehaviorRecords } = useInstitution();
    const { user } = useAuth();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 5;

    const [addModal, setAddModal] = useState<{ isOpen: boolean; student: StudentData | null; note: ProgressBehaviorData | null }>({ isOpen: false, student: null, note: null });
    const [historyModal, setHistoryModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; note: ProgressBehaviorData | null }>({ isOpen: false, note: null });

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    
    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        
        let studentsToShow = students.filter(s => 
            s.academicYear === academicYearFilter && 
            s.classLevel === classFilter && 
            s.section === sectionFilter && 
            s.status !== 'পেন্ডিং'
        );

        if (searchTerm.trim()) {
            const lowerSearchTerm = searchTerm.toLowerCase();
            studentsToShow = studentsToShow.filter(s => 
                s.nameBn.toLowerCase().includes(lowerSearchTerm) ||
                (s.roll && s.roll.toString().includes(lowerSearchTerm)) ||
                s.uniqueId.toLowerCase().includes(lowerSearchTerm)
            );
        }
        
        return studentsToShow.sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter, searchTerm]);

    useEffect(() => {
        setCurrentPage(1);
    }, [academicYearFilter, classFilter, sectionFilter, searchTerm]);

    const paginatedStudents = useMemo(() => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        return filteredStudents.slice(startIndex, startIndex + itemsPerPage);
    }, [filteredStudents, currentPage, itemsPerPage]);

    const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);

    const studentLastNoteMap = useMemo(() => {
        const map = new Map<string, string>();
        progressBehaviorRecords.forEach(record => {
            const existing = map.get(record.studentId);
            if (!existing || new Date(record.date) > new Date(existing)) {
                map.set(record.studentId, record.date);
            }
        });
        return map;
    }, [progressBehaviorRecords]);

    const handleSaveNote = (data: Omit<ProgressBehaviorData, 'id' | 'recordedBy'> & { id?: string }) => {
        if (data.id) { // Edit
            setProgressBehaviorRecords(progressBehaviorRecords.map(r => r.id === data.id ? { ...r, ...data } as ProgressBehaviorData : r));
            addToast('নোট সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Add new
            const newRecord = { ...data, id: Date.now().toString(), recordedBy: user?.displayName || 'অ্যাডমিন' };
            setProgressBehaviorRecords([...progressBehaviorRecords, newRecord]);
            addToast('নতুন নোট যোগ করা হয়েছে!', 'success');
        }
        setAddModal({ isOpen: false, student: null, note: null });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.note) {
            setProgressBehaviorRecords(progressBehaviorRecords.filter(r => r.id !== deleteModal.note!.id));
            addToast('নোট সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, note: null });
    };

    const studentHistory = useMemo(() => {
        if (!historyModal.student) return [];
        return progressBehaviorRecords.filter(r => r.studentId === historyModal.student!.id).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    }, [historyModal, progressBehaviorRecords]);

    return (
        <div>
            <PageHeader icon="🧒" title="শিক্ষার্থী অগ্রগতি ট্র্যাকিং" />

            {/* Filters */}
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ নির্বাচন</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><SearchIcon className="w-5 h-5 text-gray-400" /></span>
                        <input type="text" placeholder="নাম, রোল বা আইডি দিয়ে খুঁজুন..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500" disabled={!classFilter || !sectionFilter} />
                    </div>
                    <button onClick={() => { setAcademicYearFilter(activeSession?.name || ''); setClassFilter(''); setSectionFilter(''); setSearchTerm(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {classFilter && sectionFilter ? (
                    filteredStudents.length > 0 ? (
                        <>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="text-xs text-gray-700 uppercase bg-gray-50"><tr><th className="p-2">রোল</th><th className="p-2">শিক্ষার্থীর নাম</th><th className="p-2">শেষ নোট</th><th className="p-2 text-right">পদক্ষেপ</th></tr></thead>
                                    <tbody>
                                        {paginatedStudents.map(student => (
                                            <tr key={student.id} className="border-b hover:bg-gray-50">
                                                <td className="p-2">{student.roll}</td>
                                                <td className="p-2 font-medium">{student.nameBn}</td>
                                                <td className="p-2 text-gray-500">{studentLastNoteMap.has(student.id) ? new Date(studentLastNoteMap.get(student.id)!).toLocaleDateString('bn-BD') : 'নেই'}</td>
                                                <td className="p-2 text-right space-x-2">
                                                    <button onClick={() => setAddModal({ isOpen: true, student, note: null })} className="px-3 py-1 text-xs bg-green-100 text-green-700 font-semibold rounded-md hover:bg-green-200">নোট যোগ করুন</button>
                                                    <button onClick={() => setHistoryModal({ isOpen: true, student })} className="px-3 py-1 text-xs bg-blue-100 text-blue-700 font-semibold rounded-md hover:bg-blue-200">ইতিহাস দেখুন</button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            {totalPages > 1 && (
                                <div className="flex justify-between items-center mt-4 text-sm text-gray-600">
                                    <p>মোট {filteredStudents.length} জন শিক্ষার্থীর মধ্যে {paginatedStudents.length} জন দেখানো হচ্ছে।</p>
                                    <div className="flex items-center gap-2">
                                        <button onClick={() => setCurrentPage(p => p > 1 ? p - 1 : p)} disabled={currentPage === 1} className="px-3 py-1 border rounded-md disabled:opacity-50">পূর্ববর্তী</button>
                                        <span>পাতা {currentPage} / {totalPages}</span>
                                        <button onClick={() => setCurrentPage(p => p < totalPages ? p + 1 : p)} disabled={currentPage === totalPages} className="px-3 py-1 border rounded-md disabled:opacity-50">পরবর্তী</button>
                                    </div>
                                </div>
                            )}
                        </>
                    ) : <p className="text-center text-gray-500 py-10">এই ফিল্টারে কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                ) : <p className="text-center text-gray-500 py-10">শিক্ষার্থীদের তালিকা দেখতে একটি শ্রেণি ও সেকশন নির্বাচন করুন।</p>}
            </div>

            {/* Add/Edit Modal */}
            <ProgressBehaviorModal isOpen={addModal.isOpen} onClose={() => setAddModal({ isOpen: false, student: null, note: null })} onSave={handleSaveNote} student={addModal.student} noteToEdit={addModal.note} />
            
            {/* History Modal */}
            {historyModal.isOpen && historyModal.student && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setHistoryModal({ isOpen: false, student: null })}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4 h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
                        <div className="p-5 border-b"><h3 className="text-lg font-bold">নোটের ইতিহাস: {historyModal.student.nameBn}</h3></div>
                        <div className="p-5 flex-grow overflow-y-auto space-y-3">
                            {studentHistory.length > 0 ? studentHistory.map(note => (
                                <div key={note.id} className="p-3 bg-gray-50 rounded-lg">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${note.type === 'Progress' ? 'bg-blue-100 text-blue-700' : 'bg-yellow-100 text-yellow-700'}`}>{note.type === 'Progress' ? 'অগ্রগতি' : 'আচরণ'}</span>
                                            <span className="text-xs text-gray-500 ml-2">{new Date(note.date).toLocaleDateString('bn-BD')}</span>
                                            <p className="text-sm text-gray-800 mt-1 whitespace-pre-wrap">{note.note}</p>
                                            <p className="text-xs text-gray-400 mt-1">রেকর্ড করেছেন: {note.recordedBy}</p>
                                        </div>
                                        <div className="flex-shrink-0 space-x-1">
                                            <button onClick={() => { setHistoryModal({ isOpen: false, student: null }); setAddModal({ isOpen: true, student: historyModal.student, note }); }} className="p-1 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button>
                                            <button onClick={() => setDeleteModal({ isOpen: true, note })} className="p-1 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button>
                                        </div>
                                    </div>
                                </div>
                            )) : <p className="text-center text-gray-500 py-10">এই শিক্ষার্থীর জন্য কোনো নোট পাওয়া যায়নি।</p>}
                        </div>
                        <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                            <button type="button" onClick={() => setHistoryModal({ isOpen: false, student: null })} className="px-4 py-2 bg-gray-200 rounded-lg">বন্ধ করুন</button>
                        </div>
                    </div>
                </div>
            )}

            {/* Delete Confirmation Modal */}
            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({ isOpen: false, note: null })} onConfirm={handleConfirmDelete} title="নোট মুছুন">আপনি কি নিশ্চিতভাবে এই নোটটি মুছে ফেলতে চান?</Modal>
        </div>
    );
};

export default ProgressTracking;