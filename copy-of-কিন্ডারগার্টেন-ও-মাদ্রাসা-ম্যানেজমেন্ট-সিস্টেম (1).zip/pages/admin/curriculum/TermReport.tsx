import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { ReportCardModal, ReportData, ReportCardContent } from '../../../components/ReportCardModal';
import { useInstitution, StudentData, calculateGradeInfo, ExamData, GradeData, SubjectData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, EyeIcon } from '../../../components/icons';

const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        '.': '.', '%': '%'
    };
    return num.replace(/[0-9.%]/g, (match) => map[match] || match);
};

interface ResultRowData extends StudentData {
    totalObtained: number;
    totalMarks: number;
    overallPercentage: number;
    grade: string;
    gpa: number;
    resultStatus: 'Passed' | 'Failed' | 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থगित' | 'অনুপস্থিত';
    rank: number | '-';
    marksBySubject: Record<string, { obtained: number | null; total: number }>;
    failedSubjectsCount: number;
}


const TermReport: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams, markRecords, grades } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    
    const [reportModal, setReportModal] = useState<{ isOpen: boolean; student: StudentData | null; reportData: ReportData | null }>({ isOpen: false, student: null, reportData: null });

    // Derived data for filters
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => {
        if (!classFilter) return [];
        return exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter));
    }, [classFilter, academicYearFilter, exams]);

    useEffect(() => { if (sectionFilter && !availableSections.includes(sectionFilter)) setSectionFilter(''); }, [availableSections, sectionFilter]);
    useEffect(() => { if (examFilter && !availableExams.some(e => e.id === examFilter)) setExamFilter(''); }, [availableExams, examFilter]);

    // Calculate results for the filtered students
    const studentResults = useMemo(() => {
        if (!classFilter || !sectionFilter || !examFilter) return [];
        
        const studentsInSection = students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');

        const selectedExam = exams.find(e => e.id === examFilter);
        if (!selectedExam) return [];

        const assignedSubjects = selectedExam?.subjectAssignments?.[classFilter];
        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        
        const subjectsForExam = Array.isArray(assignedSubjects)
            ? allSubjectsForClass.filter(s => assignedSubjects.some(as => as.subjectId === s.id))
            : [];
            
        if (subjectsForExam.length === 0) return [];

        return studentsInSection.map(student => {
            const studentMarks = markRecords.filter(m => m.studentId === student.id && m.examId === examFilter);
            
            let totalObtained = 0;
            let totalMarks = 0;
            let isFail = false; // Track if student failed any subject
            let hasAnyMark = false; // Track if any marks were recorded

            subjectsForExam.forEach(subject => {
                const mark = studentMarks.find(m => m.subjectId === subject.id);
                const obtained = mark?.marksObtained ?? null;
                
                let total = selectedExam?.defaultMarks ?? 100;
                if (mark?.totalMarks) {
                    total = mark.totalMarks;
                } else if (assignedSubjects) {
                    const assignment = assignedSubjects.find(a => a.subjectId === subject.id);
                    if (assignment) total = assignment.totalMarks;
                }

                if (obtained !== null) {
                    hasAnyMark = true;
                    totalObtained += obtained;
                    totalMarks += total;
                    const percentage = total > 0 ? (obtained / total) * 100 : 0;
                    if (calculateGradeInfo(percentage, grades).gpa === 0) { // Assuming 0 GPA means fail
                        isFail = true;
                    }
                }
            });

            // Handle cases where no marks were entered for the student
            if (!hasAnyMark) {
                 return { ...student, totalObtained: 0, totalMarks: 0, percentage: 0, grade: 'অনুপস্থিত', gpa: 0 };
            }

            const percentage = totalMarks > 0 ? (totalObtained / totalMarks) * 100 : 0;
            const { grade, gpa } = calculateGradeInfo(percentage, grades);
            
            // If any subject failed, the overall grade is 'F' or the designated fail grade
            const finalGrade = isFail ? (grades.find(g => g.gpa === 0)?.name || 'F') : grade;
            const finalGpa = isFail ? 0 : gpa;

            return { ...student, totalObtained, totalMarks, percentage, grade: finalGrade, gpa: finalGpa };
        }).sort((a,b) => (a.roll || 999) - (b.roll || 999));

    }, [students, academicYearFilter, classFilter, sectionFilter, examFilter, markRecords, classLevels, exams, grades]);

    const generateSingleReportData = (student: StudentData): ReportData | null => {
        const exam = exams.find(e => e.id === examFilter);
        if (!exam) return null;

        const studentsInClass = students.filter(s => 
            s.academicYear === academicYearFilter && 
            s.classLevel === classFilter && 
            s.section === student.section && 
            s.status !== 'পেন্ডিং'
        );
        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        const assignedSubjects = exam.subjectAssignments?.[classFilter] || [];
        const subjectsForExam = allSubjectsForClass.filter(s => assignedSubjects.some(as => as.subjectId === s.id));
        const failGradeName = grades.find(g => g.gpa === 0)?.name || 'F';
        
        const allStudentResults = studentsInClass.map(currentStudent => {
            const studentMarks = markRecords.filter(m => m.studentId === currentStudent.id && m.examId === examFilter);
            let totalObtained = 0, totalMarks = 0, isFail = false, hasAnyMark = false;
            const marksBySubject: Record<string, { obtained: number | null; total: number }> = {};
            subjectsForExam.forEach(subject => {
                const mark = studentMarks.find(m => m.subjectId === subject.id);
                const obtained = mark?.marksObtained ?? null;
                const total = assignedSubjects.find(as => as.subjectId === subject.id)?.totalMarks || 100;
                marksBySubject[subject.id] = { obtained, total };
                if (obtained !== null) {
                    hasAnyMark = true; totalObtained += obtained; totalMarks += total;
                    if (calculateGradeInfo((obtained / total) * 100, grades).grade === failGradeName) isFail = true;
                }
            });
            if (!hasAnyMark) return { ...currentStudent, totalObtained: 0, resultStatus: 'অনুপস্থিত' as const, isAbsent: true, grade: 'অনুপস্থিত', gpa: 0, marksBySubject }; // Changed 'Failed' to 'অনুপস্থিত' for no marks
            const { grade, gpa } = calculateGradeInfo((totalObtained / totalMarks) * 100, grades);
            return { ...currentStudent, totalObtained, isAbsent: false, resultStatus: (isFail ? 'অকৃতকার্য' : 'কৃতকার্য') as 'কৃতকার্য' | 'অকৃতকার্য', grade: isFail ? failGradeName : grade, gpa: isFail ? 0 : gpa, marksBySubject };
        });

        // Calculate rank within the class
        const sorted = allStudentResults.sort((a, b) => {
            // Sort logic as in EvaluationReport.tsx
            const statusOrder = { 'কৃতকার্য': 1, 'অকৃতকার্য': 2, 'অনুপস্থিত': 3 };
            const statusA = statusOrder[a.resultStatus as keyof typeof statusOrder] || 4;
            const statusB = statusOrder[b.resultStatus as keyof typeof statusOrder] || 4;
            if (statusA !== statusB) return statusA - statusB;
            if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
            return (a.roll || 999) - (b.roll || 999);
        });

        let rank = 0, lastScore = -1;
        const rankedResults = sorted.map((s, index) => {
            let currentRank: number | '-' = '-';
            if (s.resultStatus === 'কৃতকার্য') { // Only rank passed students
                if (s.totalObtained !== lastScore) { rank = index + 1; lastScore = s.totalObtained; }
                currentRank = rank;
            }
            return { ...s, rank: currentRank };
        });

        const studentReport = rankedResults.find(r => r.id === student.id);
        if (!studentReport) return null;

        const highestMarksBySubject: Record<string, number> = {};
        subjectsForExam.forEach(subject => { highestMarksBySubject[subject.id] = Math.max(0, ...allStudentResults.map(res => res.marksBySubject[subject.id]?.obtained || 0)); });
        
        let failedSubjectsCount = 0;
        const subjectRows = subjectsForExam.map(subject => {
            const markInfo = studentReport.marksBySubject[subject.id];
            const obtained = markInfo?.obtained; 
            const total = markInfo?.total ?? 100;
            const gradeInfo = (obtained !== null && obtained !== undefined) ? calculateGradeInfo((obtained / total) * 100, grades) : { grade: 'N/A', gpa: 0 };
            if (gradeInfo.grade === failGradeName) failedSubjectsCount++;
            return { name: subject.name, fullMarks: total, highestMark: highestMarksBySubject[subject.id], totalMarks: obtained, letterGrade: gradeInfo.grade, gradePoint: gradeInfo.gpa.toFixed(2) };
        });
        const totalFullMarks = subjectRows.reduce((sum, r) => sum + r.fullMarks, 0);

        return { student: studentReport, exam, subjectRows, failedSubjectsCount, totalFullMarks };
    };

    const handleViewReportCard = (studentData: ResultRowData, e: React.MouseEvent<HTMLButtonElement>) => {
        e.stopPropagation();

        const student = students.find(s => s.id === studentData.id);
        const reportData = generateSingleReportData(studentData);
        if (reportData && student) {
            setReportModal({ isOpen: true, student, reportData });
        }
    };


    return (
        <div>
            <PageHeader icon="📊" title="টার্ম / মাসিক রিপোর্ট" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {studentResults.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50"><tr><th className="p-2">রোল</th><th className="p-2">শিক্ষার্থীর নাম</th><th className="p-2">মোট নম্বর</th><th className="p-2">প্রাপ্ত নম্বর</th><th className="p-2">শতকরা হার</th><th className="p-2">গ্রেড</th><th className="p-2 text-right">পদক্ষেপ</th></tr></thead>
                            <tbody>
                                {studentResults.map(s => (
                                    <tr key={s.id} className="border-b hover:bg-gray-50">
                                        <td className="p-2">{s.roll}</td>
                                        <td className="p-2 font-medium">{s.nameBn}</td>
                                        <td className="p-2">{s.totalMarks}</td>
                                        <td className="p-2">{s.totalObtained}</td>
                                        <td className="p-2">{s.percentage.toFixed(2)}%</td>
                                        <td className="p-2 font-bold">{s.grade}</td>
                                        <td className="p-2 text-right">
                                            <button onClick={(e) => handleViewReportCard(s as ResultRowData, e)} className="px-3 py-1 text-xs bg-teal-100 text-teal-700 font-semibold rounded-md hover:bg-teal-200 flex items-center gap-1">
                                                <EyeIcon className="w-3 h-3" />
                                                রিপোর্ট কার্ড দেখুন
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">ফলাফল দেখতে অনুগ্রহ করে শ্রেণি, সেকশন এবং পরীক্ষা নির্বাচন করুন।</p>
                )}
            </div>
            
            <ReportCardModal 
                isOpen={reportModal.isOpen}
                onClose={() => setReportModal({isOpen: false, student: null, reportData: null})}
                student={reportModal.student}
                isMadrasaMode={false} // TermReport is academic
                reportData={reportModal.reportData}
            />
        </div>
    );
};

export default TermReport;
