import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, ClassLevelData, SubjectData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import SubjectModal from '../../../components/SubjectModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const Subjects: React.FC = () => {
    const { classLevels, setClassLevels } = useInstitution();
    const { addToast } = useNotification();
    
    // State for modals
    const [subjectModal, setSubjectModal] = useState<{ isOpen: boolean; classLevel: ClassLevelData | null; subjectToEdit: SubjectData | null }>({ isOpen: false, classLevel: null, subjectToEdit: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; item: SubjectData | null; classId?: string; }>({ isOpen: false, item: null });

    // --- Subject Handlers ---
    const handleSaveSubject = (data: { name: string; id?: string }) => {
        const targetClassId = subjectModal.classLevel?.id;
        if (!targetClassId) return;

        const updatedClassLevels = classLevels.map(cl => {
            if (cl.id === targetClassId) {
                let updatedSubjects: SubjectData[];
                if (data.id) { // Edit subject
                    updatedSubjects = cl.subjects.map(sub => sub.id === data.id ? { ...sub, name: data.name } : sub);
                    addToast('বিষয় আপডেট করা হয়েছে!', 'success');
                } else { // Add new subject
                    const newSubject = { id: Date.now().toString(), name: data.name };
                    updatedSubjects = [...cl.subjects, newSubject];
                    addToast('নতুন বিষয় যোগ করা হয়েছে!', 'success');
                }
                return { ...cl, subjects: updatedSubjects };
            }
            return cl;
        });
        setClassLevels(updatedClassLevels);
        setSubjectModal({ isOpen: false, classLevel: null, subjectToEdit: null });
    };
    
    // --- Delete Handler ---
    const handleConfirmDelete = () => {
        const { item, classId } = deleteModal;
        if (!item || !classId) return;

        const updatedClassLevels = classLevels.map(cl => {
            if (cl.id === classId) {
                return { ...cl, subjects: cl.subjects.filter(sub => sub.id !== item.id) };
            }
            return cl;
        });
        setClassLevels(updatedClassLevels);
        addToast('বিষয়টি মুছে ফেলা হয়েছে!', 'success');
        
        setDeleteModal({ isOpen: false, item: null });
    };

    return (
        <div>
            <PageHeader icon="📝" title="বিষয় / কিতাব তালিকা" />
            
            <div className="space-y-6">
                {classLevels.map(cl => (
                    <div key={cl.id} className="bg-white p-4 rounded-xl shadow-md">
                        <div className="flex justify-between items-center border-b pb-3 mb-3">
                            <h3 className="text-xl font-bold text-gray-800">{cl.name}</h3>
                            <button 
                                onClick={() => setSubjectModal({ isOpen: true, classLevel: cl, subjectToEdit: null })} 
                                className="px-3 py-1 bg-teal-100 text-teal-700 font-semibold rounded-lg text-sm hover:bg-teal-200"
                            >
                                + নতুন বিষয় যোগ করুন
                            </button>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                            {cl.subjects.length > 0 ? cl.subjects.map(sub => (
                                <div key={sub.id} className="flex justify-between items-center p-2 bg-gray-50 rounded-lg">
                                    <span className="font-medium text-gray-700">{sub.name}</span>
                                    <div className="space-x-1 flex-shrink-0">
                                        <button 
                                            onClick={() => setSubjectModal({ isOpen: true, classLevel: cl, subjectToEdit: sub })} 
                                            className="p-1 text-blue-500 hover:bg-blue-100 rounded-full"
                                            title="সম্পাদনা করুন"
                                        >
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button 
                                            onClick={() => setDeleteModal({ isOpen: true, item: sub, classId: cl.id })} 
                                            className="p-1 text-red-500 hover:bg-red-100 rounded-full"
                                            title="মুছে ফেলুন"
                                        >
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </div>
                                </div>
                            )) : (
                                <p className="text-sm text-gray-500 col-span-full text-center py-4">এই শ্রেণিতে কোনো বিষয় যোগ করা হয়নি।</p>
                            )}
                        </div>
                    </div>
                ))}
            </div>

            {/* Modals */}
            <SubjectModal 
                isOpen={subjectModal.isOpen}
                onClose={() => setSubjectModal({ isOpen: false, classLevel: null, subjectToEdit: null })}
                onSave={handleSaveSubject}
                subjectToEdit={subjectModal.subjectToEdit}
                className={subjectModal.classLevel?.name || ''}
            />
            <Modal
                isOpen={deleteModal.isOpen}
                onClose={() => setDeleteModal({ isOpen: false, item: null })}
                onConfirm={handleConfirmDelete}
                title="বিষয় মুছে ফেলা নিশ্চিত করুন"
            >
                আপনি কি নিশ্চিতভাবে "{deleteModal.item?.name}" বিষয়টি মুছে ফেলতে চান?
            </Modal>
        </div>
    );
};

export default Subjects;