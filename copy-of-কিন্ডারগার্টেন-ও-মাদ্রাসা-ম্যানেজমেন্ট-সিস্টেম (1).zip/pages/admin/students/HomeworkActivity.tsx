
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, HomeworkData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon, EyeIcon, DownloadIcon } from '../../../components/icons';
import HomeworkModal from '../../../components/HomeworkModal';

const HomeworkActivity: React.FC = () => {
    const { homeworks, setHomeworks, classLevels, sections } = useInstitution();
    const { addToast } = useNotification();

    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [selectedHomework, setSelectedHomework] = useState<HomeworkData | null>(null);

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    const filteredHomeworks = useMemo(() => {
        return homeworks.filter(hw => 
            (!classFilter || hw.classLevel === classFilter) &&
            (!sectionFilter || hw.section === sectionFilter)
        ).sort((a, b) => new Date(b.assignDate).getTime() - new Date(a.assignDate).getTime());
    }, [homeworks, classFilter, sectionFilter]);

    const handleAddNew = () => {
        setSelectedHomework(null);
        setIsModalOpen(true);
    };

    const handleEdit = (hw: HomeworkData) => {
        setSelectedHomework(hw);
        setIsModalOpen(true);
    };

    const handleView = (hw: HomeworkData) => {
        setSelectedHomework(hw);
        setIsViewModalOpen(true);
    };

    const handleDelete = (hw: HomeworkData) => {
        setSelectedHomework(hw);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedHomework) {
            setHomeworks(homeworks.filter(hw => hw.id !== selectedHomework.id));
            addToast('হোমওয়ার্ক সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedHomework(null);
    };

    const handleSave = (data: Omit<HomeworkData, 'id'> & { id?: string }) => {
        if (data.id) {
            setHomeworks(homeworks.map(hw => hw.id === data.id ? { ...hw, ...data } : hw));
            addToast('হোমওয়ার্ক সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else {
            const newHomework = { ...data, id: Date.now().toString() };
            setHomeworks([newHomework, ...homeworks]);
            addToast('নতুন হোমওয়ার্ক যোগ করা হয়েছে!', 'success');
        }
        setIsModalOpen(false);
    };

    return (
        <div>
            <PageHeader icon="📚" title="হোমওয়ার্ক / অ্যাক্টিভিটি">
                <button onClick={handleAddNew} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                    নতুন হোমওয়ার্ক দিন
                </button>
            </PageHeader>

            <div className="bg-white p-4 rounded-xl shadow-md mb-6 flex flex-wrap items-center gap-4">
                <select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500">
                    <option value="">সকল শ্রেণি</option>
                    {classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}
                </select>
                <select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" disabled={!classFilter}>
                    <option value="">সকল সেকশন</option>
                    {availableSections.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-4 py-2">শিরোনাম</th>
                                <th className="px-4 py-2">শ্রেণি/সেকশন</th>
                                <th className="px-4 py-2">বিষয়</th>
                                <th className="px-4 py-2">জমা দেওয়ার তারিখ</th>
                                <th className="px-4 py-2 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredHomeworks.length > 0 ? filteredHomeworks.map(hw => (
                                <tr key={hw.id} className="border-b hover:bg-gray-50">
                                    <td className="px-4 py-2 font-medium">{hw.title}</td>
                                    <td className="px-4 py-2">{hw.classLevel} ({hw.section})</td>
                                    <td className="px-4 py-2">{hw.subject}</td>
                                    <td className="px-4 py-2">{new Date(hw.submissionDate).toLocaleDateString('bn-BD')}</td>
                                    <td className="px-4 py-2 text-right space-x-1">
                                        <button onClick={() => handleView(hw)} className="p-2 text-green-600 hover:bg-green-100 rounded-full" title="দেখুন"><EyeIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleEdit(hw)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleDelete(hw)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )) : (
                                <tr><td colSpan={5} className="text-center py-10 text-gray-500">কোনো হোমওয়ার্ক পাওয়া যায়নি।</td></tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <HomeworkModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onSave={handleSave} homeworkToEdit={selectedHomework} />
            
            <Modal isOpen={isDeleteModalOpen} onClose={() => setIsDeleteModalOpen(false)} onConfirm={handleConfirmDelete} title="হোমওয়ার্ক মুছুন">
                আপনি কি নিশ্চিতভাবে এই হোমওয়ার্কটি মুছে ফেলতে চান?
            </Modal>
            
            {isViewModalOpen && selectedHomework && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setIsViewModalOpen(false)}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                        <div className="p-5 border-b">
                            <h3 className="text-lg font-bold">{selectedHomework.title}</h3>
                            <p className="text-xs text-gray-500">{selectedHomework.classLevel} ({selectedHomework.section}) - {selectedHomework.subject}</p>
                        </div>
                        <div className="p-5 max-h-80 overflow-y-auto">
                            <p className="whitespace-pre-wrap">{selectedHomework.description}</p>
                            {selectedHomework.fileUrl && (
                                <div className="mt-4">
                                    <a href={selectedHomework.fileUrl} download={selectedHomework.fileName} className="flex items-center gap-2 text-sm text-blue-600 font-semibold hover:underline">
                                        <DownloadIcon className="w-4 h-4" />
                                        <span>সংযুক্তি ডাউনলোড করুন ({selectedHomework.fileName})</span>
                                    </a>
                                </div>
                            )}
                        </div>
                         <div className="bg-gray-50 p-3 text-xs text-gray-600 flex justify-between">
                             <span><strong>দেওয়ার তারিখ:</strong> {new Date(selectedHomework.assignDate).toLocaleDateString('bn-BD')}</span>
                             <span className="font-semibold"><strong>জমা দেওয়ার তারিখ:</strong> {new Date(selectedHomework.submissionDate).toLocaleDateString('bn-BD')}</span>
                         </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default HomeworkActivity;
