
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';

const AttendanceStatusBadge: React.FC<{ status: 'present' | 'absent' | 'leave' | undefined }> = ({ status }) => {
    switch (status) {
        case 'present':
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-green-100 text-green-700 font-bold text-xs" title="উপস্থিত">উ</span>;
        case 'absent':
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-red-100 text-red-700 font-bold text-xs" title="অনুপস্থিত">অ</span>;
        case 'leave':
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-yellow-100 text-yellow-700 font-bold text-xs" title="ছুটি">ছু</span>;
        default:
            return <span className="flex items-center justify-center h-6 w-6 rounded-full bg-gray-100 text-gray-400 font-bold text-xs">-</span>;
    }
};

const ViewAttendance: React.FC = () => {
    const { students, attendanceRecords, classLevels, sections, academicSessions } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [monthFilter, setMonthFilter] = useState(currentMonth);

    // Derived data from filters
    const availableSections = useMemo(() => {
        if (!classFilter) return [];
        return sections.filter(s => s.classLevel === classFilter).map(s => s.name);
    }, [classFilter, sections]);

    // Reset section if class changes
    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) {
            setSectionFilter('');
        }
    }, [availableSections, sectionFilter]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        return students
            .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter)
            .sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter]);

    const { days, year, month } = useMemo(() => {
        if (!monthFilter) return { days: [], year: 0, month: 0 };
        const [y, m] = monthFilter.split('-').map(Number);
        const date = new Date(y, m - 1, 1);
        const daysInMonth = new Date(y, m, 0).getDate();
        return {
            days: Array.from({ length: daysInMonth }, (_, i) => i + 1),
            year: y,
            month: m - 1, // 0-indexed for Date object
        };
    }, [monthFilter]);

    const attendanceMap = useMemo(() => {
        const map = new Map<string, Map<string, 'present' | 'absent' | 'leave'>>();
        filteredStudents.forEach(student => {
            const studentAttendance = new Map<string, 'present' | 'absent' | 'leave'>();
            attendanceRecords
                .filter(rec => rec.studentId === student.id && rec.date.startsWith(monthFilter))
                .forEach(rec => {
                    studentAttendance.set(rec.date, rec.status);
                });
            map.set(student.id, studentAttendance);
        });
        return map;
    }, [filteredStudents, attendanceRecords, monthFilter]);

    const studentStats = useMemo(() => {
        const stats = new Map<string, { present: number; absent: number; leave: number }>();
        filteredStudents.forEach(student => {
            const studentAttendance = attendanceMap.get(student.id) || new Map();
            const counts = { present: 0, absent: 0, leave: 0 };
            studentAttendance.forEach(status => {
                counts[status]++;
            });
            stats.set(student.id, counts);
        });
        return stats;
    }, [filteredStudents, attendanceMap]);

    const getDayName = (day: number) => {
        const date = new Date(year, month, day);
        return date.toLocaleDateString('bn-BD', { weekday: 'short' });
    };
    
    const isWeekend = (day: number) => {
        const date = new Date(year, month, day);
        const dayOfWeek = date.getDay();
        return dayOfWeek === 5; // Friday
    };
    
    const overallStats = useMemo(() => {
        let totalPresent = 0, totalAbsent = 0, totalLeave = 0;
        studentStats.forEach(stat => {
            totalPresent += stat.present;
            totalAbsent += stat.absent;
            totalLeave += stat.leave;
        });
        return { totalPresent, totalAbsent, totalLeave, totalStudents: filteredStudents.length };
    }, [studentStats, filteredStudents]);


    return (
        <div>
            <PageHeader icon="📅" title="হাজিরা (ভিউ)" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span>
                        <input type="month" value={monthFilter} onChange={e => setMonthFilter(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white" />
                    </div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setMonthFilter(currentMonth); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            {(classFilter && sectionFilter) ? (
                <div className="bg-white p-4 sm:p-6 rounded-xl shadow-md">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6 text-center">
                        <div className="p-3 bg-gray-50 rounded-lg"><p className="text-sm text-gray-500">মোট শিক্ষার্থী</p><p className="text-2xl font-bold text-gray-800">{overallStats.totalStudents}</p></div>
                        <div className="p-3 bg-green-50 rounded-lg"><p className="text-sm text-green-600">মোট উপস্থিতি</p><p className="text-2xl font-bold text-green-700">{overallStats.totalPresent}</p></div>
                        <div className="p-3 bg-red-50 rounded-lg"><p className="text-sm text-red-600">মোট অনুপস্থিতি</p><p className="text-2xl font-bold text-red-700">{overallStats.totalAbsent}</p></div>
                        <div className="p-3 bg-yellow-50 rounded-lg"><p className="text-sm text-yellow-600">মোট ছুটি</p><p className="text-2xl font-bold text-yellow-700">{overallStats.totalLeave}</p></div>
                    </div>
                    {filteredStudents.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse text-xs text-center">
                            <thead>
                                <tr className="bg-gray-50">
                                    <th className="sticky left-0 bg-gray-50 p-2 border min-w-[150px] text-left">শিক্ষার্থীর নাম</th>
                                    {days.map(day => (
                                        <th key={day} className={`p-1 border w-10 ${isWeekend(day) ? 'bg-gray-200' : ''}`}>
                                            <div>{day}</div>
                                            <div className="font-normal text-gray-500">{getDayName(day)}</div>
                                        </th>
                                    ))}
                                    <th className="p-2 border bg-green-50">উপস্থিত</th>
                                    <th className="p-2 border bg-red-50">অনুপস্থিত</th>
                                    <th className="p-2 border bg-yellow-50">ছুটি</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredStudents.map(student => {
                                    const records = attendanceMap.get(student.id);
                                    const stats = studentStats.get(student.id);
                                    return (
                                        <tr key={student.id} className="border-b hover:bg-gray-50">
                                            <td className="sticky left-0 bg-white hover:bg-gray-50 p-2 border text-left font-medium text-gray-800">
                                                {student.nameBn} <span className="text-gray-500">({student.roll})</span>
                                            </td>
                                            {days.map(day => {
                                                const date = `${monthFilter}-${String(day).padStart(2, '0')}`;
                                                const status = records?.get(date);
                                                return <td key={day} className={`border ${isWeekend(day) ? 'bg-gray-100' : ''}`}><AttendanceStatusBadge status={status} /></td>
                                            })}
                                            <td className="p-2 border font-bold text-green-700">{stats?.present}</td>
                                            <td className="p-2 border font-bold text-red-700">{stats?.absent}</td>
                                            <td className="p-2 border font-bold text-yellow-700">{stats?.leave}</td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                    ) : (
                         <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                    )}
                </div>
            ) : (
                <div className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">
                    <p>হাজিরা রিপোর্ট দেখতে অনুগ্রহ করে একটি শ্রেণি ও সেকশন নির্বাচন করুন।</p>
                </div>
            )}
        </div>
    );
};

export default ViewAttendance;
