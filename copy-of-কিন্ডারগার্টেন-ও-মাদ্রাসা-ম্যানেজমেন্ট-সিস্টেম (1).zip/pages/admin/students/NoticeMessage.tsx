import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentMessageData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, StudentsIcon, CalendarIcon, EyeIcon } from '../../../components/icons';

const NoticeMessage: React.FC = () => {
    const { students, classLevels, sections, academicSessions, notificationSettings, studentMessages, setStudentMessages } = useInstitution();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters and Selection
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(new Set());

    // Message Composition
    const [title, setTitle] = useState('');
    const [message, setMessage] = useState('');
    const [sendSms, setSendSms] = useState(false);
    
    // History Modal
    const [viewModal, setViewModal] = useState<{ isOpen: boolean; message: StudentMessageData | null }>({isOpen: false, message: null});

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        return students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');
    }, [students, academicYearFilter, classFilter, sectionFilter]);
    
    useEffect(() => {
        setSelectedStudentIds(new Set());
    }, [classFilter, sectionFilter, academicYearFilter]);

    const handleSelectStudent = (id: string, checked: boolean) => {
        setSelectedStudentIds(prev => {
            const newSet = new Set(prev);
            if (checked) newSet.add(id);
            else newSet.delete(id);
            return newSet;
        });
    };

    const handleSelectAll = (checked: boolean) => {
        if (checked) {
            setSelectedStudentIds(new Set(filteredStudents.map(s => s.id)));
        } else {
            setSelectedStudentIds(new Set());
        }
    };
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (selectedStudentIds.size === 0) {
            addToast('অনুগ্রহ করে অন্তত একজন প্রাপক নির্বাচন করুন।', 'error');
            return;
        }
        if (!title.trim() || !message.trim()) {
            addToast('শিরোনাম এবং বার্তা উভয়ই পূরণ করুন।', 'error');
            return;
        }

        const newMessage: StudentMessageData = {
            id: Date.now().toString(),
            title,
            message,
            sentDate: new Date().toISOString().split('T')[0],
            recipientIds: Array.from(selectedStudentIds),
            sentViaSms: sendSms
        };

        setStudentMessages([newMessage, ...studentMessages]);
        addToast('বার্তা সফলভাবে পাঠানো হয়েছে!', 'success');
        if (sendSms) {
            addToast('SMS সফলভাবে পাঠানো হয়েছে!', 'success');
        }

        // Reset form
        setTitle('');
        setMessage('');
        setSendSms(false);
        setSelectedStudentIds(new Set());
    };
    
    const sortedMessages = useMemo(() => studentMessages.sort((a,b) => new Date(b.sentDate).getTime() - new Date(a.sentDate).getTime()), [studentMessages]);


    return (
        <div>
            <PageHeader icon="📢" title="নোটিশ / বার্তা" />

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Left Side: Message Composition and Student Selection */}
                <div className="lg:col-span-2 space-y-6">
                    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-md space-y-4">
                        <h3 className="text-lg font-bold text-gray-800">নতুন বার্তা পাঠান</h3>
                        <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="শিরোনাম" required className="w-full p-2 border rounded-md" />
                        <textarea value={message} onChange={e => setMessage(e.target.value)} placeholder="আপনার বার্তা লিখুন..." rows={5} required className="w-full p-2 border rounded-md"></textarea>
                        <div className="flex items-center justify-between">
                            <label className="flex items-center">
                                <input type="checkbox" checked={sendSms} onChange={e => setSendSms(e.target.checked)} className="h-4 w-4 text-teal-600" disabled={!notificationSettings.smsGateway.enabled} />
                                <span className={`ml-2 text-sm ${!notificationSettings.smsGateway.enabled ? 'text-gray-400' : ''}`}>SMS এর মাধ্যমে পাঠান</span>
                            </label>
                            <button type="submit" className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400" disabled={selectedStudentIds.size === 0}>বার্তা পাঠান ({selectedStudentIds.size})</button>
                        </div>
                         {!notificationSettings.smsGateway.enabled && <p className="text-xs text-red-500">SMS পাঠানোর জন্য প্রথমে সেটিংস থেকে SMS গেটওয়ে সক্রিয় করুন।</p>}
                    </form>

                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-lg font-bold text-gray-800 mb-4">প্রাপক নির্বাচন করুন</h3>
                        <div className="flex flex-wrap items-center gap-3 mb-4">
                             <div className="relative flex-grow-0"><select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="w-full pl-3 pr-8 py-2 border rounded-lg bg-white"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id}>{cl.name}</option>)}</select></div>
                             <div className="relative flex-grow-0"><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-3 pr-8 py-2 border rounded-lg bg-white" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s}>{s}</option>)}</select></div>
                        </div>
                        {classFilter && sectionFilter && (
                             <div className="border rounded-lg overflow-hidden max-h-80 overflow-y-auto">
                                <table className="w-full text-sm">
                                     <thead className="bg-gray-100"><tr className="text-left"><th className="p-2 w-10"><input type="checkbox" onChange={e => handleSelectAll(e.target.checked)} checked={filteredStudents.length > 0 && selectedStudentIds.size === filteredStudents.length} /></th><th className="p-2">রোল</th><th className="p-2">নাম</th></tr></thead>
                                    <tbody>
                                    {filteredStudents.map(s => (
                                        <tr key={s.id} className="border-t hover:bg-gray-50"><td className="p-2"><input type="checkbox" checked={selectedStudentIds.has(s.id)} onChange={e => handleSelectStudent(s.id, e.target.checked)} /></td><td className="p-2">{s.roll}</td><td className="p-2">{s.nameBn}</td></tr>
                                    ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>

                {/* Right Side: Message History */}
                <div className="lg:col-span-1 bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-lg font-bold text-gray-800 mb-4 border-b pb-2">প্রেরিত বার্তার ইতিহাস</h3>
                    <div className="space-y-3 max-h-[80vh] overflow-y-auto">
                        {sortedMessages.length > 0 ? sortedMessages.map(msg => (
                            <div key={msg.id} className="p-3 bg-gray-50 rounded-lg">
                                <p className="font-semibold text-gray-800">{msg.title}</p>
                                <div className="flex justify-between items-center text-xs text-gray-500 mt-1">
                                    <span>{new Date(msg.sentDate).toLocaleDateString('bn-BD')}</span>
                                    <span>প্রাপক: {msg.recipientIds.length}</span>
                                    <button onClick={() => setViewModal({isOpen: true, message: msg})} className="text-teal-600 hover:underline">বিস্তারিত</button>
                                </div>
                            </div>
                        )) : <p className="text-sm text-gray-500 text-center py-10">কোনো বার্তা পাঠানো হয়নি।</p>}
                    </div>
                </div>
            </div>

            {/* View Message Modal */}
            {viewModal.isOpen && viewModal.message && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setViewModal({isOpen: false, message: null})}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                        <div className="p-5 border-b">
                            <h3 className="text-lg font-bold">{viewModal.message.title}</h3>
                             <p className="text-xs text-gray-500 mt-1">তারিখ: {new Date(viewModal.message.sentDate).toLocaleDateString('bn-BD')} | SMS পাঠানো হয়েছে: {viewModal.message.sentViaSms ? 'হ্যাঁ' : 'না'}</p>
                        </div>
                        <div className="p-5 space-y-4">
                            <div><h4 className="font-semibold">বার্তা:</h4><p className="text-sm bg-gray-50 p-2 rounded-md whitespace-pre-wrap">{viewModal.message.message}</p></div>
                            <div><h4 className="font-semibold">প্রাপক ({viewModal.message.recipientIds.length}):</h4><div className="text-xs bg-gray-50 p-2 rounded-md max-h-40 overflow-y-auto">{viewModal.message.recipientIds.map(id => students.find(s=>s.id === id)?.nameBn || 'Unknown').join(', ')}</div></div>
                        </div>
                         <div className="bg-gray-100 px-5 py-3 flex justify-end">
                            <button onClick={() => setViewModal({isOpen: false, message: null})} className="px-4 py-2 bg-gray-300 rounded-lg">বন্ধ করুন</button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default NoticeMessage;
