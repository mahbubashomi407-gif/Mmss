import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';

interface ModifiableStudent extends StudentData {
  newRoll: number | '';
  newSection: string;
}

const RollSectionChange: React.FC = () => {
    const { students, setStudents, classLevels, sections, academicSessions } = useInstitution();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters for selecting which students to show
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    
    // State for the list of students being modified
    const [modifiableStudents, setModifiableStudents] = useState<ModifiableStudent[]>([]);
    
    // State for bulk actions
    const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(new Set());
    const [bulkTargetSection, setBulkTargetSection] = useState('');

    const availableSectionsForFilter = useMemo(() => {
        if (!classFilter) return [];
        return sections.filter(s => s.classLevel === classFilter).map(s => s.name);
    }, [classFilter, sections]);
    
    // Filter students based on selection and prepare them for modification
    useEffect(() => {
        if (classFilter && sectionFilter) {
            const filtered = students
                .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
                .map(s => ({ ...s, newRoll: s.roll, newSection: s.section }));
            setModifiableStudents(filtered);
        } else {
            setModifiableStudents([]);
        }
        setSelectedStudentIds(new Set()); // Reset selection on filter change
    }, [academicYearFilter, classFilter, sectionFilter, students]);

    const hasUnsavedChanges = useMemo(() => {
        return modifiableStudents.some(s => s.roll !== s.newRoll || s.section !== s.newSection);
    }, [modifiableStudents]);

    const handleStudentUpdate = (id: string, field: 'newRoll' | 'newSection', value: string | number) => {
        setModifiableStudents(prev =>
            prev.map(s => s.id === id ? { ...s, [field]: value } : s)
        );
    };

    const handleSelectStudent = (id: string, checked: boolean) => {
        setSelectedStudentIds(prev => {
            const newSet = new Set(prev);
            if (checked) newSet.add(id);
            else newSet.delete(id);
            return newSet;
        });
    };

    const handleSelectAll = (checked: boolean) => {
        if (checked) {
            setSelectedStudentIds(new Set(modifiableStudents.map(s => s.id)));
        } else {
            setSelectedStudentIds(new Set());
        }
    };
    
    const applyBulkChange = () => {
        if (!bulkTargetSection || selectedStudentIds.size === 0) {
            addToast('অনুগ্রহ করে একটি সেকশন নির্বাচন করুন এবং অন্তত একজন শিক্ষার্থী নির্বাচন করুন।', 'error');
            return;
        }
        setModifiableStudents(prev =>
            prev.map(s => selectedStudentIds.has(s.id) ? { ...s, newSection: bulkTargetSection } : s)
        );
        addToast(`${selectedStudentIds.size} জন শিক্ষার্থীকে "${bulkTargetSection}" সেকশনে পরিবর্তনের জন্য চিহ্নিত করা হয়েছে।`, 'success');
    };

    const handleSaveChanges = () => {
        const changesMap = new Map<string, { roll: number | ''; section: string }>();
        modifiableStudents.forEach(s => {
            if (s.roll !== s.newRoll || s.section !== s.newSection) {
                changesMap.set(s.id, { roll: s.newRoll, section: s.newSection });
            }
        });

        if (changesMap.size === 0) {
            addToast('কোনো পরিবর্তন করা হয়নি।', 'error');
            return;
        }

        const updatedStudents = students.map(s => {
            if (changesMap.has(s.id)) {
                const changes = changesMap.get(s.id)!;
                return { ...s, roll: changes.roll, section: changes.section };
            }
            return s;
        });
        
        setStudents(updatedStudents);
        addToast(`${changesMap.size} জন শিক্ষার্থীর তথ্য সফলভাবে আপডেট করা হয়েছে!`, 'success');
    };
    
    return (
        <div>
            <PageHeader icon="🔄" title="রোল ও সেকশন পরিবর্তন" />

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ নির্বাচন</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSectionsForFilter.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setAcademicYearFilter(activeSession?.name || ''); setClassFilter(''); setSectionFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            {classFilter && sectionFilter && (
                <div className="bg-white p-6 rounded-xl shadow-md">
                    {modifiableStudents.length > 0 ? (
                        <>
                            <div className="bg-gray-50 p-3 rounded-lg mb-4 flex flex-wrap items-center gap-4">
                                <h4 className="font-semibold text-sm text-gray-800">ব্যাচ পরিবর্তন (নির্বাচিতদের জন্য)</h4>
                                <div className="relative flex-grow-0"><select value={bulkTargetSection} onChange={e => setBulkTargetSection(e.target.value)} className="w-full pl-3 pr-8 py-1.5 border border-gray-300 rounded-lg shadow-sm text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">নতুন সেকশন</option>{availableSectionsForFilter.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                                <button onClick={applyBulkChange} className="px-4 py-1.5 bg-blue-600 text-white text-sm font-semibold rounded-lg shadow-md hover:bg-blue-700" disabled={selectedStudentIds.size === 0 || !bulkTargetSection}>প্রয়োগ করুন</button>
                                <span className="text-sm text-gray-600">{selectedStudentIds.size} জন নির্বাচিত</span>
                            </div>

                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="text-xs text-gray-700 uppercase bg-gray-50"><tr><th className="p-2 w-10 text-center"><input type="checkbox" onChange={e => handleSelectAll(e.target.checked)} checked={modifiableStudents.length > 0 && selectedStudentIds.size === modifiableStudents.length} /></th><th className="p-2">বর্তমান রোল</th><th className="p-2">শিক্ষার্থীর নাম</th><th className="p-2">নতুন রোল</th><th className="p-2">নতুন সেকশন</th></tr></thead>
                                    <tbody>
                                        {modifiableStudents.map(s => {
                                            const isChanged = s.roll !== s.newRoll || s.section !== s.newSection;
                                            return (
                                                <tr key={s.id} className={`border-b ${isChanged ? 'bg-yellow-50' : ''}`}>
                                                    <td className="p-2 text-center"><input type="checkbox" checked={selectedStudentIds.has(s.id)} onChange={e => handleSelectStudent(s.id, e.target.checked)} /></td>
                                                    <td className="p-2">{s.roll}</td>
                                                    <td className="p-2 font-medium text-gray-800">{s.nameBn}</td>
                                                    <td className="p-2"><input type="number" value={s.newRoll} onChange={e => handleStudentUpdate(s.id, 'newRoll', e.target.value === '' ? '' : Number(e.target.value))} className="w-20 px-2 py-1 border rounded-md" /></td>
                                                    <td className="p-2"><select value={s.newSection} onChange={e => handleStudentUpdate(s.id, 'newSection', e.target.value)} className="w-full px-2 py-1 border rounded-md bg-white"><option value="">নির্বাচন</option>{availableSectionsForFilter.map(sec => <option key={sec} value={sec}>{sec}</option>)}</select></td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            <div className="mt-6 flex justify-end">
                                <button onClick={handleSaveChanges} disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 disabled:cursor-not-allowed">পরিবর্তন সংরক্ষণ করুন</button>
                            </div>
                        </>
                    ) : (
                        <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                    )}
                </div>
            )}
        </div>
    );
};

export default RollSectionChange;