import React, { useState, useEffect, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, SearchIcon } from '../../../components/icons';

// Interface for students with their potential new status
interface ModifiableStudent extends StudentData {
  newStatus: StudentData['status'];
}

const statusOptions: StudentData['status'][] = ['চলমান', 'ছাড়পত্র', 'উত্তীর্ণ', 'বাতিল'];

const StatusChange: React.FC = () => {
    const { students, setStudents, classLevels, sections, academicSessions } = useInstitution();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [statusFilter, setStatusFilter] = useState<StudentData['status'] | ''>('');
    const [searchTerm, setSearchTerm] = useState('');
    
    // Data and UI state
    const [modifiableStudents, setModifiableStudents] = useState<ModifiableStudent[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const availableSections = useMemo(() => {
        if (!classFilter) return [];
        return sections.filter(s => s.classLevel === classFilter).map(s => s.name);
    }, [classFilter, sections]);
    
    // Filter students based on selection and prepare them for modification
    useEffect(() => {
        const lowerSearchTerm = searchTerm.trim().toLowerCase();
        const activeStudents = students.filter(s => s.status !== 'পেন্ডিং');
        let filtered: StudentData[] = [];

        if (lowerSearchTerm) {
            filtered = activeStudents.filter(s => 
                s.nameBn.toLowerCase().includes(lowerSearchTerm) ||
                s.uniqueId.toLowerCase().includes(lowerSearchTerm)
            );
        } else if (classFilter && sectionFilter) {
             filtered = activeStudents.filter(s => 
                (!academicYearFilter || s.academicYear === academicYearFilter) &&
                (s.classLevel === classFilter) &&
                (s.section === sectionFilter) &&
                (!statusFilter || s.status === statusFilter)
            );
        }
        
        const modifiable = filtered.map(s => ({ ...s, newStatus: s.status })).sort((a,b) => (a.roll || 999) - (b.roll || 999));
        setModifiableStudents(modifiable);

    }, [academicYearFilter, classFilter, sectionFilter, statusFilter, searchTerm, students]);

    const hasUnsavedChanges = useMemo(() => {
        return modifiableStudents.some(s => s.status !== s.newStatus);
    }, [modifiableStudents]);

    const handleStatusUpdate = (id: string, newStatus: StudentData['status']) => {
        setModifiableStudents(prev =>
            prev.map(s => s.id === id ? { ...s, newStatus } : s)
        );
    };

    const handleSaveChanges = () => {
        const changesMap = new Map<string, StudentData['status']>();
        modifiableStudents.forEach(s => {
            if (s.status !== s.newStatus) {
                changesMap.set(s.id, s.newStatus);
            }
        });

        if (changesMap.size === 0) {
            addToast('কোনো পরিবর্তন করা হয়নি।', 'error');
            return;
        }

        const updatedStudents = students.map(s => {
            if (changesMap.has(s.id)) {
                return { ...s, status: changesMap.get(s.id)! };
            }
            return s;
        });
        
        setStudents(updatedStudents);
        addToast(`${changesMap.size} জন শিক্ষার্থীর স্ট্যাটাস সফলভাবে আপডেট করা হয়েছে!`, 'success');
        setIsModalOpen(false);
    };

    const getStatusBadge = (status: StudentData['status']) => {
        switch (status) {
            case 'চলমান': return 'bg-green-100 text-green-800';
            case 'ছাড়পত্র': return 'bg-yellow-100 text-yellow-800';
            case 'উত্তীর্ণ': return 'bg-blue-100 text-blue-800';
            case 'বাতিল': return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };
    
    const showPrompt = !searchTerm.trim() && (!classFilter || !sectionFilter);

    return (
        <div>
            <PageHeader icon="⛔" title="শিক্ষার্থী সক্রিয় / নিষ্ক্রিয়" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                     <div className="relative flex-grow min-w-[200px]">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><SearchIcon className="w-5 h-5 text-gray-400" /></span>
                        <input type="text" placeholder="আইডি বা নাম দিয়ে খুঁজুন..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"/>
                    </div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">সকল বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">সকল শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সকল সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={statusFilter} onChange={e => setStatusFilter(e.target.value as any)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">সকল স্ট্যাটাস</option>{statusOptions.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setSearchTerm(''); setAcademicYearFilter(activeSession?.name || ''); setClassFilter(''); setSectionFilter(''); setStatusFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {showPrompt ? (
                    <p className="text-center text-gray-500 py-10">শিক্ষার্থীদের তালিকা দেখতে শ্রেণি ও সেকশন নির্বাচন করুন অথবা আইডি/নাম দিয়ে খুঁজুন।</p>
                ) : modifiableStudents.length > 0 ? (
                    <>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr><th className="p-2">রোল</th><th className="p-2">শিক্ষার্থীর নাম</th><th className="p-2">বর্তমান স্ট্যাটাস</th><th className="p-2">নতুন স্ট্যাটাস</th></tr>
                                </thead>
                                <tbody>
                                    {modifiableStudents.map(s => {
                                        const isChanged = s.status !== s.newStatus;
                                        return (
                                            <tr key={s.id} className={`border-b ${isChanged ? 'bg-yellow-50' : 'hover:bg-gray-50'}`}>
                                                <td className="p-2">{s.roll}</td>
                                                <td className="p-2 font-medium text-gray-800">{s.nameBn}</td>
                                                <td className="p-2"><span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(s.status)}`}>{s.status}</span></td>
                                                <td className="p-2">
                                                    <select value={s.newStatus} onChange={e => handleStatusUpdate(s.id, e.target.value as StudentData['status'])} className="w-full p-1.5 border rounded-md bg-white text-xs">
                                                        {statusOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                                                    </select>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                        <div className="mt-6 flex justify-end">
                            <button onClick={() => setIsModalOpen(true)} disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 disabled:cursor-not-allowed">পরিবর্তন সংরক্ষণ করুন</button>
                        </div>
                    </>
                 ) : (
                    <p className="text-center text-gray-500 py-10">এই ফিল্টারে কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                 )}
            </div>
            
            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onConfirm={handleSaveChanges} title="স্ট্যাটাস পরিবর্তন নিশ্চিত করুন">
                আপনি কি নিশ্চিতভাবে নির্বাচিত শিক্ষার্থীদের স্ট্যাটাস পরিবর্তন করতে চান?
            </Modal>
        </div>
    );
};

export default StatusChange;