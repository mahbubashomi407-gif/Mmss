
import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { SearchIcon } from '../../../components/icons';
import StudentSearchModal from '../../../components/StudentSearchModal';

const initialFormData: StudentData = {
    id: '',
    uniqueId: '',
    photoUrl: null,
    nameBn: '',
    nameEn: '',
    dob: '',
    gender: 'ছাত্র',
    bloodGroup: '',
    religion: 'ইসলাম',
    birthCertNo: '',
    nationality: 'বাংলাদেশী',
    admissionDate: new Date().toISOString().split('T')[0],
    academicYear: '',
    classLevel: '',
    section: '',
    roll: '',
    fatherNameBn: '',
    fatherNameEn: '',
    fatherNid: '',
    fatherPhone: '',
    fatherOccupation: '',
    motherNameBn: '',
    motherNameEn: '',
    motherNid: '',
    motherPhone: '',
    motherOccupation: '',
    presentAddress: { village: '', postOffice: '', upazila: '', district: '' },
    permanentAddress: { village: '', postOffice: '', upazila: '', district: '' },
    isSameAddress: false,
    status: 'চলমান',
};

const generateUniqueId = (academicYear: string, allStudents: StudentData[]): string => {
    const yearPrefix = (academicYear.split('-')[0] || new Date().getFullYear().toString()).slice(-2);
    // Filter out pending students before calculating the next sequence
    const studentsInYear = allStudents.filter(student => student.academicYear === academicYear && student.status !== 'পেন্ডিং');
    const nextSequence = studentsInYear.length + 1;
    const paddedSequence = String(nextSequence).padStart(3, '0');
    return `${yearPrefix}${paddedSequence}`;
};

const AddStudent: React.FC = () => {
    const { classLevels, sections, students, setStudents, academicSessions, genders, bloodGroups, religions, nationalities } = useInstitution();
    const { addToast } = useNotification();
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const studentId = searchParams.get('id');
    const pendingStudentId = searchParams.get('from_pending');
    const isEditMode = Boolean(studentId);
    const isApproveMode = Boolean(pendingStudentId);

    const [formData, setFormData] = useState<StudentData>(initialFormData);
    const [availableSections, setAvailableSections] = useState<string[]>([]);
    const [rollError, setRollError] = useState<string>('');
    const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
    const [admissionType, setAdmissionType] = useState<'new' | 'old'>('new');

    const studentGenders = useMemo(() => genders.filter(g => ['ছাত্র', 'ছাত্রী', 'অন্যান্য'].includes(g.name)), [genders]);

    const potentialUniqueId = useMemo(() => {
        if (formData.academicYear && !isEditMode) {
            return generateUniqueId(formData.academicYear, students);
        }
        return formData.uniqueId || '...';
    }, [formData.academicYear, formData.uniqueId, students, isEditMode]);
    
    useEffect(() => {
        const activeSession = academicSessions.find(s => s.isActive);
        if (isEditMode) {
            const studentToEdit = students.find(s => s.id === studentId);
            if (studentToEdit) {
                setFormData(studentToEdit);
            } else {
                addToast('সম্পাদনার জন্য শিক্ষার্থীকে খুঁজে পাওয়া যায়নি!', 'error');
                navigate('/admin/students/list');
            }
        } else if (isApproveMode) {
            const studentToApprove = students.find(s => s.id === pendingStudentId);
            if (studentToApprove) {
                setFormData(studentToApprove);
            } else {
                addToast('অনুমোদনের জন্য আবেদনটি খুঁজে পাওয়া যায়নি!', 'error');
                navigate('/admin/students/pending-applications');
            }
        }
        else {
            setFormData({
                ...initialFormData,
                academicYear: activeSession ? activeSession.name : '',
            });
        }
    }, [studentId, pendingStudentId, isEditMode, isApproveMode, students, academicSessions, addToast, navigate]);

    useEffect(() => {
        if (formData.classLevel) {
            const relatedSections = sections
                .filter(s => s.classLevel === formData.classLevel)
                .map(s => s.name);
            setAvailableSections(relatedSections);
            if (!relatedSections.includes(formData.section)) {
                 const currentStudent = students.find(s => s.id === (studentId || pendingStudentId));
                 if(isEditMode && currentStudent?.classLevel === formData.classLevel) {
                    setFormData(prev => ({...prev, section: currentStudent!.section}));
                 } else {
                    setFormData(prev => ({ ...prev, section: '' }));
                 }
            }
        } else {
            setAvailableSections([]);
        }
    }, [formData.classLevel, sections, studentId, pendingStudentId, isEditMode, isApproveMode, students]);

    const getNextRollNumber = (classLevel: string, section: string): number => {
        const studentsInClassSection = students.filter(
            s => s.classLevel === classLevel && 
                 s.section === section && 
                 s.status !== 'পেন্ডিং' &&
                 s.id !== (studentId || pendingStudentId)
        );
        if (studentsInClassSection.length === 0) {
            return 1;
        }
        const maxRoll = Math.max(...studentsInClassSection.map(s => Number(s.roll) || 0));
        return maxRoll + 1;
    };

    useEffect(() => {
        if (!isEditMode && formData.classLevel && formData.section) {
            const nextRoll = getNextRollNumber(formData.classLevel, formData.section);
            setFormData(prev => ({ ...prev, roll: nextRoll }));
            setRollError(''); // Reset validation when auto-generating
        }
    }, [formData.classLevel, formData.section, isEditMode]);

    const handleSelectStudent = (student: StudentData) => {
        setFormData(prev => ({
            ...prev,
            photoUrl: student.photoUrl,
            nameBn: student.nameBn,
            nameEn: student.nameEn,
            dob: student.dob,
            gender: student.gender,
            bloodGroup: student.bloodGroup,
            religion: student.religion,
            birthCertNo: student.birthCertNo,
            nationality: student.nationality,
            fatherNameBn: student.fatherNameBn,
            fatherNameEn: student.fatherNameEn,
            fatherNid: student.fatherNid,
            fatherPhone: student.fatherPhone,
            fatherOccupation: student.fatherOccupation,
            motherNameBn: student.motherNameBn,
            motherNameEn: student.motherNameEn,
            motherNid: student.motherNid,
            motherPhone: student.motherPhone,
            motherOccupation: student.motherOccupation,
            presentAddress: student.presentAddress,
            permanentAddress: student.permanentAddress,
            isSameAddress: student.isSameAddress,
        }));
        setIsSearchModalOpen(false);
        addToast('শিক্ষার্থীর তথ্য সফলভাবে লোড করা হয়েছে!', 'success');
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;

        if (name === 'roll') {
            const newRoll = value === '' ? '' : Number(value);
            const isDuplicate = students.some(
                s => s.id !== (studentId || pendingStudentId) &&
                     s.classLevel === formData.classLevel &&
                     s.section === formData.section &&
                     s.roll !== '' &&
                     Number(s.roll) === newRoll
            );
            if (isDuplicate) {
                setRollError('এই রোল নম্বরটি এই সেকশনে ইতিমধ্যে ব্যবহৃত হয়েছে!');
            } else {
                setRollError('');
            }
        }
        
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleAddressChange = (type: 'presentAddress' | 'permanentAddress', e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [type]: { ...prev[type], [name]: value }
        }));
    };

    const handleSameAddressCheck = (e: React.ChangeEvent<HTMLInputElement>) => {
        const isChecked = e.target.checked;
        setFormData(prev => ({
            ...prev,
            isSameAddress: isChecked,
            permanentAddress: isChecked ? prev.presentAddress : prev.permanentAddress,
        }));
    };
    
    useEffect(() => {
        if (formData.isSameAddress) {
            setFormData(prev => ({ ...prev, permanentAddress: prev.presentAddress }));
        }
    }, [formData.presentAddress, formData.isSameAddress]);


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (rollError) {
            addToast('রোল নম্বরের সমস্যা সমাধান করুন।', 'error');
            return;
        }
        
        if (isEditMode) {
            setStudents(students.map(s => s.id === studentId ? formData : s));
            addToast('শিক্ষার্থীর তথ্য সফলভাবে আপডেট করা হয়েছে!', 'success');
            navigate(`/app/students/profile?id=${studentId}`);
        } else if (isApproveMode) {
             const uniqueId = generateUniqueId(formData.academicYear, students);
             setStudents(students.map(s => s.id === pendingStudentId
                ? { ...formData, uniqueId, status: 'চলমান' }
                : s
            ));
            addToast(`আবেদন অনুমোদিত! নতুন আইডি: ${uniqueId}`, 'success');
            navigate('/app/students/list');
        } else {
            const uniqueId = generateUniqueId(formData.academicYear, students);
            const newStudent: StudentData = { 
                ...formData, 
                id: `std-${Date.now()}`,
                uniqueId: uniqueId
            };
            setStudents([...students, newStudent]);
            addToast(`নতুন শিক্ষার্থী ভর্তি হয়েছে! ইউনিক আইডি: ${uniqueId}`, 'success');
            
            const activeSession = academicSessions.find(s => s.isActive);
            setFormData({
                ...initialFormData,
                academicYear: activeSession ? activeSession.name : '',
            });
            setAdmissionType('new');
        }
    };

    return (
        <div>
            <PageHeader icon={isEditMode ? "✏️" : isApproveMode ? "⏳" : "➕"} title={isEditMode ? "শিক্ষার্থী তথ্য সম্পাদনা" : isApproveMode ? "পেন্ডিং আবেদন অনুমোদন" : "অফিস থেকে ভর্তি"} />
            <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-md max-w-5xl mx-auto">
                <div className="space-y-6">
                    {/* Student Info */}
                    <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">শিক্ষার্থীর তথ্য</legend>
                        {!isEditMode && !isApproveMode && (
                            <div className="flex items-center gap-6 mb-4">
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="admissionType" value="new" checked={admissionType === 'new'} onChange={() => setAdmissionType('new')} className="form-radio h-4 w-4 text-teal-600"/>
                                    <span className="font-semibold">নতুন ভর্তি</span>
                                </label>
                                <label className="flex items-center gap-2 cursor-pointer">
                                    <input type="radio" name="admissionType" value="old" checked={admissionType === 'old'} onChange={() => setAdmissionType('old')} className="form-radio h-4 w-4 text-teal-600"/>
                                    <span className="font-semibold">পুরাতন ভর্তি</span>
                                </label>
                                {admissionType === 'old' && (
                                    <button
                                        type="button"
                                        onClick={() => setIsSearchModalOpen(true)}
                                        className="flex items-center gap-1 text-sm bg-blue-100 text-blue-700 font-semibold px-3 py-1 rounded-full hover:bg-blue-200"
                                        title="বিদ্যমান শিক্ষার্থী খুঁজুন"
                                    >
                                        <SearchIcon className="w-4 h-4" />
                                        <span>পুরাতন তথ্য খুঁজুন</span>
                                    </button>
                                )}
                            </div>
                        )}
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                             <div className="md:col-span-1 flex flex-col items-center">
                                <div className="w-32 h-32 rounded-full border-2 border-dashed bg-gray-50 flex items-center justify-center mb-2 overflow-hidden">
                                    {formData.photoUrl ? <img src={formData.photoUrl} alt="Student" className="w-full h-full object-cover rounded-full" /> : <span className="text-sm text-gray-400">ছবি</span>}
                                </div>
                                <input 
                                    type="url" 
                                    name="photoUrl" 
                                    value={formData.photoUrl || ''} 
                                    onChange={handleInputChange} 
                                    placeholder="ছবির লিংক দিন" 
                                    className="text-sm w-full p-2 border rounded-md" 
                                />
                            </div>
                            <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-3">
                                <div><label className="block text-sm font-medium">শিক্ষার্থীর পুরো নাম<span className="text-red-500">*</span></label><input type="text" name="nameBn" value={formData.nameBn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="নাম লিখুন..." required /></div>
                                <div><label className="block text-sm font-medium">Student's Full Name<span className="text-red-500">*</span></label><input type="text" name="nameEn" value={formData.nameEn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="Write full name..." required /></div>
                                <div><label className="block text-sm font-medium">জন্মতারিখ<span className="text-red-500">*</span></label><input type="date" name="dob" value={formData.dob} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required /></div>
                                <div><label className="block text-sm font-medium">লিঙ্গ</label><select name="gender" value={formData.gender} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500">{studentGenders.map(g => <option key={g.id} value={g.name}>{g.name}</option>)}</select></div>
                                <div><label className="block text-sm font-medium">রক্তের গ্রুপ</label><select name="bloodGroup" value={formData.bloodGroup} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"><option value="">নির্বাচন করুন</option>{bloodGroups.map(bg => <option key={bg.id} value={bg.name}>{bg.name}</option>)}</select></div>
                                <div><label className="block text-sm font-medium">ধর্ম</label><select name="religion" value={formData.religion} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500">{religions.map(r => <option key={r.id} value={r.name}>{r.name}</option>)}</select></div>
                                <div><label className="block text-sm font-medium">জন্ম সনদ নম্বর</label><input type="text" name="birthCertNo" value={formData.birthCertNo} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" /></div>
                                <div><label className="block text-sm font-medium">জাতীয়তা</label><select name="nationality" value={formData.nationality} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500">{nationalities.map(n => <option key={n.id} value={n.name}>{n.name}</option>)}</select></div>
                            </div>
                        </div>
                    </fieldset>
                    
                    <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">প্রাতিষ্ঠানিক তথ্য</legend>
                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-3">
                            <div><label className="block text-sm font-medium">ইউনিক আইডি</label><input type="text" value={potentialUniqueId} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 font-mono" readOnly /></div>
                            <div><label className="block text-sm font-medium">ভর্তির তারিখ</label><input type="date" name="admissionDate" value={formData.admissionDate} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" /></div>
                            <div><label className="block text-sm font-medium">শিক্ষা বর্ষ</label><input type="text" name="academicYear" value={formData.academicYear} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100" readOnly /></div>
                            <div><label className="block text-sm font-medium">শ্রেণি<span className="text-red-500">*</span></label><select name="classLevel" value={formData.classLevel} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required><option value="">নির্বাচন করুন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select></div>
                            <div><label className="block text-sm font-medium">সেকশন<span className="text-red-500">*</span></label><select name="section" value={formData.section} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required disabled={!formData.classLevel}><option value="">নির্বাচন করুন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select></div>
                            <div>
                                <label className="block text-sm font-medium">রোল নম্বর</label>
                                <input type="number" name="roll" value={formData.roll} onChange={handleInputChange} className={`mt-1 w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 ${rollError ? 'border-red-500 ring-red-500' : 'border-gray-300 focus:ring-teal-500'}`} />
                                {rollError && <p className="text-xs text-red-500 mt-1">{rollError}</p>}
                            </div>
                        </div>
                    </fieldset>

                    <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">অভিভাবকের তথ্য</legend>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
                            <h4 className="md:col-span-2 text-md font-semibold text-gray-600 border-b pb-1">পিতার তথ্য</h4>
                            <div><label className="block text-sm font-medium">পিতার নাম<span className="text-red-500">*</span></label><input type="text" name="fatherNameBn" value={formData.fatherNameBn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="নাম লিখুন..." required /></div>
                            <div><label className="block text-sm font-medium">Father's Name</label><input type="text" name="fatherNameEn" value={formData.fatherNameEn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="Write full name..." /></div>
                            <div><label className="block text-sm font-medium">মোবাইল নম্বর<span className="text-red-500">*</span></label><input type="tel" name="fatherPhone" value={formData.fatherPhone} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required /></div>
                            <div><label className="block text-sm font-medium">পেশা</label><input type="text" name="fatherOccupation" value={formData.fatherOccupation} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" /></div>
                            
                            <h4 className="md:col-span-2 text-md font-semibold text-gray-600 border-b pb-1 mt-4">মাতার তথ্য</h4>
                            <div><label className="block text-sm font-medium">মাতার নাম</label><input type="text" name="motherNameBn" value={formData.motherNameBn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="নাম লিখুন..." /></div>
                            <div><label className="block text-sm font-medium">Mother's Name</label><input type="text" name="motherNameEn" value={formData.motherNameEn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="Write full name..." /></div>
                            <div><label className="block text-sm font-medium">মোবাইল নম্বর<span className="text-red-500">*</span></label><input type="tel" name="motherPhone" value={formData.motherPhone} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required /></div>
                            <div><label className="block text-sm font-medium">পেশা</label><input type="text" name="motherOccupation" value={formData.motherOccupation} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" /></div>
                        </div>
                    </fieldset>

                    <fieldset className="border p-4 rounded-md">
                        <legend className="text-lg font-semibold px-2 text-gray-700">ঠিকানা</legend>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                            <div>
                                <h4 className="text-md font-semibold text-gray-600 mb-2">বর্তমান ঠিকানা</h4>
                                <div className="space-y-2">
                                    <input type="text" name="village" placeholder="গ্রাম/মহল্লা" value={formData.presentAddress.village} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500" />
                                    <input type="text" name="postOffice" placeholder="ডাকঘর" value={formData.presentAddress.postOffice} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500" />
                                    <input type="text" name="upazila" placeholder="থানা/উপজেলা" value={formData.presentAddress.upazila} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500" />
                                    <input type="text" name="district" placeholder="জেলা" value={formData.presentAddress.district} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500" />
                                </div>
                            </div>
                             <div>
                                <div className="flex justify-between items-center mb-2">
                                    <h4 className="text-md font-semibold text-gray-600">স্থায়ী ঠিকানা</h4>
                                    <label className="flex items-center text-sm">
                                        <input type="checkbox" name="isSameAddress" checked={formData.isSameAddress} onChange={handleSameAddressCheck} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500" />
                                        <span className="ml-2">বর্তমান ঠিকানার অনুরূপ</span>
                                    </label>
                                </div>
                                <div className="space-y-2">
                                    <input type="text" name="village" placeholder="গ্রাম/মহল্লা" value={formData.permanentAddress.village} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm disabled:bg-gray-100" />
                                    <input type="text" name="postOffice" placeholder="ডাকঘর" value={formData.permanentAddress.postOffice} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm disabled:bg-gray-100" />
                                    <input type="text" name="upazila" placeholder="থানা/উপজেলা" value={formData.permanentAddress.upazila} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm disabled:bg-gray-100" />
                                    <input type="text" name="district" placeholder="জেলা" value={formData.permanentAddress.district} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm disabled:bg-gray-100" />
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </div>

                <div className="mt-8 flex justify-end gap-3">
                    {(!isEditMode && !isApproveMode) && (
                        <button type="button" onClick={() => {
                             const activeSession = academicSessions.find(s => s.isActive);
                             setFormData({ ...initialFormData, academicYear: activeSession ? activeSession.name : '' });
                             setAdmissionType('new');
                        }} className="px-6 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">ফর্ম রিসেট করুন</button>
                    )}
                    <button type="submit" disabled={!!rollError} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400 disabled:cursor-not-allowed">
                        {isEditMode ? 'তথ্য আপডেট করুন' : isApproveMode ? 'আবেদন অনুমোদন করুন' : 'ভর্তি সম্পন্ন করুন'}
                    </button>
                </div>
            </form>
            <StudentSearchModal
                isOpen={isSearchModalOpen}
                onClose={() => setIsSearchModalOpen(false)}
                onSelectStudent={handleSelectStudent}
            />
        </div>
    );
};

export default AddStudent;
