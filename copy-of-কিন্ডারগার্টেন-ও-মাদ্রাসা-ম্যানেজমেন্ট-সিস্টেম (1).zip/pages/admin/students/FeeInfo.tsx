import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, StudentFeeSetupData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, SearchIcon, CogIcon } from '../../../components/icons';
import CollectFeeModal from '../../../components/CollectFeeModal'; 
import FeeHistoryModal from '../../../components/FeeHistoryModal';
import StudentFeeSetupModal from '../../../components/StudentFeeSetupModal';
import { useNotification } from '../../../context/NotificationContext';

const FeeInfo: React.FC = () => {
    const { students, classLevels, sections, academicSessions, feeTypes, studentFeeRecords, studentFeeSetups, setStudentFeeSetups } = useInstitution();
    const { addToast } = useNotification();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    
    // Modals
    const [collectFeeModal, setCollectFeeModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });
    const [historyModal, setHistoryModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });
    const [setupModal, setSetupModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });

    // Pagination
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState<number | string>(5);

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) setSectionFilter('');
    }, [availableSections, sectionFilter]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        
        let studentsToShow = students.filter(s => 
            s.academicYear === academicYearFilter && 
            s.classLevel === classFilter && 
            s.section === sectionFilter && 
            s.status !== 'পেন্ডিং'
        );

        if (searchTerm.trim()) {
            const lowerSearch = searchTerm.toLowerCase();
            studentsToShow = studentsToShow.filter(s => 
                s.nameBn.toLowerCase().includes(lowerSearch) ||
                (s.roll && s.roll.toString().includes(searchTerm)) ||
                s.uniqueId.toLowerCase().includes(lowerSearch)
            );
        }

        return studentsToShow.sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter, searchTerm]);
    
    // Reset page on filter change
    useEffect(() => {
        setCurrentPage(1);
    }, [academicYearFilter, classFilter, sectionFilter, searchTerm, itemsPerPage]);

    const handleCollectFeeClick = (student: StudentData) => {
        const setupExists = studentFeeSetups.some(s => s.studentId === student.id && s.academicYear === academicYearFilter);
        if (setupExists) {
            setCollectFeeModal({ isOpen: true, student });
        } else {
            setSetupModal({ isOpen: true, student });
        }
    };
    
    const handleSaveSetup = (newSetup: StudentFeeSetupData) => {
        const existingIndex = studentFeeSetups.findIndex(s => s.id === newSetup.id);
        if(existingIndex > -1) {
            const updated = [...studentFeeSetups];
            updated[existingIndex] = newSetup;
            setStudentFeeSetups(updated);
            addToast("ফি সেটাপ সফলভাবে আপডেট হয়েছে!", "success");
        } else {
            setStudentFeeSetups([...studentFeeSetups, newSetup]);
            addToast("ফি সেটাপ সফলভাবে সম্পন্ন হয়েছে!", "success");
        }
        setSetupModal({ isOpen: false, student: null });
        // After setup, immediately open collect modal for convenience
        setCollectFeeModal({ isOpen: true, student: students.find(s => s.id === newSetup.studentId) || null });
    };
    
    const calculateDues = (student: StudentData): { totalDue: number, totalPaid: number, arrears: number } => {
        const setup = studentFeeSetups.find(s => s.studentId === student.id && s.academicYear === student.academicYear);
        const totalPaidForYear = studentFeeRecords
            .filter(rec => rec.studentId === student.id && rec.year.toString() === student.academicYear.split('-')[0])
            .reduce((sum, rec) => sum + rec.amountPaid, 0);

        if (!setup) {
            // If no setup, due is considered 0, paid is what they paid. Arrears can be negative if they paid without setup.
            return { totalDue: totalPaidForYear, totalPaid: totalPaidForYear, arrears: 0 };
        }
    
        let totalDue = 0;
    
        // One-time fees from setup
        setup.oneTimeFeeTypeIds.forEach(feeId => {
            const feeType = feeTypes.find(ft => ft.id === feeId);
            if (feeType) {
                totalDue += feeType.amount;
            }
        });
    
        // Monthly fees from setup
        const monthlyFee = feeTypes.find(ft => ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel));
        if (monthlyFee) {
            totalDue += setup.monthlyFeeMonths.length * monthlyFee.amount;
        }
        
        const arrears = totalDue - totalPaidForYear;
    
        return { totalDue, totalPaid: totalPaidForYear, arrears };
    };

    const studentFeeInfo = useMemo(() => {
        return filteredStudents.map(student => {
            const dues = calculateDues(student);
            return { ...student, ...dues };
        });
    }, [filteredStudents, feeTypes, studentFeeRecords, studentFeeSetups]);
    
    const paginatedStudents = useMemo(() => {
        if (itemsPerPage === 'all') {
            return studentFeeInfo;
        }
        const numericItemsPerPage = Number(itemsPerPage);
        const startIndex = (currentPage - 1) * numericItemsPerPage;
        return studentFeeInfo.slice(startIndex, startIndex + numericItemsPerPage);
    }, [studentFeeInfo, currentPage, itemsPerPage]);

    const totalPages = useMemo(() => {
        if (itemsPerPage === 'all' || studentFeeInfo.length === 0) return 1;
        return Math.ceil(studentFeeInfo.length / Number(itemsPerPage));
    }, [studentFeeInfo, itemsPerPage]);

    const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;

    return (
        <div>
            <PageHeader icon="💰" title="ফি তথ্য" />

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow min-w-[250px]">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><SearchIcon className="w-5 h-5 text-gray-400" /></span>
                        <input
                            type="text"
                            placeholder="নাম, রোল বা আইডি দিয়ে খুঁজুন..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                            disabled={!classFilter || !sectionFilter}
                        />
                    </div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setSearchTerm(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

             <div className="bg-white p-6 rounded-xl shadow-md">
                {studentFeeInfo.length > 0 ? (
                    <>
                        <div className="overflow-x-auto">
                            <table className="w-full text-sm">
                                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                    <tr>
                                        <th className="p-2">রোল</th>
                                        <th className="p-2">শিক্ষার্থীর নাম</th>
                                        <th className="p-2 text-right">মোট প্রদেয়</th>
                                        <th className="p-2 text-right">মোট জমা</th>
                                        <th className="p-2 text-right">মোট বকেয়া</th>
                                        <th className="p-2 text-center">পদক্ষেপ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {paginatedStudents.map(s => (
                                        <tr key={s.id} className="border-b hover:bg-gray-50">
                                            <td className="p-2">{s.roll}</td>
                                            <td className="p-2 font-medium">{s.nameBn}</td>
                                            <td className="p-2 text-right">{formatCurrency(s.totalDue)}</td>
                                            <td className="p-2 text-right text-green-600 font-semibold">{formatCurrency(s.totalPaid)}</td>
                                            <td className="p-2 text-right font-bold text-red-600">{formatCurrency(s.arrears)}</td>
                                            <td className="p-2 text-center space-x-2">
                                                <button onClick={() => setSetupModal({ isOpen: true, student: s })} className="px-3 py-1 text-xs bg-yellow-100 text-yellow-800 font-semibold rounded-md hover:bg-yellow-200 inline-flex items-center gap-1"><CogIcon className="w-3 h-3"/> সেটাপ</button>
                                                <button onClick={() => handleCollectFeeClick(s)} className="px-3 py-1 text-xs bg-green-100 text-green-700 font-semibold rounded-md hover:bg-green-200">ফি আদায় করুন</button>
                                                <button onClick={() => setHistoryModal({ isOpen: true, student: s })} className="px-3 py-1 text-xs bg-blue-100 text-blue-700 font-semibold rounded-md hover:bg-blue-200">হিস্ট্রি দেখুন</button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>

                        <div className="flex flex-col md:flex-row justify-between items-center mt-4 text-sm text-gray-600 gap-4">
                            <div className="flex items-center gap-2">
                                <span>প্রতি পাতায় দেখান:</span>
                                <select 
                                    value={itemsPerPage} 
                                    onChange={e => setItemsPerPage(e.target.value)}
                                    className="p-1 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-teal-500"
                                >
                                    <option value={5}>৫</option>
                                    <option value={10}>১০</option>
                                    <option value={15}>১৫</option>
                                    <option value={'all'}>সব</option>
                                </select>
                                <span className="hidden md:inline">| মোট: {studentFeeInfo.length}</span>
                            </div>
                            
                            {itemsPerPage !== 'all' && totalPages > 1 && (
                                <div className="flex items-center gap-3">
                                    <span className="md:hidden text-xs">মোট: {studentFeeInfo.length}</span>
                                    <button 
                                        onClick={() => setCurrentPage(p => p - 1)} 
                                        disabled={currentPage === 1}
                                        className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                                    >
                                        পূর্ববর্তী
                                    </button>
                                    <span>পাতা {totalPages > 0 ? currentPage : 0} / {totalPages}</span>
                                    <button 
                                        onClick={() => setCurrentPage(p => p + 1)} 
                                        disabled={currentPage === totalPages || totalPages === 0}
                                        className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                                    >
                                        পরবর্তী
                                    </button>
                                </div>
                            )}
                        </div>
                    </>
                ) : (
                    <p className="text-center text-gray-500 py-10">
                        {classFilter && sectionFilter
                            ? (searchTerm ? 'আপনার অনুসন্ধানের সাথে মেলে এমন কোনো শিক্ষার্থী পাওয়া যায়নি।' : 'এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।')
                            : 'ফি-এর তথ্য দেখতে অনুগ্রহ করে শ্রেণি ও সেকশন নির্বাচন করুন।'
                        }
                    </p>
                )}
            </div>
            
            <CollectFeeModal 
                isOpen={collectFeeModal.isOpen}
                onClose={() => setCollectFeeModal({ isOpen: false, student: null })}
                student={collectFeeModal.student}
            />

            <FeeHistoryModal 
                isOpen={historyModal.isOpen}
                onClose={() => setHistoryModal({ isOpen: false, student: null })}
                student={historyModal.student}
            />

            <StudentFeeSetupModal 
                isOpen={setupModal.isOpen}
                onClose={() => setSetupModal({ isOpen: false, student: null })}
                student={setupModal.student}
                academicYear={academicYearFilter}
                onSave={handleSaveSetup}
            />
        </div>
    );
};

export default FeeInfo;