
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon, EyeIcon, SearchIcon, GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, UserGroupIcon } from '../../../components/icons';
import StudentSummaryModal from '../../../components/StudentSummaryModal';

const StudentList: React.FC = () => {
    const { students, setStudents, classLevels, sections, academicSessions } = useInstitution();
    const { addToast } = useNotification();

    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });
    const [isSummaryModalOpen, setIsSummaryModalOpen] = useState(false);
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession ? activeSession.name : '');
    
    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(5);

    const availableSections = useMemo(() => {
        if (!classFilter) return [];
        return sections.filter(s => s.classLevel === classFilter).map(s => s.name);
    }, [classFilter, sections]);

    // Reset section filter if class changes and section is no longer valid
    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) {
            setSectionFilter('');
        }
    }, [availableSections, sectionFilter]);

    const filteredStudents = useMemo(() => {
        return students.filter(student => {
            if (student.status === 'পেন্ডিং') return false;

            const lowerSearchTerm = searchTerm.toLowerCase();
            const searchMatch =
                student.nameBn.toLowerCase().includes(lowerSearchTerm) ||
                student.nameEn.toLowerCase().includes(lowerSearchTerm) ||
                (student.roll && student.roll.toString().includes(searchTerm)) ||
                (student.uniqueId && student.uniqueId.toLowerCase().includes(lowerSearchTerm)) ||
                student.fatherPhone.includes(searchTerm) ||
                student.motherPhone.includes(searchTerm);
            
            const academicYearMatch = !academicYearFilter || student.academicYear === academicYearFilter;
            const classMatch = !classFilter || student.classLevel === classFilter;
            const sectionMatch = !sectionFilter || student.section === sectionFilter;

            return searchMatch && academicYearMatch && classMatch && sectionMatch;
        }).sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter, searchTerm]);

    // Reset to first page whenever filters change
    useEffect(() => {
        setCurrentPage(1);
    }, [academicYearFilter, classFilter, sectionFilter, searchTerm, itemsPerPage]);

    const paginatedStudents = useMemo(() => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        return filteredStudents.slice(startIndex, startIndex + itemsPerPage);
    }, [filteredStudents, currentPage, itemsPerPage]);

    const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
    
    const handleDelete = (student: StudentData) => {
        setDeleteModal({ isOpen: true, student: student });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.student) {
            setStudents(students.filter(s => s.id !== deleteModal.student!.id));
            addToast('শিক্ষার্থী সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, student: null });
    };

    return (
        <div>
            <PageHeader icon="📋" title="শিক্ষার্থী তালিকা">
                <button
                    onClick={() => setIsSummaryModalOpen(true)}
                    className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                    <UserGroupIcon className="w-5 h-5" />
                    সারসংক্ষেপ দেখুন
                </button>
                 <Link
                    to="/app/students/add"
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন শিক্ষার্থী যোগ করুন
                </Link>
            </PageHeader>

            {/* Filter and Search Bar */}
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    {/* Search Input */}
                    <div className="relative flex-grow min-w-[200px]">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <SearchIcon className="w-5 h-5 text-gray-400" />
                        </span>
                        <input
                            type="text"
                            placeholder="আইডি, নাম, রোল বা মোবাইল দিয়ে খুঁজুন..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                            aria-label="Search students"
                        />
                    </div>
                    
                    {/* Academic Year Filter */}
                    <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <CalendarIcon className="w-5 h-5 text-gray-400" />
                        </span>
                        <select
                            value={academicYearFilter}
                            onChange={e => setAcademicYearFilter(e.target.value)}
                            className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"
                            aria-label="Filter by academic year"
                        >
                            <option value="">সকল বর্ষ</option>
                            {academicSessions.map(session => <option key={session.id} value={session.name}>{session.name}</option>)}
                        </select>
                         <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                            <ChevronDownIcon className="w-4 h-4 text-gray-500" />
                        </span>
                    </div>

                    {/* Class Filter */}
                    <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <GraduationCapIcon className="w-5 h-5 text-gray-400" />
                        </span>
                        <select
                            value={classFilter}
                            onChange={e => setClassFilter(e.target.value)}
                            className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"
                            aria-label="Filter by class"
                        >
                            <option value="">সকল শ্রেণি</option>
                            {classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}
                        </select>
                         <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                            <ChevronDownIcon className="w-4 h-4 text-gray-500" />
                        </span>
                    </div>

                    {/* Section Filter */}
                     <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <StudentsIcon className="w-5 h-5 text-gray-400" />
                        </span>
                        <select
                            value={sectionFilter}
                            onChange={e => setSectionFilter(e.target.value)}
                            className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"
                            disabled={!classFilter}
                            aria-label="Filter by section"
                        >
                            <option value="">সকল সেকশন</option>
                            {availableSections.map(sec => <option key={sec} value={sec}>{sec}</option>)}
                        </select>
                         <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                            <ChevronDownIcon className="w-4 h-4 text-gray-500" />
                        </span>
                    </div>

                    {/* Reset Button */}
                    <button 
                        onClick={() => { setAcademicYearFilter(activeSession ? activeSession.name : ''); setClassFilter(''); setSectionFilter(''); setSearchTerm(''); }} 
                        className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex-shrink-0"
                        title="ফিল্টার রিসেট করুন"
                    >
                        <RefreshIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>

            {/* Student Table */}
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500 table-auto">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-4 py-2">ছবি</th>
                                <th className="px-4 py-2">নাম</th>
                                <th className="px-4 py-2">শ্রেণি</th>
                                <th className="px-4 py-2">রোল</th>
                                <th className="px-4 py-2">আইডি</th>
                                <th className="px-4 py-2">অভিভাবকের মোবাইল</th>
                                <th className="px-4 py-2 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {paginatedStudents.length > 0 ? paginatedStudents.map(student => (
                                <tr key={student.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-4 py-1.5">
                                        <img 
                                            src={student.photoUrl || 'https://via.placeholder.com/40x40?text=S'} 
                                            alt={student.nameBn} 
                                            className="w-9 h-9 rounded-full object-cover"
                                        />
                                    </td>
                                    <td className="px-4 py-1.5 font-medium text-gray-900">{student.nameBn}</td>
                                    <td className="px-4 py-1.5">{student.classLevel} ({student.section})</td>
                                    <td className="px-4 py-1.5">{student.roll}</td>
                                    <td className="px-4 py-1.5 font-mono text-xs font-semibold text-gray-600">{student.uniqueId}</td>
                                    <td className="px-4 py-1.5">{student.fatherPhone}</td>
                                    <td className="px-4 py-1.5 text-right space-x-1 whitespace-nowrap">
                                         <Link to={`/app/students/profile?id=${student.id}`} className="p-2 text-green-600 hover:bg-green-100 rounded-full inline-block" title="প্রোফাইল দেখুন">
                                            <EyeIcon className="w-4 h-4" />
                                        </Link>
                                        <Link to={`/app/students/add?id=${student.id}`} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full inline-block" title="সম্পাদনা">
                                            <PencilIcon className="w-4 h-4" />
                                        </Link>
                                        <button onClick={() => handleDelete(student)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন">
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={7} className="text-center py-10 text-gray-500">
                                        <p>কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
                
                 {/* Pagination Controls */}
                <div className="flex flex-col md:flex-row justify-between items-center mt-4 text-sm text-gray-600 gap-4">
                    <div className="flex items-center gap-2">
                        <span>প্রতি পাতায় দেখান:</span>
                        <select 
                            value={itemsPerPage} 
                            onChange={e => setItemsPerPage(Number(e.target.value))}
                            className="p-1 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-teal-500"
                        >
                            <option value={5}>৫</option>
                            <option value={10}>১০</option>
                            <option value={15}>১৫</option>
                        </select>
                         <span className="hidden md:inline">| মোট শিক্ষার্থী: {filteredStudents.length}</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                         <span className="md:hidden text-xs">মোট: {filteredStudents.length}</span>
                        <button 
                            onClick={() => setCurrentPage(p => p - 1)} 
                            disabled={currentPage === 1}
                            className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                        >
                            পূর্ববর্তী
                        </button>
                        <span>পাতা {totalPages > 0 ? currentPage : 0} / {totalPages}</span>
                        <button 
                            onClick={() => setCurrentPage(p => p + 1)} 
                            disabled={currentPage === totalPages || totalPages === 0}
                            className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100"
                        >
                            পরবর্তী
                        </button>
                    </div>
                </div>
            </div>
            
            <Modal
                isOpen={deleteModal.isOpen}
                onClose={() => setDeleteModal({ isOpen: false, student: null })}
                onConfirm={handleConfirmDelete}
                title="শিক্ষার্থী মুছে ফেলুন"
            >
                আপনি কি নিশ্চিতভাবে শিক্ষার্থী "{deleteModal.student?.nameBn}"-কে তালিকা থেকে মুছে ফেলতে চান?
            </Modal>
            
            <StudentSummaryModal 
                isOpen={isSummaryModalOpen}
                onClose={() => setIsSummaryModalOpen(false)}
            />
        </div>
    );
};

export default StudentList;
