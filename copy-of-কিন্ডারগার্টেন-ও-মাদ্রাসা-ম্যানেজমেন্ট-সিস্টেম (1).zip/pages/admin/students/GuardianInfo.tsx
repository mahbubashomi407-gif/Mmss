
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { PencilIcon, EyeIcon, SearchIcon, GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';

const GuardianDetailModal: React.FC<{ student: StudentData | null; onClose: () => void }> = ({ student, onClose }) => {
    if (!student) return null;

    const InfoRow: React.FC<{ label: string, value: string | number | undefined | null }> = ({ label, value }) => (
        <div className="flex justify-between py-2.5 border-b border-gray-100 last:border-b-0">
            <span className="text-sm text-gray-500">{label}</span>
            <span className="text-sm font-semibold text-gray-800 text-right">{value || 'N/A'}</span>
        </div>
    );

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={onClose} role="dialog" aria-modal="true">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all" onClick={e => e.stopPropagation()}>
                <div className="p-5 border-b flex justify-between items-center">
                    <h3 className="text-lg font-bold text-gray-800">অভিভাবকের বিস্তারিত তথ্য</h3>
                    <button onClick={onClose} className="text-gray-400 hover:text-gray-600 font-bold text-2xl leading-none">&times;</button>
                </div>
                <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                    <div>
                        <h4 className="font-bold text-teal-700 mb-2">শিক্ষার্থীর তথ্য</h4>
                        <InfoRow label="নাম" value={student.nameBn} />
                        <InfoRow label="শ্রেণি" value={`${student.classLevel} (${student.section})`} />
                        <InfoRow label="রোল" value={student.roll || 'N/A'} />
                    </div>
                    <div>
                        <h4 className="font-bold text-teal-700 mb-2">পিতার তথ্য</h4>
                        <InfoRow label="নাম" value={student.fatherNameBn} />
                        <InfoRow label="মোবাইল" value={student.fatherPhone} />
                        <InfoRow label="পেশা" value={student.fatherOccupation} />
                    </div>
                     <div>
                        <h4 className="font-bold text-teal-700 mb-2">মাতার তথ্য</h4>
                        <InfoRow label="নাম" value={student.motherNameBn} />
                        <InfoRow label="মোবাইল" value={student.motherPhone} />
                        <InfoRow label="পেশা" value={student.motherOccupation} />
                    </div>
                </div>
                 <div className="bg-gray-50 px-5 py-3 flex justify-end">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বন্ধ করুন</button>
                </div>
            </div>
        </div>
    );
};


const GuardianInfo: React.FC = () => {
    const { students, classLevels, sections, academicSessions } = useInstitution();

    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [searchTerm, setSearchTerm] = useState('');
    const [viewModal, setViewModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession ? activeSession.name : '');

    const [currentPage, setCurrentPage] = useState(1);
    const [itemsPerPage, setItemsPerPage] = useState(10);

    const availableSections = useMemo(() => {
        if (!classFilter) return [];
        return sections.filter(s => s.classLevel === classFilter).map(s => s.name);
    }, [classFilter, sections]);
    
    useEffect(() => {
        if (sectionFilter && !availableSections.includes(sectionFilter)) {
            setSectionFilter('');
        }
    }, [availableSections, sectionFilter]);

    const filteredStudents = useMemo(() => {
        return students.filter(student => {
            if (student.status === 'পেন্ডিং') return false;

            const lowerSearchTerm = searchTerm.toLowerCase();
            const searchMatch =
                student.nameBn.toLowerCase().includes(lowerSearchTerm) ||
                student.fatherNameBn.toLowerCase().includes(lowerSearchTerm) ||
                student.motherNameBn.toLowerCase().includes(lowerSearchTerm) ||
                student.fatherPhone.includes(searchTerm) ||
                student.motherPhone.includes(searchTerm) ||
                (student.uniqueId && student.uniqueId.toLowerCase().includes(lowerSearchTerm));

            const academicYearMatch = !academicYearFilter || student.academicYear === academicYearFilter;
            const classMatch = !classFilter || student.classLevel === classFilter;
            const sectionMatch = !sectionFilter || student.section === sectionFilter;

            return searchMatch && academicYearMatch && classMatch && sectionMatch;
        }).sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter, searchTerm]);
    
    useEffect(() => {
        setCurrentPage(1);
    }, [academicYearFilter, classFilter, sectionFilter, searchTerm, itemsPerPage]);

    const paginatedStudents = useMemo(() => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        return filteredStudents.slice(startIndex, startIndex + itemsPerPage);
    }, [filteredStudents, currentPage, itemsPerPage]);

    const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
    
    const handleViewDetails = (student: StudentData) => {
        setViewModal({ isOpen: true, student });
    };

    return (
        <div>
            <PageHeader icon="👨‍👩‍👧" title="অভিভাবক তথ্য" />

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                 <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow min-w-[200px]">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <SearchIcon className="w-5 h-5 text-gray-400" />
                        </span>
                        <input
                            type="text"
                            placeholder="শিক্ষার্থী/অভিভাবকের নাম, মোবাইল..."
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                    </div>
                    
                     <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span>
                        <select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none">
                            <option value="">সকল বর্ষ</option>
                            {academicSessions.map(session => <option key={session.id} value={session.name}>{session.name}</option>)}
                        </select>
                         <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span>
                    </div>
                    <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span>
                        <select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none">
                            <option value="">সকল শ্রেণি</option>
                            {classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}
                        </select>
                         <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span>
                    </div>
                     <div className="relative flex-grow-0">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span>
                        <select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}>
                            <option value="">সকল সেকশন</option>
                            {availableSections.map(sec => <option key={sec} value={sec}>{sec}</option>)}
                        </select>
                         <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span>
                    </div>
                    <button onClick={() => { setAcademicYearFilter(activeSession ? activeSession.name : ''); setClassFilter(''); setSectionFilter(''); setSearchTerm(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex-shrink-0" title="ফিল্টার রিসেট করুন">
                        <RefreshIcon className="w-5 h-5" />
                    </button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                         <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th className="px-4 py-2">শিক্ষার্থীর নাম</th>
                                <th className="px-4 py-2">শ্রেণি</th>
                                <th className="px-4 py-2">পিতার নাম</th>
                                <th className="px-4 py-2">পিতার মোবাইল</th>
                                <th className="px-4 py-2">মাতার নাম</th>
                                <th className="px-4 py-2">মাতার মোবাইল</th>
                                <th className="px-4 py-2 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {paginatedStudents.length > 0 ? paginatedStudents.map(student => (
                                <tr key={student.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-4 py-2 font-medium text-gray-900">{student.nameBn}</td>
                                    <td className="px-4 py-2">{student.classLevel} ({student.section})</td>
                                    <td className="px-4 py-2">{student.fatherNameBn}</td>
                                    <td className="px-4 py-2">{student.fatherPhone}</td>
                                    <td className="px-4 py-2">{student.motherNameBn || 'N/A'}</td>
                                    <td className="px-4 py-2">{student.motherPhone}</td>
                                    <td className="px-4 py-2 text-right space-x-1 whitespace-nowrap">
                                        <button onClick={() => handleViewDetails(student)} className="p-2 text-green-600 hover:bg-green-100 rounded-full inline-block" title="বিস্তারিত দেখুন">
                                            <EyeIcon className="w-4 h-4" />
                                        </button>
                                        <Link to={`/app/students/add?id=${student.id}`} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full inline-block" title="সম্পাদনা">
                                            <PencilIcon className="w-4 h-4" />
                                        </Link>
                                    </td>
                                </tr>
                            )) : (
                                 <tr>
                                    <td colSpan={7} className="text-center py-10 text-gray-500">
                                        <p>কোনো তথ্য পাওয়া যায়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                 <div className="flex flex-col md:flex-row justify-between items-center mt-4 text-sm text-gray-600 gap-4">
                    <div className="flex items-center gap-2">
                        <span>প্রতি পাতায় দেখান:</span>
                        <select value={itemsPerPage} onChange={e => setItemsPerPage(Number(e.target.value))} className="p-1 border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-teal-500">
                            <option value={10}>১০</option>
                            <option value={20}>২০</option>
                            <option value={50}>৫০</option>
                        </select>
                         <span className="hidden md:inline">| মোট: {filteredStudents.length}</span>
                    </div>
                    
                    <div className="flex items-center gap-3">
                         <span className="md:hidden text-xs">মোট: {filteredStudents.length}</span>
                        <button onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1} className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100">
                            পূর্ববর্তী
                        </button>
                        <span>পাতা {totalPages > 0 ? currentPage : 0} / {totalPages}</span>
                        <button onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage === totalPages || totalPages === 0} className="px-3 py-1 border rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100">
                            পরবর্তী
                        </button>
                    </div>
                </div>
            </div>

            {viewModal.isOpen && <GuardianDetailModal student={viewModal.student} onClose={() => setViewModal({ isOpen: false, student: null })} />}
        </div>
    );
};

export default GuardianInfo;
