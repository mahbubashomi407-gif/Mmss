
import React, { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { CheckCircleIcon, ArrowLeftIcon, SearchIcon } from '../../../components/icons';
import StudentSearchModal from '../../../components/StudentSearchModal';
import { db } from '../../../services/firebase';
import { doc, runTransaction, arrayUnion } from 'firebase/firestore';


const initialFormData: Omit<StudentData, 'id' | 'uniqueId' | 'status'> = {
    photoUrl: null, nameBn: '', nameEn: '', dob: '', gender: 'ছাত্র', bloodGroup: '', religion: 'ইসলাম',
    birthCertNo: '', nationality: 'বাংলাদেশী', admissionDate: new Date().toISOString().split('T')[0],
    academicYear: '', classLevel: '', section: '', roll: '', fatherNameBn: '', fatherNameEn: '', fatherNid: '', fatherPhone: '',
    fatherOccupation: '', motherNameBn: '', motherNameEn: '', motherNid: '', motherPhone: '', motherOccupation: '',
    presentAddress: { village: '', postOffice: '', upazila: '', district: '' },
    permanentAddress: { village: '', postOffice: '', upazila: '', district: '' },
    isSameAddress: false,
};

const OnlineAdmission: React.FC = () => {
    const { institutionName, logoUrl, classLevels, sections, academicSessions } = useInstitution();
    const { addToast } = useNotification();

    const [step, setStep] = useState(1);
    const [formData, setFormData] = useState(initialFormData);
    const [availableSections, setAvailableSections] = useState<string[]>([]);
    const [submittedData, setSubmittedData] = useState<StudentData | null>(null);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
    const [admissionType, setAdmissionType] = useState<'new' | 'old'>('new');


    useEffect(() => {
       const activeSession = academicSessions.find(s => s.isActive);
       if (activeSession) {
           setFormData(prev => ({ ...prev, academicYear: activeSession.name }));
       }
   }, [academicSessions]);

    useEffect(() => {
        if (formData.classLevel) {
            const relatedSections = sections.filter(s => s.classLevel === formData.classLevel).map(s => s.name);
            setAvailableSections(relatedSections);
            if (!relatedSections.includes(formData.section)) {
                setFormData(prev => ({ ...prev, section: '' }));
            }
        } else {
            setAvailableSections([]);
        }
    }, [formData.classLevel, sections]);

    const handleSelectStudent = (student: StudentData) => {
        setFormData(prev => ({
            ...prev,
            photoUrl: student.photoUrl,
            nameBn: student.nameBn,
            nameEn: student.nameEn,
            dob: student.dob,
            gender: student.gender,
            bloodGroup: student.bloodGroup,
            religion: student.religion,
            birthCertNo: student.birthCertNo,
            nationality: student.nationality,
            fatherNameBn: student.fatherNameBn,
            fatherNameEn: student.fatherNameEn,
            fatherNid: student.fatherNid,
            fatherPhone: student.fatherPhone,
            fatherOccupation: student.fatherOccupation,
            motherNameBn: student.motherNameBn,
            motherNameEn: student.motherNameEn,
            motherNid: student.motherNid,
            motherPhone: student.motherPhone,
            motherOccupation: student.motherOccupation,
            presentAddress: student.presentAddress,
            permanentAddress: student.permanentAddress,
            isSameAddress: student.isSameAddress,
        }));
        setIsSearchModalOpen(false);
        addToast('শিক্ষার্থীর তথ্য সফলভাবে লোড করা হয়েছে!', 'success');
    };

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleAddressChange = (type: 'presentAddress' | 'permanentAddress', e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [type]: { ...prev[type], [name]: value } }));
    };

    const handleSameAddressCheck = (e: React.ChangeEvent<HTMLInputElement>) => {
        const isChecked = e.target.checked;
        setFormData(prev => ({ ...prev, isSameAddress: isChecked, permanentAddress: isChecked ? prev.presentAddress : prev.permanentAddress }));
    };
    
    useEffect(() => {
        if (formData.isSameAddress) {
            setFormData(prev => ({ ...prev, permanentAddress: prev.presentAddress }));
        }
    }, [formData.presentAddress, formData.isSameAddress]);


    const handleFormSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        
        try {
            // Assume 'default' institution for public admission for now.
            // This allows unauthenticated users to submit applications.
            const institutionId = 'default';
            const docRef = doc(db, 'institutionData', institutionId);

            const newStudentApplication: StudentData = await runTransaction(db, async (transaction) => {
                const sfDoc = await transaction.get(docRef);
                if (!sfDoc.exists()) {
                    throw new Error("প্রতিষ্ঠান খুঁজে পাওয়া যায়নি।");
                }
                
                const newStudent: StudentData = { 
                    ...formData, 
                    id: `online-${Date.now()}`,
                    uniqueId: '',
                    roll: '',
                    status: 'পেন্ডিং' // Correct Bengali status
                };
                
                transaction.update(docRef, { students: arrayUnion(newStudent) });
                return newStudent;
            });
            
            setSubmittedData(newStudentApplication);
            addToast('আপনার আবেদন সফলভাবে জমা হয়েছে!', 'success');
            setStep(3);

        } catch (err) {
            console.error("Online admission submission error:", err);
            addToast('আবেদন জমা দেওয়ার সময় একটি ত্রুটি হয়েছে।', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-gray-100 min-h-screen py-10">
            <header className="max-w-5xl mx-auto text-center mb-8 px-4">
                {logoUrl && <img src={logoUrl} alt="Logo" className="w-20 h-20 rounded-full mx-auto mb-4 border-2 border-white shadow-lg" />}
                <h1 className="text-3xl font-bold text-gray-800">{institutionName}</h1>
                <h2 className="text-xl font-semibold text-teal-700">অনলাইন ভর্তি আবেদন</h2>
            </header>

            <main className="max-w-5xl mx-auto bg-white p-6 rounded-xl shadow-lg">
                {step === 1 && (
                     <form onSubmit={handleFormSubmit}>
                        <div className="space-y-6">
                             <fieldset className="border p-4 rounded-md">
                                <legend className="text-lg font-semibold px-2 text-gray-700">শিক্ষার্থীর তথ্য</legend>
                                 <div className="flex items-center gap-6 my-4">
                                    <label className="flex items-center gap-2 cursor-pointer">
                                        <input type="radio" name="admissionType" value="new" checked={admissionType === 'new'} onChange={() => setAdmissionType('new')} className="form-radio h-4 w-4 text-teal-600"/>
                                        <span className="font-semibold">নতুন ভর্তি</span>
                                    </label>
                                    <label className="flex items-center gap-2 cursor-pointer">
                                        <input type="radio" name="admissionType" value="old" checked={admissionType === 'old'} onChange={() => setAdmissionType('old')} className="form-radio h-4 w-4 text-teal-600"/>
                                        <span className="font-semibold">পুরাতন ভর্তি</span>
                                    </label>
                                    {admissionType === 'old' && (
                                        <button
                                            type="button"
                                            onClick={() => setIsSearchModalOpen(true)}
                                            className="flex items-center gap-1 text-sm bg-blue-100 text-blue-700 font-semibold px-3 py-1 rounded-full hover:bg-blue-200"
                                            title="বিদ্যমান শিক্ষার্থী খুঁজুন"
                                        >
                                            <SearchIcon className="w-4 h-4" />
                                            <span>পুরাতন তথ্য খুঁজুন</span>
                                        </button>
                                    )}
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <div className="md:col-span-1 flex flex-col items-center">
                                        <div className="w-32 h-32 rounded-full border-2 border-dashed bg-gray-50 flex items-center justify-center mb-2 overflow-hidden">
                                            {formData.photoUrl ? <img src={formData.photoUrl} alt="Student" className="w-full h-full object-cover rounded-full" /> : <span className="text-sm text-gray-400">ছবি</span>}
                                        </div>
                                        <input 
                                            type="url" 
                                            name="photoUrl" 
                                            value={formData.photoUrl || ''} 
                                            onChange={handleInputChange} 
                                            placeholder="ছবির লিংক দিন" 
                                            className="text-sm w-full p-2 border rounded-md" 
                                        />
                                    </div>
                                    <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-3">
                                        <div><label className="block text-sm font-medium">শিক্ষার্থীর পুরো নাম<span className="text-red-500">*</span></label><input type="text" name="nameBn" value={formData.nameBn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="নাম লিখুন..." required /></div>
                                        <div><label className="block text-sm font-medium">Student's Full Name<span className="text-red-500">*</span></label><input type="text" name="nameEn" value={formData.nameEn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="Write full name..." required /></div>
                                        <div><label className="block text-sm font-medium">জন্মতারিখ<span className="text-red-500">*</span></label><input type="date" name="dob" value={formData.dob} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required /></div>
                                        <div><label className="block text-sm font-medium">লিঙ্গ</label><select name="gender" value={formData.gender} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"><option>ছাত্র</option><option>ছাত্রী</option><option>অন্যান্য</option></select></div>
                                    </div>
                                </div>
                            </fieldset>
                             <fieldset className="border p-4 rounded-md"><legend className="text-lg font-semibold px-2 text-gray-700">প্রাতিষ্ঠানিক তথ্য</legend><div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-3"><div><label className="block text-sm font-medium">শিক্ষা বর্ষ</label><input type="text" value={formData.academicYear} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100" readOnly /></div><div><label className="block text-sm font-medium">ভর্তির শ্রেণি<span className="text-red-500">*</span></label><select name="classLevel" value={formData.classLevel} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required><option value="">নির্বাচন করুন</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select></div><div><label className="block text-sm font-medium">সেকশন<span className="text-red-500">*</span></label><select name="section" value={formData.section} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required disabled={!formData.classLevel}><option value="">নির্বাচন করুন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select></div></div></fieldset>
                             <fieldset className="border p-4 rounded-md"><legend className="text-lg font-semibold px-2 text-gray-700">অভিভাবকের তথ্য</legend><div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3"><h4 className="md:col-span-2 text-md font-semibold text-gray-600 border-b pb-1">পিতার তথ্য</h4><div><label className="block text-sm font-medium">পিতার নাম<span className="text-red-500">*</span></label><input type="text" name="fatherNameBn" value={formData.fatherNameBn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="নাম লিখুন..." required /></div><div><label className="block text-sm font-medium">মোবাইল নম্বর<span className="text-red-500">*</span></label><input type="tel" name="fatherPhone" value={formData.fatherPhone} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required /></div><h4 className="md:col-span-2 text-md font-semibold text-gray-600 border-b pb-1 mt-4">মাতার তথ্য</h4><div><label className="block text-sm font-medium">মাতার নাম</label><input type="text" name="motherNameBn" value={formData.motherNameBn} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" placeholder="নাম লিখুন..." /></div><div><label className="block text-sm font-medium">মোবাইল নম্বর<span className="text-red-500">*</span></label><input type="tel" name="motherPhone" value={formData.motherPhone} onChange={handleInputChange} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" required /></div></div></fieldset>
                             <fieldset className="border p-4 rounded-md"><legend className="text-lg font-semibold px-2 text-gray-700">ঠিকানা</legend><div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4"><div><h4 className="text-md font-semibold text-gray-600 mb-2">বর্তমান ঠিকানা</h4><div className="space-y-2"><input type="text" name="village" placeholder="গ্রাম/মহল্লা" value={formData.presentAddress.village} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500" /><input type="text" name="upazila" placeholder="থানা/উপজেলা" value={formData.presentAddress.upazila} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500" /><input type="text" name="district" placeholder="জেলা" value={formData.presentAddress.district} onChange={(e) => handleAddressChange('presentAddress', e)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500" /></div></div><div><div className="flex justify-between items-center mb-2"><h4 className="text-md font-semibold text-gray-600">স্থায়ী ঠিকানা</h4><label className="flex items-center text-sm"><input type="checkbox" name="isSameAddress" checked={formData.isSameAddress} onChange={handleSameAddressCheck} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500" /><span className="ml-2">বর্তমান ঠিকানার অনুরূপ</span></label></div><div className="space-y-2"><input type="text" name="village" placeholder="গ্রাম/মহল্লা" value={formData.permanentAddress.village} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm disabled:bg-gray-100" /><input type="text" name="upazila" placeholder="থানা/উপজেলা" value={formData.permanentAddress.upazila} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm disabled:bg-gray-100" /><input type="text" name="district" placeholder="জেলা" value={formData.permanentAddress.district} onChange={(e) => handleAddressChange('permanentAddress', e)} disabled={formData.isSameAddress} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm disabled:bg-gray-100" /></div></div></div></fieldset>
                        </div>
                        <div className="mt-8 flex justify-end">
                            <button type="submit" disabled={isSubmitting} className="px-8 py-3 bg-teal-600 text-white font-bold rounded-lg shadow-md hover:bg-teal-700 text-lg disabled:bg-gray-400">
                                {isSubmitting ? 'জমা হচ্ছে...' : 'আবেদন জমা দিন'}
                            </button>
                        </div>
                    </form>
                )}
                
                {step === 3 && submittedData && (
                     <div className="text-center py-10">
                        <CheckCircleIcon className="w-20 h-20 text-green-500 mx-auto mb-4" />
                        <h3 className="text-3xl font-bold text-gray-800 mb-2">আবেদন সফলভাবে জমা হয়েছে!</h3>
                        <p className="text-lg text-gray-600 mb-6">আপনার আবেদনটি পর্যালোচনার জন্য জমা দেওয়া হয়েছে। ভর্তি নিশ্চিত করতে অনুগ্রহ করে কর্তৃপক্ষের সাথে যোগাযোগ করুন।</p>
                        <div className="bg-gray-50 p-4 rounded-lg max-w-md mx-auto text-left space-y-2">
                           <p><strong>আবেদন আইডি:</strong> <span className="font-mono">{submittedData.id}</span></p>
                           <p><strong>শিক্ষার্থীর নাম:</strong> {submittedData.nameBn}</p>
                           <p><strong>শ্রেণি:</strong> {submittedData.classLevel}</p>
                        </div>
                        <Link to="/online-admission" onClick={() => { setStep(1); setFormData(initialFormData); }} className="mt-6 inline-block px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">নতুন আবেদন করুন</Link>
                    </div>
                )}
            </main>
            <StudentSearchModal
                isOpen={isSearchModalOpen}
                onClose={() => setIsSearchModalOpen(false)}
                onSelectStudent={handleSelectStudent}
            />
        </div>
    );
};

export default OnlineAdmission;
