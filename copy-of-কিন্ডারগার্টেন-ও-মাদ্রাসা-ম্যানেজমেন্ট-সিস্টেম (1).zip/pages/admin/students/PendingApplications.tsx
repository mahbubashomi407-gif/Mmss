
import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { EyeIcon, CheckCircleIcon, XCircleIcon } from '../../../components/icons';

const PendingApplications: React.FC = () => {
    const { students, setStudents } = useInstitution();
    const { addToast } = useNotification();
    const navigate = useNavigate();

    const [viewModal, setViewModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });
    const [rejectModal, setRejectModal] = useState<{ isOpen: boolean; student: StudentData | null }>({ isOpen: false, student: null });
    
    const pendingStudents = useMemo(() => {
        return students.filter(s => s.status === 'পেন্ডিং').sort((a,b) => new Date(b.admissionDate).getTime() - new Date(a.admissionDate).getTime());
    }, [students]);
    
    const handleReject = () => {
        if (!rejectModal.student) return;
        setStudents(students.filter(s => s.id !== rejectModal.student!.id));
        addToast('আবেদনটি বাতিল করা হয়েছে।', 'success');
        setRejectModal({ isOpen: false, student: null });
    };

    const InfoRow: React.FC<{ label: string, value?: string | number | null }> = ({ label, value }) => (
        <div className="flex justify-between py-2 border-b"><span className="text-sm text-gray-600">{label}</span><span className="text-sm font-semibold text-right">{value || 'N/A'}</span></div>
    );

    return (
        <div>
            <PageHeader icon="⏳" title="পেন্ডিং আবেদন" />

            <div className="bg-white p-6 rounded-xl shadow-md">
                {pendingStudents.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-50 text-xs uppercase">
                                <tr>
                                    <th className="p-2">আবেদনের তারিখ</th>
                                    <th className="p-2 text-left">নাম</th>
                                    <th className="p-2 text-left">শ্রেণি</th>
                                    <th className="p-2 text-left">পিতার নাম</th>
                                    <th className="p-2 text-left">মোবাইল</th>
                                    <th className="p-2 text-center">পদক্ষেপ</th>
                                </tr>
                            </thead>
                            <tbody>
                                {pendingStudents.map(student => (
                                    <tr key={student.id} className="border-b hover:bg-gray-50">
                                        <td className="p-2">{new Date(student.admissionDate).toLocaleDateString('bn-BD')}</td>
                                        <td className="p-2 font-medium">{student.nameBn}</td>
                                        <td className="p-2">{student.classLevel} ({student.section})</td>
                                        <td className="p-2">{student.fatherNameBn}</td>
                                        <td className="p-2">{student.fatherPhone}</td>
                                        <td className="p-2 text-center space-x-1">
                                            <button onClick={() => setViewModal({isOpen: true, student})} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="বিস্তারিত দেখুন"><EyeIcon className="w-4 h-4" /></button>
                                            <button onClick={() => navigate(`/app/students/add?from_pending=${student.id}`)} className="p-2 text-green-600 hover:bg-green-100 rounded-full" title="পর্যালোচনা ও অনুমোদন করুন"><CheckCircleIcon className="w-4 h-4" /></button>
                                            <button onClick={() => setRejectModal({isOpen: true, student})} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="বাতিল করুন"><XCircleIcon className="w-4 h-4" /></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">কোনো পেন্ডিং আবেদন নেই।</p>
                )}
            </div>

            {/* View Details Modal */}
            {viewModal.isOpen && viewModal.student && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setViewModal({isOpen: false, student: null})}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4 h-[80vh] flex flex-col" onClick={e=>e.stopPropagation()}>
                        <div className="p-5 border-b"><h3 className="text-lg font-bold">আবেদনের বিস্তারিত</h3></div>
                        <div className="p-5 flex-grow overflow-y-auto space-y-4">
                            <InfoRow label="আবেদন আইডি" value={viewModal.student.id} />
                            <InfoRow label="শিক্ষার্থীর নাম" value={viewModal.student.nameBn} />
                            <InfoRow label="জন্মতারিখ" value={new Date(viewModal.student.dob).toLocaleDateString('bn-BD')} />
                            <InfoRow label="শ্রেণি" value={`${viewModal.student.classLevel} (${viewModal.student.section})`} />
                            <InfoRow label="পিতার নাম" value={viewModal.student.fatherNameBn} />
                            <InfoRow label="পিতার মোবাইল" value={viewModal.student.fatherPhone} />
                            <InfoRow label="মাতার নাম" value={viewModal.student.motherNameBn} />
                            <InfoRow label="মাতার মোবাইল" value={viewModal.student.motherPhone} />
                            <InfoRow label="বর্তমান ঠিকানা" value={`${viewModal.student.presentAddress.village}, ${viewModal.student.presentAddress.upazila}, ${viewModal.student.presentAddress.district}`} />
                        </div>
                        <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3"><button onClick={() => setViewModal({isOpen: false, student: null})} className="px-4 py-2 bg-gray-200 rounded-lg">বন্ধ করুন</button></div>
                    </div>
                </div>
            )}
            
            <Modal isOpen={rejectModal.isOpen} onClose={() => setRejectModal({isOpen: false, student: null})} onConfirm={handleReject} title="আবেদন বাতিল">
                আপনি কি নিশ্চিতভাবে এই আবেদনটি বাতিল করতে চান? এই কাজটি ফিরিয়ে আনা যাবে না।
            </Modal>
        </div>
    );
};

export default PendingApplications;
