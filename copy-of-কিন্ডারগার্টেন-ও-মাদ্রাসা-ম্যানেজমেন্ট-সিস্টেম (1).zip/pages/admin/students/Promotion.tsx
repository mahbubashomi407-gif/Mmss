
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { GraduationCapIcon, StudentsIcon, CalendarIcon, RefreshIcon, ChevronDownIcon } from '../../../components/icons';

const Promotion: React.FC = () => {
    const { students, setStudents, classLevels, sections, academicSessions } = useInstitution();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Source selection
    const [sourceYear, setSourceYear] = useState(activeSession?.name || '');
    const [sourceClass, setSourceClass] = useState('');
    const [sourceSection, setSourceSection] = useState('');

    // Target selection
    const [targetYear, setTargetYear] = useState('');
    const [targetClass, setTargetClass] = useState('');
    const [targetSection, setTargetSection] = useState('');

    // Student lists
    const [eligibleStudents, setEligibleStudents] = useState<StudentData[]>([]);
    const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(new Set());

    // UI State
    const [isModalOpen, setIsModalOpen] = useState(false);

    // Derived options for dropdowns
    const availableSourceSections = useMemo(() => sourceClass ? sections.filter(s => s.classLevel === sourceClass).map(s => s.name) : [], [sourceClass, sections]);
    const availableTargetSections = useMemo(() => targetClass ? sections.filter(s => s.classLevel === targetClass).map(s => s.name) : [], [targetClass, sections]);
    const futureSessions = useMemo(() => academicSessions.filter(s => s.name !== sourceYear), [academicSessions, sourceYear]);

    // Handlers
    const handleFindStudents = () => {
        if (!sourceYear || !sourceClass || !sourceSection) {
            addToast('অনুগ্রহ করে বর্ষ, শ্রেণি এবং সেকশন নির্বাচন করুন।', 'error');
            return;
        }
        const filtered = students.filter(s =>
            s.academicYear === sourceYear &&
            s.classLevel === sourceClass &&
            s.section === sourceSection &&
            s.status !== 'পেন্ডিং'
        );
        setEligibleStudents(filtered);
        setSelectedStudentIds(new Set());
    };

    const handleSelectStudent = (id: string, checked: boolean) => {
        setSelectedStudentIds(prev => {
            const newSet = new Set(prev);
            if (checked) newSet.add(id);
            else newSet.delete(id);
            return newSet;
        });
    };

    const handleSelectAll = (checked: boolean) => {
        if (checked) {
            setSelectedStudentIds(new Set(eligibleStudents.map(s => s.id)));
        } else {
            setSelectedStudentIds(new Set());
        }
    };
    
    const handlePromotionClick = () => {
        if (selectedStudentIds.size === 0 || !targetYear || !targetClass || !targetSection) {
            addToast('প্রাপক, নতুন বর্ষ, নতুন শ্রেণি এবং নতুন সেকশন নির্বাচন করুন।', 'error');
            return;
        }
        setIsModalOpen(true);
    };

    const handleConfirmPromotion = () => {
        const updatedStudents = students.map(student => {
            if (selectedStudentIds.has(student.id)) {
                return {
                    ...student,
                    academicYear: targetYear,
                    classLevel: targetClass,
                    section: targetSection,
                    roll: '', // Reset roll on promotion
                };
            }
            return student;
        });

        // The `map` operation creates an array of a mixed type that is not assignable to `StudentData[]`
        // because TypeScript widens the type of `roll: ''` to `string`. Casting the array fixes this.
        setStudents(updatedStudents as StudentData[]);
        addToast(`${selectedStudentIds.size} জন শিক্ষার্থীকে সফলভাবে প্রমোট করা হয়েছে!`, 'success');
        
        // Reset state after promotion
        setEligibleStudents([]);
        setSelectedStudentIds(new Set());
        setIsModalOpen(false);
    };

    const isPromotionDisabled = selectedStudentIds.size === 0 || !targetYear || !targetClass || !targetSection;

    return (
        <div>
            <PageHeader icon="⬆️" title="শিক্ষার্থী প্রমোশন" />

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column: Source and Target Selection */}
                <div className="space-y-6">
                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-lg font-bold text-gray-800 border-b pb-2 mb-4">১. উৎস নির্বাচন করুন</h3>
                        <div className="space-y-3">
                            <div><label className="block text-sm font-medium">বর্তমান শিক্ষা বর্ষ</label><select value={sourceYear} onChange={e => setSourceYear(e.target.value)} className="w-full mt-1 p-2 border rounded-md"><option value="" disabled>নির্বাচন করুন</option>{academicSessions.map(s=><option key={s.id} value={s.name}>{s.name}</option>)}</select></div>
                            <div><label className="block text-sm font-medium">বর্তমান শ্রেণি</label><select value={sourceClass} onChange={e => setSourceClass(e.target.value)} className="w-full mt-1 p-2 border rounded-md"><option value="" disabled>নির্বাচন করুন</option>{classLevels.map(cl=><option key={cl.id} value={cl.name}>{cl.name}</option>)}</select></div>
                            <div><label className="block text-sm font-medium">বর্তমান সেকশন</label><select value={sourceSection} onChange={e => setSourceSection(e.target.value)} className="w-full mt-1 p-2 border rounded-md" disabled={!sourceClass}><option value="" disabled>নির্বাচন করুন</option>{availableSourceSections.map(s=><option key={s} value={s}>{s}</option>)}</select></div>
                        </div>
                        <button onClick={handleFindStudents} className="w-full mt-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">শিক্ষার্থী খুঁজুন</button>
                    </div>

                    <div className="bg-white p-6 rounded-xl shadow-md">
                        <h3 className="text-lg font-bold text-gray-800 border-b pb-2 mb-4">৩. লক্ষ্য নির্ধারণ করুন</h3>
                         <div className="space-y-3">
                            <div><label className="block text-sm font-medium">নতুন শিক্ষা বর্ষ</label><select value={targetYear} onChange={e => setTargetYear(e.target.value)} className="w-full mt-1 p-2 border rounded-md"><option value="" disabled>নির্বাচন করুন</option>{futureSessions.map(s=><option key={s.id} value={s.name}>{s.name}</option>)}</select></div>
                            <div><label className="block text-sm font-medium">নতুন শ্রেণি</label><select value={targetClass} onChange={e => setTargetClass(e.target.value)} className="w-full mt-1 p-2 border rounded-md"><option value="" disabled>নির্বাচন করুন</option>{classLevels.map(cl=><option key={cl.id} value={cl.name}>{cl.name}</option>)}</select></div>
                            <div><label className="block text-sm font-medium">নতুন সেকশন</label><select value={targetSection} onChange={e => setTargetSection(e.target.value)} className="w-full mt-1 p-2 border rounded-md" disabled={!targetClass}><option value="" disabled>নির্বাচন করুন</option>{availableTargetSections.map(s=><option key={s} value={s}>{s}</option>)}</select></div>
                        </div>
                    </div>
                </div>

                {/* Right Column: Student List and Action */}
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-lg font-bold text-gray-800 border-b pb-2 mb-4">২. প্রমোশনের জন্য শিক্ষার্থী নির্বাচন করুন</h3>
                    {eligibleStudents.length > 0 ? (
                        <div className="space-y-4">
                            <div className="max-h-80 overflow-y-auto border rounded-lg">
                                <table className="w-full text-sm">
                                    <thead className="bg-gray-100 sticky top-0"><tr><th className="p-2 w-10"><input type="checkbox" onChange={e => handleSelectAll(e.target.checked)} checked={eligibleStudents.length > 0 && selectedStudentIds.size === eligibleStudents.length} /></th><th className="p-2 text-left">রোল</th><th className="p-2 text-left">নাম</th></tr></thead>
                                    <tbody>
                                        {eligibleStudents.map(s => (
                                            <tr key={s.id} className="border-t hover:bg-gray-50">
                                                <td className="p-2"><input type="checkbox" checked={selectedStudentIds.has(s.id)} onChange={e => handleSelectStudent(s.id, e.target.checked)} /></td>
                                                <td className="p-2">{s.roll}</td>
                                                <td className="p-2 font-medium">{s.nameBn}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                            <div className="text-center pt-4 border-t">
                                <p className="text-sm text-gray-600 mb-2">{selectedStudentIds.size} জন শিক্ষার্থীকে প্রমোট করার জন্য নির্বাচন করা হয়েছে।</p>
                                <button onClick={handlePromotionClick} disabled={isPromotionDisabled} className="w-full py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed">
                                    প্রমোশন সম্পন্ন করুন
                                </button>
                            </div>
                        </div>
                    ) : (
                        <p className="text-center text-gray-500 py-10">শিক্ষার্থীদের তালিকা দেখতে উৎস নির্বাচন করে "শিক্ষার্থী খুঁজুন" বাটনে ক্লিক করুন।</p>
                    )}
                </div>
            </div>

            <Modal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onConfirm={handleConfirmPromotion}
                title="প্রমোশন নিশ্চিত করুন"
            >
                <p>আপনি কি নিশ্চিতভাবে <strong>{selectedStudentIds.size}</strong> জন শিক্ষার্থীকে <strong>"{targetClass}"</strong> শ্রেণিতে (সেকশন: <strong>{targetSection}</strong>) প্রমোট করতে চান?</p>
                <p className="mt-2 text-sm text-red-600">এই কাজটি সম্পন্ন হলে শিক্ষার্থীদের রোল নম্বর রিসেট হয়ে যাবে, যা পরবর্তীতে রোল ও সেকশন পরিবর্তন পেজ থেকে ঠিক করতে হবে।</p>
            </Modal>
        </div>
    );
};

export default Promotion;
