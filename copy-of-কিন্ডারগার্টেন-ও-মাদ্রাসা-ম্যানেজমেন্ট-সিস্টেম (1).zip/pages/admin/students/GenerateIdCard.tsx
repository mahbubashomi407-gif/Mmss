import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon } from '../../../components/icons';

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
    };
    return num.replace(/[0-9]/g, (match) => map[match]);
};


// ID Card Front Component
const IdCardFront: React.FC<{ student: StudentData }> = ({ student }) => {
    const { institutionName, logoUrl, managerInfo, address } = useInstitution();
    
    return (
        <div className="relative w-[2.125in] h-[3.375in] bg-white rounded-lg shadow-md overflow-hidden text-[10px] leading-tight text-gray-800 border border-gray-200">
            {/* Top green curve */}
            <div className="absolute top-0 left-0 right-0 h-28 bg-green-800" style={{ borderBottomLeftRadius: '50% 20%', borderBottomRightRadius: '50% 20%' }}></div>
            
            {/* Watermark Logo */}
            {logoUrl && <img src={logoUrl} alt="watermark" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 opacity-10" />}

            {/* Bottom white curve overlay */}
            <div className="absolute bottom-0 left-0 right-0 h-20 bg-white" style={{ borderTopLeftRadius: '50% 40%', borderTopRightRadius: '50% 40%' }}></div>

            <div className="relative z-10 p-3 h-full flex flex-col">
                {/* Header */}
                 <div className="flex flex-col items-center text-white text-center">
                    <div className="absolute top-3 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-white ring-1 ring-green-600"></div>
                    <div className="flex items-center justify-center gap-3 mt-4">
                        <div className="flex-col items-center text-center">
                            <h3 className="font-bold text-[14px]">{institutionName}</h3>
                            <p className="text-[10px]">{address.upazila}, {address.district}</p>
                        </div>
                    </div>
                </div>

                {/* Photo */}
                <div className="absolute top-[4.6rem] left-1/2 -translate-x-1/2 w-20 h-20 rounded-full bg-white p-1 shadow-lg">
                    <img src={student.photoUrl || logoUrl || 'https://via.placeholder.com/100x120?text=Photo'} alt={student.nameBn} className="w-full h-full object-cover rounded-full" />
                </div>

                {/* Body */}
                <div className="flex-grow mt-[6.2rem] text-center">
                     <div className="inline-block bg-green-800 text-white px-4 py-1 rounded-md text-xs font-semibold">পরিচয় পত্র</div>
                     <p className="font-bold text-xl leading-tight text-gray-900 mt-1">{student.nameBn}</p>
                     
                     <div className="mt-1 text-xs text-left w-full mx-auto space-y-0.5 px-3">
                        <p><strong>পিতার নাম:</strong> {student.fatherNameBn}</p>
                        <p><strong>শ্রেণী:</strong> {student.classLevel}</p>
                        <p><strong>রোল নং:</strong> {toBengaliNumber(student.roll || '')}</p>
                        <p><strong>শাখা:</strong> {student.section}</p>
                        <p><strong>আইডি নং:</strong> {toBengaliNumber(student.uniqueId)}</p>
                     </div>
                </div>


                {/* Footer */}
                <div className="h-12 flex justify-end items-end pr-4 pb-2">
                    <div className="text-center">
                        {managerInfo.signatureUrl ? <img src={managerInfo.signatureUrl} alt="Signature" className="h-8 mx-auto object-contain" /> : null}
                        <div className="border-t border-gray-600 text-[8px] pt-0.5">অধ্যক্ষের স্বাক্ষর</div>
                    </div>
                </div>
            </div>
        </div>
    );
};


// ID Card Back Component
const IdCardBack: React.FC<{ student: StudentData }> = ({ student }) => {
    const { institutionName, logoUrl } = useInstitution();
    const qrData = encodeURIComponent(student.uniqueId);
    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=${qrData}&qzone=1`;

    return (
        <div className="relative w-[2.125in] h-[3.375in] bg-white rounded-lg shadow-md overflow-hidden text-[10px] leading-tight text-gray-800 border border-gray-200 flex flex-col">
             {/* Top green header */}
            <div className="h-10 bg-green-800 flex items-center justify-center text-white font-semibold text-[12px]">
                {institutionName}
            </div>

             <div className="relative z-10 p-3 flex-grow flex flex-col">
                {logoUrl && <img src={logoUrl} alt="Logo" className="w-14 h-14 mx-auto mt-2" />}
                <p className="text-center text-[9px] my-2 px-2 leading-relaxed">
                    এই কার্ডটি মাদরাসার পরিচয়পত্র। এটি সর্বদা সঙ্গে রাখুন। হারিয়ে গেলে দ্রুত অফিসে যোগাযোগ করুন। অন্যের কার্ড ব্যবহার করা সম্পূর্ণ নিষিদ্ধ।
                </p>

                <div className="bg-green-800 text-white text-center py-1 text-[11px] font-semibold my-2">রক্তের গ্রুপ: {student.bloodGroup || 'N/A'}</div>
                
                <div className="text-[10px] space-y-1 flex-grow">
                     <p><strong>অভিভাবকের মোবাইল:</strong> {toBengaliNumber(student.fatherPhone)}</p>
                     <p><strong>ঠিকানা:</strong> {student.isSameAddress ? `${student.presentAddress.village}, ${student.presentAddress.upazila}` : `${student.permanentAddress.village}, ${student.permanentAddress.upazila}`}</p>
                </div>
             </div>

             {/* Footer with QR Code */}
             <div className="h-24 bg-green-800 flex items-center justify-center p-2">
                 <img src={qrUrl} alt="QR Code" className="w-20 h-20 bg-white p-1 rounded" />
             </div>
        </div>
    );
};


const GenerateIdCard: React.FC = () => {
    const { students, classLevels, sections, academicSessions } = useInstitution();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    
    // Student Selection
    const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(new Set());
    const [studentsToPrint, setStudentsToPrint] = useState<StudentData[]>([]);

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    const filteredStudents = useMemo(() => {
        if (!classFilter || !sectionFilter) return [];
        return students
            .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
            .sort((a, b) => (a.roll || 999) - (b.roll || 999));
    }, [students, academicYearFilter, classFilter, sectionFilter]);
    
    useEffect(() => {
        setSelectedStudentIds(new Set());
    }, [classFilter, sectionFilter, academicYearFilter]);

    const handleSelectStudent = (id: string, checked: boolean) => {
        setSelectedStudentIds(prev => {
            const newSet = new Set(prev);
            if (checked) newSet.add(id);
            else newSet.delete(id);
            return newSet;
        });
    };

    const handleSelectAll = (checked: boolean) => {
        if (checked) {
            setSelectedStudentIds(new Set(filteredStudents.map(s => s.id)));
        } else {
            setSelectedStudentIds(new Set());
        }
    };
    
    const handleGenerate = () => {
        const toPrint = students.filter(s => selectedStudentIds.has(s.id));
        setStudentsToPrint(toPrint);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-id-cards');
            if (printContent) {
                const printWindow = window.open('', '', 'height=800,width=1200');
                if (printWindow) {
                    printWindow.document.write('<html><head><title>ID Cards</title>');
                    // Use the script tag for Tailwind JIT compiler
                    printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                    printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                    printWindow.document.write(`
                        <style>
                            body { 
                                font-family: "SolaimanLipi", sans-serif !important; 
                                /* Force printing of background colors and images */
                                -webkit-print-color-adjust: exact !important; 
                                print-color-adjust: exact !important;
                            } 
                            @page { 
                                size: A4; 
                                margin: 0.5in; 
                            } 
                            .card-grid {
                                display: flex;
                                flex-wrap: wrap;
                                gap: 0.15in;
                                justify-content: flex-start;
                            }
                            .card-grid > div {
                                page-break-inside: avoid;
                                margin-bottom: 0.15in;
                            }
                        </style>`);
                    printWindow.document.write('</head><body>');
                    printWindow.document.write(printContent.innerHTML);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    
                    // A timeout is necessary to allow the Tailwind JIT compiler to run
                    // and for the browser to render the styles before printing.
                    setTimeout(() => {
                        printWindow.focus();
                        printWindow.print();
                        printWindow.close();
                    }, 750); // 750ms should be sufficient for the script to load and execute.
                }
            }
        }, 500); // This initial timeout ensures React has updated the state for 'studentsToPrint'
    };

    return (
        <div>
            <PageHeader icon="💳" title="আইডি কার্ড তৈরী" />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Left Side: Filters and Student List */}
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <div className="flex flex-wrap items-center gap-3 mb-4">
                        <select value={classFilter} onChange={e => { setClassFilter(e.target.value); setSectionFilter(''); }} className="p-2 border rounded-md bg-white flex-grow"><option value="">শ্রেণি নির্বাচন</option>{classLevels.map(cl => <option key={cl.id}>{cl.name}</option>)}</select>
                        <select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="p-2 border rounded-md bg-white flex-grow" disabled={!classFilter}><option value="">সেকশন নির্বাচন</option>{availableSections.map(s => <option key={s}>{s}</option>)}</select>
                    </div>

                    {classFilter && sectionFilter ? (
                         <div className="border rounded-lg overflow-hidden max-h-96 overflow-y-auto">
                            <table className="w-full text-sm">
                                <thead className="bg-gray-100 sticky top-0">
                                    <tr>
                                        <th className="p-2 w-10"><input type="checkbox" onChange={e => handleSelectAll(e.target.checked)} checked={filteredStudents.length > 0 && selectedStudentIds.size === filteredStudents.length} /></th>
                                        <th className="p-2 text-left">রোল</th>
                                        <th className="p-2 text-left">নাম</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredStudents.map(s => (
                                        <tr key={s.id} className="border-t hover:bg-gray-50">
                                            <td className="p-2"><input type="checkbox" checked={selectedStudentIds.has(s.id)} onChange={e => handleSelectStudent(s.id, e.target.checked)} /></td>
                                            <td className="p-2">{toBengaliNumber(s.roll)}</td>
                                            <td className="p-2">{s.nameBn}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                         <p className="text-center text-gray-500 py-10">শিক্ষার্থী তালিকা দেখতে একটি শ্রেণি ও সেকশন নির্বাচন করুন।</p>
                    )}
                </div>

                {/* Right Side: Generate Button and Preview */}
                <div className="bg-white p-6 rounded-xl shadow-md">
                    <h3 className="text-lg font-bold text-gray-800 mb-4">জেনারেট ও প্রিন্ট</h3>
                    <p className="text-sm text-gray-600 mb-2">{toBengaliNumber(selectedStudentIds.size)} জন শিক্ষার্থী নির্বাচন করা হয়েছে।</p>
                    <button onClick={handleGenerate} disabled={selectedStudentIds.size === 0} className="w-full py-3 bg-teal-600 text-white font-bold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">
                        আইডি কার্ড জেনারেট ও প্রিন্ট করুন
                    </button>
                    <div className="mt-6">
                        <h4 className="font-semibold mb-2">প্রিভিউ:</h4>
                        <p className="text-xs text-gray-500 mb-2">এখানে প্রথম নির্বাচিত শিক্ষার্থীর আইডি কার্ডের একটি প্রিভিউ দেখানো হচ্ছে।</p>
                        {selectedStudentIds.size > 0 ? (
                            <div className="space-y-4 transform scale-75 -translate-x-12 -translate-y-8 origin-top-left">
                                 <IdCardFront student={students.find(s => selectedStudentIds.has(s.id))!} />
                                 <IdCardBack student={students.find(s => selectedStudentIds.has(s.id))!} />
                            </div>
                        ) : (
                            <div className="border-2 border-dashed rounded-lg h-32 flex items-center justify-center text-gray-400">প্রিভিউ দেখতে শিক্ষার্থী নির্বাচন করুন</div>
                        )}
                    </div>
                </div>
            </div>
            
            {/* Hidden div for printing */}
            <div id="printable-id-cards" className="hidden">
                <div className="card-grid">
                    {studentsToPrint.flatMap(student => [
                        <IdCardFront key={`${student.id}-front`} student={student} />,
                        <IdCardBack key={`${student.id}-back`} student={student} />
                    ])}
                </div>
            </div>
        </div>
    );
};

export default GenerateIdCard;