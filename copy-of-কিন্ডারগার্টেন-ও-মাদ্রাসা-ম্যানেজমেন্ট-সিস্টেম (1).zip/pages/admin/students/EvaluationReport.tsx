import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, calculateGradeInfo } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';
import { ReportCardContent, ReportData } from '../../../components/ReportCardModal';

const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        '.': '.',
    };
    return num.replace(/[0-9.]/g, (match) => map[match] || match);
};


const MarksheetPage: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams, markRecords, grades } = useInstitution();
    const [studentsToPrint, setStudentsToPrint] = useState<ReportData[]>([]);
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    
    // Derived data for filters
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    const availableExams = useMemo(() => classFilter ? exams.filter(e => e.academicYear === academicYearFilter && e.classLevels.includes(classFilter)) : [], [classFilter, academicYearFilter, exams]);

    useEffect(() => { if (sectionFilter && !availableSections.includes(sectionFilter)) setSectionFilter(''); }, [availableSections, sectionFilter]);
    useEffect(() => { if (examFilter && !availableExams.some(e => e.id === examFilter)) setExamFilter(''); }, [availableExams, examFilter]);

    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter;

    const generateReportData = () => {
        if (!allFiltersSelected) return [];
        const exam = exams.find(e => e.id === examFilter);
        if (!exam) return [];
        const studentsInClass = students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');
        const allSubjectsForClass = classLevels.find(cl => cl.name === classFilter)?.subjects || [];
        const assignedSubjects = exam.subjectAssignments?.[classFilter] || [];
        const subjectsForExam = allSubjectsForClass.filter(s => assignedSubjects.some(as => as.subjectId === s.id));
        const failGradeName = grades.find(g => g.gpa === 0)?.name || 'F';
        
        const allStudentResults = studentsInClass.map(currentStudent => {
            const studentMarks = markRecords.filter(m => m.studentId === currentStudent.id && m.examId === examFilter);
            let totalObtained = 0, totalMarks = 0, isFail = false, hasAnyMark = false;
            const marksBySubject: Record<string, { obtained: number | null; total: number }> = {};
            subjectsForExam.forEach(subject => {
                const mark = studentMarks.find(m => m.subjectId === subject.id);
                const obtained = mark?.marksObtained ?? null;
                const total = assignedSubjects.find(as => as.subjectId === subject.id)?.totalMarks || 100;
                marksBySubject[subject.id] = { obtained, total };
                if (obtained !== null) {
                    hasAnyMark = true; totalObtained += obtained; totalMarks += total;
                    if (calculateGradeInfo((obtained / total) * 100, grades).grade === failGradeName) isFail = true;
                }
            });
            if (!hasAnyMark) return { ...currentStudent, totalObtained: 0, resultStatus: 'Failed' as const, isAbsent: true, grade: 'F', gpa: 0, marksBySubject };
            const { grade, gpa } = calculateGradeInfo((totalObtained / totalMarks) * 100, grades);
            return { ...currentStudent, totalObtained, isAbsent: false, resultStatus: (isFail ? 'Failed' : 'Passed') as 'Passed' | 'Failed', grade: isFail ? failGradeName : grade, gpa: isFail ? 0 : gpa, marksBySubject };
        });

        const sorted = allStudentResults.sort((a, b) => {
            if (a.isAbsent && !b.isAbsent) return 1; if (!a.isAbsent && b.isAbsent) return -1;
            if (a.resultStatus === 'Failed' && b.resultStatus === 'Passed') return 1; if (a.resultStatus === 'Passed' && b.resultStatus === 'Failed') return -1;
            if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
            return (a.roll || 999) - (b.roll || 999);
        });

        let rank = 0, lastScore = -1;
        const rankedResults = sorted.map((s, index) => {
            let currentRank: number | '-' = '-';
            if (!s.isAbsent && s.resultStatus === 'Passed') { if (s.totalObtained !== lastScore) { rank = index + 1; lastScore = s.totalObtained; } currentRank = rank; }
            return { ...s, rank: currentRank };
        });

        const highestMarksBySubject: Record<string, number> = {};
        subjectsForExam.forEach(subject => { highestMarksBySubject[subject.id] = Math.max(0, ...allStudentResults.map(res => res.marksBySubject[subject.id]?.obtained || 0)); });
        
        return rankedResults.map(studentResult => {
            let failedSubjectsCount = 0;
            const subjectRows = subjectsForExam.map(subject => {
                const markInfo = studentResult.marksBySubject[subject.id];
                const obtained = markInfo?.obtained; const total = markInfo?.total ?? 100;
                const gradeInfo = (obtained !== null && obtained !== undefined) ? calculateGradeInfo((obtained / total) * 100, grades) : { grade: 'N/A', gpa: 0 };
                if (gradeInfo.grade === failGradeName) failedSubjectsCount++;
                return { name: subject.name, fullMarks: total, highestMark: highestMarksBySubject[subject.id], totalMarks: obtained, letterGrade: gradeInfo.grade, gradePoint: gradeInfo.gpa.toFixed(2) };
            });
            const totalFullMarks = subjectRows.reduce((sum, r) => sum + r.fullMarks, 0);
            return { student: studentResult, exam, subjectRows, failedSubjectsCount, totalFullMarks };
        });
    };
    
    const handlePrint = () => {
        const data = generateReportData();
        setStudentsToPrint(data);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-area');
            if(printContent) {
                const printWindow = window.open('', '', 'height=800,width=1200');
                if(printWindow){
                    printWindow.document.write('<html><head><title>Marksheets</title>');
                    printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                    printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                    printWindow.document.write(`<style>
                        body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                        @page { size: A4 landscape; margin: 0.6cm; }
                        .print-page { 
                            page-break-after: always; 
                            display: flex; 
                            flex-direction: row; 
                            gap: 1.2cm; 
                            width: 100%; 
                            height: 100%;
                            align-items: flex-start;
                        }
                        .marksheet-container {
                            flex: 1;
                            box-sizing: border-box;
                            overflow: hidden;
                        }
                    </style>`);
                    printWindow.document.write('</head><body>');
                    printWindow.document.write(printContent.innerHTML);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 750);
                }
            }
        }, 500);
    };

    return (
        <div>
            <PageHeader icon="📜" title="মার্কশীট" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examFilter} onChange={e => setExamFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষা</option>{availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5" /></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {allFiltersSelected ? (
                    <div className="text-center">
                        <h3 className="text-xl font-bold text-green-600">মার্কশীট তৈরী হয়েছে।</h3>
                        <p className="text-gray-600 my-4">প্রিন্ট করতে নিচের বাটনে ক্লিক করুন।</p>
                        <button onClick={handlePrint} className="px-6 py-3 bg-teal-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-teal-700">
                            সকল মার্কশীট তৈরী ও প্রিন্ট করুন
                        </button>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">মার্কশীট তৈরি করতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p>
                )}
            </div>
            
            <div id="printable-area" className="hidden">
            {
                Array.from({ length: Math.ceil(studentsToPrint.length / 2) }, (_, i) => studentsToPrint.slice(i * 2, i * 2 + 2))
                    .map((pair, pageIndex) => (
                        <div key={pageIndex} className="print-page">
                            {pair[0] && <ReportCardContent key={pair[0].student.id} reportData={pair[0]} isMadrasaMode={false} />}
                            {pair[1] ? <ReportCardContent key={pair[1].student.id} reportData={pair[1]} isMadrasaMode={false} /> : <div className="marksheet-container"></div>}
                        </div>
                    ))
            }
            </div>
        </div>
    );
};

export default MarksheetPage;
