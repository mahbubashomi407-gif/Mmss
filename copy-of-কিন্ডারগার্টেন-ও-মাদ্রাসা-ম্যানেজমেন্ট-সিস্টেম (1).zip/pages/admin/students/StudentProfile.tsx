
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link, useNavigate } from 'react-router-dom';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData } from '../../../context/InstitutionContext';
import { PencilIcon, SearchIcon } from '../../../components/icons';

const InfoRow: React.FC<{ label: string; value?: string | number | null }> = ({ label, value }) => (
    <div className="flex justify-between py-2.5 border-b border-gray-100 last:border-b-0">
        <span className="text-sm font-medium text-gray-500">{label}</span>
        <span className="text-sm font-semibold text-gray-800 text-right">{value || 'N/A'}</span>
    </div>
);

const StudentProfileView: React.FC<{ student: StudentData }> = ({ student }) => {
    const [activeTab, setActiveTab] = useState('personal');

    const TabButton: React.FC<{ tab: string; label: string }> = ({ tab, label }) => (
        <button
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-semibold rounded-t-lg transition-colors duration-200 focus:outline-none -mb-px border-b-2
                ${activeTab === tab
                    ? 'border-teal-500 text-teal-600'
                    : 'border-transparent text-gray-500 hover:text-teal-600 hover:border-gray-300'
                }`}
        >
            {label}
        </button>
    );

    return (
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
            {/* Header Section */}
            <div className="bg-teal-50 p-4 sm:p-5 flex flex-col sm:flex-row items-center gap-4">
                <img 
                    src={student.photoUrl || 'https://via.placeholder.com/150x150?text=S'}
                    alt={student.nameBn}
                    className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-md"
                />
                <div className="text-center sm:text-left">
                    <h2 className="text-2xl font-bold text-gray-900">{student.nameBn}</h2>
                    <p className="text-sm text-gray-600">{student.nameEn}</p>
                    <div className="mt-2 flex flex-wrap justify-center sm:justify-start gap-x-4 gap-y-1 text-sm font-semibold text-teal-800">
                        <p>ইউনিক আইডি: <span className="font-mono">{student.uniqueId}</span></p>
                        <p>শ্রেণি: {student.classLevel} ({student.section})</p>
                        <p>রোল: {student.roll}</p>
                    </div>
                </div>
            </div>

            {/* Tabbed Section */}
            <div>
                <div className="border-b border-gray-200 px-4 flex space-x-2">
                    <TabButton tab="personal" label="ব্যক্তিগত তথ্য" />
                    <TabButton tab="guardian" label="অভিভাবকের তথ্য" />
                    <TabButton tab="address" label="ঠিকানা" />
                </div>
                <div className="p-4 sm:p-5">
                    {activeTab === 'personal' && (
                        <div className="space-y-1">
                             <InfoRow label="জন্মতারিখ" value={student.dob ? new Date(student.dob).toLocaleDateString('bn-BD') : ''} />
                             <InfoRow label="লিঙ্গ" value={student.gender} />
                             <InfoRow label="ধর্ম" value={student.religion} />
                             <InfoRow label="রক্তের গ্রুপ" value={student.bloodGroup} />
                             <InfoRow label="জন্ম সনদ নম্বর" value={student.birthCertNo} />
                             <InfoRow label="ভর্তির তারিখ" value={student.admissionDate ? new Date(student.admissionDate).toLocaleDateString('bn-BD') : ''} />
                             <InfoRow label="শিক্ষা বর্ষ" value={student.academicYear} />
                        </div>
                    )}
                    {activeTab === 'guardian' && (
                        <div className="space-y-1">
                             <h4 className="font-semibold text-gray-600 mt-2 pb-1 border-b">পিতার তথ্য</h4>
                             <InfoRow label="নাম (বাংলা)" value={student.fatherNameBn} />
                             <InfoRow label="মোবাইল" value={student.fatherPhone} />
                             <InfoRow label="পেশা" value={student.fatherOccupation} />
                             <h4 className="font-semibold text-gray-600 mt-4 pb-1 border-b">মাতার তথ্য</h4>
                             <InfoRow label="নাম (বাংলা)" value={student.motherNameBn} />
                             <InfoRow label="মোবাইল" value={student.motherPhone} />
                             <InfoRow label="পেশা" value={student.motherOccupation} />
                        </div>
                    )}
                    {activeTab === 'address' && (
                         <div className="space-y-3">
                             <div>
                                <h4 className="font-semibold text-gray-600 text-sm">বর্তমান ঠিকানা</h4>
                                <p className="text-sm text-gray-700 mt-1 p-2 bg-gray-50 rounded">
                                 {student.presentAddress.village}, {student.presentAddress.postOffice}, {student.presentAddress.upazila}, {student.presentAddress.district}
                                </p>
                             </div>
                            <div>
                                <h4 className="font-semibold text-gray-600 text-sm">স্থায়ী ঠিকানা</h4>
                                <p className="text-sm text-gray-700 mt-1 p-2 bg-gray-50 rounded">
                                 {student.isSameAddress ? 'বর্তমান ঠিকানার অনুরূপ' : `${student.permanentAddress.village}, ${student.permanentAddress.postOffice}, ${student.permanentAddress.upazila}, ${student.permanentAddress.district}`}
                                </p>
                            </div>
                         </div>
                    )}
                </div>
            </div>
        </div>
    );
};

const StudentProfile: React.FC = () => {
    const [searchParams] = useSearchParams();
    const studentIdParam = searchParams.get('id');
    const studentUniqueIdParam = searchParams.get('uniqueId');
    const { students } = useInstitution();
    const navigate = useNavigate();

    const [searchInput, setSearchInput] = useState(studentUniqueIdParam || '');
    const [student, setStudent] = useState<StudentData | null>(null);
    const [searchError, setSearchError] = useState('');

    useEffect(() => {
        let foundStudent: StudentData | undefined;
        if (studentIdParam) {
            foundStudent = students.find(s => s.id === studentIdParam);
        } else if (studentUniqueIdParam) {
            // Make the comparison case-insensitive
            const lowerCaseUniqueIdParam = studentUniqueIdParam.toLowerCase();
            foundStudent = students.find(s => s.uniqueId.toLowerCase() === lowerCaseUniqueIdParam);
        }
        
        if (foundStudent) {
            setStudent(foundStudent);
            setSearchInput(foundStudent.uniqueId); // Sync search input if found
            setSearchError('');
        } else if (studentIdParam || studentUniqueIdParam) {
            setStudent(null);
            setSearchError('এই আইডি দিয়ে কোনো শিক্ষার্থীকে খুঁজে পাওয়া যায়নি।');
        } else {
            setStudent(null);
            setSearchError('');
        }
    }, [studentIdParam, studentUniqueIdParam, students]);

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        setSearchError('');
        if (!searchInput.trim()) {
            setSearchError('অনুগ্রহ করে একটি ইউনিক আইডি লিখুন।');
            return;
        }
        // Update URL to reflect search, this will trigger the useEffect
        navigate(`/app/students/profile?uniqueId=${searchInput.trim()}`);
    };

    return (
        <div>
            <PageHeader icon="👤" title="শিক্ষার্থী প্রোফাইল" />
            
            <div className="bg-white p-4 rounded-xl shadow-md mb-6 max-w-lg mx-auto">
                <form onSubmit={handleSearch} className="flex items-center gap-2">
                    <label htmlFor="studentIdSearch" className="text-sm font-semibold text-gray-700 shrink-0">শিক্ষার্থীর ইউনিক আইডি:</label>
                    <div className="relative flex-grow">
                        <input
                            id="studentIdSearch"
                            type="text"
                            value={searchInput}
                            onChange={(e) => setSearchInput(e.target.value)}
                            placeholder="ইউনিক আইডি দিয়ে খুঁজুন..."
                            className="w-full pl-4 pr-10 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                        />
                         <button type="submit" className="absolute inset-y-0 right-0 flex items-center pr-3" aria-label="Search">
                            <SearchIcon className="w-5 h-5 text-gray-400 hover:text-teal-600" />
                        </button>
                    </div>
                </form>
            </div>

            {searchError && (
                 <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-lg max-w-lg mx-auto text-center" role="alert">
                    <p>{searchError}</p>
                </div>
            )}

            {student ? (
                <StudentProfileView student={student} />
            ) : (!searchError && !studentIdParam && !studentUniqueIdParam) && (
                <div className="text-center text-gray-500 py-10">
                    <p>শিক্ষার্থীর প্রোফাইল দেখতে ইউনিক আইডি দিয়ে সার্চ করুন।</p>
                </div>
            )}
        </div>
    );
};

export default StudentProfile;
