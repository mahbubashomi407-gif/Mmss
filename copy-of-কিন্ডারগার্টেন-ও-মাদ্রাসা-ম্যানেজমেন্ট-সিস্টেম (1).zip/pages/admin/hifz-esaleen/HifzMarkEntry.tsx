
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, MarkRecordData, HifzSubjectData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';

interface MarkInput {
    studentId: string;
    studentName: string;
    roll: number | '';
    marks: Record<string, number | ''>; // { [subjectId]: marksObtained }
}

const HifzMarkEntry: React.FC = () => {
    const { students, classLevels, sections, academicSessions, exams, setExams, markRecords, setMarkRecords, hifzExamTypes, hifzSubjects } = useInstitution();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examFilter, setExamFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState('');

    const [marksData, setMarksData] = useState<MarkInput[]>([]);
    const [initialMarksData, setInitialMarksData] = useState<MarkInput[]>([]);

    useEffect(() => {
        if (academicYearFilter) {
            const genericHifzExamName = 'হিফজ পরীক্ষা';
            const hifzExam = exams.find(e => e.academicYear === academicYearFilter && e.name === genericHifzExamName);
            if (hifzExam) {
                setExamFilter(hifzExam.id);
            } else {
                const newExam = {
                    id: `exam-hifz-${academicYearFilter.replace(/[^0-9]/g, '')}-${Date.now()}`,
                    name: genericHifzExamName,
                    academicYear: academicYearFilter,
                    classLevels: classLevels.map(cl => cl.name),
                };
                setExams(prevExams => [...prevExams, newExam]);
                setExamFilter(newExam.id);
            }
        }
    }, [academicYearFilter, exams, setExams, classLevels]);

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);
    
    useEffect(() => {
        setSectionFilter('');
        setExamTypeFilter('');
    }, [classFilter]);

    useEffect(() => {
        const canRun = academicYearFilter && classFilter && sectionFilter && examFilter && examTypeFilter;
        if (canRun) {
            const existingRecordsForContext = markRecords.filter(m => 
                m.examId === examFilter && 
                m.examTypeId === examTypeFilter
            );

            const filteredStudents = students
                .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং')
                .sort((a, b) => (a.roll || 999) - (b.roll || 999));

            const newMarksData = filteredStudents.map(student => {
                const marks: Record<string, number | ''> = {};
                hifzSubjects.forEach(subject => {
                    const existingRecord = existingRecordsForContext.find(m => m.studentId === student.id && m.subjectId === subject.id);
                    marks[subject.id] = existingRecord?.marksObtained ?? '';
                });
                return { studentId: student.id, studentName: student.nameBn, roll: student.roll, marks };
            });
            setMarksData(newMarksData);
            setInitialMarksData(JSON.parse(JSON.stringify(newMarksData)));
        } else {
            setMarksData([]);
            setInitialMarksData([]);
        }
    }, [academicYearFilter, classFilter, sectionFilter, examFilter, examTypeFilter, students, markRecords, hifzSubjects]);

    const hasUnsavedChanges = JSON.stringify(marksData) !== JSON.stringify(initialMarksData);
    
    const handleMarkChange = (studentId: string, subjectId: string, value: string) => {
        const numValue: number | '' = value === '' ? '' : Number(value);
        const subject = hifzSubjects.find(s => s.id === subjectId);
        const maxMarks = subject?.totalMarks ?? 100;
    
        if (numValue !== '' && (numValue < 0 || numValue > maxMarks)) {
            addToast(`"${subject?.name}" বিষয়ের প্রাপ্ত নম্বর পূর্ণমান (${maxMarks}) চেয়ে বেশি হতে পারে না।`, 'error');
        } else {
            setMarksData(prev => prev.map(m => m.studentId === studentId ? { ...m, marks: { ...m.marks, [subjectId]: numValue } } : m));
        }
    };
    
    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>, studentIndex: number, subjectIndex: number) => {
        let nextStudentIndex = studentIndex, nextSubjectIndex = subjectIndex;
        switch (e.key) {
            case 'ArrowDown': case 'Enter': e.preventDefault(); nextStudentIndex = studentIndex + 1; break;
            case 'ArrowUp': e.preventDefault(); nextStudentIndex = studentIndex - 1; break;
            case 'ArrowRight': e.preventDefault(); nextSubjectIndex = subjectIndex + 1; break;
            case 'ArrowLeft': e.preventDefault(); nextSubjectIndex = subjectIndex - 1; break;
            default: return;
        }
        if (nextStudentIndex >= 0 && nextStudentIndex < marksData.length && nextSubjectIndex >= 0 && nextSubjectIndex < hifzSubjects.length) {
            document.getElementById(`mark-input-${nextStudentIndex}-${nextSubjectIndex}`)?.focus();
        }
    };

    const handleSaveChanges = () => {
        for (const studentData of marksData) {
            for (const subject of hifzSubjects) {
                const marks = studentData.marks[subject.id];
                const maxMarks = subject.totalMarks;
                if (marks !== '' && (Number(marks) > maxMarks || Number(marks) < 0)) {
                    addToast(`শিক্ষার্থী "${studentData.studentName}"-এর "${subject.name}" বিষয়ের নম্বর (${marks}) সঠিক নয়।`, 'error');
                    return;
                }
            }
        }

        const studentIdsInView = new Set(marksData.map(md => md.studentId));
        const otherRecords = markRecords.filter(rec => {
            const isThisRecordContext = rec.examId === examFilter && rec.examTypeId === examTypeFilter && studentIdsInView.has(rec.studentId);
            return !isThisRecordContext;
        });
        
        const newRecords: MarkRecordData[] = [];
        marksData.forEach(studentData => {
            hifzSubjects.forEach(subject => {
                const subjectId = subject.id;
                const marks = studentData.marks[subjectId];
                if (marks !== '' && marks !== undefined) {
                    const record: MarkRecordData = {
                        id: `${studentData.studentId}-${examFilter}-${subjectId}-${examTypeFilter}`,
                        studentId: studentData.studentId,
                        examId: examFilter,
                        subjectId,
                        examTypeId: examTypeFilter,
                        marksObtained: Number(marks),
                        totalMarks: subject.totalMarks,
                    };
                    newRecords.push(record);
                }
            });
        });
        setMarkRecords([...otherRecords, ...newRecords]);
        setInitialMarksData(JSON.parse(JSON.stringify(marksData)));
        addToast('ফলাফল সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };

    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examFilter && examTypeFilter;

    return (
        <div>
            <PageHeader icon="🔢" title="হিফজ নম্বর এন্ট্রি" />
            
            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষার ধরণ</option>{hifzExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamTypeFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5"/></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {allFiltersSelected ? (
                    marksData.length > 0 ? (
                        <div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm">
                                    <thead className="text-xs text-gray-700 uppercase bg-gray-100">
                                        <tr>
                                            <th className="p-3 text-center">রোল</th>
                                            <th className="p-3 text-left min-w-40">শিক্ষার্থীর নাম</th>
                                            {hifzSubjects.map(subject => (
                                                <th key={subject.id} className="p-3 w-40 text-center">{subject.name} ({subject.totalMarks})</th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {marksData.map((s, studentIndex) => (
                                            <tr key={s.studentId} className="border-b hover:bg-gray-50/50 transition-colors">
                                                <td className="px-4 py-3 text-center font-mono">{s.roll}</td>
                                                <td className="px-4 py-3 font-medium">{s.studentName}</td>
                                                {hifzSubjects.map((subject, subjectIndex) => (
                                                    <td key={subject.id} className="p-1 w-40">
                                                        <input
                                                            id={`mark-input-${studentIndex}-${subjectIndex}`}
                                                            type="number"
                                                            value={s.marks[subject.id] ?? ''}
                                                            onChange={e => handleMarkChange(s.studentId, subject.id, e.target.value)}
                                                            onKeyDown={e => handleKeyDown(e, studentIndex, subjectIndex)}
                                                            className="w-full h-full text-center text-base p-2 border-0 rounded-md bg-transparent focus:bg-teal-50 focus:ring-2 focus:ring-teal-500 focus:outline-none transition-all duration-200"
                                                            placeholder="N/A"
                                                        />
                                                    </td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                             <div className="mt-6 flex justify-end">
                                <button onClick={handleSaveChanges} disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">
                                    ফলাফল সংরক্ষণ করুন
                                </button>
                            </div>
                        </div>
                    ) : ( <p className="text-center text-gray-500 py-10">এই সেকশনে কোনো শিক্ষার্থী পাওয়া যায়নি।</p> )
                ) : ( <p className="text-center text-gray-500 py-10">ফলাফল এন্ট্রি করতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p> )}
            </div>
        </div>
    );
};

export default HifzMarkEntry;
