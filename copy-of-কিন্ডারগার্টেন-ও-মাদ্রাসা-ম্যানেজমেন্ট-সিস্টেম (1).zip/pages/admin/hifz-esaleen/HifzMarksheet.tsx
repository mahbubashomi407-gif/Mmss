
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, HifzGradeData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon } from '../../../components/icons';
import { useNotification } from '../../../context/NotificationContext';

// Helper to convert numbers to Bengali script
const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯', '.': '.' };
    return num.replace(/[0-9.]/g, (match) => map[match] || match);
};

// Interface for structured report data
interface HifzReportData {
    student: StudentData & {
        marksBySubject: Record<string, number | null>;
        totalObtained: number;
        grade: string;
        rank: number | '-';
        resultStatus: 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত';
    };
    examName: string;
}

// Sub-component for a single marksheet
const HifzCardView: React.FC<{ reportData: HifzReportData }> = ({ reportData }) => {
    const { student, examName } = reportData;
    const { institutionName, logoUrl, address, hifzSubjects, hifzGrades, managerInfo } = useInstitution();

    const sortedGrades = [...hifzGrades].sort((a, b) => b.minTotalMarks - a.minTotalMarks);

    return (
        <div className="marksheet-container bg-white p-2 font-['SolaimanLipi'] text-[11px] border border-black flex flex-col h-full w-full relative" style={{ boxSizing: 'border-box' }}>
            {logoUrl && <img src={logoUrl} alt="watermark" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 opacity-10" />}

            <header className="relative z-10 flex items-start justify-between p-1">
                <div className="flex-shrink-0 w-[45px]">
                    {logoUrl && <img src={logoUrl} alt="Logo" className="h-[45px] w-[45px] object-cover" />}
                </div>
                <div className="flex-grow text-center">
                    <h1 className="text-[13px] font-bold m-0">{institutionName}</h1>
                    <p className="text-[9px] m-0 text-gray-600">{`${address.upazila}, ${address.district}`}</p>
                    <p className="text-[10px] font-bold mb-0.5">শিক্ষাবর্ষ: {toBengaliNumber(student.academicYear)}</p>
                    <h2 className="text-[15px] font-bold inline-block border border-black px-2 py-0.5 m-0">মার্কশীট - {examName}</h2>
                </div>
                <div className="flex-shrink-0 w-[130px] border border-black text-[9px]">
                    <h3 className="font-bold text-center bg-gray-100 border-b border-black p-0.5">গ্রেডিং টেবিল</h3>
                    <ul className="list-none p-1 m-0">
                        {sortedGrades.map(g => (
                            <li key={g.id} className="flex justify-between p-[1px]">
                                <span>{g.name}</span>
                                <span>{toBengaliNumber(g.minHifzMarks)}-{toBengaliNumber(g.minTotalMarks)}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </header>

            <section className="mt-1 grid grid-cols-2 gap-x-4 gap-y-0.5 text-sm z-10">
                <p><strong>নাম:</strong> {student.nameBn}</p>
                <p><strong>শ্রেণি:</strong> {student.classLevel} ({student.section})</p>
                <p><strong>পিতার নাম:</strong> {student.fatherNameBn}</p>
                <p><strong>রোল:</strong> {toBengaliNumber(student.roll || '')}</p>
                <p><strong>আইডি:</strong> {toBengaliNumber(student.uniqueId)}</p>
            </section>

            <section className="mt-0.5 flex-grow z-10">
                <table className="w-full border-collapse border border-black text-xs">
                    <thead>
                        <tr className="bg-gray-100 font-bold">
                            <td className="border border-black py-1 px-1">বিষয়</td>
                            <td className="border border-black py-1 px-1 text-center">পূর্ণমান</td>
                            <td className="border border-black py-1 px-1 text-center">পাশ নম্বর</td>
                            <td className="border border-black py-1 px-1 text-center">প্রাপ্ত নম্বর</td>
                        </tr>
                    </thead>
                    <tbody>
                        {hifzSubjects.map(subject => (
                            <tr key={subject.id}>
                                <td className="border border-black py-1 px-1">{subject.name}</td>
                                <td className="border border-black py-1 px-1 text-center">{toBengaliNumber(subject.totalMarks)}</td>
                                <td className="border border-black py-1 px-1 text-center">{toBengaliNumber(subject.passMarks)}</td>
                                <td className="border border-black py-1 px-1 text-center font-semibold">{toBengaliNumber(student.marksBySubject[subject.id])}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </section>
            
            <footer className="mt-1 pt-1 text-sm flex-shrink-0 z-10">
                <div className="grid grid-cols-3 gap-2 border-t border-black pt-1">
                    <p><strong>মোট নাম্বার:</strong> {toBengaliNumber(student.totalObtained)}</p>
                    <p><strong>বিভাগ:</strong> {student.grade}</p>
                    <p><strong>মেধা স্থান:</strong> {toBengaliNumber(student.rank)}</p>
                </div>
                 <div className="flex justify-between items-end mt-3">
                    <div className="text-center w-40"><p className="border-t border-dotted border-black pt-1 text-[10px]">অভিভাবকের স্বাক্ষর</p></div>
                    <div className="text-center w-40"><p className="border-t border-dotted border-black pt-1 text-[10px]">শিক্ষাসচিবের স্বাক্ষর</p></div>
                    <div className="text-center w-40">
                         {managerInfo.signatureUrl ? (
                            <img src={managerInfo.signatureUrl} alt="Signature" className="h-6 mx-auto object-contain" />
                        ) : <div className="h-6"></div> }
                        <p className="border-t border-dotted border-black pt-1 text-[10px]">প্রিন্সিপালের স্বাক্ষর</p>
                    </div>
                </div>
            </footer>
        </div>
    );
};


const HifzMarksheet: React.FC = () => {
    const { 
        students, classLevels, sections, academicSessions, exams, markRecords, hifzExamTypes, 
        hifzSubjects, hifzGrades, hifzResultSettings
    } = useInstitution();
    const { addToast } = useNotification();
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState('');
    const [studentsToPrint, setStudentsToPrint] = useState<HifzReportData[]>([]);
    
    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    useEffect(() => { setSectionFilter(''); setExamTypeFilter(''); }, [classFilter]);

    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examTypeFilter;

    const generateAllReportData = (): HifzReportData[] => {
        if (!allFiltersSelected) return [];

        const hifzExam = exams.find(e => e.academicYear === academicYearFilter && e.name === 'হিফজ পরীক্ষা');
        if (!hifzExam) return [];

        const filteredStudents = students.filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');
        const sortedGrades = [...hifzGrades].sort((a, b) => b.minTotalMarks - a.minTotalMarks);
        const mainHifzSubject = hifzSubjects.find(s => s.name.includes('হিফয'));

        const results = filteredStudents.map(student => {
            const studentRecords = markRecords.filter(m => m.studentId === student.id && m.examId === hifzExam.id && m.examTypeId === examTypeFilter);
            const marksBySubject: Record<string, number | null> = {};
            let totalObtained = 0, marksGivenCount = 0;
            
            hifzSubjects.forEach(subject => {
                const record = studentRecords.find(m => m.subjectId === subject.id);
                const obtained = record ? record.marksObtained : null;
                marksBySubject[subject.id] = obtained;
                if (obtained !== null) { totalObtained += obtained; marksGivenCount++; }
            });

            let grade = 'রাসিব (অকৃতকার্য)';
            let resultStatus: 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত' = 'অকৃতকার্য';

            if (hifzResultSettings.enableAbsentStatus && marksGivenCount === 0) {
                resultStatus = 'অনুপস্থিত';
                grade = 'অনুপস্থিত';
            } else if (hifzResultSettings.enableSuspendedStatus && marksGivenCount > 0 && marksGivenCount < hifzSubjects.length) {
                resultStatus = 'স্থগিত';
                grade = 'স্থগিত';
            } else {
                const mainHifzMark = mainHifzSubject ? marksBySubject[mainHifzSubject.id] : null;
                let isPassedAllSubjects = hifzSubjects.every(subject => {
                    const mark = marksBySubject[subject.id];
                    return mark !== null && mark >= subject.passMarks;
                });
                
                if (isPassedAllSubjects && mainHifzMark !== null) {
                    for (const gradeDef of sortedGrades) {
                        if (gradeDef.name.includes('রাসিব')) continue;
                        if (mainHifzMark >= gradeDef.minHifzMarks && totalObtained >= gradeDef.minTotalMarks) {
                            grade = gradeDef.name;
                            break;
                        }
                    }
                }
                 resultStatus = grade.includes('রাসিব') || grade.includes('অনুপস্থিত') || grade.includes('স্থগিত') ? 'অকৃতকার্য' : 'কৃতকার্য';
            }
            return { ...student, marksBySubject, totalObtained, grade, rank: '-', resultStatus };
        });

        const sortedByMarks = results.sort((a,b) => {
             const statusOrder = { 'কৃতকার্য': 1, 'অকৃতকার্য': 2, 'স্থগিত': 3, 'অনুপস্থিত': 4 };
             if ((statusOrder[a.resultStatus] || 5) !== (statusOrder[b.resultStatus] || 5)) return (statusOrder[a.resultStatus] || 5) - (statusOrder[b.resultStatus] || 5);
             if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
             return (a.roll || 999) - (b.roll || 999);
        });

        let rank = 0, lastScore = -1;
        const rankedResults = sortedByMarks.map((s, index) => {
            const gradeDef = hifzGrades.find(g => g.name === s.grade);
            if (s.resultStatus === 'কৃতকার্য' && (gradeDef?.isRankable ?? false)) {
                if (s.totalObtained !== lastScore) { rank = index + 1; lastScore = s.totalObtained; }
                return { ...s, rank };
            }
            return s;
        });
        
        const examName = hifzExamTypes.find(e => e.id === examTypeFilter)?.name || '';
        return rankedResults.map(res => ({ student: res, examName }));
    };

    const handlePrint = () => {
        const data = generateAllReportData();
        if (data.length === 0) {
            addToast('প্রিন্ট করার জন্য কোনো তথ্য নেই।', 'error');
            return;
        }
        setStudentsToPrint(data);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-area');
            if (printContent) {
                const printWindow = window.open('', '', 'height=800,width=1200');
                if (printWindow) {
                    printWindow.document.write('<html><head><title>Hifz Marksheets</title>');
                    printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                    printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                    printWindow.document.write(`<style>
                        body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                        @page { size: A4 landscape; margin: 0.6cm; }
                        .print-page { page-break-after: always; display: flex; flex-direction: row; gap: 1.2cm; width: 100%; height: 100%; align-items: flex-start; }
                        .marksheet-container { flex: 1; box-sizing: border-box; overflow: hidden; }
                    </style>`);
                    printWindow.document.write('</head><body>');
                    printWindow.document.write(printContent.innerHTML);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 750);
                }
            }
        }, 500);
    };

    return (
        <div>
            <PageHeader icon="📑" title="হিফজ মার্কশীট" />

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400"/></span><select value={academicYearFilter} onChange={e=>setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none"><option disabled value="">বর্ষ</option>{academicSessions.map(s=><option key={s.id}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500"/></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400"/></span><select value={classFilter} onChange={e=>setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl=><option key={cl.id}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500"/></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400"/></span><select value={sectionFilter} onChange={e=>setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s=><option key={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500"/></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400"/></span><select value={examTypeFilter} onChange={e=>setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border rounded-lg bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষার ধরণ</option>{hifzExamTypes.map(et=><option key={et.id} value={et.id}>{et.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500"/></span></div>
                    <button onClick={()=>{setClassFilter('');setSectionFilter('');setExamTypeFilter('');}} className="p-2.5 bg-gray-200 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5"/></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {allFiltersSelected ? (
                    <div className="text-center">
                        <h3 className="text-xl font-bold text-green-600">মার্কশীট তৈরী হয়েছে।</h3>
                        <p className="text-gray-600 my-4">প্রিন্ট করতে নিচের বাটনে ক্লিক করুন।</p>
                        <button onClick={handlePrint} className="px-6 py-3 bg-teal-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-teal-700">সকল মার্কশীট প্রিন্ট করুন</button>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">মার্কশীট তৈরি করতে অনুগ্রহ করে উপরের সকল ফিল্টার পূরণ করুন।</p>
                )}
            </div>

            <div id="printable-area" className="hidden">
                {Array.from({ length: Math.ceil(studentsToPrint.length / 2) }, (_, i) => studentsToPrint.slice(i * 2, i * 2 + 2))
                    .map((pair, pageIndex) => (
                        <div key={pageIndex} className="print-page">
                            {pair[0] && <HifzCardView key={pair[0].student.id} reportData={pair[0]} />}
                            {pair[1] ? <HifzCardView key={pair[1].student.id} reportData={pair[1]} /> : <div className="marksheet-container"></div>}
                        </div>
                    ))
                }
            </div>
        </div>
    );
};

export default HifzMarksheet;
