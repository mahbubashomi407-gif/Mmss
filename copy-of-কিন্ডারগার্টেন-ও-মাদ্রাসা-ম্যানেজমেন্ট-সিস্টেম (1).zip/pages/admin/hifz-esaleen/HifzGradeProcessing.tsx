
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, HifzGradeData, HifzResultSettings } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import HifzGradeModal from '../../../components/HifzGradeModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';
import ToggleSwitch from '../../../components/ToggleSwitch';

const HifzGradeProcessing: React.FC = () => {
    const { hifzGrades, setHifzGrades, hifzResultSettings, setHifzResultSettings } = useInstitution();
    const { addToast } = useNotification();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedGrade, setSelectedGrade] = useState<HifzGradeData | null>(null);

    const sortedGrades = useMemo(() => 
        [...hifzGrades].sort((a, b) => b.minTotalMarks - a.minTotalMarks), 
    [hifzGrades]);

    const handleAddNew = () => {
        setSelectedGrade(null);
        setIsModalOpen(true);
    };

    const handleEdit = (grade: HifzGradeData) => {
        setSelectedGrade(grade);
        setIsModalOpen(true);
    };

    const handleDelete = (grade: HifzGradeData) => {
        setSelectedGrade(grade);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedGrade) {
            setHifzGrades(hifzGrades.filter(g => g.id !== selectedGrade.id));
            addToast('গ্রেড সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedGrade(null);
    };

    const handleSave = (data: Omit<HifzGradeData, 'id'> & { id?: string }) => {
        if (data.id) {
            setHifzGrades(hifzGrades.map(g => g.id === data.id ? { ...g, ...data } as HifzGradeData : g));
            addToast('গ্রেড সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else {
            const newGrade: HifzGradeData = { ...data, id: `hgrade-${Date.now()}` };
            setHifzGrades([...hifzGrades, newGrade]);
            addToast('নতুন গ্রেড যোগ করা হয়েছে!', 'success');
        }
        setIsModalOpen(false);
    };

    const handleSettingsChange = (key: keyof HifzResultSettings, value: boolean) => {
        const newSettings = { ...hifzResultSettings, [key]: value };
        setHifzResultSettings(newSettings);
        addToast('সেটিংস আপডেট করা হয়েছে!', 'success');
    };

    return (
        <div>
            <PageHeader icon="⚙️" title="হিফজ গ্রেড সিস্টেম সেটআপ">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700"
                >
                    নতুন গ্রেড যোগ করুন
                </button>
            </PageHeader>

            <div className="bg-white p-6 rounded-xl shadow-md mb-6">
                <h3 className="text-lg font-bold text-gray-800 border-b pb-3 mb-4">ফলাফল প্রক্রিয়াকরণ নিয়মাবলী</h3>
                <div className="space-y-4">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h4 className="font-semibold">"অনুপস্থিত" স্ট্যাটাস</h4>
                            <p className="text-sm text-gray-600">শিক্ষার্থী কোনো বিষয়েই পরীক্ষা না দিলে তার ফলাফল "অনুপস্থিত" দেখানো হবে।</p>
                        </div>
                        <ToggleSwitch 
                            enabled={hifzResultSettings.enableAbsentStatus}
                            onChange={(value) => handleSettingsChange('enableAbsentStatus', value)}
                        />
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                        <div>
                            <h4 className="font-semibold">"স্থগিত" স্ট্যাটাস</h4>
                            <p className="text-sm text-gray-600">শিক্ষার্থী কিছু বিষয়ে অনুপস্থিত থাকলে তার ফলাফল "স্থগিত" দেখানো হবে।</p>
                        </div>
                        <ToggleSwitch 
                            enabled={hifzResultSettings.enableSuspendedStatus}
                            onChange={(value) => handleSettingsChange('enableSuspendedStatus', value)}
                        />
                    </div>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">বিভাগের নাম</th>
                                <th scope="col" className="px-6 py-3">হিফয (ইয়াদ) বিষয়ে সর্বনিম্ন নম্বর</th>
                                <th scope="col" className="px-6 py-3">সর্বমোট সর্বনিম্ন নম্বর</th>
                                <th scope="col" className="px-6 py-3 text-center">মেধা বিভাগ</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedGrades.length > 0 ? sortedGrades.map(grade => {
                                const isRasib = grade.name.includes('রাসিব');
                                return (
                                    <tr key={grade.id} className="bg-white border-b hover:bg-gray-50">
                                        <td className="px-6 py-4 font-medium text-gray-900">{grade.name}</td>
                                        <td className="px-6 py-4">{isRasib ? <span className="text-gray-500 italic">অন্যান্য শর্ত পূরণ না হলে</span> : grade.minHifzMarks}</td>
                                        <td className="px-6 py-4">{isRasib ? '-' : grade.minTotalMarks}</td>
                                        <td className="px-6 py-4 text-center">
                                            {grade.isRankable ? 
                                                <span className="text-green-500 font-bold text-lg" title="মেধা বিভাগে অন্তর্ভুক্ত">✓</span> : 
                                                <span className="text-red-500 font-bold text-lg" title="মেধা বিভাগে অন্তর্ভুক্ত নয়">✗</span>
                                            }
                                        </td>
                                        <td className="px-6 py-4 text-right space-x-2">
                                            <button onClick={() => handleEdit(grade)} disabled={isRasib} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full disabled:opacity-50 disabled:cursor-not-allowed" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                            <button onClick={() => handleDelete(grade)} disabled={isRasib} className="p-2 text-red-600 hover:bg-red-100 rounded-full disabled:opacity-50 disabled:cursor-not-allowed" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                        </td>
                                    </tr>
                                );
                            }) : (
                                <tr>
                                    <td colSpan={5} className="text-center py-10 text-gray-500">
                                        <p>কোনো গ্রেড যোগ করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <HifzGradeModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                gradeToEdit={selectedGrade}
            />

            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="গ্রেড মুছুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই গ্রেডটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default HifzGradeProcessing;
