
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, StudentData, HifzGradeData } from '../../../context/InstitutionContext';
import { GraduationCapIcon, StudentsIcon, RefreshIcon, ChevronDownIcon, CalendarIcon, DownloadIcon } from '../../../components/icons';
import { useNotification } from '../../../context/NotificationContext';

// Helper to convert numbers to Bengali script
const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯', '.': '.' };
    return num.replace(/[0-9.]/g, (match) => map[match] || match);
};

// Result data interface
interface HifzResultData extends StudentData {
    marksBySubject: Record<string, number | null>;
    totalObtained: number;
    grade: string;
    rank: number | '-';
    resultStatus: 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত';
}

const HifzResultSheet: React.FC = () => {
    const { 
        students, classLevels, sections, academicSessions, exams, markRecords, hifzExamTypes, 
        hifzSubjects, hifzGrades, hifzResultSettings, institutionName, logoUrl, address, managerInfo 
    } = useInstitution();
    const { addToast } = useNotification();

    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    // Filters
    const [academicYearFilter, setAcademicYearFilter] = useState(activeSession?.name || '');
    const [classFilter, setClassFilter] = useState('');
    const [sectionFilter, setSectionFilter] = useState('');
    const [examTypeFilter, setExamTypeFilter] = useState('');
    
    // State for printable data
    const [studentsToPrint, setStudentsToPrint] = useState<HifzResultData[]>([]);

    const availableSections = useMemo(() => classFilter ? sections.filter(s => s.classLevel === classFilter).map(s => s.name) : [], [classFilter, sections]);

    useEffect(() => {
        setSectionFilter('');
        setExamTypeFilter('');
    }, [classFilter]);

    const allFiltersSelected = academicYearFilter && classFilter && sectionFilter && examTypeFilter;

    // --- Result Calculation Logic ---
    const generateReportData = (): HifzResultData[] => {
        if (!allFiltersSelected) return [];

        const hifzExam = exams.find(e => e.academicYear === academicYearFilter && e.name === 'হিফজ পরীক্ষা');
        if (!hifzExam) return [];

        const filteredStudents = students
            .filter(s => s.academicYear === academicYearFilter && s.classLevel === classFilter && s.section === sectionFilter && s.status !== 'পেন্ডিং');
            
        const sortedGrades = [...hifzGrades].sort((a, b) => b.minTotalMarks - a.minTotalMarks);
        const mainHifzSubject = hifzSubjects.find(s => s.name.includes('হিফয'));

        const results = filteredStudents.map(student => {
            const studentRecords = markRecords.filter(m => m.studentId === student.id && m.examId === hifzExam.id && m.examTypeId === examTypeFilter);
            
            const marksBySubject: Record<string, number | null> = {};
            let totalObtained = 0;
            let marksGivenCount = 0;
            
            hifzSubjects.forEach(subject => {
                const record = studentRecords.find(m => m.subjectId === subject.id);
                const obtained = record ? record.marksObtained : null;
                marksBySubject[subject.id] = obtained;
                if (obtained !== null) {
                    totalObtained += obtained;
                    marksGivenCount++;
                }
            });

            let grade = 'রাসিব (অকৃতকার্য)';
            let resultStatus: HifzResultData['resultStatus'] = 'অকৃতকার্য';

            if (hifzResultSettings.enableAbsentStatus && marksGivenCount === 0) {
                resultStatus = 'অনুপস্থিত';
                grade = 'অনুপস্থিত';
            } else if (hifzResultSettings.enableSuspendedStatus && marksGivenCount > 0 && marksGivenCount < hifzSubjects.length) {
                resultStatus = 'স্থগিত';
                grade = 'স্থগিত';
            } else {
                const mainHifzMark = mainHifzSubject ? marksBySubject[mainHifzSubject.id] : null;
                let isPassedAllSubjects = true;
                for (const subject of hifzSubjects) {
                    const mark = marksBySubject[subject.id];
                    if (mark === null || mark < subject.passMarks) {
                        isPassedAllSubjects = false;
                        break;
                    }
                }
                
                if (isPassedAllSubjects && mainHifzMark !== null) {
                    for (const gradeDef of sortedGrades) {
                        if (gradeDef.name.includes('রাসিব')) continue;
                        if (mainHifzMark >= gradeDef.minHifzMarks && totalObtained >= gradeDef.minTotalMarks) {
                            grade = gradeDef.name;
                            break;
                        }
                    }
                }
                 resultStatus = grade.includes('রাসিব') || grade.includes('অনুপস্থিত') || grade.includes('স্থগিত') ? 'অকৃতকার্য' : 'কৃতকার্য';
            }

            return { ...student, marksBySubject, totalObtained, grade, rank: '-', resultStatus };
        });

        const sortedByMarks = results.sort((a,b) => {
             const statusOrder = { 'কৃতকার্য': 1, 'অকৃতকার্য': 2, 'স্থগিত': 3, 'অনুপস্থিত': 4 };
             const statusA = statusOrder[a.resultStatus] || 5;
             const statusB = statusOrder[b.resultStatus] || 5;
             if (statusA !== statusB) return statusA - statusB;
             if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
             return (a.roll || 999) - (b.roll || 999);
        });

        let rank = 0;
        let lastScore = -1;
        const rankedResults = sortedByMarks.map((s, index) => {
            const gradeDef = hifzGrades.find(g => g.name === s.grade);
            if (s.resultStatus === 'কৃতকার্য' && (gradeDef?.isRankable ?? false)) {
                if (s.totalObtained !== lastScore) {
                    rank = index + 1;
                    lastScore = s.totalObtained;
                }
                return { ...s, rank };
            }
            return s;
        });

        return rankedResults.sort((a, b) => (a.roll || 999) - (b.roll || 999)) as HifzResultData[];
    };

    // --- Print Handler ---
    const handlePrint = () => {
        const data = generateReportData();
        if (data.length === 0) {
            addToast('প্রিন্ট করার জন্য কোনো তথ্য নেই।', 'error');
            return;
        }
        setStudentsToPrint(data);
        
        setTimeout(() => {
            const printContent = document.getElementById('printable-area');
            if (printContent) {
                const examTypeName = hifzExamTypes.find(e => e.id === examTypeFilter)?.name || '';
                const reportTitle = `হিফজ পরীক্ষার ফলাফল - ${examTypeName}`;
                const subTitle = `শ্রেণি: ${classFilter} | শাখা: ${sectionFilter} | শিক্ষাবর্ষ: ${toBengaliNumber(academicYearFilter)}`;

                const gradingTableHtml = `
                    <table class="grading-table">
                        <thead>
                            <tr><th colspan="3" class="text-center">গ্রেডিং টেবিল</th></tr>
                            <tr><th>বিভাগ</th><th>কুরআন</th><th>সর্বমোট</th></tr>
                        </thead>
                        <tbody>
                            ${[...hifzGrades].sort((a,b)=> b.minTotalMarks - a.minTotalMarks).map(grade => `
                                <tr>
                                    <td>${grade.name}</td>
                                    <td class="text-center">${grade.name.includes('রাসিব') ? '-' : toBengaliNumber(grade.minHifzMarks)}</td>
                                    <td class="text-center">${grade.name.includes('রাসিব') ? '-' : toBengaliNumber(grade.minTotalMarks)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                `;

                const printWindow = window.open('', '', 'height=800,width=1200');
                if (printWindow) {
                    printWindow.document.write('<html><head>');
                    printWindow.document.write(`<title>${reportTitle}</title>`);
                    printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                    printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                    printWindow.document.write(`
                        <style>
                            body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                            @page { size: A4 portrait; margin: 0.6cm; }
                            .print-page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; border-bottom: 2px solid #333; padding-bottom: 0.5rem;}
                            .logo-container { flex: 0 0 80px; }
                            .logo-container img { width: 80px; height: 80px; object-fit: cover; }
                            .institution-info { flex-grow: 1; text-align: center; }
                            .grading-table-container { flex: 0 0 220px; font-size: 9px; }
                            .grading-table { width: 100%; border-collapse: collapse; }
                            .grading-table th, .grading-table td { border: 1px solid #ddd; padding: 2px; }
                            .grading-table th { background-color: #f2f2f2 !important; font-weight: bold; }
                            table { width: 100%; border-collapse: collapse; font-size: 14px; }
                            th, td { border: 1px solid #ddd; padding: 4px; text-align: center; }
                            td.text-left { text-align: left; }
                            th { background-color: #f2f2f2 !important; font-weight: bold; }
                            .footer-signatures { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 25px; page-break-inside: avoid; }
                            .footer-signatures div { width: 180px; text-align: center; border-top: 1px dotted black; padding-top: 5px; font-size: 12px; }
                            .footer-signatures div:nth-child(2) { border-top: none; font-size: 11px; }
                        </style>
                    `);
                    printWindow.document.write('</head><body>');
                    printWindow.document.write(`
                    <div class="print-page-header">
                        <div class="logo-container">
                            ${logoUrl ? `<img src="${logoUrl}" alt="লোগো" />` : ''}
                        </div>
                        <div class="institution-info">
                            <h1 style="font-size: 1.8rem; font-weight: bold;">${institutionName}</h1>
                            <p style="margin: 0.1rem 0;">${address.village}, ${address.upazila}, ${address.district}</p>
                            <h2 style="font-size: 1.3rem; margin-top: 0.5rem;">${reportTitle}</h2>
                            <p style="font-size: 1.1rem;">${subTitle}</p>
                        </div>
                        <div class="grading-table-container">
                            ${gradingTableHtml}
                        </div>
                    </div>
                `);
                    printWindow.document.write(printContent.innerHTML);
                    printWindow.document.write('</body></html>');
                    printWindow.document.close();
                    setTimeout(() => {
                        printWindow.focus();
                        printWindow.print();
                        printWindow.close();
                    }, 750);
                }
            }
        }, 500);
    };
    
    // --- PDF Download Handler ---
    const handlePdfDownload = () => {
        const data = generateReportData();
        if (data.length === 0) {
            addToast('ডাউনলোড করার জন্য কোনো তথ্য নেই।', 'error');
            return;
        }
        setStudentsToPrint(data);

        setTimeout(() => {
            const printContentElement = document.getElementById('printable-area');
            if (printContentElement) {
                const examTypeName = hifzExamTypes.find(e => e.id === examTypeFilter)?.name || '';
                const reportTitle = `হিফজ পরীক্ষার ফলাফল - ${examTypeName}`;
                const subTitle = `শ্রেণি: ${classFilter} | শাখা: ${sectionFilter} | শিক্ষাবর্ষ: ${toBengaliNumber(academicYearFilter)}`;
                const filename = `Hifz-Result-Sheet-${classFilter}-${sectionFilter}.pdf`;
                
                 const gradingTableHtml = `
                    <table class="grading-table">
                        <thead>
                            <tr><th colspan="3" class="text-center">গ্রেডিং টেবিল</th></tr>
                            <tr><th>বিভাগ</th><th>কুরআন</th><th>সর্বমোট</th></tr>
                        </thead>
                        <tbody>
                            ${[...hifzGrades].sort((a,b)=> b.minTotalMarks - a.minTotalMarks).map(grade => `
                                <tr>
                                    <td>${grade.name}</td>
                                    <td class="text-center">${grade.name.includes('রাসিব') ? '-' : toBengaliNumber(grade.minHifzMarks)}</td>
                                    <td class="text-center">${grade.name.includes('রাসিব') ? '-' : toBengaliNumber(grade.minTotalMarks)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                `;

                const elementToPrint = document.createElement('div');
                elementToPrint.style.fontFamily = "'SolaimanLipi', sans-serif";
                elementToPrint.innerHTML = `
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1rem; border-bottom: 2px solid #333; padding-bottom: 0.5rem; font-family: 'SolaimanLipi', sans-serif;">
                        <div style="flex: 0 0 80px;">
                            ${logoUrl ? `<img src="${logoUrl}" alt="লোগো" style="width: 80px; height: 80px; object-fit: cover;" />` : ''}
                        </div>
                        <div style="flex-grow: 1; text-align: center;">
                            <h1 style="font-size: 1.8rem; font-weight: bold;">${institutionName}</h1>
                            <p style="margin: 0.1rem 0;">${address.village}, ${address.upazila}, ${address.district}</p>
                            <h2 style="font-size: 1.3rem; margin-top: 0.5rem;">${reportTitle}</h2>
                            <p style="font-size: 1.1rem;">${subTitle}</p>
                        </div>
                        <div style="flex: 0 0 220px; font-size: 9px;">
                            ${gradingTableHtml}
                        </div>
                    </div>
                    <style>
                        .grading-table { width: 100%; border-collapse: collapse; }
                        .grading-table th, .grading-table td { border: 1px solid #ddd; padding: 2px; }
                        .grading-table th { background-color: #f2f2f2 !important; font-weight: bold; }
                        table { width: 100%; border-collapse: collapse; font-size: 14px; }
                        th, td { border: 1px solid #ddd; padding: 4px; text-align: center; }
                        td.text-left { text-align: left; }
                        th { background-color: #f2f2f2 !important; font-weight: bold; }
                        .footer-signatures { display: flex; justify-content: space-between; align-items: flex-end; margin-top: 25px; page-break-inside: avoid; }
                        .footer-signatures div { width: 180px; text-align: center; border-top: 1px dotted black; padding-top: 5px; font-size: 12px; }
                        .footer-signatures div:nth-child(2) { border-top: none; font-size: 11px; }
                    </style>
                    ${printContentElement.innerHTML}
                `;

                const opt = {
                    margin: 0.6,
                    filename: filename,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { scale: 2, useCORS: true },
                    jsPDF: { unit: 'cm', format: 'a4', orientation: 'portrait' }
                };

                (window as any).html2pdf().from(elementToPrint).set(opt).save();
            }
        }, 500);
    };

    return (
        <div>
            <PageHeader icon="📊" title="হিফজ রেজাল্ট শিট" />

            <div className="bg-white p-3 rounded-xl shadow-md mb-6">
                <div className="flex flex-wrap items-center gap-3">
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span><select value={academicYearFilter} onChange={e => setAcademicYearFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="" disabled>বর্ষ</option>{academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={classFilter} onChange={e => setClassFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"><option value="">শ্রেণি</option>{classLevels.map(cl => <option key={cl.id} value={cl.name}>{cl.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><StudentsIcon className="w-5 h-5 text-gray-400" /></span><select value={sectionFilter} onChange={e => setSectionFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">সেকশন</option>{availableSections.map(s => <option key={s} value={s}>{s}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <div className="relative flex-grow-0"><span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><GraduationCapIcon className="w-5 h-5 text-gray-400" /></span><select value={examTypeFilter} onChange={e => setExamTypeFilter(e.target.value)} className="w-full pl-10 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none" disabled={!classFilter}><option value="">পরীক্ষার ধরণ</option>{hifzExamTypes.map(et => <option key={et.id} value={et.id}>{et.name}</option>)}</select><span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none"><ChevronDownIcon className="w-4 h-4 text-gray-500" /></span></div>
                    <button onClick={() => { setClassFilter(''); setSectionFilter(''); setExamTypeFilter(''); }} className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"><RefreshIcon className="w-5 h-5"/></button>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                {allFiltersSelected ? (
                     <div className="text-center">
                        <h3 className="text-xl font-bold text-green-600">রেজাল্ট শিট তৈরী হয়েছে।</h3>
                        <p className="text-gray-600 my-4">প্রিন্ট বা ডাউনলোড করতে নিচের বাটনে ক্লিক করুন।</p>
                        <div className="flex flex-wrap justify-center gap-4">
                           <button onClick={handlePrint} className="flex items-center gap-2 px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-teal-700" aria-label="রেজাল্ট শিট প্রিন্ট করুন">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                                <span className="hidden sm:inline">প্রিন্ট করুন</span>
                            </button>
                             <button onClick={handlePdfDownload} className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg text-lg shadow-md hover:bg-blue-700" aria-label="পিডিএফ ডাউনলোড করুন">
                                <DownloadIcon className="w-6 h-6"/>
                                <span className="hidden sm:inline">PDF ডাউনলোড</span>
                            </button>
                        </div>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">ফলাফল দেখতে অনুগ্রহ করে সকল ফিল্টার পূরণ করুন।</p>
                )}
            </div>

            <div id="printable-area" className="hidden">
                <table>
                    <thead>
                        <tr>
                            <th>রোল</th>
                            <th>আইডি</th>
                            <th>নাম</th>
                            {hifzSubjects.map(s => <th key={s.id}>{s.name}</th>)}
                            <th>মোট</th>
                            <th>বিভাগ</th>
                            <th>মেধা স্থান</th>
                        </tr>
                    </thead>
                    <tbody>
                        {studentsToPrint.map(s => (
                            <tr key={s.id}>
                                <td className="text-center">{toBengaliNumber(s.roll)}</td>
                                <td className="text-center">{toBengaliNumber(s.uniqueId)}</td>
                                <td className="text-left">{s.nameBn}</td>
                                {hifzSubjects.map(sub => (
                                    <td key={sub.id} className="text-center">{toBengaliNumber(s.marksBySubject[sub.id])}</td>
                                ))}
                                <td className="text-center font-bold">{toBengaliNumber(s.totalObtained)}</td>
                                <td className="text-center font-semibold">{s.grade}</td>
                                <td className="text-center font-bold">{toBengaliNumber(s.rank)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                <div className="footer-signatures" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: '25px', pageBreakInside: 'avoid', fontSize: '12px' }}>
                    <div style={{ width: '180px', textAlign: 'center', borderTop: '1px dotted black', paddingTop: '5px' }}>
                        <p>শিক্ষাসচিবের স্বাক্ষর</p>
                    </div>
                    <div style={{ textAlign: 'center', fontSize: '11px' }}>
                        <p style={{ margin: 0 }}>প্রস্তুতকারী: মোঃ ওয়ালীউল্লাহ রাব্বানী, ইস্যুর তারিখ: {new Date().toLocaleDateString('bn-BD')}</p>
                    </div>
                    <div style={{ width: '180px', textAlign: 'center', borderTop: '1px dotted black', paddingTop: '5px' }}>
                        <p>প্রিন্সিপালের স্বাক্ষর</p>
                    </div>
                </div>
            </div>

        </div>
    );
};

export default HifzResultSheet;
