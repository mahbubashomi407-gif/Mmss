
import React, { useState } from 'react';
import PageHeader from '../../components/PageHeader';
import { useInstitution, NoticeData, GuardianNotificationData } from '../../context/InstitutionContext';
import { useNotification } from '../../context/NotificationContext';
import Modal from '../../components/Modal';
import NoticeModal from '../../components/NoticeModal';
import { PencilIcon, TrashIcon, EyeIcon } from '../../components/icons';
import { showNotification } from '../../utils/notificationService';

const ManageNotices: React.FC = () => {
    const { notices, setNotices, students, notificationSettings, appNotificationTemplates, setGuardianNotifications, logoUrl } = useInstitution();
    const { addToast } = useNotification();
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [isViewModalOpen, setIsViewModalOpen] = useState(false);
    const [selectedNotice, setSelectedNotice] = useState<NoticeData | null>(null);

    const handleAddNew = () => {
        setSelectedNotice(null);
        setIsModalOpen(true);
    };

    const handleEdit = (notice: NoticeData) => {
        setSelectedNotice(notice);
        setIsModalOpen(true);
    };
    
    const handleView = (notice: NoticeData) => {
        setSelectedNotice(notice);
        setIsViewModalOpen(true);
    };

    const handleDelete = (notice: NoticeData) => {
        setSelectedNotice(notice);
        setIsDeleteModalOpen(true);
    };
    
    const handleConfirmDelete = () => {
        if (selectedNotice) {
            setNotices(notices.filter(n => n.id !== selectedNotice.id));
            addToast('নোটিশ সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedNotice(null);
    };

    const handleSave = (noticeData: Omit<NoticeData, 'id' | 'publishDate'> & { id?: string }) => {
        const today = new Date().toISOString().split('T')[0];
        if (noticeData.id) { // Editing
            setNotices(notices.map(n => n.id === noticeData.id ? { ...n, ...noticeData } as NoticeData : n));
            addToast('নোটিশ সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newNotice: NoticeData = { ...noticeData, id: Date.now().toString(), publishDate: today };
            setNotices([newNotice, ...notices]);
            addToast('নতুন নোটিশ সফলভাবে যোগ করা হয়েছে!', 'success');

            // --- Trigger Push Notification ---
            if (newNotice.target.includes('Guardians')) {
                showNotification(newNotice.title, {
                    body: 'আপনার সন্তানের জন্য একটি নতুন নোটিশ প্রকাশ করা হয়েছে।',
                    icon: logoUrl || '/vite.svg',
                    tag: newNotice.id,
                });
            }

            if(newNotice.sendSms) {
                addToast('নোটিশের জন্য SMS পাঠানো হয়েছে!', 'success');
            }
            // Send App Notifications if enabled
            if (newNotice.target.includes('Guardians') && notificationSettings.automaticNotifications.newNotice.app) {
                const message = appNotificationTemplates.newNotice.replace('{{institution_name}}', ''); // Placeholder might not be needed as per template.
                const newNotifications: GuardianNotificationData[] = students
                    .filter(s => s.status !== 'পেন্ডিং')
                    .map(student => ({
                        id: `noti-notice-${newNotice.id}-${student.id}`,
                        studentId: student.id,
                        timestamp: new Date().toISOString(),
                        title: newNotice.title,
                        message,
                        isRead: false,
                    }));
                setGuardianNotifications(prev => [...newNotifications, ...prev]);
                addToast(`${newNotifications.length} জন অভিভাবককে অ্যাপ নোটিফিকেশন পাঠানো হয়েছে।`, 'success');
            }
        }
        setIsModalOpen(false);
        setSelectedNotice(null);
    };
    
    const getTargetAudience = (target: ('Guardians' | 'Teachers')[]) => {
        const audience = [];
        if (target.includes('Guardians')) audience.push('অভিভাবক');
        if (target.includes('Teachers')) audience.push('শিক্ষক');
        return audience.join(', ');
    };

    return (
        <div>
            <PageHeader icon="📢" title="নোটিশ ও যোগাযোগ">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন নোটিশ যোগ করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">শিরোনাম</th>
                                <th scope="col" className="px-6 py-3">প্রকাশের তারিখ</th>
                                <th scope="col" className="px-6 py-3">লক্ষ্য</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {notices.length > 0 ? notices.map(notice => (
                                <tr key={notice.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{notice.title}</td>
                                    <td className="px-6 py-4">{new Date(notice.publishDate).toLocaleDateString('bn-BD')}</td>
                                    <td className="px-6 py-4">{getTargetAudience(notice.target)}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => handleView(notice)} className="p-2 text-green-600 hover:bg-green-100 rounded-full" title="দেখুন"><EyeIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleEdit(notice)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleDelete(notice)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={4} className="text-center py-10 text-gray-500">
                                        <p>কোনো নোটিশ যোগ করা হয়নি।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <NoticeModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                noticeToEdit={selectedNotice}
            />

            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="নোটিশ মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই নোটিশটি মুছে ফেলতে চান?</p>
            </Modal>
            
            {selectedNotice && (
                 <div className={`fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 ${isViewModalOpen ? '' : 'hidden'}`} aria-modal="true" role="dialog">
                     <div className="bg-white rounded-lg shadow-xl w-full max-w-xl m-4 transform transition-all">
                         <div className="p-5">
                             <h3 className="text-lg font-bold text-gray-800">{selectedNotice.title}</h3>
                             <div className="mt-2 text-sm text-gray-700 space-y-2 whitespace-pre-wrap max-h-80 overflow-y-auto">
                                 {selectedNotice.details}
                             </div>
                             <div className="text-xs text-gray-500 pt-3 mt-3 border-t">
                                 <p><strong>লক্ষ্য:</strong> {getTargetAudience(selectedNotice.target)}</p>
                                 <p><strong>প্রকাশের তারিখ:</strong> {new Date(selectedNotice.publishDate).toLocaleDateString('bn-BD')}</p>
                                 {selectedNotice.sendSms && <p className="text-green-600 font-semibold">এই নোটিশের জন্য SMS পাঠানো হয়েছে।</p>}
                             </div>
                         </div>
                         <div className="bg-gray-50 px-5 py-3 flex justify-end">
                             <button
                                 onClick={() => setIsViewModalOpen(false)}
                                 className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
                             >
                                 বন্ধ করুন
                             </button>
                         </div>
                     </div>
                 </div>
            )}
        </div>
    );
};

export default ManageNotices;
