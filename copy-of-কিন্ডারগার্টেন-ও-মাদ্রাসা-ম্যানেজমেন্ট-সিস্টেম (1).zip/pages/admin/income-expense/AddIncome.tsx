
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, IncomeData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

const AddIncome: React.FC = () => {
    const { fundCategories, fundHeads, incomeRecords, setIncomeRecords } = useInstitution();
    const { addToast } = useNotification();

    const today = new Date().toISOString().split('T')[0];

    const [date, setDate] = useState(today);
    const [fundCategoryId, setFundCategoryId] = useState('');
    const [fundHeadId, setFundHeadId] = useState('');
    const [amount, setAmount] = useState<number | ''>('');
    const [description, setDescription] = useState('');
    const [receiptNo, setReceiptNo] = useState('');

    const availableHeads = useMemo(() => {
        if (!fundCategoryId) return [];
        return fundHeads.filter(head => head.fundCategoryId === fundCategoryId && head.type === 'Income');
    }, [fundCategoryId, fundHeads]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!fundHeadId || amount === '' || amount <= 0 || !date) {
            addToast('অনুগ্রহ করে তারিখ, ক্যাটাগরি, খাত এবং টাকার পরিমাণ পূরণ করুন।', 'error');
            return;
        }

        const newIncome: IncomeData = {
            id: `inc-${Date.now()}`,
            date,
            fundHeadId,
            amount: Number(amount),
            description,
            receiptNo: receiptNo || undefined,
        };

        setIncomeRecords([...incomeRecords, newIncome]);
        addToast('আয় সফলভাবে যোগ করা হয়েছে!', 'success');

        // Reset form
        setDate(today);
        setFundCategoryId('');
        setFundHeadId('');
        setAmount('');
        setDescription('');
        setReceiptNo('');
    };

    return (
        <div>
            <PageHeader icon="➕" title="আয় যোগ করুন" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="date" className="block text-sm font-medium text-gray-700">তারিখ<span className="text-red-500">*</span></label>
                        <input
                            id="date"
                            type="date"
                            value={date}
                            onChange={e => setDate(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                            required
                        />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="fundCategory" className="block text-sm font-medium text-gray-700">তহবিল ক্যাটাগরি<span className="text-red-500">*</span></label>
                            <select
                                id="fundCategory"
                                value={fundCategoryId}
                                onChange={e => { setFundCategoryId(e.target.value); setFundHeadId(''); }}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                                required
                            >
                                <option value="">নির্বাচন করুন</option>
                                {fundCategories.map(cat => (
                                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="fundHead" className="block text-sm font-medium text-gray-700">আয়ের খাত<span className="text-red-500">*</span></label>
                            <select
                                id="fundHead"
                                value={fundHeadId}
                                onChange={e => setFundHeadId(e.target.value)}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                                required
                                disabled={!fundCategoryId}
                            >
                                <option value="">নির্বাচন করুন</option>
                                {availableHeads.map(head => (
                                    <option key={head.id} value={head.id}>{head.name}</option>
                                ))}
                            </select>
                            {fundCategoryId && availableHeads.length === 0 && (
                                <p className="text-xs text-red-500 mt-1">এই ক্যাটাগরিতে কোনো আয়ের খাত নেই।</p>
                            )}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="amount" className="block text-sm font-medium text-gray-700">পরিমাণ (টাকা)<span className="text-red-500">*</span></label>
                        <input
                            id="amount"
                            type="number"
                            value={amount}
                            onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                            placeholder="উদাহরণ: ১০০০"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="description" className="block text-sm font-medium text-gray-700">বিবরণ</label>
                        <textarea
                            id="description"
                            rows={3}
                            value={description}
                            onChange={e => setDescription(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                            placeholder="আয়ের সংক্ষিপ্ত বিবরণ লিখুন..."
                        />
                    </div>
                    <div>
                        <label htmlFor="receiptNo" className="block text-sm font-medium text-gray-700">রসিদ নম্বর (ঐচ্ছিক)</label>
                        <input
                            id="receiptNo"
                            type="text"
                            value={receiptNo}
                            onChange={e => setReceiptNo(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                            placeholder="উদাহরণ: REC-2024001"
                        />
                    </div>
                    
                    <div className="flex justify-end pt-4 border-t">
                        <button
                            type="submit"
                            className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700"
                        >
                            আয় যোগ করুন
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddIncome;
