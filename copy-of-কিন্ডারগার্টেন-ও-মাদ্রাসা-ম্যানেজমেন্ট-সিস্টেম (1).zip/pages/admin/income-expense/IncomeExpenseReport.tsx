
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, IncomeData, ExpenseData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import { PencilIcon, TrashIcon } from '../../../components/icons';
import EditIncomeModal from '../../../components/EditIncomeModal';
import EditExpenseModal from '../../../components/EditExpenseModal';

type ActiveTab = 'income' | 'expense';
type RecordType = IncomeData | ExpenseData;

const IncomeExpenseReport: React.FC = () => {
    const { incomeRecords, setIncomeRecords, expenseRecords, setExpenseRecords, fundCategories, fundHeads } = useInstitution();
    const { addToast } = useNotification();
    
    const [activeTab, setActiveTab] = useState<ActiveTab>('income');
    const [categoryFilter, setCategoryFilter] = useState<string>('all');
    
    const [editModal, setEditModal] = useState<{ isOpen: boolean, record: RecordType | null }>({ isOpen: false, record: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean, record: RecordType | null }>({ isOpen: false, record: null });
    
    const dataMaps = useMemo(() => {
        const headMap = new Map(fundHeads.map(h => [h.id, h]));
        const categoryMap = new Map(fundCategories.map(c => [c.id, c.name]));
        return { headMap, categoryMap };
    }, [fundHeads, fundCategories]);

    const getRecordDetails = (record: RecordType) => {
        const head = dataMaps.headMap.get(record.fundHeadId);
        const categoryName = head ? dataMaps.categoryMap.get(head.fundCategoryId) : 'অজানা';
        return { headName: head?.name || 'অজানা', categoryName: categoryName || 'অজানা', categoryId: head?.fundCategoryId };
    };

    const filteredRecords = useMemo(() => {
        const records = activeTab === 'income' ? incomeRecords : expenseRecords;
        if (categoryFilter === 'all') {
            return records;
        }
        return records.filter(rec => getRecordDetails(rec).categoryId === categoryFilter);
    }, [activeTab, categoryFilter, incomeRecords, expenseRecords, getRecordDetails]);
    
    const handleEdit = (record: RecordType) => setEditModal({ isOpen: true, record });
    const handleDelete = (record: RecordType) => setDeleteModal({ isOpen: true, record });
    
    const handleSave = (record: RecordType) => {
        if (activeTab === 'income') {
            setIncomeRecords(incomeRecords.map(r => r.id === record.id ? record as IncomeData : r));
        } else {
            setExpenseRecords(expenseRecords.map(r => r.id === record.id ? record as ExpenseData : r));
        }
        addToast('রেকর্ড সফলভাবে আপডেট করা হয়েছে!', 'success');
        setEditModal({ isOpen: false, record: null });
    };

    const handleConfirmDelete = () => {
        if (!deleteModal.record) return;
        if (activeTab === 'income') {
            setIncomeRecords(incomeRecords.filter(r => r.id !== deleteModal.record!.id));
        } else {
            setExpenseRecords(expenseRecords.filter(r => r.id !== deleteModal.record!.id));
        }
        addToast('রেকর্ড সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        setDeleteModal({ isOpen: false, record: null });
    };
    
    const sortedRecords = useMemo(() => [...filteredRecords].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()), [filteredRecords]);

    return (
        <div>
            <PageHeader icon="📄" title="আয়-ব্যয় রিপোর্ট" />
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="flex justify-between items-center border-b border-gray-200 mb-4">
                    <nav className="-mb-px flex space-x-6">
                        <button onClick={() => setActiveTab('income')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'income' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500'}`}>আয়</button>
                        <button onClick={() => setActiveTab('expense')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'expense' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500'}`}>ব্যয়</button>
                    </nav>
                    <div>
                        <label className="text-sm font-medium mr-2">তহবিল:</label>
                        <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)} className="p-2 border rounded-md bg-white">
                            <option value="all">সকল</option>
                            {fundCategories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="p-2 text-left">তারিখ</th>
                                <th className="p-2 text-left">খাত</th>
                                <th className="p-2 text-left">তহবিল</th>
                                <th className="p-2 text-left">বিবরণ</th>
                                <th className="p-2 text-right">পরিমাণ</th>
                                <th className="p-2 text-center">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sortedRecords.map(record => {
                                const details = getRecordDetails(record);
                                return (
                                <tr key={record.id} className="border-b">
                                    <td className="p-2">{new Date(record.date).toLocaleDateString('bn-BD')}</td>
                                    <td className="p-2 font-medium">{details.headName}</td>
                                    <td className="p-2">{details.categoryName}</td>
                                    <td className="p-2 text-gray-600 max-w-xs truncate">{record.description}</td>
                                    <td className="p-2 text-right font-semibold">৳{record.amount.toLocaleString('bn-BD')}</td>
                                    <td className="p-2 text-center space-x-1">
                                        <button onClick={() => handleEdit(record)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button>
                                        <button onClick={() => handleDelete(record)} className="p-2 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button>
                                    </td>
                                </tr>
                            )})}
                        </tbody>
                    </table>
                </div>
                 {sortedRecords.length === 0 && <p className="text-center text-gray-500 py-10">কোনো রেকর্ড পাওয়া যায়নি।</p>}
            </div>

            {activeTab === 'income' ? 
                <EditIncomeModal isOpen={editModal.isOpen} onClose={() => setEditModal({isOpen: false, record: null})} onSave={handleSave as any} recordToEdit={editModal.record as IncomeData | null} />
                :
                <EditExpenseModal isOpen={editModal.isOpen} onClose={() => setEditModal({isOpen: false, record: null})} onSave={handleSave as any} recordToEdit={editModal.record as ExpenseData | null} />
            }
            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({isOpen: false, record: null})} onConfirm={handleConfirmDelete} title="রেকর্ড মুছে ফেলুন">আপনি কি নিশ্চিতভাবে এই রেকর্ডটি মুছে ফেলতে চান?</Modal>
        </div>
    );
};

export default IncomeExpenseReport;
