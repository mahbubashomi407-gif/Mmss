
import React, { useState, useMemo } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';

// Helper function to convert numbers to Bengali script
const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match]);
};

// Helper to format currency
const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;

const MonthlySummary: React.FC = () => {
    const { incomeRecords, expenseRecords, fundHeads, fundCategories, institutionName, logoUrl, address } = useInstitution();
    
    const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth());
    const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
    
    const dataMaps = useMemo(() => {
        const headMap = new Map(fundHeads.map(h => [h.id, h]));
        return { headMap };
    }, [fundHeads]);

    const reportData = useMemo(() => {
        const monthFilter = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}`;
        
        const monthlyIncomes = incomeRecords.filter(rec => rec.date.startsWith(monthFilter));
        const monthlyExpenses = expenseRecords.filter(rec => rec.date.startsWith(monthFilter));

        const summaryByFund: { [key: string]: { name: string; incomeDetails: { headName: string; amount: number }[]; expenseDetails: { headName: string; amount: number }[]; totalIncome: number; totalExpense: number; } } = {};

        fundCategories.forEach(cat => {
            summaryByFund[cat.id] = { name: cat.name, incomeDetails: [], expenseDetails: [], totalIncome: 0, totalExpense: 0 };
        });

        monthlyIncomes.forEach(rec => {
            const head = dataMaps.headMap.get(rec.fundHeadId);
            if (head && summaryByFund[head.fundCategoryId]) {
                const fundSummary = summaryByFund[head.fundCategoryId];
                let item = fundSummary.incomeDetails.find(i => i.headName === head.name);
                if (item) { item.amount += rec.amount; } 
                else { fundSummary.incomeDetails.push({ headName: head.name, amount: rec.amount }); }
                fundSummary.totalIncome += rec.amount;
            }
        });

        monthlyExpenses.forEach(rec => {
            const head = dataMaps.headMap.get(rec.fundHeadId);
            if (head && summaryByFund[head.fundCategoryId]) {
                const fundSummary = summaryByFund[head.fundCategoryId];
                let item = fundSummary.expenseDetails.find(i => i.headName === head.name);
                if (item) { item.amount += rec.amount; } 
                else { fundSummary.expenseDetails.push({ headName: head.name, amount: rec.amount }); }
                fundSummary.totalExpense += rec.amount;
            }
        });

        const grandTotalIncome = Object.values(summaryByFund).reduce((sum, fund) => sum + fund.totalIncome, 0);
        const grandTotalExpense = Object.values(summaryByFund).reduce((sum, fund) => sum + fund.totalExpense, 0);
        const balance = grandTotalIncome - grandTotalExpense;
        
        const activeFunds = Object.values(summaryByFund).filter(f => f.totalIncome > 0 || f.totalExpense > 0);

        return { activeFunds, grandTotalIncome, grandTotalExpense, balance };
    }, [selectedMonth, selectedYear, incomeRecords, expenseRecords, dataMaps, fundCategories]);
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-summary');
        if (printContent) {
            const reportTitle = `মাসিক আয়-ব্যয় সারসংক্ষেপ`;
            const subTitle = `${months[selectedMonth]}, ${toBengaliNumber(selectedYear)}`;
            const printWindow = window.open('', '', 'height=800,width=1200');
            
            if (printWindow) {
                printWindow.document.write('<html><head>');
                printWindow.document.write(`<title>${reportTitle}</title>`);
                printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                printWindow.document.write(`
                    <style>
                        body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                        @page { size: A4; margin: 0.5in; }
                        .print-header { text-align: center; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #333; }
                        .print-header img { height: 50px; width: 50px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.25rem; }
                        .print-header h1 { font-size: 1.5rem; font-weight: bold; margin: 0; }
                        .print-header p { margin: 0.1rem 0; font-size: 0.8rem; }
                        .summary-grid { display: none !important; }
                        .fund-container { margin-bottom: 1rem !important; page-break-inside: avoid; }
                        .fund-container h3 { font-size: 1.1rem; font-weight: bold; margin-bottom: 0.5rem; text-align: center; background-color: #f3f4f6 !important; padding: 4px; border: 1px solid #ddd; }
                        .tables-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
                        table { width: 100%; border-collapse: collapse; font-size: 11px; }
                        th, td { border: 1px solid #ddd; padding: 3px; }
                        th { background-color: #f9fafb !important; }
                        tfoot { font-weight: bold; background-color: #f3f4f6 !important; }
                        .text-right { text-align: right; }
                        .grand-total-summary { margin-top: 1.5rem !important; page-break-before: auto; }
                    </style>
                `);
                printWindow.document.write('</head><body>');
                printWindow.document.write(`<div class="print-header">
                    ${logoUrl ? `<img src="${logoUrl}" alt="লোগো" />` : ''}
                    <h1>${institutionName}</h1>
                    <p>${address.village}, ${address.upazila}, ${address.district}</p>
                    <h2>${reportTitle} - ${subTitle}</h2>
                </div>`);
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 500);
            }
        }
    };

    return (
        <div>
            <PageHeader icon="📊" title="মাসিক সারসংক্ষেপ">
                <button onClick={handlePrint} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                    রিপোর্ট প্রিন্ট করুন
                </button>
            </PageHeader>
            <div className="bg-white p-4 rounded-xl shadow-md mb-6 flex items-center gap-4">
                <div><label className="text-sm font-medium">মাস:</label><select value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">{months.map((m, index) => <option key={index} value={index}>{m}</option>)}</select></div>
                <div><label className="text-sm font-medium">বছর:</label><select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">{years.map(y => <option key={y} value={y}>{toBengaliNumber(y)}</option>)}</select></div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 summary-grid">
                <div className="p-4 bg-green-50 rounded-lg text-center"><p className="text-sm text-green-600">মোট আয়</p><p className="text-3xl font-bold text-green-700">{formatCurrency(reportData.grandTotalIncome)}</p></div>
                <div className="p-4 bg-red-50 rounded-lg text-center"><p className="text-sm text-red-600">মোট ব্যয়</p><p className="text-3xl font-bold text-red-700">{formatCurrency(reportData.grandTotalExpense)}</p></div>
                <div className={`p-4 rounded-lg text-center ${reportData.balance >= 0 ? 'bg-blue-50' : 'bg-orange-50'}`}><p className={`text-sm ${reportData.balance >= 0 ? 'text-blue-600' : 'text-orange-600'}`}>অবশিষ্ট / ঘাটতি</p><p className={`text-3xl font-bold ${reportData.balance >= 0 ? 'text-blue-700' : 'text-orange-700'}`}>{formatCurrency(reportData.balance)}</p></div>
            </div>

            <div id="printable-summary">
                {reportData.activeFunds.map(fund => (
                    <div key={fund.name} className="bg-white p-4 rounded-xl shadow-md mb-4 fund-container">
                        <h3 className="text-lg font-bold text-gray-800 mb-3 border-b pb-2">{fund.name}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 tables-grid">
                            <div>
                                <h4 className="font-semibold text-center mb-2">আয়ের বিবরণ</h4>
                                <table className="w-full text-sm"><thead className="bg-gray-50"><tr><th className="p-2 text-left">খাত</th><th className="p-2 text-right">টাকা</th></tr></thead><tbody>{fund.incomeDetails.map((item, index) => (<tr key={index} className="border-b"><td className="p-2">{item.headName}</td><td className="p-2 text-right">{formatCurrency(item.amount)}</td></tr>))}</tbody><tfoot className="bg-gray-100 font-bold"><tr><td className="p-2 text-right">মোট আয়</td><td className="p-2 text-right">{formatCurrency(fund.totalIncome)}</td></tr></tfoot></table>
                            </div>
                            <div>
                                <h4 className="font-semibold text-center mb-2">ব্যয়ের বিবরণ</h4>
                                <table className="w-full text-sm"><thead className="bg-gray-50"><tr><th className="p-2 text-left">খাত</th><th className="p-2 text-right">টাকা</th></tr></thead><tbody>{fund.expenseDetails.map((item, index) => (<tr key={index} className="border-b"><td className="p-2">{item.headName}</td><td className="p-2 text-right">{formatCurrency(item.amount)}</td></tr>))}</tbody><tfoot className="bg-gray-100 font-bold"><tr><td className="p-2 text-right">মোট ব্যয়</td><td className="p-2 text-right">{formatCurrency(fund.totalExpense)}</td></tr></tfoot></table>
                            </div>
                        </div>
                    </div>
                ))}
                
                <div className="bg-gray-100 p-4 rounded-xl shadow-md mt-6 grand-total-summary">
                    <h3 className="text-lg font-bold text-gray-800 mb-3 text-center">সর্বমোট সারসংক্ষেপ</h3>
                    <div className="overflow-x-auto">
                        <table className="w-full max-w-sm mx-auto text-sm">
                            <tbody>
                                <tr className="border-b"><td className="p-2 font-medium">সর্বমোট আয়</td><td className="p-2 text-right font-semibold">{formatCurrency(reportData.grandTotalIncome)}</td></tr>
                                <tr className="border-b"><td className="p-2 font-medium">সর্বমোট ব্যয়</td><td className="p-2 text-right font-semibold">{formatCurrency(reportData.grandTotalExpense)}</td></tr>
                            </tbody>
                            <tfoot className="bg-gray-200 font-bold">
                                <tr>
                                    <td className="p-2">অবশিষ্ট / ঘাটতি</td>
                                    <td className={`p-2 text-right ${reportData.balance >= 0 ? 'text-green-700' : 'text-red-700'}`}>{formatCurrency(reportData.balance)}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MonthlySummary;
