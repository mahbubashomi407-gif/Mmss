import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, RoutineSlotData, TimeSlotData, ClassLevelData, TeacherData, SubjectData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import RoutineSlotModal from '../../../components/RoutineSlotModal';
import AddTimeSlotModal from '../../../components/AddTimeSlotModal';
import Modal from '../../../components/Modal';
import { PlusIcon, TrashIcon, CogIcon, CheckCircleIcon } from '../../../components/icons';

// A placeholder for the day since the user wants a single daily routine template
const GENERIC_DAY = 'GenericDay';

const toBengaliNumber = (numStr: string | number) => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯', ':': ':' };
    return num.replace(/[0-9:]/g, (match) => map[match]);
};

const ClassRoutine: React.FC = () => {
    const { classLevels, teachers, routineSlots, setRoutineSlots, timeSlots, setTimeSlots, institutionName, logoUrl } = useInstitution();
    const { addToast } = useNotification();
    
    const [isEditMode, setIsEditMode] = useState(false);
    
    const [visibleTeacherIds, setVisibleTeacherIds] = useState<Set<string>>(new Set());
    const [teacherToAdd, setTeacherToAdd] = useState('');

    const [modalState, setModalState] = useState<{ type: 'slot' | 'time' | 'confirmDelete' | null; data: any }>({ type: null, data: null });

    const sortedTimeSlots = useMemo(() => [...timeSlots].sort((a, b) => a.startTime.localeCompare(b.startTime)), [timeSlots]);

    const dataMaps = useMemo(() => {
        const teacherMap = new Map<string, TeacherData>(teachers.map(t => [t.id, t]));
        const subjectMap = new Map<string, SubjectData>();
        const classMap = new Map<string, ClassLevelData>();
        classLevels.forEach(cl => {
            classMap.set(cl.id, cl);
            cl.subjects.forEach(s => subjectMap.set(s.id, s));
        });
        return { teacherMap, subjectMap, classMap };
    }, [teachers, classLevels]);
    
    const routineData = useMemo(() => {
        return routineSlots.filter(slot => slot.day === GENERIC_DAY);
    }, [routineSlots]);

    useEffect(() => {
        const teacherIdsInRoutine = new Set(routineData.map(slot => slot.teacherId));
        setVisibleTeacherIds(teacherIdsInRoutine);
        setTeacherToAdd('');
    }, [routineData]);

    const conflicts = useMemo(() => {
        const conflictSlots = new Set<string>();
        const timeSlotClassUsage = new Map<string, Map<string, string>>(); // Map<timeSlotId, Map<classLevelId, routineSlotId>>

        routineData.forEach(slot => {
            if (!timeSlotClassUsage.has(slot.timeSlotId)) {
                timeSlotClassUsage.set(slot.timeSlotId, new Map());
            }
            const classUsage = timeSlotClassUsage.get(slot.timeSlotId)!;
            // The user wants a warning if the same class AND same subject is duplicated.
            // A simpler and more robust check is if the same CLASS is scheduled at the same time, regardless of subject.
            // This prevents a class from being in two places at once.
            if (classUsage.has(slot.classLevelId)) {
                conflictSlots.add(slot.id);
                const existingSlotId = classUsage.get(slot.classLevelId);
                if (existingSlotId) {
                    conflictSlots.add(existingSlotId);
                }
            } else {
                classUsage.set(slot.classLevelId, slot.id);
            }
        });
        return conflictSlots;
    }, [routineData]);
    
    // Handlers
    const handleSaveSlot = (data: { classLevelId: string; subjectId: string } | null) => {
        const { teacher, timeSlot } = modalState.data;
        let updatedSlots = routineSlots.filter(s => !(s.day === GENERIC_DAY && s.timeSlotId === timeSlot.id && s.teacherId === teacher.id));
        if (data) {
            updatedSlots.push({ id: `${GENERIC_DAY}-${timeSlot.id}-${teacher.id}`, day: GENERIC_DAY, timeSlotId: timeSlot.id, teacherId: teacher.id, classLevelId: data.classLevelId, subjectId: data.subjectId });
            addToast('স্লট আপডেট করা হয়েছে!', 'success');
        } else {
            addToast('স্লট খালি করা হয়েছে।', 'success');
        }
        setRoutineSlots(updatedSlots);
        setModalState({ type: null, data: null });
    };

    const handleAddTimeSlot = (startTime: string, endTime: string) => {
        setTimeSlots([...timeSlots, { id: `ts-${Date.now()}`, startTime, endTime }]);
        addToast('নতুন সময় যোগ করা হয়েছে!', 'success');
    };

    const handleConfirmDelete = () => {
        const { type, item } = modalState.data;
        if (type === 'timeSlot') {
            setTimeSlots(timeSlots.filter(ts => ts.id !== item.id));
            setRoutineSlots(routineSlots.filter(rs => rs.timeSlotId !== item.id));
            addToast('সময়সূচী মুছে ফেলা হয়েছে।', 'success');
        }
        setModalState({ type: null, data: null });
    };

    const handleAddTeacherToView = () => {
        if (teacherToAdd && !visibleTeacherIds.has(teacherToAdd)) {
            setVisibleTeacherIds(new Set(visibleTeacherIds).add(teacherToAdd));
            setTeacherToAdd('');
        }
    };
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-routine');
        if (printContent) {
            const printWindow = window.open('', '', 'height=800,width=1200');
            if(printWindow){
                printWindow.document.write(`<html><head><title>দৈনিক ক্লাস রুটিন</title><script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet"><style>body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; } @page { size: A4 landscape; margin: 1.0cm; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ddd; padding: 2px; text-align: center; font-size: 13px; } th { background-color: #f2f2f2 !important; } th.teacher-col, td.teacher-col { text-align: left; padding-left: 4px; } .header-info { text-align: center; margin-bottom: 1rem; } .header-info img { height: 50px; width: 50px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.5rem; } </style></head><body>`);
                printWindow.document.write(`<div class="header-info">${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}<h1>${institutionName}</h1><h2>দৈনিক ক্লাস রুটিন</h2></div>`);
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => { printWindow.print(); printWindow.close(); }, 500);
            }
        }
    };
    
    const teachersToShow = useMemo(() => Array.from(visibleTeacherIds).map(id => dataMaps.teacherMap.get(id)).filter(Boolean) as TeacherData[], [visibleTeacherIds, dataMaps.teacherMap]);
    const availableTeachersToAdd = useMemo(() => teachers.filter(t => !visibleTeacherIds.has(t.id)), [teachers, visibleTeacherIds]);

    return (
        <div>
            <PageHeader icon="🗓️" title="দৈনিক ক্লাস রুটিন">
                <button onClick={handlePrint} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700">রুটিন প্রিন্ট করুন</button>
                <button onClick={() => setIsEditMode(prev => !prev)} className="p-2 text-gray-600 hover:bg-gray-200 rounded-full" title={isEditMode ? "সম্পাদনা শেষ করুন" : "রুটিন সম্পাদনা করুন"}>
                    {isEditMode ? <CheckCircleIcon className="w-6 h-6 text-green-600" /> : <CogIcon className="w-6 h-6" />}
                </button>
            </PageHeader>
            
            {isEditMode && (
                <div className="mb-6 p-4 bg-gray-50 rounded-xl border">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                             <h4 className="font-semibold mb-2">সময়সূচী যোগ করুন</h4>
                             <div className="flex items-center gap-2">
                                <button onClick={() => setModalState({ type: 'time', data: null })} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                                    <PlusIcon className="w-5 h-5 text-gray-500"/>
                                    <span>নতুন সময় যোগ করুন</span>
                                </button>
                             </div>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2">শিক্ষক যোগ করুন</h4>
                            <div className="flex items-center gap-2">
                                <select value={teacherToAdd} onChange={e => setTeacherToAdd(e.target.value)} className="flex-grow p-2 border rounded-md bg-white">
                                    <option value="">-- শিক্ষক নির্বাচন --</option>
                                    {availableTeachersToAdd.map(t => <option key={t.id} value={t.id}>{t.nameBn}</option>)}
                                </select>
                                <button onClick={handleAddTeacherToView} disabled={!teacherToAdd} className="px-4 py-2 bg-blue-500 text-white font-semibold rounded-md disabled:bg-gray-300">যোগ করুন</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            <div className="overflow-x-auto bg-white p-4 rounded-xl shadow-md">
                <table className="w-full border-collapse text-sm min-w-[800px]">
                    <thead>
                        <tr className="bg-gray-50">
                            <th className="p-2 border font-semibold sticky left-0 bg-gray-50 z-10 min-w-[150px]">শিক্ষক</th>
                            {sortedTimeSlots.map(ts => (
                                <th key={ts.id} className="p-1 border font-semibold text-center align-top">
                                    {toBengaliNumber(ts.startTime)} - {toBengaliNumber(ts.endTime)}
                                    {isEditMode && <button onClick={() => setModalState({ type: 'confirmDelete', data: { type: 'timeSlot', item: ts } })} className="ml-1 text-red-500 hover:text-red-800"> <TrashIcon className="w-3 h-3"/> </button>}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {teachersToShow.map(teacher => {
                            return (
                                <tr key={teacher.id} className="border-b">
                                    <td className="p-2 border font-semibold sticky left-0 bg-white z-10">
                                        {isEditMode && <button onClick={() => setVisibleTeacherIds(prev => { const next = new Set(prev); next.delete(teacher.id); return next; })} className="text-red-500 hover:text-red-800 mr-1"><TrashIcon className="w-3 h-3 inline"/></button>}
                                        {teacher.nameBn}
                                    </td>
                                    {sortedTimeSlots.map(ts => {
                                        const slot = routineData.find(s => s.teacherId === teacher.id && s.timeSlotId === ts.id);
                                        const subject = slot ? dataMaps.subjectMap.get(slot.subjectId) : null;
                                        const classLevel = slot ? dataMaps.classMap.get(slot.classLevelId) : null;
                                        const isConflict = slot ? conflicts.has(slot.id) : false;
                                        return (
                                            <td key={ts.id} className={`p-1 border text-center align-middle ${isEditMode ? 'cursor-pointer hover:bg-teal-50' : ''} ${isConflict ? 'bg-red-100 ring-1 ring-red-500' : ''}`} onClick={() => isEditMode && setModalState({ type: 'slot', data: { day: GENERIC_DAY, timeSlot: ts, teacher, existingSlot: slot } })}>
                                                {slot && subject && classLevel ? (
                                                    <div>
                                                        <p className="font-bold text-gray-800">{subject.name}</p>
                                                        <p className="text-xs text-gray-500">({classLevel.name})</p>
                                                    </div>
                                                ) : (isEditMode && <PlusIcon className="w-4 h-4 text-gray-400 mx-auto"/>)}
                                            </td>
                                        );
                                    })}
                                </tr>
                            );
                        })}
                        {teachersToShow.length === 0 && (
                            <tr><td colSpan={sortedTimeSlots.length + 1} className="text-center py-10 text-gray-500">অনুগ্রহ করে রুটিন দেখার জন্য শিক্ষক যোগ করুন।</td></tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* Modals */}
            {modalState.type === 'slot' && <RoutineSlotModal isOpen={true} onClose={() => setModalState({ type: null, data: null })} onSave={handleSaveSlot} slotInfo={modalState.data} />}
            {modalState.type === 'time' && <AddTimeSlotModal isOpen={true} onClose={() => setModalState({ type: null, data: null })} onSave={handleAddTimeSlot} />}
            {modalState.type === 'confirmDelete' && <Modal isOpen={true} onClose={() => setModalState({ type: null, data: null })} onConfirm={handleConfirmDelete} title="মুছে ফেলা নিশ্চিত করুন"><p>আপনি কি এই আইটেমটি মুছে ফেলতে চান? এর সাথে সম্পর্কিত সকল রুটিন স্লট মুছে যাবে।</p></Modal>}
            
            {/* Hidden div for printing */}
            <div id="printable-routine" className="hidden">
                <table className="w-full">
                    <thead>
                        <tr>
                            <th className="teacher-col">শিক্ষক</th>
                            {sortedTimeSlots.map(ts => <th key={ts.id}>{toBengaliNumber(ts.startTime)}<br/>{toBengaliNumber(ts.endTime)}</th>)}
                        </tr>
                    </thead>
                    <tbody>
                        {teachers.map(teacher => (
                            <tr key={teacher.id}>
                                <td className="teacher-col font-semibold">{teacher.nameBn}</td>
                                {sortedTimeSlots.map(ts => {
                                    const slot = routineSlots.find(s => s.day === GENERIC_DAY && s.teacherId === teacher.id && s.timeSlotId === ts.id);
                                    const subject = slot ? dataMaps.subjectMap.get(slot.subjectId) : null;
                                    const classLevel = slot ? dataMaps.classMap.get(slot.classLevelId) : null;
                                    return (
                                        <td key={ts.id}>
                                            {slot && subject && classLevel ? (<div><p className="font-semibold">{subject.name}</p><p className="text-xs">({classLevel.name})</p></div>) : '-'}
                                        </td>
                                    );
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ClassRoutine;