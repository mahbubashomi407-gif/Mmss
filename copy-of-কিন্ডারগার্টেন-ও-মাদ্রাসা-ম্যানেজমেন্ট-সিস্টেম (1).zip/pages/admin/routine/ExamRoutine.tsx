

import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, ExamData, ClassLevelData, SubjectData, ExamRoutineSlotData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import ExamSlotModal from '../../../components/ExamSlotModal';
import AddDateModal from '../../../components/AddDateModal';
import Modal from '../../../components/Modal';
import { PlusIcon, TrashIcon, CogIcon, CheckCircleIcon } from '../../../components/icons';

const toBengaliNumber = (numStr: string | number) => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match]);
};

const ExamRoutine: React.FC = () => {
    const { exams, classLevels, examRoutineSlots, setExamRoutineSlots, institutionName, logoUrl } = useInstitution();
    const { addToast } = useNotification();
    
    const [selectedExamId, setSelectedExamId] = useState<string>('');
    const [isEditMode, setIsEditMode] = useState(false);
    const [modalState, setModalState] = useState<{ type: 'slot' | 'date' | 'confirmDelete' | null; data: any }>({ type: null, data: null });

    const dataMaps = useMemo(() => {
        const subjectMap = new Map<string, SubjectData>();
        const classMap = new Map<string, ClassLevelData>();
        classLevels.forEach(cl => {
            classMap.set(cl.id, cl);
            cl.subjects.forEach(s => subjectMap.set(s.id, s));
        });
        return { subjectMap, classMap };
    }, [classLevels]);

    const selectedExam = useMemo(() => exams.find(e => e.id === selectedExamId), [exams, selectedExamId]);
    
    const routineDataForExam = useMemo(() => {
        return examRoutineSlots.filter(slot => slot.examId === selectedExamId);
    }, [examRoutineSlots, selectedExamId]);

    const applicableClassLevels = useMemo(() => {
        if (!selectedExam) return [];
        return classLevels.filter(cl => selectedExam.classLevels.includes(cl.name));
    }, [selectedExam, classLevels]);

    const uniqueDates = useMemo(() => {
        const dates = new Set(routineDataForExam.map(slot => slot.date));
        // FIX: Explicitly type 'a' and 'b' as strings to resolve TypeScript inference issue.
        return Array.from(dates).sort((a: string, b: string) => new Date(a).getTime() - new Date(b).getTime());
    }, [routineDataForExam]);

    // Handlers
    const handleSaveSlot = (subjectId: string | null) => {
        const { classLevel, date, session } = modalState.data;
        let updatedSlots = examRoutineSlots.filter(s => !(s.examId === selectedExamId && s.classLevelId === classLevel.id && s.date === date && s.session === session));
        if (subjectId) {
            updatedSlots.push({
                id: `${selectedExamId}-${classLevel.id}-${date}-${session}`,
                examId: selectedExamId,
                classLevelId: classLevel.id,
                subjectId,
                date,
                session,
            });
            addToast('বিষয় নির্ধারণ করা হয়েছে!', 'success');
        } else {
            addToast('বিষয় খালি করা হয়েছে।', 'success');
        }
        setExamRoutineSlots(updatedSlots);
        setModalState({ type: null, data: null });
    };

    const handleAddDate = (date: string) => {
        if (uniqueDates.includes(date)) {
            addToast('এই তারিখটি ইতিমধ্যে যোগ করা আছে।', 'error');
            return;
        }
        // Just adding a dummy slot to make the date appear. It won't be saved unless a subject is added.
        // A better approach would be a local state for dates, but for simplicity this works.
        // To make the date appear, we must add at least one slot.
        const dummySlot: ExamRoutineSlotData = {
             id: `${selectedExamId}-dummy-${date}`,
             examId: selectedExamId,
             classLevelId: '',
             subjectId: '',
             date: date,
             session: 'Morning'
        }
        setExamRoutineSlots([...examRoutineSlots, dummySlot]);
        addToast('নতুন তারিখ যোগ করা হয়েছে!', 'success');
    };

    const handleConfirmDelete = () => {
        const { date } = modalState.data;
        setExamRoutineSlots(examRoutineSlots.filter(slot => !(slot.examId === selectedExamId && slot.date === date)));
        addToast('তারিখ ও সংশ্লিষ্ট পরীক্ষা মুছে ফেলা হয়েছে।', 'success');
        setModalState({ type: null, data: null });
    };
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-routine');
        if (printContent && selectedExam) {
            const printWindow = window.open('', '', 'height=800,width=1200');
            if(printWindow){
                printWindow.document.write(`<html><head><title>${selectedExam.name}</title><script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet"><style>body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; } @page { size: A4 landscape; margin: 1.0cm; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #ddd; padding: 2px; text-align: center; font-size: 13px; } th { background-color: #f2f2f2 !important; } .header-info { text-align: center; margin-bottom: 1rem; } .header-info img { height: 50px; width: 50px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.5rem; } </style></head><body>`);
                printWindow.document.write(`<div class="header-info">${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}<h1>${institutionName}</h1><h2>${selectedExam.name}</h2></div>`);
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 750);
            }
        }
    };
    
    const datesForPrint = useMemo(() => uniqueDates.map(date => {
        const hasMorning = routineDataForExam.some(s => s.date === date && s.session === 'Morning' && s.subjectId);
        const hasAfternoon = routineDataForExam.some(s => s.date === date && s.session === 'Afternoon' && s.subjectId);
        return { date, hasMorning, hasAfternoon };
    }).filter(d => d.hasMorning || d.hasAfternoon), [uniqueDates, routineDataForExam]);


    return (
        <div>
            <PageHeader icon="📝" title="পরীক্ষার রুটিন">
                <button onClick={handlePrint} disabled={!selectedExamId} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 disabled:bg-gray-400">রুটিন প্রিন্ট করুন</button>
                <button onClick={() => setIsEditMode(prev => !prev)} className="p-2 text-gray-600 hover:bg-gray-200 rounded-full" title={isEditMode ? "সম্পাদনা শেষ করুন" : "রুটিন সম্পাদনা করুন"}>
                    {isEditMode ? <CheckCircleIcon className="w-6 h-6 text-green-600" /> : <CogIcon className="w-6 h-6" />}
                </button>
            </PageHeader>
            
            <div className="mb-6 p-4 bg-white rounded-xl border shadow-sm">
                <div className="flex flex-col sm:flex-row items-center gap-4">
                    <div className="w-full sm:w-auto">
                        <label htmlFor="exam-select" className="block text-sm font-semibold text-gray-700 mb-1">পরীক্ষা নির্বাচন করুন:</label>
                        <select id="exam-select" value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)} className="w-full p-2 border rounded-md bg-white">
                            <option value="">-- পরীক্ষা নির্বাচন --</option>
                            {exams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                        </select>
                    </div>
                    {isEditMode && selectedExamId && (
                        <div className="w-full sm:w-auto">
                            <label className="block text-sm font-semibold text-gray-700 mb-1 opacity-0 hidden sm:block">.</label>
                             <button onClick={() => setModalState({ type: 'date', data: null })} className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-white border border-gray-300 rounded-md hover:bg-gray-100">
                                <PlusIcon className="w-5 h-5 text-gray-500"/>
                                <span>নতুন তারিখ যোগ করুন</span>
                            </button>
                        </div>
                    )}
                </div>
            </div>

            {selectedExamId ? (
                <div className="overflow-x-auto bg-white p-4 rounded-xl shadow-md">
                    <table className="w-full border-collapse text-sm min-w-[1000px]">
                        <thead>
                            <tr>
                                <th rowSpan={2} className="p-2 border font-semibold align-middle sticky left-0 bg-gray-50 z-10">শ্রেণি</th>
                                {uniqueDates.map(date => (
                                    <th key={date} colSpan={2} className="p-1 border font-semibold text-center">
                                        {new Date(date).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', weekday: 'long' })}
                                        {isEditMode && <button onClick={() => setModalState({ type: 'confirmDelete', data: { date } })} className="ml-2 text-red-500 hover:text-red-800"><TrashIcon className="w-3 h-3"/></button>}
                                    </th>
                                ))}
                            </tr>
                             <tr>
                                {uniqueDates.flatMap(date => [<th key={`${date}-m`} className="p-1 border font-semibold text-center">সকাল</th>, <th key={`${date}-a`} className="p-1 border font-semibold text-center">বিকাল</th>])}
                            </tr>
                        </thead>
                        <tbody>
                            {applicableClassLevels.map(cl => (
                                <tr key={cl.id}>
                                    <td className="p-2 border font-semibold sticky left-0 bg-white z-10">{cl.name}</td>
                                    {uniqueDates.flatMap(date => {
                                        const morningSlot = routineDataForExam.find(s => s.classLevelId === cl.id && s.date === date && s.session === 'Morning');
                                        const afternoonSlot = routineDataForExam.find(s => s.classLevelId === cl.id && s.date === date && s.session === 'Afternoon');
                                        const morningSubject = morningSlot ? dataMaps.subjectMap.get(morningSlot.subjectId) : null;
                                        const afternoonSubject = afternoonSlot ? dataMaps.subjectMap.get(afternoonSlot.subjectId) : null;

                                        const subjectsUsedOnDate = routineDataForExam
                                            .filter(s => s.classLevelId === cl.id && s.date === date)
                                            .map(s => s.subjectId);
                                
                                        const availableSubjectsForMorning = cl.subjects.filter(
                                            subj => !subjectsUsedOnDate.includes(subj.id) || subj.id === morningSlot?.subjectId
                                        );
                                        const availableSubjectsForAfternoon = cl.subjects.filter(
                                            subj => !subjectsUsedOnDate.includes(subj.id) || subj.id === afternoonSlot?.subjectId
                                        );
                                        
                                        return [
                                            <td key={`${date}-m`} className={`p-2 border text-center ${isEditMode ? 'cursor-pointer hover:bg-teal-50' : ''}`} onClick={() => isEditMode && setModalState({ type: 'slot', data: { classLevel: cl, subjects: availableSubjectsForMorning, date, session: 'Morning', existingSubjectId: morningSlot?.subjectId } })}>
                                                {morningSubject ? morningSubject.name : (isEditMode && <PlusIcon className="w-4 h-4 text-gray-400 mx-auto"/>)}
                                            </td>,
                                            <td key={`${date}-a`} className={`p-2 border text-center ${isEditMode ? 'cursor-pointer hover:bg-teal-50' : ''}`} onClick={() => isEditMode && setModalState({ type: 'slot', data: { classLevel: cl, subjects: availableSubjectsForAfternoon, date, session: 'Afternoon', existingSubjectId: afternoonSlot?.subjectId } })}>
                                                {afternoonSubject ? afternoonSubject.name : (isEditMode && <PlusIcon className="w-4 h-4 text-gray-400 mx-auto"/>)}
                                            </td>
                                        ];
                                    })}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            ) : (
                 <div className="text-center text-gray-500 py-20 bg-white rounded-xl shadow-md">
                    <p>অনুগ্রহ করে একটি পরীক্ষা নির্বাচন করুন।</p>
                </div>
            )}
            
            {/* Modals */}
            {modalState.type === 'slot' && <ExamSlotModal isOpen={true} onClose={() => setModalState({ type: null, data: null })} onSave={handleSaveSlot} slotInfo={{ className: modalState.data.classLevel.name, ...modalState.data }} />}
            {modalState.type === 'date' && <AddDateModal isOpen={true} onClose={() => setModalState({ type: null, data: null })} onSave={handleAddDate} />}
            {modalState.type === 'confirmDelete' && <Modal isOpen={true} onClose={() => setModalState({ type: null, data: null })} onConfirm={handleConfirmDelete} title="তারিখ মুছে ফেলা নিশ্চিত করুন"><p>আপনি কি এই তারিখটি এবং এর সকল পরীক্ষা মুছে ফেলতে চান?</p></Modal>}
        
            {/* Hidden div for printing */}
            <div id="printable-routine" className="hidden">
                <table>
                    <thead>
                         <tr>
                            <th rowSpan={2} style={{ verticalAlign: 'middle' }}>শ্রেণি</th>
                            {datesForPrint.map(({ date, hasMorning, hasAfternoon }) => (
                                <th key={date} colSpan={Number(hasMorning) + Number(hasAfternoon)}>
                                    {new Date(date).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', weekday: 'long' })}
                                </th>
                            ))}
                        </tr>
                        <tr>
                            {datesForPrint.flatMap(({ date, hasMorning, hasAfternoon }) => [
                                hasMorning && <th key={`${date}-m`}>সকাল</th>,
                                hasAfternoon && <th key={`${date}-a`}>বিকাল</th>
                            ])}
                        </tr>
                    </thead>
                    <tbody>
                        {applicableClassLevels.map(cl => (
                            <tr key={cl.id}>
                                <td style={{ fontWeight: 'bold' }}>{cl.name}</td>
                                {datesForPrint.flatMap(({ date, hasMorning, hasAfternoon }) => {
                                    const morningSlot = routineDataForExam.find(s => s.classLevelId === cl.id && s.date === date && s.session === 'Morning');
                                    const afternoonSlot = routineDataForExam.find(s => s.classLevelId === cl.id && s.date === date && s.session === 'Afternoon');
                                    const morningSubject = morningSlot ? dataMaps.subjectMap.get(morningSlot.subjectId)?.name : '-';
                                    const afternoonSubject = afternoonSlot ? dataMaps.subjectMap.get(afternoonSlot.subjectId)?.name : '-';
                                    return [
                                        hasMorning && <td key={`${date}-m`}>{morningSubject}</td>,
                                        hasAfternoon && <td key={`${date}-a`}>{afternoonSubject}</td>
                                    ];
                                })}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

        </div>
    );
};

export default ExamRoutine;
