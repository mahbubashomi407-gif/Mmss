
import React from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';
import { useInstitution } from '../../context/InstitutionContext';
import { useAuth } from '../../context/AuthContext';
import { PermissionGuard } from '../../components/PermissionGuard';

// Reusable card component
const ActionCard: React.FC<{ icon: string; title: string }> = ({ icon, title }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className="bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
            role="button"
            tabIndex={0}
            aria-label={title}
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};

const ManageHifzEsaleen: React.FC = () => {
    const { hasPermission } = useAuth();
    
    const hifzActions: { to: string, icon: string, title: string, permission: string }[] = [
      { to: 'entry', icon: '🔢', title: 'হিফজ নম্বর এন্ট্রি', permission: 'hifz:enter_marks' },
      { to: 'result-sheet', icon: '📊', title: 'হিফজ রেজাল্ট শিট', permission: 'hifz:view_result_sheet' },
      { to: 'marksheet', icon: '📑', title: 'হিফজ মার্কশীট', permission: 'hifz:generate_marksheet' },
      { to: 'grade-processing', icon: '⚙️', title: 'হিফজ গ্রেড সিস্টেম সেটআপ', permission: 'hifz:manage_grade_system' },
      { to: 'subject-assignment', icon: '📚', title: 'হিফজ বিষয় অ্যাসাইনমেন্ট', permission: 'hifz:manage_subject_assignment' },
      { to: 'exam-types', icon: '📝', title: 'হিফজ পরীক্ষার ধরণ', permission: 'hifz:manage_exam_types' },
    ];
    
    const accessibleActions = hifzActions.filter(action => hasPermission(action.permission));

    return (
        <div>
            <PageHeader icon="📖" title="হিফজ এসালাইন" />
            
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {accessibleActions.length > 0 ? accessibleActions.map((action) => (
                    <Link to={action.to} key={action.to} className="no-underline h-full">
                        <ActionCard icon={action.icon} title={action.title} />
                    </Link>
                )) : (
                     <div className="col-span-full text-center py-10 text-gray-500 bg-white rounded-xl shadow-md">
                        <p>এই মডিউলে আপনার জন্য কোনো অপশন সক্রিয় করা নেই।</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ManageHifzEsaleen;
