
import React from 'react';
import { useInstitution } from '../../context/InstitutionContext';
import { CheckCircleIcon } from '../../components/icons';
import { Link } from 'react-router-dom';
import PageHeader from '../../components/PageHeader';

// Reusable card component for settings actions
const SettingsActionCard: React.FC<{ icon: string; title: string; isActive?: boolean }> = ({ icon, title, isActive = false }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className={`bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 relative h-full
                       ${isActive ? 'ring-2 ring-teal-500' : ''}`}
            role="button"
            tabIndex={0}
            aria-label={title}
        >
            {isActive && <CheckCircleIcon className="absolute top-1 right-1 w-5 h-5 text-teal-600" />}
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};


const Settings: React.FC = () => {
    const settingsActions = [
      { id: 'academicYear', icon: '🏫', title: 'শিক্ষা বর্ষ সেটআপ', to: 'academic-year' },
      { id: 'classSetup', icon: '📚', title: 'শ্রেণি / জামাত সেটিং', to: 'class-setup' },
      { id: 'holidays', icon: '📅', title: 'ছুটি / ছুটির তালিকা', to: 'holiday-list' },
      { id: 'fundCategory', icon: '🏦', title: 'তহবিল ব্যবস্থাপনা', to: 'fund-category' },
      { id: 'autoSms', icon: '💬', title: 'স্বয়ংক্রিয় SMS ও নোটিফিকেশন', to: 'automatic-notifications' },
      { id: 'paymentGateway', icon: '💳', title: 'পেমেন্ট গেটওয়ে সেটিং', to: 'payment-gateway' },
      { id: 'backup', icon: '🔄', title: 'ডাটাবেস ব্যাকআপ / রিস্টোর', to: 'database-backup' },
      { id: 'general', icon: '🌐', title: 'সাধারণ সিস্টেম সেটিং', to: 'general-settings' },
    ];

    return (
        <div>
            <PageHeader icon="⚙️" title="সেটিংস" />
            
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {settingsActions.map((action) => (
                    <Link to={action.to} key={action.id} className="no-underline h-full">
                        <SettingsActionCard icon={action.icon} title={action.title} />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default Settings;
