
import React from 'react';
import { Link } from 'react-router-dom';
import { useInstitution } from '../../context/InstitutionContext';
import PageHeader from '../../components/PageHeader';

// Reusable card component for institution info actions
const InfoActionCard: React.FC<{ icon: string; title: string; }> = ({ icon, title }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className="bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};


const InstitutionInfo: React.FC = () => {
    
    const infoActions = [
      { to: 'name', icon: '🏷️', title: 'প্রতিষ্ঠান নাম' },
      { to: 'code', icon: '🔢', title: 'প্রতিষ্ঠান কোড' }, // New: Institution Code card
      { to: 'address', icon: '📍', title: 'ঠিকানা / লোকেশন' },
      { to: 'contact', icon: '📞', title: 'যোগাযোগ নম্বর / ইমেইল' },
      { to: 'logo', icon: '🏢', title: 'প্রতিষ্ঠান লোগো আপলোড' },
      { to: 'session', icon: '🏫', title: 'শিক্ষা বর্ষ / একাডেমিক সেশন' },
      { to: 'manager', icon: '👨‍🏫', title: 'প্রধান শিক্ষক / ম্যানেজার তথ্য' },
      { to: 'schedule', icon: '✨', title: 'কার্যক্রম' },
      { to: 'sections', icon: '🗂️', title: 'বিভাগ / সেকশন তালিকা' },
      { to: 'social', icon: '🌐', title: 'ওয়েবসাইট / সোশ্যাল মিডিয়া' },
      { to: 'license', icon: '📜', title: 'অনুমোদন / লাইসেন্স' },
    ];

    return (
        <div>
            <PageHeader icon="🏫" title="প্রতিষ্ঠান তথ্য" />
            
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {infoActions.map((action) => (
                     <Link to={action.to} key={action.to} className="no-underline">
                        <InfoActionCard 
                            icon={action.icon} 
                            title={action.title} 
                        />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default InstitutionInfo;
