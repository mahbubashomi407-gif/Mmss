
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, LicenseData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import LicenseModal from '../../../components/LicenseModal';
import Modal from '../../../components/Modal';
import { EyeIcon, TrashIcon } from '../../../components/icons';

const License: React.FC = () => {
    const { licenses, setLicenses } = useInstitution();
    const { addToast } = useNotification();
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedLicense, setSelectedLicense] = useState<LicenseData | null>(null);

    const handleAddNew = () => {
        setIsModalOpen(true);
    };

    const handleDelete = (license: LicenseData) => {
        setSelectedLicense(license);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = () => {
        if (selectedLicense) {
            setLicenses(licenses.filter(l => l.id !== selectedLicense.id));
            addToast('নথি সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedLicense(null);
    };

    const handleSave = (licenseData: Omit<LicenseData, 'id'>) => {
        const newLicense = { ...licenseData, id: Date.now().toString() };
        setLicenses([...licenses, newLicense]);
        addToast('নতুন নথি সফলভাবে যোগ করা হয়েছে!', 'success');
        setIsModalOpen(false);
    };

    const isExpired = (expiryDate?: string) => {
        if (!expiryDate) return false;
        // Check if date is valid before comparing
        const expiry = new Date(expiryDate);
        if (isNaN(expiry.getTime())) return false;
        // Set hours to 0 to compare dates only
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return expiry < today;
    };

    return (
        <div>
            <PageHeader icon="📜" title="অনুমোদন / লাইসেন্স">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন নথি যোগ করুন
                </button>
            </PageHeader>
             <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">নথির নাম</th>
                                <th scope="col" className="px-6 py-3">মেয়াদ উত্তীর্ণের তারিখ</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {licenses.length > 0 ? licenses.map(license => (
                                <tr key={license.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{license.name}</td>
                                    <td className="px-6 py-4">
                                        {license.expiryDate ? (
                                            <span className={isExpired(license.expiryDate) ? 'text-red-500 font-semibold' : ''}>
                                                {new Date(license.expiryDate).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', year: 'numeric' })}
                                                {isExpired(license.expiryDate) && ' (মেয়াদোত্তীর্ণ)'}
                                            </span>
                                        ) : 'নেই'}
                                    </td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <a href={license.fileUrl} target="_blank" rel="noopener noreferrer" download={license.fileName} className="inline-block p-2 text-green-600 hover:text-green-800 hover:bg-green-100 rounded-full transition-colors" title="দেখুন / ডাউনলোড করুন">
                                            <EyeIcon className="w-4 h-4" />
                                        </a>
                                        <button onClick={() => handleDelete(license)} className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors" title="মুছুন">
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={3} className="text-center py-10 text-gray-500">
                                        <p>কোনো নথি যোগ করা হয়নি।</p>
                                        <p className="mt-1">শুরু করতে "নতুন নথি যোগ করুন" বাটনে ক্লিক করুন।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
            
            <LicenseModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
            />

            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="নথি মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই নথিটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default License;
