
import React from 'react';
import { useAuth } from '../../../context/AuthContext';
import PageHeader from '../../../components/PageHeader';
import { InfoIcon } from '../../../components/icons';

const InstitutionCode: React.FC = () => {
    const { user } = useAuth(); // Get current user from AuthContext

    return (
        <div>
            <PageHeader icon="🔢" title="প্রতিষ্ঠান কোড" />
            
            <div className="bg-white p-6 rounded-xl shadow-md max-w-lg mx-auto">
                <div className="space-y-4">
                    <div>
                        <label htmlFor="institutionCode" className="block text-sm font-medium text-gray-700 mb-1">
                            আপনার প্রতিষ্ঠানের কোড
                        </label>
                        <input
                            id="institutionCode"
                            type="text"
                            value={user?.institutionCode || 'N/A'}
                            className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed font-mono text-lg"
                            readOnly
                        />
                    </div>
                </div>
            </div>

            <div className="mt-6 max-w-lg mx-auto p-4 bg-blue-50 border-l-4 border-blue-400 text-blue-800 rounded-r-lg">
                <div className="flex">
                    <div className="py-1">
                        <InfoIcon className="w-6 h-6 mr-3" />
                    </div>
                    <div>
                        <p className="font-bold">গুরুত্বপূর্ণ তথ্য</p>
                        <p className="text-sm">এই কোডটি শুধুমাত্র সুপার অ্যাডমিন পরিবর্তন করতে পারবেন।</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default InstitutionCode;
