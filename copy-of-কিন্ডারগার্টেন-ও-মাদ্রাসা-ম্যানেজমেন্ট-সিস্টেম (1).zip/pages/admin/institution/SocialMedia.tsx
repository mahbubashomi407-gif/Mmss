
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

interface SocialMediaFormState {
    website: string;
    facebook: string;
    youtube: string;
}

const InputField: React.FC<{ 
    name: keyof SocialMediaFormState, 
    label: string, 
    placeholder: string, 
    value: string,
    onChange: (name: keyof SocialMediaFormState, value: string) => void
}> = ({ name, label, placeholder, value, onChange }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input 
            id={name} 
            name={name} 
            type="url" 
            value={value} 
            onChange={(e) => onChange(name, e.target.value)}
            placeholder={placeholder} 
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
        />
    </div>
);


const SocialMedia: React.FC = () => {
    const { socialMediaLinks, setSocialMediaLinks } = useInstitution();
    const { addToast } = useNotification();
    const [formData, setFormData] = useState<SocialMediaFormState>(socialMediaLinks);

    const hasUnsavedChanges = JSON.stringify(formData) !== JSON.stringify(socialMediaLinks);

    const handleChange = (name: keyof SocialMediaFormState, value: string) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleCancel = () => {
        setFormData(socialMediaLinks);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setSocialMediaLinks(formData);
        addToast('সোশ্যাল মিডিয়া লিঙ্ক সফলভাবে সংরক্ষণ করা হয়েছে!');
    };
    
    return (
        <div>
            <PageHeader icon="🌐" title="ওয়েবসাইট / সোশ্যাল মিডিয়া" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-4">
                    <InputField 
                        name="website" 
                        label="ওয়েবসাইট" 
                        placeholder="https://example.com" 
                        value={formData.website} 
                        onChange={handleChange}
                    />
                    <InputField 
                        name="facebook" 
                        label="ফেসবুক পেজ" 
                        placeholder="https://facebook.com/yourpage" 
                        value={formData.facebook} 
                        onChange={handleChange}
                    />
                    <InputField 
                        name="youtube" 
                        label="ইউটিউব চ্যানেল" 
                        placeholder="https://youtube.com/yourchannel" 
                        value={formData.youtube} 
                        onChange={handleChange}
                    />
                    
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t">
                        {hasUnsavedChanges && (
                            <button type="button" onClick={handleCancel} className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition-colors w-full sm:w-auto">বাতিল</button>
                        )}
                        <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed w-full sm:w-auto">সংরক্ষণ করুন</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default SocialMedia;
