
import React, { useState } from 'react';
import { useInstitution, ActivityData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import ActivityModal from '../../../components/ActivityModal';
import { PencilIcon, TrashIcon, CogIcon, CheckCircleIcon } from '../../../components/icons';
import PageHeader from '../../../components/PageHeader';

const ManageActivities: React.FC = () => {
    const { activities, setActivities } = useInstitution();
    const { addToast } = useNotification();

    const [isEditMode, setIsEditMode] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedActivity, setSelectedActivity] = useState<ActivityData | null>(null);

    const handleAddNew = () => {
        setSelectedActivity(null);
        setIsModalOpen(true);
    };

    const handleEdit = (activity: ActivityData) => {
        setSelectedActivity(activity);
        setIsModalOpen(true);
    };
    
    const handleDelete = (activity: ActivityData) => {
        setSelectedActivity(activity);
        setIsDeleteModalOpen(true);
    };
    
    const handleConfirmDelete = () => {
        if (selectedActivity) {
            const updatedActivities = activities.filter(a => a.id !== selectedActivity.id);
            setActivities(updatedActivities);
            addToast('কার্যক্রম সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedActivity(null);
    };

    const handleSave = (activityData: Omit<ActivityData, 'id'> & { id?: string }) => {
        if (activityData.id) { // Editing
            const updatedActivities = activities.map(a => a.id === activityData.id ? { ...a, ...activityData } : a);
            setActivities(updatedActivities);
            addToast('কার্যক্রম সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newActivity = { ...activityData, id: Date.now().toString() };
            setActivities([...activities, newActivity]);
            addToast('নতুন কার্যক্রম সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        setIsModalOpen(false);
        setSelectedActivity(null);
    };

    return (
        <div>
            <PageHeader icon="✨" title="কার্যক্রম">
                {isEditMode && (
                    <button
                        onClick={handleAddNew}
                        className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                    >
                        নতুন কার্যক্রম যোগ করুন
                    </button>
                )}
                <button
                    onClick={() => setIsEditMode(prev => !prev)}
                    className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-200 rounded-full transition-colors"
                    title={isEditMode ? "সম্পাদনা শেষ করুন" : "কার্যক্রম সম্পাদনা করুন"}
                >
                    {isEditMode ? <CheckCircleIcon className="w-6 h-6 text-green-600" /> : <CogIcon className="w-6 h-6" />}
                </button>
            </PageHeader>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {activities.map(activity => (
                    <div key={activity.id} className={`bg-white p-5 rounded-xl shadow-md flex flex-col transition-all duration-200 ${isEditMode ? 'ring-2 ring-teal-300' : ''}`}>
                        <div className="flex-grow">
                            <h3 className="text-lg font-bold text-gray-800 mb-2">{activity.title}</h3>
                            <p className="text-sm text-gray-600 whitespace-pre-wrap">{activity.description}</p>
                        </div>
                        {isEditMode && (
                            <div className="mt-4 pt-3 border-t border-gray-100 flex justify-end gap-2">
                                <button onClick={() => handleEdit(activity)} className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" title="সম্পাদনা">
                                    <PencilIcon className="w-4 h-4" />
                                </button>
                                <button onClick={() => handleDelete(activity)} className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors" title="মুছুন">
                                    <TrashIcon className="w-4 h-4" />
                                </button>
                            </div>
                        )}
                    </div>
                ))}

                 {activities.length === 0 && (
                    <div className="md:col-span-2 lg:col-span-3 text-center py-10 text-gray-500 bg-white rounded-xl shadow-md">
                        <p>কোনো কার্যক্রম যোগ করা হয়নি।</p>
                        {isEditMode && <p>শুরু করতে "নতুন কার্যক্রম যোগ করুন" বাটনে ক্লিক করুন।</p>}
                    </div>
                )}
            </div>

            <ActivityModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                activityToEdit={selectedActivity}
            />
            
            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="কার্যক্রম মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই কার্যক্রমটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default ManageActivities;
