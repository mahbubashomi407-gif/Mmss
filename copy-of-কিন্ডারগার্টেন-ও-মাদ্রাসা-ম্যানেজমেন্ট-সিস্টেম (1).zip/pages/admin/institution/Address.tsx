
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

interface AddressFormState {
    village: string;
    postOffice: string;
    upazila: string;
    district: string;
    division: string;
    country: string;
    mapLink: string;
}

const InputField: React.FC<{ 
    name: keyof AddressFormState, 
    label: string, 
    placeholder: string, 
    type?: string, 
    required?: boolean,
    readOnly?: boolean,
    value: string,
    onChange: (name: keyof AddressFormState, value: string) => void
}> = ({ name, label, placeholder, type = 'text', required = true, readOnly = false, value, onChange }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input 
            id={name} 
            name={name} 
            type={type} 
            value={value} 
            onChange={(e) => !readOnly && onChange(name, e.target.value)}
            placeholder={placeholder} 
            required={required}
            readOnly={readOnly}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 read-only:bg-gray-100 read-only:cursor-not-allowed"
        />
    </div>
);


const Address: React.FC = () => {
    const { address, setAddress } = useInstitution();
    const { addToast } = useNotification();
    const [formData, setFormData] = useState<AddressFormState>(address);

    const hasUnsavedChanges = JSON.stringify(formData) !== JSON.stringify(address);

    const handleChange = (name: keyof AddressFormState, value: string) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleCancel = () => {
        setFormData(address);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setAddress(formData);
        addToast('ঠিকানা সফলভাবে সংরক্ষণ করা হয়েছে!');
    };
    
    return (
        <div>
            <PageHeader icon="📍" title="ঠিকানা / লোকেশন" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <InputField name="division" label="বিভাগ" placeholder="উদাহরণ: ঢাকা" value={formData.division} onChange={handleChange} />
                        <InputField name="district" label="জেলা" placeholder="উদাহরণ: ঢাকা" value={formData.district} onChange={handleChange} />
                        <InputField name="upazila" label="থানা/উপজেলা" placeholder="উদাহরণ: গুলশান" value={formData.upazila} onChange={handleChange} />
                        <InputField name="postOffice" label="ডাকঘর" placeholder="উদাহরণ: গুলশান" value={formData.postOffice} onChange={handleChange} />
                        <div className="md:col-span-2">
                           <InputField name="village" label="গ্রাম/মহল্লা" placeholder="উদাহরণ: রোড নং-১, বাড়ি নং-২" value={formData.village} onChange={handleChange} />
                        </div>
                        <InputField name="country" label="দেশ" placeholder="উদাহরণ: বাংলাদেশ" value={formData.country} onChange={handleChange} readOnly />
                        <InputField name="mapLink" label="গুগল ম্যাপ লিঙ্ক (ঐচ্ছিক)" placeholder="https://maps.app.goo.gl/..." type="url" required={false} value={formData.mapLink} onChange={handleChange} />
                    </div>
                    
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t">
                        {hasUnsavedChanges && (
                            <button type="button" onClick={handleCancel} className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition-colors w-full sm:w-auto">বাতিল</button>
                        )}
                        <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed w-full sm:w-auto">সংরক্ষণ করুন</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default Address;
