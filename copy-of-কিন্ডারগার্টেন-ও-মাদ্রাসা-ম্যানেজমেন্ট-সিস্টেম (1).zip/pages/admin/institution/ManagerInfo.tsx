import React, { useState, useRef } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
// FIX: Import UploadIcon from shared icons component and remove local definition.
import { UploadIcon } from '../../../components/icons';

interface ManagerFormState {
    name: string;
    designation: string;
    phone: string;
    email: string;
    message: string;
    photoUrl: string | null;
    signatureUrl: string | null;
}

const ImageUploader: React.FC<{
    label: string;
    imageUrl: string | null;
    onFileSelect: (file: File | null) => void;
    isSignature?: boolean;
}> = ({ label, imageUrl, onFileSelect, isSignature = false }) => {
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        onFileSelect(file || null);
    };

    const containerClasses = isSignature 
        ? "w-48 h-24 rounded-lg" 
        : "w-32 h-32 rounded-full";
    
    const imageClasses = isSignature ? "w-full h-full object-contain" : "w-full h-full object-cover";

    return (
        <div className="flex flex-col items-center gap-2">
            <label className="text-sm font-medium text-gray-700">{label}</label>
            <div className={`${containerClasses} border-2 border-dashed border-gray-300 flex items-center justify-center overflow-hidden bg-gray-50 text-gray-400 p-1`}>
                {imageUrl ? (
                    <img src={imageUrl} alt={label} className={imageClasses} />
                ) : (
                    <span className="text-xs text-center p-2">{label} নেই</span>
                )}
            </div>
            <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
            />
            <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="text-sm flex items-center gap-1 px-3 py-1 bg-white text-gray-700 font-semibold rounded-lg shadow-sm hover:bg-gray-50 transition-colors border border-gray-200"
            >
                <UploadIcon className="w-4 h-4" />
                <span>{imageUrl ? 'পরিবর্তন করুন' : 'আপলোড করুন'}</span>
            </button>
        </div>
    );
};


const ManagerInfo: React.FC = () => {
    const { managerInfo, setManagerInfo } = useInstitution();
    const { addToast } = useNotification();
    const [formData, setFormData] = useState<ManagerFormState>(managerInfo);

    const hasUnsavedChanges = JSON.stringify(formData) !== JSON.stringify(managerInfo);

    const handleChange = (field: keyof Omit<ManagerFormState, 'photoUrl' | 'signatureUrl'>, value: string) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const handleImageChange = (field: 'photoUrl' | 'signatureUrl', file: File | null) => {
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFormData(prev => ({ ...prev, [field]: reader.result as string }));
            };
            reader.readAsDataURL(file);
        }
    };
    
    const handleCancel = () => {
        setFormData(managerInfo);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setManagerInfo(formData);
        addToast('তথ্য সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };

    return (
        <div>
            <PageHeader icon="👨‍🏫" title="প্রধান শিক্ষক / ম্যানেজার তথ্য" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-4xl mx-auto">
                <form onSubmit={handleSubmit}>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Left Side: Text Info */}
                        <div className="md:col-span-2 space-y-4">
                            <div>
                                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">নাম</label>
                                <input id="name" type="text" value={formData.name} onChange={e => handleChange('name', e.target.value)} placeholder="সম্পূর্ণ নাম" required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" />
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <label htmlFor="designation" className="block text-sm font-medium text-gray-700 mb-1">পদবি</label>
                                    <input id="designation" type="text" value={formData.designation} onChange={e => handleChange('designation', e.target.value)} placeholder="প্রধান শিক্ষক / অধ্যক্ষ" required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" />
                                </div>
                                <div>
                                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">মোবাইল নম্বর</label>
                                    <input id="phone" type="tel" value={formData.phone} onChange={e => handleChange('phone', e.target.value)} placeholder="01..." required className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" />
                                </div>
                            </div>
                            <div>
                                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">ইমেইল (ঐচ্ছিক)</label>
                                <input id="email" type="email" value={formData.email} onChange={e => handleChange('email', e.target.value)} placeholder="example@mail.com" className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" />
                            </div>
                            <div>
                                <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">প্রধান শিক্ষকের বার্তা (ঐচ্ছিক)</label>
                                <textarea id="message" value={formData.message} onChange={e => handleChange('message', e.target.value)} rows={4} placeholder="প্রতিষ্ঠানের পক্ষ থেকে একটি সংক্ষিপ্ত বার্তা..." className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500" />
                            </div>
                        </div>

                        {/* Right Side: Image Uploads */}
                        <div className="md:col-span-1 flex flex-col items-center justify-center gap-6 bg-gray-50 p-4 rounded-lg">
                            <ImageUploader label="ছবি" imageUrl={formData.photoUrl} onFileSelect={(file) => handleImageChange('photoUrl', file)} />
                            <ImageUploader label="স্বাক্ষর" imageUrl={formData.signatureUrl} onFileSelect={(file) => handleImageChange('signatureUrl', file)} isSignature />
                        </div>
                    </div>
                    
                    {/* Action Buttons */}
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-6 mt-6 border-t">
                        {hasUnsavedChanges && (
                            <button type="button" onClick={handleCancel} className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition-colors w-full sm:w-auto">বাতিল</button>
                        )}
                        <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed w-full sm:w-auto">সংরক্ষণ করুন</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ManagerInfo;