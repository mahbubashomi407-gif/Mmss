
import React, { useState } from 'react';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import PageHeader from '../../../components/PageHeader';
import Modal from '../../../components/Modal';

const InstitutionName: React.FC = () => {
    const { institutionName, setInstitutionName } = useInstitution();
    const { addToast } = useNotification();
    const [name, setName] = useState(institutionName);
    const [isModalOpen, setIsModalOpen] = useState(false);

    const hasUnsavedChanges = name !== institutionName;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (name.trim() === '') {
            addToast('প্রতিষ্ঠানের নাম খালি হতে পারে না!', 'error');
            return;
        }
        setInstitutionName(name);
        addToast('প্রতিষ্ঠানের নাম সফলভাবে সংরক্ষণ করা হয়েছে!');
    };

    const handleCancel = () => {
        setName(institutionName);
    };

    const handleConfirmReset = () => {
        const defaultName = 'আমার প্রতিষ্ঠান';
        setInstitutionName(defaultName);
        setName(defaultName);
        addToast('নাম ডিফল্ট হিসাবে রিসেট করা হয়েছে!');
        setIsModalOpen(false);
    };

    return (
        <div>
            <PageHeader icon="🏷️" title="প্রতিষ্ঠান নাম" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-lg mx-auto">
                <form onSubmit={handleSubmit}>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="institutionName" className="block text-sm font-medium text-gray-700 mb-1">
                                প্রতিষ্ঠানের নাম লিখুন
                            </label>
                            <input
                                id="institutionName"
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                                placeholder="আপনার প্রতিষ্ঠানের নাম"
                                required
                            />
                        </div>
                        
                        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t">
                            {hasUnsavedChanges && (
                                <button
                                    type="button"
                                    onClick={handleCancel}
                                    className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition-colors w-full sm:w-auto"
                                >
                                    বাতিল
                                </button>
                            )}
                            <button
                                type="submit"
                                disabled={!hasUnsavedChanges || name.trim() === ''}
                                className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed w-full sm:w-auto"
                            >
                                সংরক্ষণ করুন
                            </button>
                        </div>
                    </div>
                </form>

                <div className="mt-4 text-center">
                    <button
                        type="button"
                        onClick={() => setIsModalOpen(true)}
                        className="text-sm text-red-500 hover:text-red-700 hover:underline"
                    >
                        ডিফল্ট নামে রিসেট করুন
                    </button>
                </div>
            </div>

            <Modal 
                isOpen={isModalOpen} 
                onClose={() => setIsModalOpen(false)} 
                onConfirm={handleConfirmReset}
                title="নাম রিসেট করুন"
            >
                <p>আপনি কি নিশ্চিতভাবে প্রতিষ্ঠানের নাম ডিফল্ট হিসাবে রিসেট করতে চান?</p>
            </Modal>
        </div>
    );
};

export default InstitutionName;
