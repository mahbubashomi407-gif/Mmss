
import React, { useRef, useState, useEffect } from 'react';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import PageHeader from '../../../components/PageHeader';

const UploadLogo: React.FC = () => {
    const { logoUrl, setLogo } = useInstitution();
    const { addToast } = useNotification();
    const fileInputRef = useRef<HTMLInputElement>(null);

    const [previewUrl, setPreviewUrl] = useState<string | null>(logoUrl);
    const [selectedFile, setSelectedFile] = useState<File | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    
    // Sync preview with context if it changes elsewhere
    useEffect(() => {
        setPreviewUrl(logoUrl);
    }, [logoUrl]);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setSelectedFile(file);
            const reader = new FileReader();
            reader.onloadend = () => {
                setPreviewUrl(reader.result as string);
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSave = () => {
        if (previewUrl) {
            setLogo(previewUrl);
            addToast('লোগো সফলভাবে সংরক্ষণ করা হয়েছে!');
            setSelectedFile(null); // Reset file selection
        }
    };

    const handleCancel = () => {
        setPreviewUrl(logoUrl);
        setSelectedFile(null);
        if (fileInputRef.current) {
            fileInputRef.current.value = '';
        }
    };
    
    const handleDelete = () => {
        setLogo(null);
        setPreviewUrl(null);
        setSelectedFile(null);
        setIsModalOpen(false);
        addToast('লোগো সফলভাবে মুছে ফেলা হয়েছে!');
    };

    const hasUnsavedChanges = selectedFile !== null && previewUrl !== logoUrl;

    return (
        <div>
            <PageHeader icon="🏢" title="প্রতিষ্ঠান লোগো আপলোড" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-md mx-auto">
                <div className="flex flex-col items-center space-y-4">
                    <h2 className="text-lg font-semibold text-gray-700">লোগো প্রিভিউ</h2>
                    <div className="w-32 h-32 rounded-full border-4 border-gray-200 flex items-center justify-center overflow-hidden bg-gray-100">
                        {previewUrl ? (
                            <img src={previewUrl} alt="Institution Logo Preview" className="w-full h-full object-cover" />
                        ) : (
                            <span className="text-gray-400">লোগো নেই</span>
                        )}
                    </div>

                    <input
                        type="file"
                        ref={fileInputRef}
                        onChange={handleFileChange}
                        accept="image/*"
                        className="hidden"
                    />
                    
                    <button
                        onClick={() => fileInputRef.current?.click()}
                        className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors"
                    >
                        {logoUrl ? 'লোগো পরিবর্তন করুন' : 'লোগো আপলোড করুন'}
                    </button>
                    
                    <div className="flex items-center gap-3 pt-4 border-t w-full justify-center">
                        {hasUnsavedChanges && (
                             <button
                                onClick={handleCancel}
                                className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition-colors"
                            >
                                বাতিল
                            </button>
                        )}
                        <button
                            onClick={handleSave}
                            disabled={!hasUnsavedChanges}
                            className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
                        >
                            সংরক্ষণ করুন
                        </button>
                    </div>

                    {logoUrl && (
                        <button
                            onClick={() => setIsModalOpen(true)}
                            className="text-sm text-red-500 hover:text-red-700 hover:underline mt-2"
                        >
                            লোগো মুছুন
                        </button>
                    )}
                </div>
            </div>
            
            <Modal 
                isOpen={isModalOpen} 
                onClose={() => setIsModalOpen(false)} 
                onConfirm={handleDelete}
                title="লোগো মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই লোগোটি মুছে ফেলতে চান? এই কাজটি ফিরিয়ে আনা যাবে না।</p>
            </Modal>
        </div>
    );
};

export default UploadLogo;
