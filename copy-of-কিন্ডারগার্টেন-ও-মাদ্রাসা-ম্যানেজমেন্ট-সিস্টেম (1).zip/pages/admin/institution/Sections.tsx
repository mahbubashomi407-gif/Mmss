import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution, SectionData } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';
import Modal from '../../../components/Modal';
import SectionModal from '../../../components/SectionModal';
import { PencilIcon, TrashIcon } from '../../../components/icons';

const Sections: React.FC = () => {
    const { sections, setSections, classLevels, teachers } = useInstitution();
    const { addToast } = useNotification();
    
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedSection, setSelectedSection] = useState<SectionData | null>(null);

    const handleAddNew = () => {
        setSelectedSection(null);
        setIsModalOpen(true);
    };

    const handleEdit = (section: SectionData) => {
        setSelectedSection(section);
        setIsModalOpen(true);
    };
    
    const handleDelete = (section: SectionData) => {
        setSelectedSection(section);
        setIsDeleteModalOpen(true);
    };
    
    const handleConfirmDelete = () => {
        if (selectedSection) {
            const updatedSections = sections.filter(s => s.id !== selectedSection.id);
            setSections(updatedSections);
            addToast('সেকশন সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedSection(null);
    };

    const handleSave = (sectionData: Omit<SectionData, 'id' | 'studentCount'> & { id?: string }) => {
        if (sectionData.id) { // Editing
            const updatedSections = sections.map(s => 
                s.id === sectionData.id ? { ...s, ...sectionData } : s
            );
            setSections(updatedSections);
            addToast('সেকশন সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newSection = { ...sectionData, id: Date.now().toString(), studentCount: 0 }; // New sections start with 0 students
            setSections([...sections, newSection]);
            addToast('নতুন সেকশন সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        
        setIsModalOpen(false);
        setSelectedSection(null);
    };

    return (
        <div>
            <PageHeader icon="🗂️" title="বিভাগ / সেকশন তালিকা">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    নতুন সেকশন যোগ করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-500">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th scope="col" className="px-6 py-3">শ্রেণি</th>
                                <th scope="col" className="px-6 py-3">সেকশনের নাম</th>
                                <th scope="col" className="px-6 py-3">শ্রেণি শিক্ষক</th>
                                <th scope="col" className="px-6 py-3">শিক্ষার্থী সংখ্যা</th>
                                <th scope="col" className="px-6 py-3 text-right">পদক্ষেপ</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sections.length > 0 ? sections.map(section => (
                                <tr key={section.id} className="bg-white border-b hover:bg-gray-50">
                                    <td className="px-6 py-4 font-medium text-gray-900">{section.classLevel}</td>
                                    <td className="px-6 py-4">{section.name}</td>
                                    <td className="px-6 py-4">{section.teacherName || 'নেই'}</td>
                                    <td className="px-6 py-4">{section.studentCount}</td>
                                    <td className="px-6 py-4 text-right space-x-2">
                                        <button onClick={() => handleEdit(section)} className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-100 rounded-full transition-colors" title="সম্পাদনা">
                                            <PencilIcon className="w-4 h-4" />
                                        </button>
                                        <button onClick={() => handleDelete(section)} className="p-2 text-red-600 hover:text-red-800 hover:bg-red-100 rounded-full transition-colors" title="মুছুন">
                                            <TrashIcon className="w-4 h-4" />
                                        </button>
                                    </td>
                                </tr>
                            )) : (
                                <tr>
                                    <td colSpan={5} className="text-center py-10 text-gray-500">
                                        <p>কোনো সেকশন যোগ করা হয়নি।</p>
                                        <p className="mt-1">শুরু করতে "নতুন সেকশন যোগ করুন" বাটনে ক্লিক করুন।</p>
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>

            <SectionModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                sectionToEdit={selectedSection}
                classLevels={classLevels}
                teachers={teachers}
            />

            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="সেকশন মুছে ফেলুন"
            >
                <p>আপনি কি নিশ্চিতভাবে এই সেকশনটি মুছে ফেলতে চান?</p>
            </Modal>
        </div>
    );
};

export default Sections;