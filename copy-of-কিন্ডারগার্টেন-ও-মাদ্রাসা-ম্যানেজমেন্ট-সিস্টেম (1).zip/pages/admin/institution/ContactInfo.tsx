
import React, { useState } from 'react';
import PageHeader from '../../../components/PageHeader';
import { useInstitution } from '../../../context/InstitutionContext';
import { useNotification } from '../../../context/NotificationContext';

interface ContactFormState {
    primaryPhone: string;
    secondaryPhone: string;
    email: string;
    website: string;
}

const InputField: React.FC<{ 
    name: keyof ContactFormState, 
    label: string, 
    placeholder: string, 
    type?: string, 
    required?: boolean,
    value: string,
    onChange: (name: keyof ContactFormState, value: string) => void
}> = ({ name, label, placeholder, type = 'text', required = false, value, onChange }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
        <input 
            id={name} 
            name={name} 
            type={type} 
            value={value} 
            onChange={(e) => onChange(name, e.target.value)}
            placeholder={placeholder} 
            required={required}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
        />
    </div>
);


const ContactInfo: React.FC = () => {
    const { contactInfo, setContactInfo } = useInstitution();
    const { addToast } = useNotification();
    const [formData, setFormData] = useState<ContactFormState>(contactInfo);

    const hasUnsavedChanges = JSON.stringify(formData) !== JSON.stringify(contactInfo);

    const handleChange = (name: keyof ContactFormState, value: string) => {
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleCancel = () => {
        setFormData(contactInfo);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setContactInfo(formData);
        addToast('যোগাযোগের তথ্য সফলভাবে সংরক্ষণ করা হয়েছে!');
    };
    
    return (
        <div>
            <PageHeader icon="📞" title="যোগাযোগ নম্বর / ইমেইল" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-2xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <InputField 
                            name="primaryPhone" 
                            label="প্রধান মোবাইল নম্বর" 
                            placeholder="উদাহরণ: 017..." 
                            type="tel" 
                            value={formData.primaryPhone} 
                            onChange={handleChange}
                            required={true}
                        />
                        <InputField 
                            name="secondaryPhone" 
                            label="বিকল্প মোবাইল নম্বর (ঐচ্ছিক)" 
                            placeholder="উদাহরণ: 018..." 
                            type="tel" 
                            value={formData.secondaryPhone} 
                            onChange={handleChange}
                        />
                         <div className="md:col-span-2">
                             <InputField 
                                name="email" 
                                label="প্রাতিষ্ঠানিক ইমেইল (ঐচ্ছিক)" 
                                placeholder="উদাহরণ: info@example.com" 
                                type="email" 
                                value={formData.email} 
                                onChange={handleChange}
                            />
                        </div>
                         <div className="md:col-span-2">
                            <InputField 
                                name="website" 
                                label="ওয়েবসাইট (ঐচ্ছিক)" 
                                placeholder="উদাহরণ: https://example.com" 
                                type="url" 
                                value={formData.website} 
                                onChange={handleChange}
                            />
                        </div>
                    </div>
                    
                    <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4 border-t">
                        {hasUnsavedChanges && (
                            <button type="button" onClick={handleCancel} className="px-6 py-2 bg-gray-500 text-white font-semibold rounded-lg shadow-md hover:bg-gray-600 transition-colors w-full sm:w-auto">বাতিল</button>
                        )}
                        <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed w-full sm:w-auto">সংরক্ষণ করুন</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default ContactInfo;