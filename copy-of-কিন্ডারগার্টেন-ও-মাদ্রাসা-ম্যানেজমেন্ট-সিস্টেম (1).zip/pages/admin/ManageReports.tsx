import React from 'react';
import { useInstitution } from '../../context/InstitutionContext';
import { Link } from 'react-router-dom';

// Reusable card component for report management actions
const ReportActionCard: React.FC<{ icon: string; title: string }> = ({ icon, title }) => {
    const { logoUrl } = useInstitution();
    return (
        <div 
            className="bg-white p-3 rounded-xl shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
            role="button"
            tabIndex={0}
            aria-label={title}
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2">
                {logoUrl ? (
                    <img src={logoUrl} alt={title} className="w-full h-full rounded-full object-cover" />
                ) : (
                    <span className="text-3xl md:text-4xl">{icon}</span>
                )}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </div>
    );
};


const ManageReports: React.FC = () => {
    
    const reportActions = [
      { to: '/app/students/list', icon: '📋', title: 'শিক্ষার্থী তালিকা রিপোর্ট' },
      { to: '/app/attendance/report', icon: '📅', title: 'মাসিক হাজিরা রিপোর্ট' },
      { to: '/app/homework/list', icon: '📝', title: 'হোমওয়ার্ক রিপোর্ট' },
      { to: '/app/reports/student-fee-report', icon: '💰', title: 'শিক্ষার্থী ফি রিপোর্ট' },
      { to: '/app/reports/class-fee-summary-report', icon: '🏦', title: 'ফি সংগ্রহ রিপোর্ট (শ্রেণিভিত্তিক)' },
      { to: '/app/attendance/export', icon: '⬆️', title: 'এক্সপোর্ট রিপোর্ট' },
    ];

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-6">📊 রিপোর্ট ও ডাটা</h1>
            
            <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 sm:gap-4">
                {reportActions.map((action, index) => (
                    <Link to={action.to} key={index} className="no-underline h-full">
                        <ReportActionCard icon={action.icon} title={action.title} />
                    </Link>
                ))}
            </div>
        </div>
    );
};

export default ManageReports;