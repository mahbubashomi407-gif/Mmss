
import React from 'react';
import { Link } from 'react-router-dom';
import { useInstitution } from '../context/InstitutionContext';
import { BuildingOfficeIcon, UsersIcon } from '../components/icons';

const PortalSelection: React.FC = () => {
    const { institutionName, logoUrl } = useInstitution();
    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-gray-100 to-gray-200 p-4">
            <div className="text-center mb-8">
                {logoUrl && <img src={logoUrl} alt={institutionName} className="w-24 h-24 rounded-full mx-auto mb-4 border-4 border-white shadow-lg" />}
                <h1 className="text-3xl font-bold text-gray-800">{institutionName}</h1>
                <p className="text-gray-500 mt-2">আপনার পোর্টালে স্বাগতম। অনুগ্রহ করে লগইন করার জন্য একটি অপশন বেছে নিন।</p>
            </div>
            <div className="w-full max-w-lg grid grid-cols-1 md:grid-cols-2 gap-6">
                <Link to="/login" className="no-underline">
                    <div className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                        <BuildingOfficeIcon className="w-16 h-16 text-teal-500 mx-auto mb-3" />
                        <h2 className="text-xl font-bold text-gray-800">ম্যানেজমেন্ট পোর্টাল</h2>
                        <p className="text-sm text-gray-500 mt-1">অ্যাডমিন, শিক্ষক, হিসাবরক্ষক</p>
                    </div>
                </Link>
                <Link to="/student-login" className="no-underline">
                    <div className="bg-white rounded-2xl shadow-lg p-6 text-center hover:shadow-2xl hover:-translate-y-1 transition-all duration-300">
                        <UsersIcon className="w-16 h-16 text-green-500 mx-auto mb-3" />
                        <h2 className="text-xl font-bold text-gray-800">শিক্ষার্থী/অভিভাবক পোর্টাল</h2>
                        <p className="text-sm text-gray-500 mt-1">শিক্ষার্থী ও অভিভাবক</p>
                    </div>
                </Link>
            </div>
        </div>
    );
};
export default PortalSelection;
