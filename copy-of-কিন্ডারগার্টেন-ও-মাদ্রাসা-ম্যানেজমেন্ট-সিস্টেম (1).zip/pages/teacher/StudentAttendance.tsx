
import React, { useState, useEffect, useMemo } from 'react';
import { Student } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';
import { StudentData } from '../../context/InstitutionContext';

const StudentAttendance: React.FC = () => {
    const { user } = useAuth();
    const { teachers, sections, students: allStudentsData } = useInstitution();
    const [attendance, setAttendance] = useState<Record<string, 'present' | 'absent'>>({});
    const [loading, setLoading] = useState(false);

    const students: Student[] = useMemo(() => {
        if (!user) return [];
        const currentTeacher = teachers.find(t => t.id === user.uid);
        if (!currentTeacher) return [];

        const assignedSections = sections.filter(s => s.teacherName === currentTeacher.nameBn);
        if (assignedSections.length === 0) return [];

        const assignedSectionMap = new Map(assignedSections.map(s => [`${s.classLevel}-${s.name}`, true]));

        const assignedStudentsData = allStudentsData.filter(s => assignedSectionMap.has(`${s.classLevel}-${s.section}`));
        
        return assignedStudentsData.map((s: StudentData): Student => ({
            id: s.id,
            name: s.nameBn,
            class: s.classLevel,
            roll: Number(s.roll) || 0,
            guardianId: s.fatherPhone,
            guardianName: s.fatherNameBn,
        }));
    }, [user, teachers, sections, allStudentsData]);

    useEffect(() => {
        // Initialize attendance state when students list is available
        const initialAttendance = students.reduce((acc, student) => {
            acc[student.id] = 'present';
            return acc;
        }, {} as Record<string, 'present' | 'absent'>);
        setAttendance(initialAttendance);
    }, [students]);

    const handleStatusChange = (studentId: string, status: 'present' | 'absent') => {
        setAttendance(prev => ({ ...prev, [studentId]: status }));
    };

    const handleSubmit = () => {
        alert('হাজিরা জমা দেওয়া হয়েছে!');
        console.log(attendance);
    };

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">শিক্ষার্থীদের হাজিরা</h1>
            <div className="bg-white rounded-xl shadow-lg p-4">
                <div className="mb-4">
                    <label htmlFor="class-select" className="mr-2 font-semibold text-sm">শ্রেণী নির্বাচন করুন:</label>
                    <select id="class-select" className="p-2 border rounded-md text-sm">
                        <option>প্লে</option>
                        <option>নার্সারি</option>
                    </select>
                </div>
                {loading ? <p>লোড হচ্ছে...</p> : (
                    <div className="space-y-3">
                        {students.map(student => (
                            <div key={student.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg text-sm">
                                <span className="font-medium text-gray-800">{student.name} (রোল: {student.roll})</span>
                                <div className="flex items-center gap-3">
                                    <label className="flex items-center cursor-pointer">
                                        <input
                                            type="radio"
                                            name={`attendance-${student.id}`}
                                            checked={attendance[student.id] === 'present'}
                                            onChange={() => handleStatusChange(student.id, 'present')}
                                            className="form-radio h-4 w-4 text-green-600"
                                        />
                                        <span className="ml-2 text-green-700">উপস্থিত</span>
                                    </label>
                                    <label className="flex items-center cursor-pointer">
                                        <input
                                            type="radio"
                                            name={`attendance-${student.id}`}
                                            checked={attendance[student.id] === 'absent'}
                                            onChange={() => handleStatusChange(student.id, 'absent')}
                                            className="form-radio h-4 w-4 text-red-600"
                                        />
                                        <span className="ml-2 text-red-700">অনুপস্থিত</span>
                                    </label>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
                <div className="mt-4 text-right">
                    <button onClick={handleSubmit} className="px-5 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition-colors">
                        হাজিরা জমা দিন
                    </button>
                </div>
            </div>
        </div>
    );
};

export default StudentAttendance;