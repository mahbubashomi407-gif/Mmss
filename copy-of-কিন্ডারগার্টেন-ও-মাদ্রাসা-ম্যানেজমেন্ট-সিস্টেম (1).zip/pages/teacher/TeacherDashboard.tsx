
import React, { useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { DASHBOARD_ITEMS } from '../../constants/dashboardMap';
import DashboardActionCard from '../../components/DashboardActionCard';

const TeacherDashboard: React.FC = () => {
    const { user, hasPermission } = useAuth();

    const accessibleItems = useMemo(() => {
        if (!user) return [];
        return DASHBOARD_ITEMS.filter(item => 
            item.roles.includes('teacher') && hasPermission(item.permission)
        );
    }, [user, hasPermission]);

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">শিক্ষক ড্যাশবোর্ড</h1>
            
            <div className="mt-6 bg-white p-4 rounded-xl shadow-lg">
                <h2 className="text-lg font-bold text-gray-800 mb-3">দ্রুত পদক্ষেপ</h2>
                {accessibleItems.length > 0 ? (
                     <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                        {accessibleItems.map(item => (
                            <DashboardActionCard 
                                key={item.link}
                                to={`/app/${item.link}`}
                                icon={item.icon}
                                title={item.title}
                            />
                        ))}
                    </div>
                ) : (
                    <div className="text-center py-10">
                        <p className="text-gray-500">আপনার জন্য কোনো অপশন সক্রিয় করা নেই।</p>
                        <p className="text-sm text-gray-400 mt-2">অনুগ্রহ করে এডমিনের সাথে যোগাযোগ করুন।</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default TeacherDashboard;
