
import React, { useState, useEffect, useMemo } from 'react';
import { Student } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';
import { StudentData } from '../../context/InstitutionContext';

const EnterMarks: React.FC = () => {
    const { user } = useAuth();
    const { teachers, sections, students: allStudentsData } = useInstitution();
    const [marks, setMarks] = useState<Record<string, number | ''>>({});
    const [loading, setLoading] = useState(false);
    
    const students: Student[] = useMemo(() => {
        if (!user) return [];
        const currentTeacher = teachers.find(t => t.id === user.uid);
        if (!currentTeacher) return [];

        const assignedSections = sections.filter(s => s.teacherName === currentTeacher.nameBn);
        if (assignedSections.length === 0) return [];

        const assignedSectionMap = new Map(assignedSections.map(s => [`${s.classLevel}-${s.name}`, true]));

        const assignedStudentsData = allStudentsData.filter(s => assignedSectionMap.has(`${s.classLevel}-${s.section}`));
        
        return assignedStudentsData.map((s: StudentData): Student => ({
            id: s.id,
            name: s.nameBn,
            class: s.classLevel,
            roll: Number(s.roll) || 0,
            guardianId: s.fatherPhone,
            guardianName: s.fatherNameBn,
        }));
    }, [user, teachers, sections, allStudentsData]);

    useEffect(() => {
        const initialMarks = students.reduce((acc, student) => {
            acc[student.id] = '';
            return acc;
        }, {} as Record<string, number | ''>);
        setMarks(initialMarks);
    }, [students]);

    const handleMarkChange = (studentId: string, value: string) => {
        const numValue = value === '' ? '' : Number(value);
        if (numValue === '' || (numValue >= 0 && numValue <= 100)) {
            setMarks(prev => ({ ...prev, [studentId]: numValue }));
        }
    };
    
    const handleSubmit = () => {
        alert('নম্বর জমা দেওয়া হয়েছে!');
        console.log(marks);
    };

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">নম্বর প্রদান করুন</h1>
            <div className="bg-white rounded-xl shadow-lg p-4">
                <div className="flex flex-wrap gap-4 mb-4 text-sm">
                    <div>
                        <label htmlFor="class-select" className="mr-2 font-semibold">শ্রেণী:</label>
                        <select id="class-select" className="p-2 border rounded-md">
                            <option>প্লে</option>
                            <option>নার্সারি</option>
                        </select>
                    </div>
                    <div>
                        <label htmlFor="subject-select" className="mr-2 font-semibold">বিষয়:</label>
                        <select id="subject-select" className="p-2 border rounded-md">
                            <option>বাংলা</option>
                            <option>গণিত</option>
                            <option>ইংরেজি</option>
                        </select>
                    </div>
                </div>
                {loading ? <p>লোড হচ্ছে...</p> : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="bg-gray-100">
                                    <th className="p-2 text-left font-semibold">রোল</th>
                                    <th className="p-2 text-left font-semibold">নাম</th>
                                    <th className="p-2 text-left font-semibold">নম্বর (১০০ এর মধ্যে)</th>
                                </tr>
                            </thead>
                            <tbody>
                                {students.map(student => (
                                    <tr key={student.id} className="border-b">
                                        <td className="p-2">{student.roll}</td>
                                        <td className="p-2 font-medium">{student.name}</td>
                                        <td className="p-2">
                                            <input 
                                                type="number" 
                                                value={marks[student.id]}
                                                onChange={(e) => handleMarkChange(student.id, e.target.value)}
                                                className="w-20 p-1 border rounded-md focus:ring-2 focus:ring-indigo-500"
                                                max="100"
                                                min="0"
                                            />
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
                <div className="mt-4 text-right">
                    <button onClick={handleSubmit} className="px-5 py-2 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition-colors">
                        নম্বর জমা দিন
                    </button>
                </div>
            </div>
        </div>
    );
};

export default EnterMarks;