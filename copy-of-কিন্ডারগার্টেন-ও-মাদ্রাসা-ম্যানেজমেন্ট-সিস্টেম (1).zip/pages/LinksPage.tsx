
import React, { useState, useEffect } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../services/firebase';
import type { LinkSection } from '../context/SuperAdminContext';
import PageHeader from '../components/PageHeader';
import { LinkIcon, DownloadIcon } from '../components/icons';
import Spinner from '../components/Spinner';

const transformGoogleDriveUrl = (url: string): string => {
    // Tries to find a file ID from various Google Drive URL formats.
    const regexes = [
        /drive\.google\.com\/file\/d\/([a-zA-Z0-9_-]+)/, // .../file/d/FILE_ID/...
        /drive\.google\.com\/open\?id=([a-zA-Z0-9_-]+)/,   // .../open?id=FILE_ID...
        /drive\.google\.com\/uc\?id=([a-zA-Z0-9_-]+)/     // .../uc?id=FILE_ID... (might be missing export=download)
    ];

    for (const regex of regexes) {
        const match = url.match(regex);
        if (match && match[1]) {
            const fileId = match[1];
            // Returns a URL that forces the browser to start a download.
            return `https://drive.google.com/uc?export=download&id=${fileId}`;
        }
    }

    // If it's not a recognized Google Drive file URL, return it as is.
    return url;
};


const LinksPage: React.FC = () => {
    const [linksData, setLinksData] = useState<LinkSection[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchLinks = async () => {
            setLoading(true);
            try {
                const docRef = doc(db, 'superAdminData', 'links');
                const docSnap = await getDoc(docRef);
                if (docSnap.exists() && docSnap.data().list) {
                    setLinksData(docSnap.data().list);
                }
            } catch (error) {
                console.error("Error fetching links:", error);
            } finally {
                setLoading(false);
            }
        };
        fetchLinks();
    }, []);

    if (loading) {
        return <Spinner />;
    }

    return (
        <div>
            <PageHeader icon="🔗" title="গুরুত্বপূর্ণ লিংক" />
            
            {linksData.length === 0 ? (
                <div className="bg-white p-10 rounded-xl shadow-md text-center">
                    <p className="text-gray-500">কোনো লিংক যোগ করা হয়নি।</p>
                </div>
            ) : (
                <div className="space-y-6">
                    {linksData.map(section => (
                        <div key={section.id} className="bg-white p-4 rounded-xl shadow-md">
                            <h2 className="text-xl font-bold text-gray-800 mb-3 border-b pb-2">{section.title}</h2>
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                                {section.cards.map(card => {
                                    let finalUrl = card.url;
                                    const isDownload = card.type === 'download';
                                    
                                    if (isDownload) {
                                        finalUrl = transformGoogleDriveUrl(card.url);
                                    }
                                    
                                    return (
                                        <a
                                            key={card.id}
                                            href={finalUrl}
                                            {...(isDownload ? { download: true } : { target: '_blank', rel: 'noopener noreferrer' })}
                                            className="bg-gray-50 p-4 rounded-lg flex items-center gap-4 hover:bg-teal-50 hover:shadow-sm transition-all"
                                        >
                                            <div className="flex-shrink-0">
                                                {card.type === 'download' ? (
                                                    <DownloadIcon className="w-8 h-8 text-blue-500" />
                                                ) : (
                                                    <LinkIcon className="w-8 h-8 text-teal-500" />
                                                )}
                                            </div>
                                            <div>
                                                <h3 className="font-semibold text-gray-700">{card.title}</h3>
                                            </div>
                                        </a>
                                    );
                                })}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default LinksPage;
