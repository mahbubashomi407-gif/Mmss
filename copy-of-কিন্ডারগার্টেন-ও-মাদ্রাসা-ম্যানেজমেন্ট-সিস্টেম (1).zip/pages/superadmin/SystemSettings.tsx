
import React, { useState, useEffect } from 'react';
import PageHeader from '../../components/PageHeader';
import { useSuperAdmin, SuperAdminSettings } from '../../context/SuperAdminContext';
import { useNotification } from '../../context/NotificationContext';
import ToggleSwitch from '../../components/ToggleSwitch';

const SystemSettings: React.FC = () => {
    const { settings, updateSettings } = useSuperAdmin();
    const { addToast } = useNotification();
    const [formData, setFormData] = useState<SuperAdminSettings>(settings);

    const hasUnsavedChanges = JSON.stringify(formData) !== JSON.stringify(settings);
    
    useEffect(() => {
        setFormData(settings);
    }, [settings]);

    const handleDirectorChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, directorInfo: { ...prev.directorInfo, [name]: value } }));
    };

    const handleSettingChange = <K extends keyof Omit<SuperAdminSettings, 'directorInfo'>>(key: K, value: SuperAdminSettings[K]) => {
        setFormData(prev => ({ ...prev, [key]: value }));
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        await updateSettings(formData);
        addToast('তথ্য সফলভাবে সংরক্ষণ করা হয়েছে!', 'success');
    };

    return (
        <div>
            <PageHeader icon="⚙️" title="সিস্টেম সেটিংস" />
            <div className="bg-white p-6 rounded-xl shadow-md max-w-4xl mx-auto">
                <form onSubmit={handleSubmit} className="space-y-8">
                    
                    <fieldset className="space-y-4 border p-4 rounded-lg">
                        <legend className="text-lg font-bold text-gray-800 px-2">পরিচালকের তথ্য</legend>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">নাম</label>
                            <input type="text" name="name" value={formData.directorInfo.name} onChange={handleDirectorChange} className="mt-1 w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">ঠিকানা</label>
                            <input type="text" name="address" value={formData.directorInfo.address} onChange={handleDirectorChange} className="mt-1 w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">মোবাইল</label>
                                <input type="tel" name="mobile" value={formData.directorInfo.mobile} onChange={handleDirectorChange} className="mt-1 w-full p-2 border border-gray-300 rounded-md" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">হোয়াটসঅ্যাপ</label>
                                <input type="tel" name="whatsapp" value={formData.directorInfo.whatsapp} onChange={handleDirectorChange} className="mt-1 w-full p-2 border border-gray-300 rounded-md" required />
                            </div>
                        </div>
                    </fieldset>
                    
                     <fieldset className="space-y-4 pt-4 border p-4 rounded-lg">
                        <legend className="text-lg font-bold text-gray-800 px-2">সিস্টেম সেটিংস</legend>
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                           <div>
                                <h4 className="font-semibold text-gray-700">নতুন প্রতিষ্ঠান রেজিস্ট্রেশন</h4>
                                <p className="text-sm text-gray-500">এটি চালু থাকলে যে কেউ নতুন প্রতিষ্ঠানের জন্য আবেদন করতে পারবে।</p>
                           </div>
                            <ToggleSwitch enabled={formData.isRegistrationOpen} onChange={(value) => handleSettingChange('isRegistrationOpen', value)} />
                        </div>
                        <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                            <div>
                                <h4 className="font-semibold text-gray-700">দ্রুত লগইন বাটন</h4>
                                <p className="text-sm text-gray-500">লগইন পেজে ডেমো এডমিন হিসেবে দ্রুত লগইন করার বাটনটি দেখান বা লুকান।</p>
                            </div>
                            <ToggleSwitch enabled={formData.showQuickLoginButton} onChange={(value) => handleSettingChange('showQuickLoginButton', value)} />
                        </div>
                    </fieldset>

                    <div className="flex justify-end pt-4 border-t">
                        <button type="submit" disabled={!hasUnsavedChanges} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">সংরক্ষণ করুন</button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default SystemSettings;
