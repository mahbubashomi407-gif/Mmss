
import React, { useState } from 'react';
import PageHeader from '../../components/PageHeader';
import { useSuperAdmin, LinkSection, LinkCard } from '../../context/SuperAdminContext';
import { useNotification } from '../../context/NotificationContext';
import { PlusIcon, PencilIcon, TrashIcon } from '../../components/icons';
import Modal from '../../components/Modal';
import { doc, runTransaction } from 'firebase/firestore';
import { db } from '../../services/firebase';

// Link Card Modal
const LinkCardModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (card: Omit<LinkCard, 'id'> & { id?: string }) => void;
    cardToEdit: Omit<LinkCard, 'id'> & { id?: string } | null;
}> = ({ isOpen, onClose, onSave, cardToEdit }) => {
    const [title, setTitle] = useState(cardToEdit?.title || '');
    const [url, setUrl] = useState(cardToEdit?.url || '');
    const [type, setType] = useState<'navigation' | 'download'>(cardToEdit?.type || 'navigation');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: cardToEdit?.id, title, url, type });
        onClose();
    };

    return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b"><h3 className="text-lg font-bold">{cardToEdit?.id ? 'লিংক সম্পাদনা' : 'নতুন লিংক'}</h3></div>
                    <div className="p-5 space-y-4">
                        <div><label className="block text-sm font-medium">শিরোনাম</label><input type="text" value={title} onChange={e=>setTitle(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div>
                        <div><label className="block text-sm font-medium">URL/লিংক</label><input type="url" value={url} onChange={e=>setUrl(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div>
                        <div><label className="block text-sm font-medium">ধরণ</label><select value={type} onChange={e=>setType(e.target.value as any)} className="mt-1 w-full p-2 border rounded-md bg-white"><option value="navigation">ন্যাভিগেশন</option><option value="download">ডাউনলোড</option></select></div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3"><button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button><button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">সংরক্ষণ</button></div>
                </form>
            </div>
        </div>
    );
};


const LinksManagement: React.FC = () => {
    const { links, updateLinks } = useSuperAdmin();
    const { addToast } = useNotification();
    
    const [sectionModal, setSectionModal] = useState<{ isOpen: boolean, section: Omit<LinkSection, 'cards'> | null }>({ isOpen: false, section: null });
    const [cardModal, setCardModal] = useState<{ isOpen: boolean, card: Omit<LinkCard, 'id'> & { id?: string } | null, sectionId: string | null }>({ isOpen: false, card: null, sectionId: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean, item: any, type: 'section' | 'card', sectionId?: string }>({ isOpen: false, item: null, type: 'section' });

    // Section Handlers
    const handleSaveSection = async (data: { title: string; id?: string }) => {
        const docRef = doc(db, 'superAdminData', 'links');
        try {
            await runTransaction(db, async (transaction) => {
                const docSnap = await transaction.get(docRef);
                const currentLinks = docSnap.data()?.list || [];
                let newLinks;
                if (data.id) {
                    newLinks = currentLinks.map((s: LinkSection) => s.id === data.id ? { ...s, title: data.title } : s);
                } else {
                    const newSection: LinkSection = { id: `sec-${Date.now()}`, title: data.title, cards: [] };
                    newLinks = [...currentLinks, newSection];
                }
                transaction.set(docRef, { list: newLinks });
            });
            addToast(data.id ? 'শাখা আপডেট করা হয়েছে!' : 'নতুন শাখা যোগ করা হয়েছে!', 'success');
        } catch (error) {
            console.error("Error saving section:", error);
            addToast('ত্রুটি: শাখা সংরক্ষণ করা যায়নি।', 'error');
        }
        setSectionModal({ isOpen: false, section: null });
    };

    // Card Handlers
    const handleSaveCard = async (cardData: Omit<LinkCard, 'id'> & { id?: string }) => {
        const { sectionId } = cardModal;
        if (!sectionId) return;
        const docRef = doc(db, 'superAdminData', 'links');
        try {
            await runTransaction(db, async (transaction) => {
                const docSnap = await transaction.get(docRef);
                const currentLinks = docSnap.data()?.list || [];
                const newLinks = currentLinks.map((section: LinkSection) => {
                    if (section.id === sectionId) {
                        if (cardData.id) { // Edit card
                            return { ...section, cards: section.cards.map(c => c.id === cardData.id ? cardData as LinkCard : c) };
                        } else { // Add card
                            return { ...section, cards: [...section.cards, { ...cardData, id: `card-${Date.now()}` }] };
                        }
                    }
                    return section;
                });
                transaction.set(docRef, { list: newLinks });
            });
            addToast(cardData.id ? 'লিংক আপডেট করা হয়েছে!' : 'নতুন লিংক যোগ করা হয়েছে!', 'success');
        } catch (error) {
            console.error("Error saving card:", error);
            addToast('ত্রুটি: লিংক সংরক্ষণ করা যায়নি।', 'error');
        }
        setCardModal({ isOpen: false, card: null, sectionId: null });
    };

    // Delete Handler
    const handleConfirmDelete = async () => {
        const { item, type, sectionId } = deleteModal;
        if (!item) return;
        const docRef = doc(db, 'superAdminData', 'links');
        try {
            await runTransaction(db, async (transaction) => {
                const docSnap = await transaction.get(docRef);
                const currentLinks = docSnap.data()?.list || [];
                let newLinks;
                if (type === 'section') {
                    newLinks = currentLinks.filter((s: LinkSection) => s.id !== item.id);
                } else if (type === 'card' && sectionId) {
                    newLinks = currentLinks.map((s: LinkSection) => s.id === sectionId ? { ...s, cards: s.cards.filter((c: LinkCard) => c.id !== item.id) } : s);
                } else {
                    throw new Error("Invalid delete operation");
                }
                transaction.set(docRef, { list: newLinks });
            });
            addToast('আইটেম সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        } catch (error) {
            console.error("Error deleting item:", error);
            addToast('ত্রুটি: আইটেমটি মোছা যায়নি।', 'error');
        }
        setDeleteModal({ isOpen: false, item: null, type: 'section' });
    };

    return (
        <div>
            <PageHeader icon="🔗" title="লিংক ম্যানেজমেন্ট">
                <button onClick={() => setSectionModal({ isOpen: true, section: null })} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 flex items-center gap-2">
                    <PlusIcon className="w-5 h-5" />
                    <span>নতুন শাখা যোগ করুন</span>
                </button>
            </PageHeader>
            
            <div className="space-y-6">
                {links.map(section => (
                    <div key={section.id} className="bg-white p-4 rounded-xl shadow-md">
                        <div className="flex justify-between items-center border-b pb-2 mb-3">
                            <h2 className="text-xl font-bold text-gray-800">{section.title}</h2>
                            <div className="space-x-2">
                                <button onClick={() => setSectionModal({ isOpen: true, section })} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4" /></button>
                                <button onClick={() => setDeleteModal({ isOpen: true, item: section, type: 'section' })} className="p-2 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4" /></button>
                            </div>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                            {section.cards.map(card => (
                                <div key={card.id} className="bg-gray-50 p-3 rounded-lg flex justify-between items-center">
                                    <div>
                                        <p className="font-semibold text-gray-700">{card.title}</p>
                                        <p className="text-xs text-blue-500 truncate">{card.url}</p>
                                    </div>
                                    <div className="space-x-1 flex-shrink-0 ml-2">
                                         <button onClick={() => setCardModal({isOpen: true, card, sectionId: section.id})} className="p-1 text-blue-600 hover:bg-blue-100 rounded-full"><PencilIcon className="w-4 h-4"/></button>
                                         <button onClick={() => setDeleteModal({isOpen: true, item: card, type: 'card', sectionId: section.id})} className="p-1 text-red-600 hover:bg-red-100 rounded-full"><TrashIcon className="w-4 h-4"/></button>
                                    </div>
                                </div>
                            ))}
                            <button onClick={() => setCardModal({ isOpen: true, card: null, sectionId: section.id })} className="flex items-center justify-center gap-2 p-3 bg-gray-100 text-gray-600 rounded-lg hover:bg-gray-200 transition-colors">
                                <PlusIcon className="w-5 h-5" />
                                <span>নতুন লিংক</span>
                            </button>
                        </div>
                    </div>
                ))}
                 {links.length === 0 && <p className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">কোনো শাখা যোগ করা হয়নি।</p>}
            </div>

            {/* Section Modal */}
            {sectionModal.isOpen && (
                <Modal isOpen={true} onClose={() => setSectionModal({ isOpen: false, section: null })} onConfirm={() => {
                    const title = (document.getElementById('sectionTitle') as HTMLInputElement).value;
                    if (title) handleSaveSection({ title, id: sectionModal.section?.id });
                }} title={sectionModal.section ? 'শাখা সম্পাদনা করুন' : 'নতুন শাখা যোগ করুন'}>
                    <input id="sectionTitle" type="text" defaultValue={sectionModal.section?.title || ''} className="w-full p-2 border rounded" placeholder="শাখার শিরোনাম" required/>
                </Modal>
            )}

            {/* Card Modal */}
            {cardModal.isOpen && <LinkCardModal isOpen={true} onClose={() => setCardModal({ isOpen: false, card: null, sectionId: null })} onSave={handleSaveCard} cardToEdit={cardModal.card} />}

            {/* Delete Modal */}
            <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({ isOpen: false, item: null, type: 'section' })} onConfirm={handleConfirmDelete} title="মুছে ফেলা নিশ্চিত করুন">
                আপনি কি নিশ্চিতভাবে "{deleteModal.item?.title}" মুছে ফেলতে চান?
            </Modal>
        </div>
    );
};

export default LinksManagement;
