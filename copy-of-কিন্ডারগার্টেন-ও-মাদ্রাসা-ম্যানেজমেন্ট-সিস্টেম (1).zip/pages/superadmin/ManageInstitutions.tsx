
import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useSuperAdmin, Institution } from '../../context/SuperAdminContext';
import { useNotification } from '../../context/NotificationContext';
import PageHeader from '../../components/PageHeader';
import Modal from '../../components/Modal';
import InstitutionModal from '../../components/InstitutionModal';
import { PencilIcon, TrashIcon, ArrowRightOnRectangleIcon } from '../../components/icons';
import { useAuth } from '../../context/AuthContext';

const ManageInstitutions: React.FC = () => {
    const { institutions, updateInstitutions } = useSuperAdmin();
    const { addToast } = useNotification();
    const { impersonateAdmin } = useAuth();
    const navigate = useNavigate();

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
    const [selectedInstitution, setSelectedInstitution] = useState<Institution | null>(null);

    const { pendingInstitutions, otherInstitutions } = useMemo(() => {
        const pending = institutions.filter(i => i.status === 'Pending');
        const others = institutions.filter(i => i.status !== 'Pending');
        return { pendingInstitutions: pending, otherInstitutions: others };
    }, [institutions]);

    const handleAddNew = () => {
        setSelectedInstitution(null);
        setIsModalOpen(true);
    };

    const handleEdit = (inst: Institution) => {
        setSelectedInstitution(inst);
        setIsModalOpen(true);
    };

    const handleDelete = (inst: Institution) => {
        setSelectedInstitution(inst);
        setIsDeleteModalOpen(true);
    };

    const handleConfirmDelete = async () => {
        if (selectedInstitution) {
            await updateInstitutions(institutions.filter(i => i.id !== selectedInstitution.id));
            addToast('প্রতিষ্ঠান সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setIsDeleteModalOpen(false);
        setSelectedInstitution(null);
    };

    const handleSave = async (data: Omit<Institution, 'id'> & { id?: string }) => {
        if (data.id) { // Editing
            await updateInstitutions(institutions.map(i => i.id === data.id ? { ...i, ...data, status: new Date(data.subscriptionEndDate) >= new Date() ? 'Active' : 'Expired' } as Institution : i));
            addToast('প্রতিষ্ঠান সফলভাবে আপডেট করা হয়েছে!', 'success');
        } else { // Adding new
            const newInstitution: Institution = { 
                ...data, 
                id: `inst-${Date.now()}`,
                status: new Date(data.subscriptionEndDate) >= new Date() ? 'Active' : 'Expired'
            };
            await updateInstitutions([...institutions, newInstitution]);
            addToast('নতুন প্রতিষ্ঠান সফলভাবে যোগ করা হয়েছে!', 'success');
        }
        setIsModalOpen(false);
    };
    
    const handleLoginAs = (inst: Institution) => {
        impersonateAdmin({ id: inst.id, code: inst.code });
        navigate('/app/dashboard');
    };

    const getStatusBadge = (status: 'Active' | 'Expired' | 'Pending') => {
        if (status === 'Active') return 'bg-green-100 text-green-800';
        if (status === 'Expired') return 'bg-red-100 text-red-800';
        return 'bg-yellow-100 text-yellow-800';
    };

    const renderTable = (data: Institution[], title: string) => (
        <div className="bg-white p-6 rounded-xl shadow-md mb-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4">{title}</h2>
            <div className="overflow-x-auto">
                <table className="w-full text-sm">
                    <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th className="p-2">নাম</th>
                            <th className="p-2">কোড</th>
                            {data[0]?.status !== 'Pending' && <th className="p-2">মেয়াদ শেষ</th>}
                            <th className="p-2">স্ট্যাটাস</th>
                            <th className="p-2 text-right">পদক্ষেপ</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map(inst => (
                            <tr key={inst.id} className="border-b hover:bg-gray-50">
                                <td className="p-2 font-medium">{inst.name}</td>
                                <td className="p-2 font-mono">{inst.code || '-'}</td>
                                {inst.status !== 'Pending' && <td className="p-2">{new Date(inst.subscriptionEndDate).toLocaleDateString('bn-BD')}</td>}
                                <td className="p-2">
                                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${getStatusBadge(inst.status)}`}>
                                        {inst.status === 'Active' ? 'সক্রিয়' : inst.status === 'Expired' ? 'মেয়াদোত্তীর্ণ' : 'অপেক্ষমান'}
                                    </span>
                                </td>
                                <td className="p-2 text-right space-x-1">
                                    {inst.status === 'Pending' ? (
                                         <button onClick={() => handleEdit(inst)} className="px-3 py-1 bg-green-500 text-white text-xs font-semibold rounded-md hover:bg-green-600">
                                            অনুমোদন করুন
                                        </button>
                                    ) : (
                                        <button onClick={() => handleLoginAs(inst)} className="p-2 text-green-600 hover:bg-green-100 rounded-full" title="এডমিন হিসেবে লগইন করুন">
                                            <ArrowRightOnRectangleIcon className="w-4 h-4" />
                                        </button>
                                    )}
                                    <button onClick={() => handleEdit(inst)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                    <button onClick={() => handleDelete(inst)} className="p-2 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
                 {data.length === 0 && <p className="text-center py-6 text-gray-500">কোনো তথ্য নেই।</p>}
            </div>
        </div>
    );

    return (
        <div>
            <PageHeader icon="🏢" title="প্রতিষ্ঠান পরিচালনা">
                <button
                    onClick={handleAddNew}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700"
                >
                    নতুন প্রতিষ্ঠান যোগ করুন
                </button>
            </PageHeader>
            {pendingInstitutions.length > 0 && renderTable(pendingInstitutions, 'অপেক্ষমান আবেদন')}
            {renderTable(otherInstitutions, 'সকল প্রতিষ্ঠান')}

            <InstitutionModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                onSave={handleSave}
                institutionToEdit={selectedInstitution}
            />
            
            <Modal
                isOpen={isDeleteModalOpen}
                onClose={() => setIsDeleteModalOpen(false)}
                onConfirm={handleConfirmDelete}
                title="প্রতিষ্ঠান মুছে ফেলুন"
            >
                আপনি কি নিশ্চিতভাবে "{selectedInstitution?.name}" প্রতিষ্ঠানটি মুছে ফেলতে চান?
            </Modal>
        </div>
    );
};

export default ManageInstitutions;
