
import React, { useState, useEffect } from 'react';
import { useNotification } from '../../context/NotificationContext';
import { Link } from 'react-router-dom';
import { CheckCircleIcon, ArrowLeftIcon } from '../../components/icons';
import { doc, getDoc, setDoc, runTransaction } from 'firebase/firestore';
import { db } from '../../services/firebase';
import type { Institution, DirectorInfo } from '../../context/SuperAdminContext';

const COLLECTION_NAME = 'superAdminData';
const INSTITUTIONS_DOC_ID = 'institutions';
const SETTINGS_DOC_ID = 'settings';

const InstitutionRegistration: React.FC = () => {
    const { addToast } = useNotification();
    
    const [name, setName] = useState('');
    const [principalName, setPrincipalName] = useState('');
    const [principalMobile, setPrincipalMobile] = useState('');
    const [adminEmail, setAdminEmail] = useState('');

    const [loading, setLoading] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [isRegistrationOpen, setIsRegistrationOpen] = useState(true);
    const [checkingStatus, setCheckingStatus] = useState(true);
    const [directorInfo, setDirectorInfo] = useState<DirectorInfo | null>(null);

    useEffect(() => {
        const checkRegistrationStatus = async () => {
            try {
                const docRef = doc(db, COLLECTION_NAME, SETTINGS_DOC_ID);
                const docSnap = await getDoc(docRef);
                if (docSnap.exists() && docSnap.data().settings) {
                    setIsRegistrationOpen(docSnap.data().settings.isRegistrationOpen !== false);
                }
            } catch (error) {
                console.error("Error checking registration status:", error);
            } finally {
                setCheckingStatus(false);
            }
        };
        checkRegistrationStatus();
    }, []);


    useEffect(() => {
        if (submitted) {
            setCheckingStatus(true); // Reuse loading state
            const fetchDirectorInfo = async () => {
                try {
                    const docRef = doc(db, COLLECTION_NAME, SETTINGS_DOC_ID);
                    const docSnap = await getDoc(docRef);
                    if (docSnap.exists() && docSnap.data().settings && docSnap.data().settings.directorInfo) {
                        setDirectorInfo(docSnap.data().settings.directorInfo);
                    }
                } catch (error) {
                    console.error("Error fetching director info:", error);
                } finally {
                    setCheckingStatus(false);
                }
            };
            fetchDirectorInfo();
        }
    }, [submitted]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);

        if (!name || !principalName || !principalMobile || !adminEmail) {
            addToast('অনুগ্রহ করে সকল ঘর পূরণ করুন।', 'error');
            setLoading(false);
            return;
        }

        try {
            const docRef = doc(db, COLLECTION_NAME, INSTITUTIONS_DOC_ID);

            await runTransaction(db, async (transaction) => {
                const docSnap = await transaction.get(docRef);
                let institutions: Institution[] = [];

                if (docSnap.exists() && docSnap.data().list) {
                    institutions = docSnap.data().list;
                    const isEmailTaken = institutions.some(
                        (inst: Institution) => inst.adminEmail?.toLowerCase() === adminEmail.toLowerCase()
                    );
                    if (isEmailTaken) {
                        // Throwing an error from a transaction aborts it.
                        throw new Error('এই ইমেইলটি ইতিমধ্যে নিবন্ধিত বা একটি আবেদনের জন্য ব্যবহৃত হয়েছে।');
                    }
                }

                const newInstitution: Institution = {
                    id: `inst-pending-${Date.now()}`,
                    name,
                    code: '',
                    subscriptionEndDate: new Date().toISOString().split('T')[0],
                    status: 'Pending',
                    principalName,
                    principalMobile,
                    adminEmail,
                };

                const newList = [...institutions, newInstitution];
                
                // set will create or overwrite
                transaction.set(docRef, { list: newList });
            });

            addToast('আপনার আবেদন সফলভাবে জমা হয়েছে!', 'success');
            setSubmitted(true);

        } catch (err: any) {
            console.error("Registration submission error:", err);
            // The transaction error message will be caught here.
            addToast(err.message || 'আবেদন জমা দেওয়ার সময় একটি ত্রুটি হয়েছে।', 'error');
        } finally {
            setLoading(false);
        }
    };

    if (checkingStatus) {
        return <div className="flex items-center justify-center h-screen bg-gray-100"><div className="text-xl">লোড হচ্ছে...</div></div>;
    }

    if (!submitted && !isRegistrationOpen) {
        return (
             <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
                <div className="w-full max-w-lg text-center bg-white p-8 rounded-xl shadow-lg">
                    <h1 className="text-2xl font-bold text-red-700">রেজিস্ট্রেশন বন্ধ আছে</h1>
                    <p className="text-gray-600 mt-2">বর্তমানে নতুন প্রতিষ্ঠান রেজিস্ট্রেশন সাময়িকভাবে বন্ধ আছে। অনুগ্রহ করে কর্তৃপক্ষের সাথে যোগাযোগ করুন।</p>
                    <Link to="/login" className="mt-6 inline-flex items-center gap-2 px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                        <ArrowLeftIcon className="w-5 h-5" />
                        লগইন পেজে ফিরে যান
                    </Link>
                </div>
            </div>
        );
    }

    if (submitted) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
                <div className="w-full max-w-lg bg-white p-8 rounded-xl shadow-lg">
                    <div className="text-center">
                        <CheckCircleIcon className="w-20 h-20 text-green-500 mx-auto mb-4" />
                        <h1 className="text-2xl font-bold text-gray-800">আবেদন সফল হয়েছে</h1>
                        <p className="text-gray-600 mt-2">আপনার প্রতিষ্ঠানের আবেদনটি পর্যালোচনার জন্য জমা দেওয়া হয়েছে। কর্তৃপক্ষ সাথে যোগাযোগ করুন।</p>
                    </div>

                    {directorInfo && (
                        <div className="mt-6 pt-4 border-t text-left bg-gray-50 p-4 rounded-lg">
                            <h2 className="text-center font-bold text-gray-700 mb-2">কর্তৃপক্ষের সাথে যোগাযোগ করুন</h2>
                            <p className="text-sm text-gray-600"><strong>নাম:</strong> {directorInfo.name}</p>
                            <p className="text-sm text-gray-600"><strong>ঠিকানা:</strong> {directorInfo.address}</p>
                            <p className="text-sm text-gray-600"><strong>মোবাইল:</strong> {directorInfo.mobile}</p>
                            <p className="text-sm text-gray-600"><strong>হোয়াটসঅ্যাপ:</strong> {directorInfo.whatsapp}</p>
                        </div>
                    )}

                    <div className="text-center">
                         <Link to="/login" className="mt-8 inline-flex items-center gap-2 px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">
                            <ArrowLeftIcon className="w-5 h-5" />
                            লগইন পেজে ফিরে যান
                        </Link>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-4">
            <div className="w-full max-w-2xl">
                <div className="text-center mb-6">
                    <h1 className="text-3xl font-bold text-gray-800">নতুন প্রতিষ্ঠান রেজিস্ট্রেশন</h1>
                    <p className="text-gray-500 mt-2">আপনার প্রতিষ্ঠানের তথ্য দিয়ে নিচের ফরমটি পূরণ করুন।</p>
                </div>
                <form onSubmit={handleSubmit} className="bg-white p-6 rounded-xl shadow-lg space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">প্রতিষ্ঠানের নাম<span className="text-red-500">*</span></label>
                        <input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 w-full p-2 border border-gray-300 rounded-md" required />
                    </div>
                     <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">প্রধান/অধ্যক্ষের নাম<span className="text-red-500">*</span></label>
                            <input type="text" value={principalName} onChange={e => setPrincipalName(e.target.value)} className="mt-1 w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">প্রধানের মোবাইল নম্বর<span className="text-red-500">*</span></label>
                            <input type="tel" value={principalMobile} onChange={e => setPrincipalMobile(e.target.value)} className="mt-1 w-full p-2 border border-gray-300 rounded-md" required />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">এডমিন ইমেইল<span className="text-red-500">*</span></label>
                        <input type="email" value={adminEmail} onChange={e => setAdminEmail(e.target.value)} className="mt-1 w-full p-2 border border-gray-300 rounded-md" placeholder="এই ইমেইলটি লগইনের জন্য ব্যবহৃত হবে" required />
                    </div>
                    
                    <div className="text-xs text-gray-500 pt-2 border-t">
                        <p>আবেদন জমা দেওয়ার পর, আমাদের প্রতিনিধি আপনার সাথে যোগাযোগ করে আপনার অ্যাকাউন্ট সক্রিয় করে দেবে। ডিফল্ট পাসওয়ার্ড হবে '123456', যা আপনি প্রথমবার লগইন করার পর পরিবর্তন করতে পারবেন।</p>
                    </div>

                     <div className="flex items-center justify-end gap-4 pt-2">
                        <Link to="/login" className="text-sm font-semibold text-gray-600 hover:text-gray-800">বাতিল করুন</Link>
                        <button type="submit" disabled={loading} className="px-6 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">
                            {loading ? 'জমা হচ্ছে...' : 'আবেদন জমা দিন'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default InstitutionRegistration;
