
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import AdminDashboard from './admin/AdminDashboard';
import TeacherDashboard from './teacher/TeacherDashboard';
import AccountantDashboard from './accountant/AccountantDashboard';
import Spinner from '../components/Spinner';

const Dashboard: React.FC = () => {
    const { user, loading } = useAuth();

    if (loading || !user) {
        return <Spinner />;
    }

    switch (user.role) {
        case UserRole.ADMIN:
            return <AdminDashboard />;
        case UserRole.TEACHER:
            return <TeacherDashboard />;
        case UserRole.ACCOUNTANT:
            return <AccountantDashboard />;
        default:
            return (
                <div className="text-center p-10 bg-white rounded-lg shadow-md">
                    <h2 className="text-2xl font-bold text-red-600">ড্যাশবোর্ড পাওয়া যায়নি</h2>
                    <p className="text-gray-600 mt-2">আপনার ভূমিকার জন্য কোনো ড্যাশবোর্ড কনফিগার করা নেই।</p>
                </div>
            );
    }
};

export default Dashboard;
