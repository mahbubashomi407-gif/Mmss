import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { MarkRecord } from '../../types';
import { useInstitution, calculateGradeInfo } from '../../context/InstitutionContext';

const ViewMarks: React.FC = () => {
    const { user } = useAuth();
    const { students, markRecords, exams, classLevels, grades } = useInstitution();
    const [loading, setLoading] = useState(true);

    const { child, childMarks } = useMemo(() => {
        if (!user) return { child: null, childMarks: [] };

        const currentChild = students.find(s => s.id === user.uid);
        if (!currentChild) return { child: null, childMarks: [] };

        const allSubjects = classLevels.flatMap(cl => cl.subjects);

        const marks = markRecords
            .filter(rec => rec.studentId === currentChild.id)
            .map(rec => {
                const exam = exams.find(e => e.id === rec.examId);
                const subject = allSubjects.find(s => s.id === rec.subjectId);
                return {
                    ...rec,
                    examName: exam?.name || 'অজানা পরীক্ষা',
                    subjectName: subject?.name || 'অজানা বিষয়',
                };
            })
            .sort((a,b) => (a.examName > b.examName) ? -1 : 1);
        
        return { child: currentChild, childMarks: marks };
    }, [user, students, markRecords, exams, classLevels]);
    
    useEffect(() => {
        // Simulate loading
        const timer = setTimeout(() => setLoading(false), 200);
        return () => clearTimeout(timer);
    }, [user]);
    
    const getGrade = (mark: number, total: number) => {
        if (total === 0) return 'N/A';
        const percentage = (mark / total) * 100;
        return calculateGradeInfo(percentage, grades).grade;
    }
    
    if (loading) return <p>ফলাফল লোড হচ্ছে...</p>;
    if (!child) return <p>আপনার সন্তানের তথ্য পাওয়া যায়নি।</p>;

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">{child.nameBn}-এর পরীক্ষার ফলাফল</h1>
            <div className="bg-white rounded-xl shadow-lg p-4">
                {childMarks.length > 0 ? (
                     <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="p-3 font-semibold text-gray-600">পরীক্ষার নাম</th>
                                    <th className="p-3 font-semibold text-gray-600">বিষয়</th>
                                    <th className="p-3 font-semibold text-gray-600">প্রাপ্ত নম্বর</th>
                                    <th className="p-3 font-semibold text-gray-600">মোট নম্বর</th>
                                    <th className="p-3 font-semibold text-gray-600">গ্রেড</th>
                                </tr>
                            </thead>
                            <tbody>
                                {childMarks.map((record, index) => (
                                    <tr key={index} className="border-t">
                                        <td className="p-3">{record.examName}</td>
                                        <td className="p-3 font-medium">{record.subjectName}</td>
                                        <td className="p-3">{record.marksObtained}</td>
                                        <td className="p-3">{record.totalMarks}</td>
                                        <td className="p-3 font-bold">{getGrade(record.marksObtained, record.totalMarks)}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">এখনো কোনো পরীক্ষার ফলাফল রেকর্ড করা হয়নি।</p>
                )}
            </div>
        </div>
    );
};

export default ViewMarks;