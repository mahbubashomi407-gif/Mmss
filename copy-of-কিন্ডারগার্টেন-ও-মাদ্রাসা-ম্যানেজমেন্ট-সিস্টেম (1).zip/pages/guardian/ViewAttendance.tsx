import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';

const ViewAttendance: React.FC = () => {
    const { user } = useAuth();
    const { students, attendanceRecords } = useInstitution();
    const [loading, setLoading] = useState(true);

    const { child, childAttendance } = useMemo(() => {
        if (!user) return { child: null, childAttendance: [] };
        
        const currentChild = students.find(s => s.id === user.uid);
        if (!currentChild) return { child: null, childAttendance: [] };

        const attendance = attendanceRecords
            .filter(rec => rec.studentId === currentChild.id)
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
        
        return { child: currentChild, childAttendance: attendance };

    }, [user, students, attendanceRecords]);
    
    useEffect(() => {
        // Simulate loading for better UX, even though data is local
        const timer = setTimeout(() => setLoading(false), 200);
        return () => clearTimeout(timer);
    }, [user]);

    if (loading) return <p>হাজিরার তথ্য লোড হচ্ছে...</p>;
    if (!child) return <p>আপনার সন্তানের তথ্য পাওয়া যায়নি।</p>;

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">{child.nameBn}-এর হাজিরা</h1>
            <div className="bg-white rounded-xl shadow-lg p-4">
                {childAttendance.length > 0 ? (
                     <div className="overflow-x-auto max-h-96">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-100 sticky top-0">
                                <tr>
                                    <th className="p-3 font-semibold text-gray-600">তারিখ</th>
                                    <th className="p-3 font-semibold text-gray-600">অবস্থা</th>
                                </tr>
                            </thead>
                            <tbody>
                                {childAttendance.map((record, index) => (
                                    <tr key={index} className="border-t">
                                        <td className="p-3">{new Date(record.date).toLocaleDateString('bn-BD')}</td>
                                        <td className="p-3">
                                            <span className={`px-3 py-1 text-xs font-semibold rounded-full ${record.status === 'present' ? 'bg-green-100 text-green-800' : record.status === 'absent' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>
                                                {record.status === 'present' ? 'উপস্থিত' : record.status === 'absent' ? 'অনুপস্থিত' : 'ছুটি'}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                     <p className="text-center text-gray-500 py-10">এখনো কোনো হাজিরার তথ্য রেকর্ড করা হয়নি।</p>
                )}
            </div>
        </div>
    );
};

export default ViewAttendance;