
import React, { useMemo } from 'react';
import PageHeader from '../../components/PageHeader';
import { useInstitution } from '../../context/InstitutionContext';
import { useAuth } from '../../context/AuthContext';

const GuardianNotifications: React.FC = () => {
    const { user } = useAuth();
    const { guardianNotifications, setGuardianNotifications } = useInstitution();

    const notifications = useMemo(() => {
        if (!user) return [];
        return guardianNotifications
            .filter(n => n.studentId === user.uid)
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    }, [user, guardianNotifications]);

    const handleMarkAllAsRead = () => {
        if (!user) return;
        setGuardianNotifications(prev =>
            prev.map(n => (n.studentId === user.uid ? { ...n, isRead: true } : n))
        );
    };

    const timeSince = (dateString: string) => {
        const seconds = Math.floor((new Date().getTime() - new Date(dateString).getTime()) / 1000);
        let interval = seconds / 31536000;
        if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " বছর আগে";
        interval = seconds / 2592000;
        if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " মাস আগে";
        interval = seconds / 86400;
        if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " দিন আগে";
        interval = seconds / 3600;
        if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " ঘন্টা আগে";
        interval = seconds / 60;
        if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " মিনিট আগে";
        return "এইমাত্র";
    };

    const toBengaliNumber = (numStr: string | number): string => {
        const num = String(numStr);
        const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
        return num.replace(/[0-9]/g, match => map[match]);
    };

    return (
        <div>
            <PageHeader icon="🔔" title="সকল নোটিফিকেশন">
                <button
                    onClick={handleMarkAllAsRead}
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 transition-colors"
                >
                    সবগুলো পঠিত হিসেবে চিহ্নিত করুন
                </button>
            </PageHeader>
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="space-y-4">
                    {notifications.length > 0 ? notifications.map(n => (
                        <div key={n.id} className={`p-4 rounded-lg border-l-4 ${n.isRead ? 'bg-gray-50 border-gray-300' : 'bg-blue-50 border-blue-400'}`}>
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-bold text-gray-800">{n.title}</h3>
                                    <p className="text-sm text-gray-600 mt-1">{n.message}</p>
                                </div>
                                <span className="text-xs text-gray-500 flex-shrink-0 ml-4">{timeSince(n.timestamp)}</span>
                            </div>
                        </div>
                    )) : (
                        <p className="text-center text-gray-500 py-10">আপনার জন্য কোনো নোটিফিকেশন নেই।</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default GuardianNotifications;
