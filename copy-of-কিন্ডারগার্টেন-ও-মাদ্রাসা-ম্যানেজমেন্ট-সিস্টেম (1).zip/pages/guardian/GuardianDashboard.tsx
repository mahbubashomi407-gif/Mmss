
import React, { useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';
import { ChildIcon } from '../../components/icons';
import { DASHBOARD_ITEMS } from '../../constants/dashboardMap';
import DashboardActionCard from '../../components/DashboardActionCard';
import { Link } from 'react-router-dom';

const timeSince = (dateString: string) => {
    const seconds = Math.floor((new Date().getTime() - new Date(dateString).getTime()) / 1000);
    let interval = seconds / 31536000;
    if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " বছর আগে";
    interval = seconds / 2592000;
    if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " মাস আগে";
    interval = seconds / 86400;
    if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " দিন আগে";
    interval = seconds / 3600;
    if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " ঘন্টা আগে";
    interval = seconds / 60;
    if (interval > 1) return toBengaliNumber(Math.floor(interval)) + " মিনিট আগে";
    return "এইমাত্র";
};

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, match => map[match]);
};

const GuardianDashboard: React.FC = () => {
    const { user, hasPermission } = useAuth();
    const { students, guardianNotifications } = useInstitution();
    
    const child = useMemo(() => {
        if (!user) return null;
        return students.find(s => s.id === user.uid) || null;
    }, [user, students]);

    const accessibleItems = useMemo(() => {
        return DASHBOARD_ITEMS.filter(item => 
            item.roles.includes('student') && hasPermission(item.permission)
        );
    }, [hasPermission]);

    const recentNotifications = useMemo(() => {
        if (!user) return [];
        return guardianNotifications
            .filter(n => n.studentId === user.uid)
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
            .slice(0, 5); // Show latest 5
    }, [user, guardianNotifications]);

    if (!child) return <p>আপনার সন্তানের তথ্য পাওয়া যায়নি।</p>;

    return (
        <div className="space-y-6">
            <h1 className="text-2xl font-bold text-gray-800">শিক্ষার্থী ড্যাশবোর্ড</h1>
            
            <div className="bg-white p-4 sm:p-5 rounded-xl shadow-lg flex flex-row items-center gap-4">
                <div className="flex-shrink-0">
                    {child.photoUrl ? (
                        <img src={child.photoUrl} alt={child.nameBn} className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover border-4 border-white ring-4 ring-green-300" />
                    ) : (
                        <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full bg-green-200 flex items-center justify-center border-4 border-white ring-4 ring-green-300">
                            <ChildIcon className="w-12 h-12 sm:w-16 sm:h-16 text-green-600" />
                        </div>
                    )}
                </div>
                <div className="flex-grow text-left">
                    <h2 className="text-xl sm:text-2xl font-bold text-gray-800">{child.nameBn}</h2>
                    <p className="text-gray-500 text-xs sm:text-sm -mt-1">{child.nameEn}</p>
                    
                    <div className="mt-2 sm:mt-3 grid grid-cols-2 gap-x-4 sm:gap-x-6 gap-y-1 text-xs sm:text-sm text-gray-700">
                        <p><strong>শ্রেণী:</strong> {child.classLevel}</p>
                        <p><strong>শাখা:</strong> {child.section}</p>
                        <p><strong>রোল:</strong> {toBengaliNumber(child.roll)}</p>
                        <p><strong>আইডি:</strong> {toBengaliNumber(child.uniqueId)}</p>
                        <p className="col-span-2"><strong>পিতার নাম:</strong> {child.fatherNameBn}</p>
                        <p className="col-span-2"><strong>মোবাইল:</strong> {toBengaliNumber(child.fatherPhone)}</p>
                    </div>
                </div>
            </div>

            {/* Recent Notifications Section */}
            <div className="bg-white p-4 rounded-xl shadow-lg">
                <div className="flex justify-between items-center mb-3">
                    <h2 className="text-lg font-bold text-gray-800">সাম্প্রতিক নোটিফিকেশন</h2>
                    <Link to="/student/notifications" className="text-sm font-semibold text-teal-600 hover:underline">সব দেখুন</Link>
                </div>
                <div className="space-y-3">
                    {recentNotifications.length > 0 ? recentNotifications.map(n => (
                        <div key={n.id} className={`p-3 rounded-lg border-l-4 ${n.isRead ? 'bg-gray-50 border-gray-200' : 'bg-blue-50 border-blue-300'}`}>
                            <div className="flex justify-between items-start">
                                <div>
                                    <p className="font-semibold text-gray-800 text-sm">{n.title}</p>
                                    <p className="text-xs text-gray-600">{n.message}</p>
                                </div>
                                <span className="text-xs text-gray-500 flex-shrink-0 ml-2">{timeSince(n.timestamp)}</span>
                            </div>
                        </div>
                    )) : (
                        <p className="text-center text-gray-500 py-4">কোনো নতুন নোটিফিকেশন নেই।</p>
                    )}
                </div>
            </div>


            {accessibleItems.length > 0 ? (
                <div className="grid grid-cols-4 gap-2 sm:gap-4">
                    {accessibleItems.map(item => (
                        <DashboardActionCard 
                            key={item.link}
                            to={item.link}
                            icon={item.icon}
                            title={item.title}
                        />
                    ))}
                </div>
            ) : (
                <div className="text-center py-10 mt-6 bg-white rounded-xl shadow-md">
                    <p className="text-gray-500">আপনার জন্য কোনো অপশন সক্রিয় করা নেই।</p>
                    <p className="text-sm text-gray-400 mt-2">অনুগ্রহ করে এডমিনের সাথে যোগাযোগ করুন।</p>
                </div>
            )}
        </div>
    );
};

export default GuardianDashboard;
