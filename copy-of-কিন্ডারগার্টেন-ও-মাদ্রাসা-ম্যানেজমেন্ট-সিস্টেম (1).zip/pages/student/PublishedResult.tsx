import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../components/PageHeader';
import { useInstitution, StudentData, calculateGradeInfo, ExamData, GradeData } from '../../context/InstitutionContext';
import { ReportCardContent, ReportData } from '../../components/ReportCardModal';
import { useAuth } from '../../context/AuthContext';
import { useNotification } from '../../context/NotificationContext';

declare global {
    interface Window {
        html2pdf: any;
    }
}

// --- UTILITY ---
const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        '.': '.',
    };
    return num.replace(/[0-9.]/g, (match) => map[match] || match);
};

// --- MAIN PAGE COMPONENT ---
const PublishedResult: React.FC = () => {
    const { user } = useAuth();
    const { students, exams, classLevels, academicSessions, markRecords, grades } = useInstitution();
    const { addToast } = useNotification();

    const [selectedExamId, setSelectedExamId] = useState('');
    const [reportData, setReportData] = useState<ReportData | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const student = useMemo(() => students.find(s => s.id === user?.uid), [students, user]);
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    const availableExams = useMemo(() => {
        if (!student || !activeSession) return [];
        return exams.filter(e => e.academicYear === activeSession.name && e.classLevels.includes(student.classLevel));
    }, [exams, student, activeSession]);
    
    const selectedExam = useMemo(() => exams.find(e => e.id === selectedExamId), [exams, selectedExamId]);
    
    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setReportData(null);
        setIsLoading(true);

        if (!selectedExamId || !student) {
            addToast('অনুগ্রহ করে একটি পরীক্ষা নির্বাচন করুন।', 'error');
            setIsLoading(false);
            return;
        }

        const exam = selectedExam;
        if (!exam) {
             addToast('নির্বাচিত পরীক্ষা খুঁজে পাওয়া যায়নি।', 'error');
            setIsLoading(false);
            return;
        }
        
        // --- Result Calculation Logic ---
        const studentsInClass = students.filter(s => s.academicYear === student.academicYear && s.classLevel === student.classLevel && s.section === student.section && s.status !== 'পেন্ডিং');
        const allSubjectsForClass = classLevels.find(cl => cl.name === student.classLevel)?.subjects || [];
        const assignedSubjects = exam.subjectAssignments?.[student.classLevel] || [];
        const subjectsForExam = allSubjectsForClass.filter(s => assignedSubjects.some(as => as.subjectId === s.id));
        const failGradeName = grades.find(g => g.gpa === 0)?.name || 'F';
        
        const allStudentResults = studentsInClass.map(currentStudent => {
            const studentMarks = markRecords.filter(m => m.studentId === currentStudent.id && m.examId === selectedExamId);
            let totalObtained = 0, totalMarks = 0, isFail = false, hasAnyMark = false;
            const marksBySubject: Record<string, { obtained: number | null; total: number }> = {};
            subjectsForExam.forEach(subject => {
                const mark = studentMarks.find(m => m.subjectId === subject.id);
                const obtained = mark?.marksObtained ?? null;
                const total = assignedSubjects.find(as => as.subjectId === subject.id)?.totalMarks || 100;
                marksBySubject[subject.id] = { obtained, total };
                if (obtained !== null) {
                    hasAnyMark = true; totalObtained += obtained; totalMarks += total;
                    if (calculateGradeInfo((obtained / total) * 100, grades).grade === failGradeName) isFail = true;
                }
            });
            if (!hasAnyMark) return { ...currentStudent, totalObtained: 0, resultStatus: 'অনুপস্থিত' as const, isAbsent: true, grade: 'অনুপস্থিত', gpa: 0, marksBySubject };
            const { grade, gpa } = calculateGradeInfo((totalObtained / totalMarks) * 100, grades);
            return { ...currentStudent, totalObtained, isAbsent: false, resultStatus: (isFail ? 'অকৃতকার্য' : 'কৃতকার্য') as 'কৃতকার্য' | 'অকৃতকার্য', grade: isFail ? failGradeName : grade, gpa: isFail ? 0 : gpa, marksBySubject };
        });

        const sorted = allStudentResults.sort((a, b) => {
            const statusOrder = { 'কৃতকার্য': 1, 'অকৃতকার্য': 2, 'অনুপস্থিত': 3 };
            const statusA = statusOrder[a.resultStatus as keyof typeof statusOrder] || 4;
            const statusB = statusOrder[b.resultStatus as keyof typeof statusOrder] || 4;
            if (statusA !== statusB) return statusA - statusB;
            if (a.totalObtained !== b.totalObtained) return b.totalObtained - a.totalObtained;
            return (a.roll || 999) - (b.roll || 999);
        });

        let rank = 0, lastScore = -1;
        const rankedResults = sorted.map((s, index) => {
            let currentRank: number | '-' = '-';
            if (!s.isAbsent && s.resultStatus === 'কৃতকার্য') { if (s.totalObtained !== lastScore) { rank = index + 1; lastScore = s.totalObtained; } currentRank = rank; }
            return { ...s, rank: currentRank };
        });

        const studentResult = rankedResults.find(r => r.id === student.id);
        if (!studentResult) {
            setError('আপনার ফলাফল এই পরীক্ষার জন্য এখনও প্রক্রিয়া করা হয়নি।');
            setIsLoading(false);
            return;
        }
        
        const highestMarksBySubject: Record<string, number> = {};
        subjectsForExam.forEach(subject => {
            const marksForThisSubject = allStudentResults
                .map(res => res.marksBySubject[subject.id]?.obtained)
                .filter(mark => typeof mark === 'number') as number[];
            
            highestMarksBySubject[subject.id] = marksForThisSubject.length > 0 ? Math.max(...marksForThisSubject) : 0;
        });
        
        let failedSubjectsCount = 0;
        const subjectRows = subjectsForExam.map(subject => {
            const markInfo = studentResult.marksBySubject[subject.id];
            const obtained = markInfo?.obtained; const total = markInfo?.total ?? 100;
            const gradeInfo = (obtained !== null && obtained !== undefined) ? calculateGradeInfo((obtained / total) * 100, grades) : { grade: 'N/A', gpa: 0 };
            if (gradeInfo.gpa === 0) failedSubjectsCount++;
            return { name: subject.name, fullMarks: total, highestMark: highestMarksBySubject[subject.id], totalMarks: obtained, letterGrade: gradeInfo.grade, gradePoint: gradeInfo.gpa.toFixed(2) };
        });
        const totalFullMarks = subjectRows.reduce((sum, r) => sum + r.fullMarks, 0);

        setReportData({ student: studentResult, exam, subjectRows, failedSubjectsCount, totalFullMarks });
        setIsLoading(false);
    };
    
    const handlePrint = () => {
        const printContent = document.getElementById('printable-marksheet');
        if (printContent) {
            const printWindow = window.open('', '', 'height=800,width=1200');
            if(printWindow){
                printWindow.document.write('<html><head><title>মার্কশীট</title>');
                printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                printWindow.document.write(`<style> body { font-family: "SolaimanLipi", sans-serif !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; margin: 0; } @page { size: A4 portrait; margin: 0.7cm; } #printable-marksheet-container { width: 100%; height: 100%; display: flex; flex-direction: column; } .marksheet-container { page-break-inside: avoid; height: 100%; padding: 0.5rem; } </style>`); /* Adjusted @page margin and marksheet-container padding */
                printWindow.document.write('</head><body><div id="printable-marksheet-container">');
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</div></body></html>');
                printWindow.document.close();
                setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 750);
            }
        }
    };

    const handlePdfDownload = () => {
        if (!reportData) return;
        
        const element = document.getElementById('printable-marksheet');
        if (element) {
            const studentName = (reportData.student.nameEn || 'student').replace(/\s/g, '_');
            const examName = (reportData.exam.name || 'exam').replace(/\s/g, '_');
            
            const opt = {
                margin: 1, // 1cm on all sides
                filename: `Marksheet_${studentName}_${examName}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { scale: 2, useCORS: true },
                jsPDF: { unit: 'cm', format: 'a4', orientation: 'portrait' }
            };
    
            window.html2pdf().from(element).set(opt).save();
        }
    };
    
    if (!student) return <p>আপনার তথ্য পাওয়া যায়নি।</p>;

    return (
        <div>
            <PageHeader icon="📢" title="ফলাফল দেখুন" />
             <div className="bg-white p-6 rounded-xl shadow-md mb-6">
                <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end">
                     <div>
                        <label className="block text-sm font-medium">পরীক্ষা নির্বাচন করুন</label>
                        <select value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)} className="mt-1 w-full p-2 border rounded-md">
                            <option value="">-- পরীক্ষা নির্বাচন --</option>
                            {availableExams.map(ex => <option key={ex.id} value={ex.id}>{ex.name}</option>)}
                        </select>
                    </div>
                    <button type="submit" disabled={isLoading || !selectedExamId} className="w-full py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700 disabled:bg-gray-400">
                        {isLoading ? 'লোড হচ্ছে...' : 'ফলাফল দেখুন'}
                    </button>
                </form>
                {error && <p className="text-center text-red-500 mt-4">{error}</p>}
            </div>

            {reportData && (
                <div className="mt-8">
                    <div className="flex justify-end gap-3 mb-4">
                         <button onClick={handlePdfDownload} className="px-6 py-2 bg-green-600 text-white font-semibold rounded-lg shadow-md hover:bg-green-700">পিডিএফ ডাউনলোড</button>
                         <button onClick={handlePrint} className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700">প্রিন্ট করুন</button>
                    </div>
                    <div className="mx-auto border p-2" style={{width: '21cm', height: '29.7cm'}}>
                        <div id="printable-marksheet" style={{height: '100%', width: '100%'}}>
                           <ReportCardContent reportData={reportData} isMadrasaMode={false} />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default PublishedResult;
