
import React, { useState, useMemo, useEffect } from 'react';
import PageHeader from '../../components/PageHeader';
import { useInstitution, StudentData, ExamData } from '../../context/InstitutionContext';
import { useAuth } from '../../context/AuthContext';
import { DownloadIcon } from '../../components/icons';

const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match] || match);
};

const AdmitCardView: React.FC<{ student: StudentData, exam: ExamData | undefined }> = ({ student, exam }) => {
    // ... Admit card view component (kept as is)
    const { institutionName, logoUrl, address, examRoutineSlots, classLevels, managerInfo } = useInstitution();
    const routine = useMemo(() => {
        if (!exam || !student) return [];
        const studentClass = classLevels.find(cl => cl.name === student.classLevel);
        if (!studentClass) return [];
        const slots = examRoutineSlots.filter(s => s.examId === exam.id && s.classLevelId === studentClass.id);
        const groupedByDate: { [key: string]: { date: Date, morningSubject?: string, afternoonSubject?: string } } = {};
        slots.forEach(slot => {
            const date = new Date(slot.date + 'T00:00:00');
            const dateStr = slot.date;
            const subject = studentClass.subjects.find(s => s.id === slot.subjectId);
            if (!groupedByDate[dateStr]) groupedByDate[dateStr] = { date };
            if (slot.session === 'Morning') groupedByDate[dateStr].morningSubject = subject?.name;
            else if (slot.session === 'Afternoon') groupedByDate[dateStr].afternoonSubject = subject?.name;
        });
        return Object.values(groupedByDate).sort((a,b) => a.date.getTime() - b.date.getTime());
    }, [exam, student, examRoutineSlots, classLevels]);
    const issueDate = new Date().toLocaleDateString('bn-BD');
    return (
        <div id="printable-admit-card" className="w-[19cm] h-[13.2cm] bg-white p-1 relative flex flex-col border-2 border-black" style={{ fontFamily: "'SolaimanLipi', sans-serif" }}>
            <header className="text-center relative z-10 border-b-2 border-black pb-1">
                <div className="flex justify-between items-center">
                    <img src={logoUrl || ''} className="w-20 h-20"/>
                    <div className="flex-grow"><h1 className="text-4xl font-bold">{institutionName}</h1><p className="text-sm">{`${address.village}, ${address.upazila}, ${address.district}`}</p></div>
                    <div className="w-24 h-28 border-2 border-gray-400 flex items-center justify-center text-gray-400">ছবি</div>
                </div>
                <div className="inline-block bg-gray-200 px-8 py-1 text-lg font-semibold rounded mt-1 shadow-sm border border-gray-400">প্রবেশপত্র</div>
            </header>
            <section className="text-base mt-1 relative z-10">
                <p className="text-center font-semibold mb-1">{exam?.name} - {toBengaliNumber(exam?.academicYear || '')}, শ্রেণি/জামাতঃ {student.classLevel}</p>
                <div className="grid grid-cols-2 gap-x-6 gap-y-1.5">
                    <p className="flex items-end"><strong className="w-32 shrink-0">পরীক্ষার্থীর নামঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{student.nameBn}</span></p>
                    <p className="flex items-end"><strong className="w-32 shrink-0">পিতার নামঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{student.fatherNameBn}</span></p>
                    <p className="flex items-end"><strong className="w-32 shrink-0">রোল/সীট নংঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{toBengaliNumber(student.roll || '')}</span></p>
                    <p className="flex items-end"><strong className="w-32 shrink-0">রেজি/দাখেলা নংঃ</strong> <span className="border-b border-dotted border-black flex-grow text-left">{toBengaliNumber(student.uniqueId)}</span></p>
                </div>
            </section>
            <section className="flex-grow mt-2 relative z-10">
                <p className="text-center font-semibold mb-1">পরীক্ষার রুটিন</p>
                <table className="w-full text-sm border-collapse border border-black">
                    <thead><tr className="bg-gray-100"><th className="border border-black p-1 w-24">সময়</th>{routine.map(r => <th key={r.date.toISOString()} className="border border-black p-1">{r.date.toLocaleDateString('bn-BD', { day: 'numeric', month: 'long' })}<br/>{r.date.toLocaleDateString('bn-BD', { weekday: 'long' })}</th>)}</tr></thead>
                    <tbody><tr><td className="border border-black p-1 font-semibold text-center">সকাল</td>{routine.map(r => <td key={r.date.toISOString()} className="border border-black p-1 text-center font-semibold">{r.morningSubject || '*'}</td>)}</tr><tr><td className="border border-black p-1 font-semibold text-center">বিকাল</td>{routine.map(r => <td key={r.date.toISOString()} className="border border-black p-1 text-center font-semibold">{r.afternoonSubject || '*'}</td>)}</tr></tbody>
                </table>
                 {routine.length === 0 && <p className="text-center text-red-500 mt-2">এই পরীক্ষার জন্য কোনো রুটিন তৈরি করা হয়নি।</p>}
            </section>
            <footer className="mt-auto pt-1 flex justify-between items-end relative z-10 text-sm">
                <div className="text-center w-56"><p className="border-t border-dotted border-black pt-1">নাজেমে তা'লীমাতের স্বাক্ষর</p></div>
                <div className="text-center"><p>ইস্যু: {toBengaliNumber(issueDate)}</p></div>
                <div className="text-center w-56">{managerInfo.signatureUrl ? (<img src={managerInfo.signatureUrl} alt="Signature" className="h-8 mx-auto object-contain" />) : <div className="h-8"></div> }<p className="border-t border-dotted border-black pt-1">মুহতামিমের স্বাক্ষর</p></div>
            </footer>
        </div>
    );
};

const Documents: React.FC = () => {
    const { user } = useAuth();
    const { students, exams, academicSessions } = useInstitution();
    const [activeTab, setActiveTab] = useState('monthly_report');
    
    // --- Admit Card State ---
    const [selectedExamId, setSelectedExamId] = useState('');
    const student = useMemo(() => students.find(s => s.id === user?.uid), [students, user]);
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    const availableExams = useMemo(() => {
        if (!student || !activeSession) return [];
        return exams.filter(e => e.academicYear === activeSession.name && e.classLevels.includes(student.classLevel));
    }, [exams, student, activeSession]);
    const selectedExam = useMemo(() => exams.find(e => e.id === selectedExamId), [exams, selectedExamId]);
    
    // --- Monthly Report State ---
    const today = new Date();
    const lastMonthDate = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const [selectedYear, setSelectedYear] = useState(lastMonthDate.getFullYear());
    const [selectedMonth, setSelectedMonth] = useState(lastMonthDate.getMonth());
    const years = Array.from({ length: 5 }, (_, i) => new Date().getFullYear() - i);
    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];

    const handleAdmitCardPrint = () => {
        const printContent = document.getElementById('printable-admit-card');
        if (printContent) {
            const printWindow = window.open('', '', 'height=800,width=1200');
            if(printWindow){
                printWindow.document.write('<html><head><title>Admit Card</title><script src="https://cdn.tailwindcss.com"></script><link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet"><style>body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; } @page { size: A4 portrait; margin: 1cm; } .print-container { display: flex; justify-content: center; align-items: flex-start; }</style></head><body><div class="print-container">');
                printWindow.document.write(printContent.outerHTML);
                printWindow.document.write('</div></body></html>');
                printWindow.document.close();
                setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 750);
            }
        }
    };
    
    const handleGenerateReport = () => {
        const element = document.getElementById("monthly-report-content");
        if (!element || !student) return;

        const monthName = months[selectedMonth];
        const opt = {
            margin: 1,
            filename: `মাসিক-রিপোর্ট-${student.nameBn}-${monthName}-${selectedYear}.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true },
            jsPDF: { unit: 'cm', format: 'a4', orientation: 'portrait' }
        };
        (window as any).html2pdf().from(element).set(opt).save();
    };

    if (!student) return <p>আপনার তথ্য পাওয়া যায়নি।</p>;
    
    return (
        <div>
            <PageHeader icon="📄" title="নথিপত্র" />
            
            <div className="border-b border-gray-200 mb-6">
                <nav className="-mb-px flex space-x-6">
                    <button onClick={() => setActiveTab('monthly_report')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'monthly_report' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>মাসিক রিপোর্ট</button>
                    <button onClick={() => setActiveTab('admit_card')} className={`py-3 px-1 font-semibold text-sm ${activeTab === 'admit_card' ? 'border-b-2 border-teal-500 text-teal-600' : 'text-gray-500 hover:text-gray-700'}`}>প্রবেশপত্র</button>
                </nav>
            </div>

            {activeTab === 'admit_card' && (
                <div className="space-y-6">
                    <div className="bg-white p-4 rounded-xl shadow-md max-w-md">
                        <label htmlFor="exam-select" className="block text-sm font-semibold text-gray-700 mb-1">পরীক্ষা নির্বাচন করুন:</label>
                        <select id="exam-select" value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)} className="w-full p-2 border rounded-md bg-white">
                            <option value="">-- পরীক্ষা নির্বাচন --</option>
                            {availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                        </select>
                    </div>
                    {selectedExamId ? (
                        <div className="space-y-4">
                            <div className="flex justify-end">
                                <button onClick={handleAdmitCardPrint} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg shadow-md hover:bg-teal-700">প্রিন্ট করুন</button>
                            </div>
                            <div className="mx-auto" style={{width: '19cm'}}><AdmitCardView student={student} exam={selectedExam} /></div>
                        </div>
                    ) : (
                        <p className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">প্রবেশপত্র দেখতে অনুগ্রহ করে একটি পরীক্ষা নির্বাচন করুন।</p>
                    )}
                </div>
            )}

            {activeTab === 'monthly_report' && (
                <div className="space-y-6">
                     <div className="bg-white p-4 rounded-xl shadow-md flex flex-wrap items-center gap-4">
                         <div><label className="text-sm font-medium">মাস:</label><select value={selectedMonth} onChange={e => setSelectedMonth(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">{months.map((m, index) => <option key={index} value={index}>{m}</option>)}</select></div>
                         <div><label className="text-sm font-medium">বছর:</label><select value={selectedYear} onChange={e => setSelectedYear(Number(e.target.value))} className="ml-2 p-2 border rounded-md bg-white">{years.map(y=><option key={y} value={y}>{toBengaliNumber(y)}</option>)}</select></div>
                         <button onClick={handleGenerateReport} className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700"><DownloadIcon className="w-5 h-5"/><span>রিপোর্ট ডাউনলোড করুন</span></button>
                    </div>
                     <div className="bg-white p-4 rounded-xl shadow-md">
                        <MonthlyReportContent student={student} month={selectedMonth} year={selectedYear} />
                    </div>
                </div>
            )}
        </div>
    );
};

const MonthlyReportContent: React.FC<{ student: StudentData, month: number, year: number }> = ({ student, month, year }) => {
    const { institutionName, logoUrl, address, attendanceRecords, studentFeeRecords, feeTypes, homeworks, progressBehaviorRecords } = useInstitution();
    const monthName = new Date(year, month).toLocaleString('bn-BD', { month: 'long' });
    const reportTitle = `মাসিক শিক্ষার্থী রিপোর্ট - ${monthName} ${toBengaliNumber(year)}`;
    
    const filterStartDate = new Date(year, month, 1);
    const filterEndDate = new Date(year, month + 1, 0);

    const data = useMemo(() => {
        const filteredAttendance = attendanceRecords.filter(r => { const d = new Date(r.date); return r.studentId === student.id && d >= filterStartDate && d <= filterEndDate; }).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        const filteredFees = studentFeeRecords.filter(r => { const d = new Date(r.paymentDate); return r.studentId === student.id && d >= filterStartDate && d <= filterEndDate; }).sort((a,b) => new Date(a.paymentDate).getTime() - new Date(b.paymentDate).getTime());
        const filteredHomeworks = homeworks.filter(h => { const d = new Date(h.assignDate); return h.classLevel === student.classLevel && h.section === student.section && d >= filterStartDate && d <= filterEndDate; }).sort((a,b) => new Date(a.assignDate).getTime() - new Date(b.assignDate).getTime());
        const filteredNotes = progressBehaviorRecords.filter(n => { const d = new Date(n.date); return n.studentId === student.id && d >= filterStartDate && d <= filterEndDate; }).sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
        return { filteredAttendance, filteredFees, filteredHomeworks, filteredNotes };
    }, [student.id, month, year, attendanceRecords, studentFeeRecords, homeworks, progressBehaviorRecords]);

    const ReportSection: React.FC<{ title: string; children: React.ReactNode; count: number }> = ({ title, children, count }) => (
        <div>
            <h4 className="font-bold text-gray-700 mb-2 border-b-2 border-gray-200 pb-1">{title} ({toBengaliNumber(count)})</h4>
            {count > 0 ? children : <p className="text-sm text-gray-500 py-4 text-center">এই মাসে কোনো রেকর্ড নেই।</p>}
        </div>
    );

    return (
        <div id="monthly-report-content" className="p-4 bg-white text-sm font-['SolaimanLipi']">
            <div className="text-center mb-4 border-b pb-2">
                {logoUrl && <img src={logoUrl} alt="Logo" className="w-16 h-16 rounded-full mx-auto mb-2" />}
                <h2 className="text-2xl font-bold">{institutionName}</h2>
                <p className="text-xs">{`${address.village}, ${address.upazila}, ${address.district}`}</p>
                <h3 className="text-xl font-semibold mt-2">{reportTitle}</h3>
            </div>
            <div className="mb-4 p-2 bg-gray-50 rounded-md">
                <h4 className="font-bold text-center mb-1">শিক্ষার্থীর তথ্য</h4>
                <div className="grid grid-cols-2 gap-x-4 text-xs">
                    <p><strong>নাম:</strong> {student.nameBn}</p>
                    <p><strong>শ্রেণি:</strong> {student.classLevel} ({student.section})</p>
                    <p><strong>রোল:</strong> {toBengaliNumber(student.roll)}</p>
                    <p><strong>আইডি:</strong> {toBengaliNumber(student.uniqueId)}</p>
                </div>
            </div>
            <div className="space-y-6">
                <ReportSection title="হাজিরার সারসংক্ষেপ" count={data.filteredAttendance.length}>
                    <div className="grid grid-cols-3 gap-2 text-center">
                        <div className="bg-green-100 p-2 rounded"><p>উপস্থিত</p><p className="font-bold text-lg">{toBengaliNumber(data.filteredAttendance.filter(a=>a.status === 'present').length)}</p></div>
                        <div className="bg-red-100 p-2 rounded"><p>অনুপস্থিত</p><p className="font-bold text-lg">{toBengaliNumber(data.filteredAttendance.filter(a=>a.status === 'absent').length)}</p></div>
                        <div className="bg-yellow-100 p-2 rounded"><p>ছুটি</p><p className="font-bold text-lg">{toBengaliNumber(data.filteredAttendance.filter(a=>a.status === 'leave').length)}</p></div>
                    </div>
                </ReportSection>
                <ReportSection title="ফি প্রদানের বিবরণ" count={data.filteredFees.length}>
                    <table className="w-full text-xs"><thead><tr className="bg-gray-100"><th className="p-1 border text-left">তারিখ</th><th className="p-1 border text-left">বিবরণ</th><th className="p-1 border text-right">টাকা</th></tr></thead><tbody>{data.filteredFees.map(rec=><tr key={rec.id}><td className="p-1 border">{new Date(rec.paymentDate).toLocaleDateString('bn-BD')}</td><td className="p-1 border">{feeTypes.find(f=>f.id===rec.feeTypeId)?.name} {rec.month && `(${rec.month})`}</td><td className="p-1 border text-right font-semibold">{toBengaliNumber(rec.amountPaid)}</td></tr>)}</tbody><tfoot><tr className="font-bold bg-gray-100"><td colSpan={2} className="p-1 border text-right">মোট জমা</td><td className="p-1 border text-right">{toBengaliNumber(data.filteredFees.reduce((s,r)=>s+r.amountPaid,0))}</td></tr></tfoot></table>
                </ReportSection>
                <ReportSection title="প্রদত্ত হোমওয়ার্ক" count={data.filteredHomeworks.length}>
                    <table className="w-full text-xs"><thead><tr className="bg-gray-100"><th className="p-1 border text-left">বিষয়</th><th className="p-1 border text-left">শিরোনাম</th><th className="p-1 border text-left">জমার তারিখ</th></tr></thead><tbody>{data.filteredHomeworks.map(hw=><tr key={hw.id}><td className="p-1 border">{hw.subject}</td><td className="p-1 border">{hw.title}</td><td className="p-1 border">{new Date(hw.submissionDate).toLocaleDateString('bn-BD')}</td></tr>)}</tbody></table>
                </ReportSection>
                <ReportSection title="অগ্রগতি ও আচরণ" count={data.filteredNotes.length}>
                     <div className="space-y-2">{data.filteredNotes.map(note=><div key={note.id} className="p-2 bg-gray-50 rounded"><span className={`font-semibold text-xs px-2 py-0.5 rounded-full ${note.type === 'Progress' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'}`}>{note.type === 'Progress' ? 'অগ্রগতি' : 'আচরণ'}</span><p className="text-xs text-gray-700 mt-1">{note.note}</p><p className="text-[10px] text-gray-400 text-right">-{note.recordedBy} ({new Date(note.date).toLocaleDateString('bn-BD')})</p></div>)}</div>
                </ReportSection>
            </div>
        </div>
    );
};

export default Documents;
