
import React, { useMemo, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useInstitution, HomeworkData } from '../../context/InstitutionContext';
import { EyeIcon, DownloadIcon } from '../../components/icons';

const ViewHomework: React.FC = () => {
    const { user } = useAuth();
    const { students, homeworks } = useInstitution();
    const [viewModal, setViewModal] = useState<{ isOpen: boolean; homework: HomeworkData | null }>({ isOpen: false, homework: null });
    
    const student = useMemo(() => students.find(s => s.id === user?.uid), [students, user]);

    const studentHomeworks = useMemo(() => {
        if (!student) return [];
        return homeworks
            .filter(hw => hw.classLevel === student.classLevel && hw.section === student.section)
            .sort((a,b) => new Date(b.assignDate).getTime() - new Date(a.assignDate).getTime());
    }, [student, homeworks]);

    const handleView = (hw: HomeworkData) => {
        setViewModal({ isOpen: true, homework: hw });
    };

    if (!student) return <p>আপনার তথ্য পাওয়া যায়নি।</p>;

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">আমার হোমওয়ার্ক</h1>
            <div className="bg-white p-6 rounded-xl shadow-md">
                {studentHomeworks.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-100 text-xs uppercase"><tr className="text-left"><th className="p-2">বিষয়</th><th className="p-2">শিরোনাম</th><th className="p-2">দেওয়ার তারিখ</th><th className="p-2">জমা দেওয়ার তারিখ</th><th className="p-2 text-center">পদক্ষেপ</th></tr></thead>
                            <tbody>
                                {studentHomeworks.map(hw => (
                                    <tr key={hw.id} className="border-b hover:bg-gray-50">
                                        <td className="p-2 font-semibold">{hw.subject}</td>
                                        <td className="p-2">{hw.title}</td>
                                        <td className="p-2">{new Date(hw.assignDate).toLocaleDateString('bn-BD')}</td>
                                        <td className="p-2">{new Date(hw.submissionDate).toLocaleDateString('bn-BD')}</td>
                                        <td className="p-2 text-center"><button onClick={() => handleView(hw)} className="p-2 text-blue-600 hover:bg-blue-100 rounded-full"><EyeIcon className="w-4 h-4" /></button></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">আপনার জন্য কোনো হোমওয়ার্ক নেই।</p>
                )}
            </div>

            {viewModal.isOpen && viewModal.homework && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={() => setViewModal({ isOpen: false, homework: null })}>
                    <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4" onClick={e => e.stopPropagation()}>
                        <div className="p-5 border-b"><h3 className="text-lg font-bold">{viewModal.homework.title}</h3><p className="text-xs text-gray-500">{viewModal.homework.subject}</p></div>
                        <div className="p-5 max-h-80 overflow-y-auto"><p className="whitespace-pre-wrap">{viewModal.homework.description}</p>
                            {viewModal.homework.fileUrl && (
                                <div className="mt-4"><a href={viewModal.homework.fileUrl} download={viewModal.homework.fileName} className="flex items-center gap-2 text-sm text-blue-600 font-semibold hover:underline"><DownloadIcon className="w-4 h-4" /><span>সংযুক্তি ডাউনলোড ({viewModal.homework.fileName})</span></a></div>
                            )}
                        </div>
                        <div className="bg-gray-50 p-3 text-xs text-gray-600 flex justify-between">
                            <span><strong>দেওয়ার তারিখ:</strong> {new Date(viewModal.homework.assignDate).toLocaleDateString('bn-BD')}</span>
                            <span className="font-semibold"><strong>জমা দেওয়ার তারিখ:</strong> {new Date(viewModal.homework.submissionDate).toLocaleDateString('bn-BD')}</span>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ViewHomework;
