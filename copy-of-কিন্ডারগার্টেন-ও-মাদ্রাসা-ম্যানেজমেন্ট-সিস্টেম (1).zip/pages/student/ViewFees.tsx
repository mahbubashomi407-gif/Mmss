
import React, { useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';

const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;

const ViewFees: React.FC = () => {
    const { user } = useAuth();
    const { students, studentFeeRecords, feeTypes, studentFeeSetups, academicSessions } = useInstitution();

    const student = useMemo(() => students.find(s => s.id === user?.uid), [user, students]);
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    const feeHistory = useMemo(() => {
        if (!student) return [];
        return studentFeeRecords
            .filter(rec => rec.studentId === student.id)
            .map(rec => ({...rec, feeTypeName: feeTypes.find(ft => ft.id === rec.feeTypeId)?.name || 'Unknown'}))
            .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
    }, [student, studentFeeRecords, feeTypes]);
    
    const { totalDue, totalPaid, arrears } = useMemo(() => {
        if (!student || !activeSession) return { totalDue: 0, totalPaid: 0, arrears: 0 };
        const setup = studentFeeSetups.find(s => s.studentId === student.id && s.academicYear === activeSession.name);
        
        const paid = feeHistory.reduce((sum, rec) => sum + rec.amountPaid, 0);
        
        if (!setup) {
            return { totalDue: paid, totalPaid: paid, arrears: 0 };
        }

        let due = 0;
        setup.oneTimeFeeTypeIds.forEach(feeId => {
            const feeType = feeTypes.find(ft => ft.id === feeId);
            if (feeType) due += feeType.amount;
        });

        const monthlyFee = feeTypes.find(ft => ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel));
        if (monthlyFee) {
            due += setup.monthlyFeeMonths.length * monthlyFee.amount;
        }

        return { totalDue: due, totalPaid: paid, arrears: due - paid };
    }, [student, activeSession, studentFeeSetups, feeHistory, feeTypes]);
    
    if (!student) return <p>আপনার তথ্য পাওয়া যায়নি।</p>;
    
    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">ফি ও পেমেন্ট</h1>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-blue-50 rounded-lg text-center"><p className="text-sm text-blue-600">মোট প্রদেয়</p><p className="text-2xl font-bold text-blue-700">{formatCurrency(totalDue)}</p></div>
                <div className="p-4 bg-green-50 rounded-lg text-center"><p className="text-sm text-green-600">মোট জমা</p><p className="text-2xl font-bold text-green-700">{formatCurrency(totalPaid)}</p></div>
                <div className="p-4 bg-red-50 rounded-lg text-center"><p className="text-sm text-red-600">মোট বকেয়া</p><p className="text-2xl font-bold text-red-700">{formatCurrency(arrears)}</p></div>
            </div>

            <div className="bg-white p-6 rounded-xl shadow-md">
                <h2 className="text-lg font-bold text-gray-800 mb-3">পেমেন্টের ইতিহাস</h2>
                {feeHistory.length > 0 ? (
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="bg-gray-100">
                                <tr>
                                    <th className="p-2 text-left">তারিখ</th>
                                    <th className="p-2 text-left">বিবরণ</th>
                                    <th className="p-2 text-right">টাকা</th>
                                    <th className="p-2">পদ্ধতি</th>
                                </tr>
                            </thead>
                            <tbody>
                                {feeHistory.map(rec => (
                                    <tr key={rec.id} className="border-b">
                                        <td className="p-2">{new Date(rec.paymentDate).toLocaleDateString('bn-BD')}</td>
                                        <td className="p-2">{rec.feeTypeName} {rec.month && `(${rec.month})`}</td>
                                        <td className="p-2 text-right font-semibold">{formatCurrency(rec.amountPaid)}</td>
                                        <td className="p-2 text-center">{rec.paymentMethod}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <p className="text-center text-gray-500 py-10">এখনো কোনো পেমেন্ট রেকর্ড করা হয়নি।</p>
                )}
            </div>
        </div>
    );
};
export default ViewFees;
