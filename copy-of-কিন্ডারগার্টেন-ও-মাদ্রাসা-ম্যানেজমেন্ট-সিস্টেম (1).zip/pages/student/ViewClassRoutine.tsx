
import React, { useMemo } from 'react';
import PageHeader from '../../components/PageHeader';
import { useInstitution } from '../../context/InstitutionContext';
import { useAuth } from '../../context/AuthContext';

const toBengaliNumber = (numStr: string | number) => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯', ':': ':' };
    return num.replace(/[0-9:]/g, (match) => map[match] || match);
};

const GENERIC_DAY = 'GenericDay';

const ViewClassRoutine: React.FC = () => {
    const { user } = useAuth();
    const { students, classLevels, teachers, routineSlots, timeSlots } = useInstitution();

    const student = useMemo(() => students.find(s => s.id === user?.uid), [students, user]);
    const studentClass = useMemo(() => classLevels.find(cl => cl.name === student?.classLevel), [classLevels, student]);
    
    const sortedTimeSlots = useMemo(() => [...timeSlots].sort((a, b) => a.startTime.localeCompare(b.startTime)), [timeSlots]);

    const dataMaps = useMemo(() => {
        const teacherMap = new Map(teachers.map(t => [t.id, t]));
        const subjectMap = new Map();
        classLevels.forEach(cl => {
            cl.subjects.forEach(s => subjectMap.set(s.id, s));
        });
        return { teacherMap, subjectMap };
    }, [teachers, classLevels]);

    const routineForClass = useMemo(() => {
        if (!studentClass) return [];
        return routineSlots.filter(slot => slot.classLevelId === studentClass.id && slot.day === GENERIC_DAY);
    }, [routineSlots, studentClass]);

    if (!student || !studentClass) {
        return <p>আপনার শ্রেণির রুটিন খুঁজে পাওয়া যায়নি।</p>;
    }

    return (
        <div>
            <PageHeader icon="🗓️" title={`${student.classLevel} (${student.section}) - দৈনিক ক্লাস রুটিন`} />

            <div className="overflow-x-auto bg-white p-4 rounded-xl shadow-md">
                <table className="w-full border-collapse text-sm min-w-[600px]">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="p-2 border font-semibold">সময়</th>
                            <th className="p-2 border font-semibold">বিষয়</th>
                            <th className="p-2 border font-semibold">শিক্ষক</th>
                        </tr>
                    </thead>
                    <tbody>
                        {sortedTimeSlots.map(ts => {
                            const slot = routineForClass.find(s => s.timeSlotId === ts.id);
                            const subject = slot ? dataMaps.subjectMap.get(slot.subjectId) : null;
                            const teacher = slot ? dataMaps.teacherMap.get(slot.teacherId) : null;
                            
                            return (
                                <tr key={ts.id} className="border-b">
                                    <td className="p-2 border font-semibold text-center w-40">
                                        {toBengaliNumber(ts.startTime)} - {toBengaliNumber(ts.endTime)}
                                    </td>
                                    <td className="p-2 border text-center font-bold text-gray-800">
                                        {subject ? subject.name : '-'}
                                    </td>
                                     <td className="p-2 border text-center text-gray-600">
                                        {teacher ? teacher.nameBn : '-'}
                                    </td>
                                </tr>
                            );
                        })}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ViewClassRoutine;
