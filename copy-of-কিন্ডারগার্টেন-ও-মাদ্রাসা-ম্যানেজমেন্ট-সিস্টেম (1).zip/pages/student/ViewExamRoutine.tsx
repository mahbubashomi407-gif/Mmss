
import React, { useState, useMemo } from 'react';
import PageHeader from '../../components/PageHeader';
import { useInstitution, SubjectData, ClassLevelData } from '../../context/InstitutionContext';
import { useAuth } from '../../context/AuthContext';

const ViewExamRoutine: React.FC = () => {
    const { user } = useAuth();
    const { students, exams, classLevels, examRoutineSlots, academicSessions } = useInstitution();
    
    const student = useMemo(() => students.find(s => s.id === user?.uid), [students, user]);
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
    
    const [selectedExamId, setSelectedExamId] = useState<string>('');
    
    const availableExams = useMemo(() => {
        if (!student || !activeSession) return [];
        return exams.filter(e => e.academicYear === activeSession.name && e.classLevels.includes(student.classLevel));
    }, [exams, student, activeSession]);

    const dataMaps = useMemo(() => {
        const subjectMap = new Map<string, SubjectData>();
        const classMap = new Map<string, ClassLevelData>();
        classLevels.forEach(cl => {
            classMap.set(cl.id, cl);
            cl.subjects.forEach(s => subjectMap.set(s.id, s));
        });
        return { subjectMap, classMap };
    }, [classLevels]);

    const selectedExam = useMemo(() => exams.find(e => e.id === selectedExamId), [exams, selectedExamId]);

    const routineDataForExam = useMemo(() => {
        return examRoutineSlots.filter(slot => slot.examId === selectedExamId);
    }, [examRoutineSlots, selectedExamId]);

    const applicableClassLevels = useMemo(() => {
        if (!selectedExam) return [];
        return classLevels.filter(cl => selectedExam.classLevels.includes(cl.name));
    }, [selectedExam, classLevels]);

    const uniqueDates = useMemo(() => {
        const dates = new Set(routineDataForExam.map(slot => slot.date));
        return Array.from(dates).sort((a: string, b: string) => new Date(a).getTime() - new Date(b).getTime());
    }, [routineDataForExam]);

    if (!student) {
        return <p>আপনার তথ্য পাওয়া যায়নি।</p>;
    }

    return (
        <div>
            <PageHeader icon="📝" title="পরীক্ষার রুটিন" />
            
            <div className="bg-white p-4 rounded-xl shadow-md mb-6 max-w-md">
                <label htmlFor="exam-select" className="block text-sm font-semibold text-gray-700 mb-1">পরীক্ষা নির্বাচন করুন:</label>
                <select id="exam-select" value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)} className="w-full p-2 border rounded-md bg-white">
                    <option value="">-- পরীক্ষা নির্বাচন --</option>
                    {availableExams.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                </select>
            </div>
            
            {selectedExamId ? (
                <div className="overflow-x-auto bg-white p-4 rounded-xl shadow-md">
                    {applicableClassLevels.length > 0 && uniqueDates.length > 0 ? (
                        <table className="w-full border-collapse text-sm min-w-[1000px]">
                            <thead>
                                <tr>
                                    <th rowSpan={2} className="p-2 border font-semibold align-middle sticky left-0 bg-gray-50 z-10">শ্রেণি</th>
                                    {uniqueDates.map(date => (
                                        <th key={date} colSpan={2} className="p-1 border font-semibold text-center">
                                            {new Date(date).toLocaleDateString('bn-BD', { day: 'numeric', month: 'long', weekday: 'long' })}
                                        </th>
                                    ))}
                                </tr>
                                <tr>
                                    {uniqueDates.flatMap(date => [<th key={`${date}-m`} className="p-1 border font-semibold text-center">সকাল</th>, <th key={`${date}-a`} className="p-1 border font-semibold text-center">বিকাল</th>])}
                                </tr>
                            </thead>
                            <tbody>
                                {applicableClassLevels.map(cl => (
                                    <tr key={cl.id} className={cl.name === student.classLevel ? 'bg-teal-50' : ''}>
                                        <td className={`p-2 border font-semibold sticky left-0 z-10 ${cl.name === student.classLevel ? 'bg-teal-100' : 'bg-white'}`}>{cl.name}</td>
                                        {uniqueDates.flatMap(date => {
                                            const morningSlot = routineDataForExam.find(s => s.classLevelId === cl.id && s.date === date && s.session === 'Morning');
                                            const afternoonSlot = routineDataForExam.find(s => s.classLevelId === cl.id && s.date === date && s.session === 'Afternoon');
                                            const morningSubject = morningSlot ? dataMaps.subjectMap.get(morningSlot.subjectId) : null;
                                            const afternoonSubject = afternoonSlot ? dataMaps.subjectMap.get(afternoonSlot.subjectId) : null;
                                            
                                            return [
                                                <td key={`${date}-m`} className="p-2 border text-center">{morningSubject ? morningSubject.name : '-'}</td>,
                                                <td key={`${date}-a`} className="p-2 border text-center">{afternoonSubject ? afternoonSubject.name : '-'}</td>
                                            ];
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : <p className="text-center py-10 text-gray-500">এই পরীক্ষার জন্য কোনো রুটিন তৈরি করা হয়নি।</p>}
                </div>
            ) : (
                <p className="text-center text-gray-500 py-10 bg-white rounded-xl shadow-md">রুটিন দেখতে অনুগ্রহ করে একটি পরীক্ষা নির্বাচন করুন।</p>
            )}
        </div>
    );
};

export default ViewExamRoutine;
