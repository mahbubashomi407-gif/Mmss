
import React, { useMemo } from 'react';
import { useInstitution } from '../../context/InstitutionContext';
import { DASHBOARD_ITEMS } from '../../constants/dashboardMap';
import DashboardActionCard from '../../components/DashboardActionCard';
import { useAuth } from '../../context/AuthContext';

const StudentDashboard: React.FC = () => {
    const { user } = useAuth();
    const { studentRoles } = useInstitution();
    
    const permissions = useMemo(() => {
        if (!user?.roleId) return [];
        const role = studentRoles.find(r => r.id === user.roleId);
        return role?.permissions || [];
    }, [user, studentRoles]);

    const accessibleItems = DASHBOARD_ITEMS.filter(item =>
        item.roles.includes('student') && permissions.includes(item.permission)
    );

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-6">শিক্ষার্থী ড্যাশবোর্ড</h1>
            
            {accessibleItems.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    {accessibleItems.map(item => (
                        <DashboardActionCard 
                            key={item.link}
                            to={item.link}
                            icon={item.icon}
                            title={item.title}
                        />
                    ))}
                </div>
            ) : (
                <div className="text-center py-20 bg-white rounded-xl shadow-md">
                    <p className="text-gray-500">আপনার জন্য কোনো অপশন সক্রিয় করা নেই।</p>
                    <p className="text-sm text-gray-400 mt-2">অনুগ্রহ করে এডমিনের সাথে যোগাযোগ করুন।</p>
                </div>
            )}
        </div>
    );
};

export default StudentDashboard;
