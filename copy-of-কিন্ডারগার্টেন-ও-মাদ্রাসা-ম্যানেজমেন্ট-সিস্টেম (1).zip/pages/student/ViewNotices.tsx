
import React, { useMemo } from 'react';
import { useInstitution } from '../../context/InstitutionContext';

const ViewNotices: React.FC = () => {
    const { notices } = useInstitution();
    
    const relevantNotices = useMemo(() => {
        return notices
            .filter(n => n.target.includes('Guardians'))
            .sort((a,b) => new Date(b.publishDate).getTime() - new Date(a.publishDate).getTime());
    }, [notices]);

    return (
        <div>
            <h1 className="text-2xl font-bold text-gray-800 mb-4">নোটিশ বোর্ড</h1>
            <div className="bg-white p-6 rounded-xl shadow-md">
                <div className="space-y-4">
                    {relevantNotices.length > 0 ? relevantNotices.map(n => (
                        <div key={n.id} className="p-4 rounded-lg border border-gray-200">
                             <div className="flex justify-between items-start">
                                <div>
                                    <h3 className="font-bold text-gray-800">{n.title}</h3>
                                    <p className="text-xs text-gray-500 mt-1">প্রকাশের তারিখ: {new Date(n.publishDate).toLocaleDateString('bn-BD')}</p>
                                </div>
                            </div>
                            <p className="text-sm text-gray-600 mt-2 whitespace-pre-wrap">{n.details}</p>
                        </div>
                    )) : (
                        <p className="text-center text-gray-500 py-10">প্রতিষ্ঠানের পক্ষ থেকে কোনো নোটিশ নেই।</p>
                    )}
                </div>
            </div>
        </div>
    );
};

export default ViewNotices;
