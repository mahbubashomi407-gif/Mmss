
import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';
import { useNavigate, Link } from 'react-router-dom';

const StudentLoginPage: React.FC = () => {
    const [institutionCode, setInstitutionCode] = useState('');
    const [studentId, setStudentId] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { studentLogin } = useAuth();
    const { institutionName, logoUrl } = useInstitution();
    const navigate = useNavigate();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            await studentLogin(institutionCode, studentId, password);
            navigate('/student/dashboard', { replace: true });
        } catch (err: any) {
            setError(err.message || 'লগইন ব্যর্থ হয়েছে।');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-400 to-teal-600 p-4">
            <div className="w-full max-w-md bg-white rounded-2xl shadow-2xl p-6 space-y-4">
                <div className="text-center">
                    {logoUrl && <img src={logoUrl} alt={institutionName} className="w-20 h-20 rounded-full mx-auto mb-3 border-2 border-gray-200" />}
                    <h1 className="text-2xl font-bold text-gray-800">{institutionName}</h1>
                    <p className="text-gray-500 mt-1">শিক্ষার্থী পোর্টাল</p>
                </div>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label htmlFor="institutionCode" className="text-sm font-semibold text-gray-600">মাদরাসা কোড</label>
                        <input
                            id="institutionCode"
                            type="text"
                            value={institutionCode}
                            onChange={(e) => setInstitutionCode(e.target.value)}
                            className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                            placeholder="আপনার মাদরাসার কোড"
                            required
                        />
                    </div>
                     <div>
                        <label htmlFor="studentId" className="text-sm font-semibold text-gray-600">শিক্ষার্থী আইডি</label>
                        <input
                            id="studentId"
                            type="text"
                            value={studentId}
                            onChange={(e) => setStudentId(e.target.value)}
                            className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                            placeholder="আপনার ইউনিক আইডি নম্বর"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="password"className="text-sm font-semibold text-gray-600">পাসওয়ার্ড</label>
                        <input
                            id="password"
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full px-4 py-2 mt-1 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                            placeholder="••••••••"
                            required
                        />
                    </div>

                    {error && <p className="text-sm text-red-500 text-center">{error}</p>}

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full py-2 font-semibold text-white bg-green-600 rounded-lg hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:bg-gray-400 transition-colors duration-300"
                    >
                        {loading ? 'প্রসেস হচ্ছে...' : 'লগইন করুন'}
                    </button>
                </form>
                <div className="text-center text-sm text-gray-500 pt-3 border-t mt-4">
                    <Link to="/" className="font-medium text-blue-600 hover:text-blue-500">
                        ফিরে যান
                    </Link>
                </div>
            </div>
        </div>
    );
};

export default StudentLoginPage;
