
import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';
import PageHeader from '../../components/PageHeader';
import { RefreshIcon, CalendarIcon, ChevronDownIcon } from '../../components/icons';
import { useNotification } from '../../context/NotificationContext';

// Helper function to convert numbers to Bengali script
const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, (match) => map[match]);
};

const ViewAttendance: React.FC = () => {
    const { user } = useAuth();
    const { students, attendanceRecords, institutionName, logoUrl, address } = useInstitution();
    const { addToast } = useNotification();

    const today = new Date();
    const [selectedMonth, setSelectedMonth] = useState(today.getMonth()); // 0-indexed
    const [selectedYear, setSelectedYear] = useState(today.getFullYear());

    const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];
    const years = Array.from({ length: 5 }, (_, i) => today.getFullYear() - i); // Current year and 4 previous years

    const student = useMemo(() => students.find(s => s.id === user?.uid), [user, students]);

    const { daysInMonthArray, startDayOfWeek, currentMonthName } = useMemo(() => {
        const firstDayOfMonth = new Date(selectedYear, selectedMonth, 1);
        const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();
        
        return {
            daysInMonthArray: Array.from({ length: daysInMonth }, (_, i) => i + 1),
            startDayOfWeek: firstDayOfMonth.getDay(), // 0 for Sunday, 1 for Monday... 5 for Friday
            currentMonthName: firstDayOfMonth.toLocaleDateString('bn-BD', { month: 'long', year: 'numeric' }),
        };
    }, [selectedYear, selectedMonth]);

    const attendanceMap = useMemo(() => {
        if (!student) return new Map();
        const map = new Map<string, 'present' | 'absent' | 'leave'>();
        const monthFilter = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}`;

        attendanceRecords
            .filter(rec => rec.studentId === student.id && rec.date.startsWith(monthFilter))
            .forEach(rec => {
                map.set(rec.date, rec.status);
            });
        return map;
    }, [student, attendanceRecords, selectedYear, selectedMonth]);

    const monthlySummary = useMemo(() => {
        let present = 0, absent = 0, leave = 0;
        attendanceMap.forEach(status => {
            if (status === 'present') present++;
            else if (status === 'absent') absent++;
            else if (status === 'leave') leave++;
        });
        return { present, absent, leave };
    }, [attendanceMap]);

    const getDayNameShort = (day: number) => {
        const date = new Date(selectedYear, selectedMonth, day);
        return date.toLocaleDateString('bn-BD', { weekday: 'short' });
    };

    const isWeekend = (day: number) => {
        const date = new Date(selectedYear, selectedMonth, day);
        return date.getDay() === 5; // Friday
    };

    const isCurrentDay = (day: number) => {
        const d = new Date();
        return selectedYear === d.getFullYear() && selectedMonth === d.getMonth() && day === d.getDate();
    };

    const handlePrint = () => {
        const printContent = document.getElementById('printable-attendance');
        if (!printContent) {
            addToast('প্রিন্ট করার জন্য কোনো তথ্য পাওয়া যায়নি।', 'error');
            return;
        }

        const printWindow = window.open('', '_blank', 'height=800,width=1200');
        if (!printWindow) {
            addToast('প্রিন্টিং ব্যর্থ হয়েছে। অনুগ্রহ করে এই সাইটের জন্য পপ-আপ অনুমতি দিন।', 'error');
            return;
        }

        const fullAddress = `${address.village}, ${address.upazila}, ${address.district}`;

        printWindow.document.write('<html><head>');
        printWindow.document.write(`<title>${student?.nameBn}-এর মাসিক হাজিরা</title>`);
        printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
        printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
        printWindow.document.write(`
            <style>
                body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                @page { size: A4 portrait; margin: 0.75in; }
                .print-header { text-align: center; margin-bottom: 1rem; padding-bottom: 0.5rem; border-bottom: 2px solid #333; }
                .print-header img { height: 50px; width: 50px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.25rem; }
                .print-header h1 { font-size: 1.5rem; font-weight: bold; margin: 0; }
                .print-header p { margin: 0.1rem 0; font-size: 0.8rem; }
                .summary-card { padding: 8px; border-radius: 8px; text-align: center; }
                .calendar-grid { display: grid; grid-template-columns: repeat(7, 1fr); gap: 2px; }
                .calendar-cell { height: 60px; display: flex; flex-col; items-center; justify-center; border-radius: 4px; font-size: 12px; }
                .calendar-cell .day-number { font-weight: bold; margin-bottom: 2px; }
            </style>
        `);
        printWindow.document.write('</head><body>');
        printWindow.document.write(`
            <div class="print-header">
                ${logoUrl ? `<img src="${logoUrl}" alt="লোগো" />` : ''}
                <h1>${institutionName}</h1>
                <p>${fullAddress}</p>
                <h2>${student?.nameBn}-এর মাসিক হাজিরা</h2>
                <h3>${currentMonthName}</h3>
            </div>
        `);
        printWindow.document.write(printContent.innerHTML);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        
        setTimeout(() => {
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }, 750);
    };


    if (!student) return <p>আপনার তথ্য পাওয়া যায়নি।</p>;

    return (
        <div>
            <PageHeader icon="📅" title={`${student.nameBn}-এর হাজিরা`} >
                <button onClick={handlePrint} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition-colors">
                    প্রিন্ট করুন
                </button>
            </PageHeader>
            
            <div className="bg-white p-6 rounded-xl shadow-md">
                {/* Month/Year Selector */}
                <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                    <div className="flex items-center gap-2">
                        <label htmlFor="month-select" className="sr-only">মাস নির্বাচন করুন</label>
                        <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                                <CalendarIcon className="w-5 h-5 text-gray-400" />
                            </span>
                            <select
                                id="month-select"
                                value={selectedMonth}
                                onChange={e => setSelectedMonth(Number(e.target.value))}
                                className="w-32 pl-10 pr-4 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"
                            >
                                {months.map((monthName, index) => (
                                    <option key={index} value={index}>{monthName}</option>
                                ))}
                            </select>
                            <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                                <ChevronDownIcon className="w-4 h-4 text-gray-500" />
                            </span>
                        </div>
                        <label htmlFor="year-select" className="sr-only">বছর নির্বাচন করুন</label>
                        <div className="relative">
                            <select
                                id="year-select"
                                value={selectedYear}
                                onChange={e => setSelectedYear(Number(e.target.value))}
                                className="w-24 pl-3 pr-8 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white appearance-none"
                            >
                                {years.map(year => (
                                    <option key={year} value={year}>{toBengaliNumber(year)}</option>
                                ))}
                            </select>
                            <span className="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                                <ChevronDownIcon className="w-4 h-4 text-gray-500" />
                            </span>
                        </div>
                    </div>
                    <button 
                        onClick={() => { setSelectedMonth(today.getMonth()); setSelectedYear(today.getFullYear()); }}
                        className="p-2.5 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 flex-shrink-0"
                        title="রিসেট"
                    >
                        <RefreshIcon className="w-5 h-5" />
                    </button>
                </div>

                {/* Monthly Summary */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6" id="printable-summary-section">
                    <div className="p-4 bg-green-50 rounded-lg text-center">
                        <p className="text-sm text-green-600">উপস্থিত</p>
                        <p className="text-3xl font-bold text-green-700">{toBengaliNumber(monthlySummary.present)}</p>
                    </div>
                    <div className="p-4 bg-red-50 rounded-lg text-center">
                        <p className="text-sm text-red-600">অনুপস্থিত</p>
                        <p className="text-3xl font-bold text-red-700">{toBengaliNumber(monthlySummary.absent)}</p>
                    </div>
                    <div className="p-4 bg-yellow-50 rounded-lg text-center">
                        <p className="text-sm text-yellow-600">ছুটি</p>
                        <p className="text-3xl font-bold text-yellow-700">{toBengaliNumber(monthlySummary.leave)}</p>
                    </div>
                </div>

                {/* Calendar Grid */}
                <div className="border rounded-lg p-2 bg-gray-50" id="printable-calendar-section">
                    <h3 className="text-center font-bold text-lg text-gray-800 mb-4">{currentMonthName}</h3>
                    <div className="calendar-grid">
                        {['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'].map(dayName => (
                            <div key={dayName} className="text-center font-bold text-gray-700 py-2 text-sm">{dayName}</div>
                        ))}
                        {Array.from({ length: startDayOfWeek }).map((_, index) => (
                            <div key={`empty-${index}`} className="calendar-cell"></div>
                        ))}
                        {daysInMonthArray.map(day => {
                            const dateString = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                            const status = attendanceMap.get(dateString);
                            let bgColor = 'bg-white';
                            let textColor = 'text-gray-800';
                            
                            if (status === 'present') { bgColor = 'bg-green-100'; textColor = 'text-green-800'; }
                            else if (status === 'absent') { bgColor = 'bg-red-100'; textColor = 'text-red-800'; }
                            else if (status === 'leave') { bgColor = 'bg-yellow-100'; textColor = 'text-yellow-800'; }

                            if (isWeekend(day)) {
                                bgColor = 'bg-gray-200';
                                // Keep status colors even on weekends if recorded
                                if (status === 'present') { bgColor = 'bg-green-200'; }
                                else if (status === 'absent') { bgColor = 'bg-red-200'; }
                                else if (status === 'leave') { bgColor = 'bg-yellow-200'; }
                            }

                            const ringClass = isCurrentDay(day) ? 'ring-2 ring-teal-500' : '';

                            return (
                                <div key={day} className={`calendar-cell ${bgColor} ${ringClass}`}>
                                    <span className={`day-number ${textColor}`}>{toBengaliNumber(day)}</span>
                                    <span className="text-xs text-gray-500">{getDayNameShort(day)}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>

            {/* Hidden printable area for specific sections */}
            <div id="printable-attendance" className="hidden">
                <div className="mb-4">
                    <h3 className="text-xl font-bold text-gray-800 text-center mb-4">মাসিক সারাংশ</h3>
                    <div className="grid grid-cols-3 gap-4">
                        <div className="summary-card bg-green-50">
                            <p className="text-green-600">উপস্থিত</p>
                            <p className="text-2xl font-bold text-green-700">{toBengaliNumber(monthlySummary.present)}</p>
                        </div>
                        <div className="summary-card bg-red-50">
                            <p className="text-red-600">অনুপস্থিত</p>
                            <p className="text-2xl font-bold text-red-700">{toBengaliNumber(monthlySummary.absent)}</p>
                        </div>
                        <div className="summary-card bg-yellow-50">
                            <p className="text-sm text-yellow-600">ছুটি</p>
                            <p className="text-2xl font-bold text-yellow-700">{toBengaliNumber(monthlySummary.leave)}</p>
                        </div>
                    </div>
                </div>

                <div className="mt-8">
                    <h3 className="text-xl font-bold text-gray-800 text-center mb-4">হাজিরা ক্যালেন্ডার</h3>
                    <div className="calendar-grid border border-gray-300">
                        {['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'].map(dayName => (
                            <div key={dayName} className="text-center font-bold text-gray-700 py-2 text-sm border-b border-r border-gray-300 last:border-r-0 bg-gray-100">{dayName}</div>
                        ))}
                        {Array.from({ length: startDayOfWeek }).map((_, index) => (
                            <div key={`empty-${index}-print`} className="calendar-cell border border-gray-300"></div>
                        ))}
                        {daysInMonthArray.map(day => {
                            const dateString = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                            const status = attendanceMap.get(dateString);
                            let bgColor = 'bg-white';
                            let textColor = 'text-gray-800';
                            
                            if (status === 'present') { bgColor = 'bg-green-100'; textColor = 'text-green-800'; }
                            else if (status === 'absent') { bgColor = 'bg-red-100'; textColor = 'text-red-800'; }
                            else if (status === 'leave') { bgColor = 'bg-yellow-100'; textColor = 'text-yellow-800'; }

                            if (isWeekend(day)) {
                                bgColor = 'bg-gray-200';
                                if (status === 'present') { bgColor = 'bg-green-200'; }
                                else if (status === 'absent') { bgColor = 'bg-red-200'; }
                                else if (status === 'leave') { bgColor = 'bg-yellow-200'; }
                            }

                            return (
                                <div key={`print-${day}`} className={`calendar-cell border border-gray-300 ${bgColor}`}>
                                    <span className={`day-number ${textColor}`}>{toBengaliNumber(day)}</span>
                                    <span className="text-xs text-gray-500">{getDayNameShort(day)}</span>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ViewAttendance;
    