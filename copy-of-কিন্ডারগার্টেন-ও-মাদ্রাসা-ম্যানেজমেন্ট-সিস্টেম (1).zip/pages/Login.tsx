
import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { UserRole } from '../types';
import { EyeIcon, EyeSlashIcon, UserCircleIcon, LockClosedIcon, BuildingOfficeIcon, InfoIcon, LightningBoltIcon } from '../components/icons';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../services/firebase';
import Spinner from '../components/Spinner';

// --- SVG Icons for Inputs ---
const EnvelopeIcon: React.FC<{ className?: string }> = ({ className }) => <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}><path strokeLinecap="round" strokeLinejoin="round" d="M21.75 6.75v10.5a2.25 2.25 0 01-2.25 2.25h-15a2.25 2.25 0 01-2.25-2.25V6.75m19.5 0A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25m19.5 0v.243a2.25 2.25 0 01-1.07 1.916l-7.5 4.615a2.25 2.25 0 01-2.36 0L3.32 8.91a2.25 2.25 0 01-1.07-1.916V6.75" /></svg>;

interface LoginProps {
    onForgotPasswordClick: (e: React.MouseEvent) => void;
}

const ManagementLogin: React.FC<LoginProps> = ({ onForgotPasswordClick }) => {
    const [institutionCode, setInstitutionCode] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { login } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            await login(institutionCode, email, password);
        } catch (err: any) {
            setError(err.message || 'লগইন ব্যর্থ হয়েছে।');
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} noValidate>
             <div className="input-group">
                <span className="icon"><BuildingOfficeIcon className="w-5 h-5" /></span>
                <input id="institutionCode" type="text" value={institutionCode} onChange={(e) => setInstitutionCode(e.target.value)} placeholder="প্রতিষ্ঠানের কোড" required />
            </div>
            <div className="input-group">
                <span className="icon"><EnvelopeIcon className="w-5 h-5" /></span>
                <input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="ইমেইল" required />
            </div>
            <div className="input-group">
                <span className="icon"><LockClosedIcon className="w-5 h-5" /></span>
                <input id="password" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="পাসওয়ার্ড" required />
                 <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 px-4 flex items-center text-gray-400" aria-label="Toggle password visibility">
                    {showPassword ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
            </div>
            {error && <p className="text-sm text-red-300 text-center mb-4 -mt-2">{error}</p>}
             <div className="options-row">
                <label>
                    <input type="checkbox" />
                    <span>মনে রাখুন</span>
                </label>
                <button type="button" onClick={onForgotPasswordClick}>পাসওয়ার্ড ভুলে গেছেন?</button>
            </div>
            <button type="submit" disabled={loading} className="login-button">
                {loading ? 'লোড হচ্ছে...' : 'লগইন'}
            </button>
        </form>
    );
};

const StudentLogin: React.FC<LoginProps> = ({ onForgotPasswordClick }) => {
    const [institutionCode, setInstitutionCode] = useState('');
    const [studentId, setStudentId] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const { studentLogin } = useAuth();

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            await studentLogin(institutionCode, studentId, password);
        } catch (err: any) {
            setError(err.message || 'লগইন ব্যর্থ হয়েছে।');
        } finally {
            setLoading(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} noValidate>
            <div className="input-group">
                <span className="icon"><BuildingOfficeIcon className="w-5 h-5" /></span>
                <input id="studentInstitutionCode" type="text" value={institutionCode} onChange={(e) => setInstitutionCode(e.target.value)} placeholder="প্রতিষ্ঠানের কোড" required />
            </div>
             <div className="input-group">
                <span className="icon"><UserCircleIcon className="w-5 h-5" /></span>
                <input id="studentId" type="text" value={studentId} onChange={(e) => setStudentId(e.target.value)} placeholder="শিক্ষার্থী আইডি" required />
            </div>
            <div className="input-group">
                <span className="icon"><LockClosedIcon className="w-5 h-5" /></span>
                <input id="studentPassword" type={showPassword ? 'text' : 'password'} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="পাসওয়ার্ড" required />
                 <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute inset-y-0 right-0 px-4 flex items-center text-gray-400" aria-label="Toggle password visibility">
                    {showPassword ? <EyeSlashIcon className="w-5 h-5" /> : <EyeIcon className="w-5 h-5" />}
                </button>
            </div>
            {error && <p className="text-sm text-red-300 text-center mb-4 -mt-2">{error}</p>}
             <div className="options-row">
                <label>
                    <input type="checkbox" />
                    <span>মনে রাখুন</span>
                </label>
                 <button type="button" onClick={onForgotPasswordClick}>পাসওয়ার্ড ভুলে গেছেন?</button>
            </div>
            <button type="submit" disabled={loading} className="login-button">
                {loading ? 'প্রসেস হচ্ছে...' : 'লগইন'}
            </button>
        </form>
    );
};


const Stars = () => {
    const starStyles = useMemo(() => {
        const styles = [];
        for (let i = 0; i < 50; i++) {
            styles.push({
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 2000}px`,
                width: `${Math.random() * 1.5 + 0.5}px`,
                height: `${Math.random() * 1.5 + 0.5}px`,
                animationDelay: `${Math.random() * 2}s`,
            });
        }
        return styles;
    }, []);

    return (
        <div className="stars">
            <div className="stars-sm">
                {starStyles.map((style, i) => <div key={i} className="star" style={style}></div>)}
            </div>
             <div className="stars-md">
                {starStyles.map((style, i) => <div key={i} className="star" style={{...style, top: `${Math.random() * 2000}px`}}></div>)}
            </div>
             <div className="stars-lg">
                {starStyles.map((style, i) => <div key={i} className="star" style={{...style, top: `${Math.random() * 2000}px`}}></div>)}
            </div>
        </div>
    );
};

const LoginPage: React.FC = () => {
    const [activeTab, setActiveTab] = useState<'management' | 'student'>('management');
    const { user, login } = useAuth();
    const navigate = useNavigate();
    const [globalSettings, setGlobalSettings] = useState<{ isRegistrationOpen: boolean; loginBackgroundUrl?: string | null; showQuickLoginButton: boolean } | null>(null);
    const [showForgotPasswordModal, setShowForgotPasswordModal] = useState(false);

     useEffect(() => {
        document.body.classList.add('login-page-active');
        const bgUrl = globalSettings?.loginBackgroundUrl;
        if (bgUrl) {
            document.body.classList.add('custom-bg');
            document.body.style.setProperty('--bg-image', `url(${bgUrl})`);
        } else {
            document.body.classList.remove('custom-bg');
            document.body.style.removeProperty('--bg-image');
        }
        return () => {
            document.body.classList.remove('login-page-active');
            document.body.classList.remove('custom-bg');
            document.body.style.removeProperty('--bg-image');
        };
    }, [globalSettings]);
    
    useEffect(() => {
        if (showForgotPasswordModal) {
            const timer = setTimeout(() => {
                setShowForgotPasswordModal(false);
            }, 3000); // 3 seconds
            return () => clearTimeout(timer);
        }
    }, [showForgotPasswordModal]);

    useEffect(() => {
        const docRef = doc(db, 'superAdminData', 'settings');
        const defaultSettings = { isRegistrationOpen: true, showQuickLoginButton: true, loginBackgroundUrl: null };
        
        const unsubscribe = onSnapshot(docRef, (docSnap) => {
            try {
                if (docSnap.exists() && docSnap.data().settings) {
                    const settings = docSnap.data().settings;
                    setGlobalSettings({ ...defaultSettings, ...settings });
                } else {
                    setGlobalSettings(defaultSettings);
                }
            } catch (error) {
                console.error("Error fetching global settings with snapshot:", error);
                setGlobalSettings(defaultSettings);
            }
        }, (error) => {
            console.error("Snapshot error on global settings:", error);
            setGlobalSettings(defaultSettings);
        });

        return () => unsubscribe();
    }, []);

    useEffect(() => {
        if (user) {
            const dashboardPath = user.role === UserRole.STUDENT || user.role === UserRole.GUARDIAN ? '/student/dashboard' 
                            : user.role === UserRole.SUPER_ADMIN ? '/superadmin/dashboard'
                            : '/app/dashboard';
            navigate(dashboardPath, { replace: true });
        }
    }, [user, navigate]);

    if (user || globalSettings === null) {
        return <Spinner />;
    }
    
    const handleForgotPasswordClick = (e: React.MouseEvent) => {
        e.preventDefault();
        setShowForgotPasswordModal(true);
    };

    const handleQuickAdminLogin = async () => {
        try {
            await login('501', 'admin@example.com', '123456');
            // Navigation handled by useEffect when `user` changes
        } catch (error: any) {
            alert(error.message || '501 এডমিন লগইন ব্যর্থ হয়েছে।');
        }
    };
    
    return (
        <div className="min-h-screen flex flex-col items-center justify-center p-4">
            <Stars />
            <div className="glass-container">
                <h2 className="text-3xl font-bold text-center mb-6">
                    {activeTab === 'management' ? 'লগইন' : 'শিক্ষার্থী লগইন'}
                </h2>
                
                {activeTab === 'management' ? <ManagementLogin onForgotPasswordClick={handleForgotPasswordClick} /> : <StudentLogin onForgotPasswordClick={handleForgotPasswordClick} />}

                <div className="bottom-links">
                    <p>
                        {activeTab === 'management' ? 'আপনি কি একজন শিক্ষার্থী?' : 'আপনি কি ম্যানেজমেন্টের অংশ?'}
                        <button onClick={() => setActiveTab(activeTab === 'management' ? 'student' : 'management')} className="font-semibold ml-2 switch-link">
                            এখানে ক্লিক করুন
                        </button>
                    </p>
                    {globalSettings.isRegistrationOpen && (
                        <p className="mt-2">
                            নতুন প্রতিষ্ঠান?
                            <Link to="/register-institution" className="font-bold ml-2 text-white underline hover:text-yellow-300">
                                রেজিস্ট্রেশন করুন
                            </Link>
                        </p>
                    )}
                </div>
            </div>
            
            {showForgotPasswordModal && (
                <div className="fixed inset-0 z-[999] flex items-center justify-center bg-black/60 backdrop-blur-sm transition-opacity duration-300">
                    <div className="bg-white rounded-xl shadow-2xl p-8 m-4 max-w-sm text-center transform transition-all animate-fade-in-up">
                        <InfoIcon className="w-16 h-16 text-teal-500 mx-auto mb-4" />
                        <p className="text-lg font-semibold text-gray-800" style={{ fontFamily: "'SolaimanLipi', sans-serif" }}>
                            অনুগ্রহ করে আপনার প্রতিষ্ঠানের কর্তৃপক্ষের সাথে যোগাযোগ করুন।
                        </p>
                    </div>
                </div>
            )}

            {!user && globalSettings.showQuickLoginButton && (
                <button
                    onClick={handleQuickAdminLogin}
                    className="fixed bottom-4 left-4 z-40 w-12 h-12 bg-purple-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-purple-700 transition transform hover:scale-110"
                    title="501 এডমিন হিসেবে দ্রুত লগইন করুন"
                    aria-label="Quick login as 501 admin"
                >
                    <LightningBoltIcon className="w-6 h-6" />
                </button>
            )}
        </div>
    );
};

export default LoginPage;
