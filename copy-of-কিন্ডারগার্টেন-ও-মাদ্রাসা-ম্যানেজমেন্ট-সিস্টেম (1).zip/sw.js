// This is the service worker script, which executes in its own context
// when the app is installed or updated, and on certain events.

const CACHE_NAME = 'kindergarten-management-v2'; // Versioned cache name

// This is a list of core files that make up the "app shell".
// We'll cache them on install. Other resources will be cached on-the-fly.
const APP_SHELL_URLS = [
  '/',
  'index.html',
  'icon-192.png',
  'icon-512.png',
  'screenshot1.png',
  'screenshot2.png',
  // Key CDN assets. Others will be cached dynamically.
  'https://cdn.tailwindcss.com',
  'https://fonts.maateen.me/solaiman-lipi/font.css',
  'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
];

// The install handler takes care of precaching the resources we always need.
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('Service Worker: Caching app shell');
        return cache.addAll(APP_SHELL_URLS);
      })
      .catch(error => {
        console.error('Failed to cache app shell:', error);
      })
  );
});

// The activate handler takes care of cleaning up old caches.
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Service Worker: Deleting old cache', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// The fetch handler serves responses for network requests from the cache first.
// If a resource isn't in the cache, it gets fetched from the network,
// cached for future use, and then returned to the page.
self.addEventListener('fetch', (event) => {
  // We only want to cache GET requests.
  if (event.request.method !== 'GET') {
    return;
  }
  
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        // If we have a cached response, return it.
        if (response) {
          return response;
        }

        // If the resource is not in the cache, fetch it from the network.
        return fetch(event.request).then(
          (response) => {
            // We can't cache responses that are not OK, or chrome-extension:// URLs
            if (!response || response.status !== 200 || response.url.startsWith('chrome-extension://')) {
              return response;
            }

            // Clone the response because it's a stream and can only be consumed once.
            // We need one for the cache and one for the browser.
            const responseToCache = response.clone();

            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(event.request, responseToCache);
              });

            return response;
          }
        ).catch(error => {
            console.error('Service Worker: Fetch failed.', error);
            // Optional: return an offline fallback page if the fetch fails.
        });
      })
  );
});


// A listener for the 'notificationclick' event.
self.addEventListener('notificationclick', (event) => {
    // Close the notification pop-up.
    event.notification.close();

    // The code below is focused on opening a new window or focusing an existing one.
    // It looks for any open windows of our app.
    event.waitUntil(
        clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
            // If there's an open window, focus it.
            if (clientList.length > 0) {
                let client = clientList[0];
                for (let i = 0; i < clientList.length; i++) {
                    if (clientList[i].focused) {
                        client = clientList[i];
                    }
                }
                return client.focus();
            }
            // If there's no open window, open a new one to the root of the app.
            return clients.openWindow('/');
        })
    );
});