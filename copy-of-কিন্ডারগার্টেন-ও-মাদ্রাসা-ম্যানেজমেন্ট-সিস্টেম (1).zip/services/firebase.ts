

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { initializeFirestore, persistentLocalCache, memoryLocalCache } from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyBYELmY9lx8t3WvvZN4BtNE4_GP7-LwYpw",
  authDomain: "management-system-2c67f.firebaseapp.com",
  projectId: "management-system-2c67f",
  storageBucket: "management-system-2c67f.firebasestorage.app",
  messagingSenderId: "232947351433",
  appId: "1:232947351433:web:baaae5cf97e644c0a92b58",
  measurementId: "G-26KNVF54FV"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app);

// Enable offline persistence for Firestore using the new API with error handling.
let db;
try {
  db = initializeFirestore(app, {
    localCache: persistentLocalCache({})
  });
} catch (error: any) {
  if (error.code == 'failed-precondition') {
    // This can happen if multiple tabs are open, as persistence can only be
    // enabled in one tab at a time. It can also be caused by private browsing modes.
    console.warn('Firestore persistence failed: Multiple tabs open or private browsing mode detected.');
    // Fallback to memory cache
    db = initializeFirestore(app, {
        localCache: memoryLocalCache()
    });
  } else if (error.code == 'unimplemented') {
    // The current browser does not support all of the features required to enable persistence.
    console.warn('Firestore persistence is not available in this browser.');
     // Fallback to memory cache
    db = initializeFirestore(app, {
        localCache: memoryLocalCache()
    });
  } else {
    // Some other error occurred
    console.error("Firestore initialization error:", error);
    // Fallback to memory cache as a last resort
     db = initializeFirestore(app, {
        localCache: memoryLocalCache()
    });
  }
}

export { app, auth, db, analytics };
