
import React, { useEffect, useState, useRef } from 'react';
import { HashRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage from './pages/Login';
import Dashboard from './pages/Dashboard';
import AppLayout from './components/layouts/AppLayout';
import ManageStudents from './pages/admin/ManageStudents';
import ManageTeachers from './pages/admin/ManageTeachers';
import ManageAttendance from './pages/admin/ManageAttendance';
import ManageTeacherAttendance from './pages/admin/ManageTeacherAttendance';
import ManageCurriculum from './pages/admin/ManageCurriculum';
import ManageHomework from './pages/admin/ManageHomework';
import ManageExams from './pages/admin/ManageExams';
import ManageFees from './pages/admin/ManageFees';
import ManageNotices from './pages/admin/ManageNotices';
import ManageReports from './pages/admin/ManageReports';
import Settings from './pages/admin/Settings';
import { UserRole } from './types';
import InstitutionInfo from './pages/admin/InstitutionInfo';
import { InstitutionProvider } from './context/InstitutionContext';
import { NotificationProvider } from './context/NotificationContext';
import InstitutionName from './pages/admin/institution/InstitutionName';
import UploadLogo from './pages/admin/institution/UploadLogo';
import Address from './pages/admin/institution/Address';
import ContactInfo from './pages/admin/institution/ContactInfo';
import AcademicSession from './pages/admin/institution/AcademicSession';
import ManagerInfo from './pages/admin/institution/ManagerInfo';
import Schedule from './pages/admin/institution/Schedule';
import Sections from './pages/admin/institution/Sections';
import SocialMedia from './pages/admin/institution/SocialMedia';
import License from './pages/admin/institution/License';
import AcademicYearSetup from './pages/admin/settings/AcademicYearSetup';
import ClassSetup from './pages/admin/settings/ClassSetup';
import FeeTypes from './pages/admin/settings/FeeTypes';
import HolidayList from './pages/admin/settings/HolidayList';
import FundCategory from './pages/admin/settings/FundCategory';
import DatabaseBackup from './pages/admin/settings/DatabaseBackup';
import GeneralSettings from './pages/admin/settings/GeneralSettings';
import PaymentGatewaySettings from './pages/admin/settings/PaymentGateway';
import GlobalSettings from './pages/admin/GlobalSettings';
import ManageGenders from './pages/admin/global-settings/ManageGenders';
import ManageBloodGroups from './pages/admin/global-settings/ManageBloodGroups';
import ManageReligions from './pages/admin/global-settings/ManageReligions';
import ManageNationalities from './pages/admin/global-settings/ManageNationalities';
import ManageDesignations from './pages/admin/global-settings/ManageDesignations';
import AddStudent from './pages/admin/students/AddStudent';
import OnlineAdmission from './pages/admin/students/OnlineAdmission';
import StudentList from './pages/admin/students/StudentList';
import StudentProfile from './pages/admin/students/StudentProfile';
import GuardianInfo from './pages/admin/students/GuardianInfo';
import RollSectionChange from './pages/admin/students/RollSectionChange';
import StatusChange from './pages/admin/students/StatusChange';
import GenerateIdCard from './pages/admin/students/GenerateIdCard';
import PendingApplications from './pages/admin/students/PendingApplications';
import Promotion from './pages/admin/students/Promotion';
import ProgressBehavior from './pages/admin/students/ProgressBehavior';
import FeeInfo from './pages/admin/students/FeeInfo';
import AddTeacher from './pages/admin/teachers/AddTeacher';
import TeacherList from './pages/admin/teachers/TeacherList';
import TeacherProfile from './pages/admin/teachers/TeacherProfile';
import ClassAssignment from './pages/admin/teachers/ClassAssignment';
import SubjectAssignment from './pages/admin/teachers/SubjectAssignment';
import StudentAssignment from './pages/admin/teachers/StudentAssignment';
import AssignHomework from './pages/admin/teachers/AssignHomework';
import Salary from './pages/admin/teachers/Salary';
import TeacherNoticeMessage from './pages/admin/teachers/NoticeMessage';
import TeacherReport from './pages/admin/teachers/TeacherReport';
import TeacherStatusChange from './pages/admin/teachers/StatusChange';
import EnterMarks from './pages/teacher/EnterMarks';
import StudentAttendance from './pages/teacher/StudentAttendance';
import DailyTeacherAttendance from './pages/admin/teacher-attendance/DailyTeacherAttendance';
import LeaveApplications from './pages/admin/teacher-attendance/LeaveApplications';
import DailyAttendance from './pages/admin/attendance/DailyAttendance';
import AttendanceReport from './pages/admin/attendance/AttendanceReport';
import EditAttendance from './pages/admin/attendance/EditAttendance';
import AbsenceSummary from './pages/admin/attendance/AbsenceSummary';
import ExportReport from './pages/admin/attendance/ExportReport';
import ArrivalDeparture from './pages/admin/attendance/ArrivalDeparture';
import CurriculumSubjects from './pages/admin/curriculum/Subjects';
import CurriculumProgressTracking from './pages/admin/curriculum/ProgressTracking';
import TeacherComments from './pages/admin/curriculum/TeacherComments';
import AddHomework from './pages/admin/homework/AddHomework';
import HomeworkList from './pages/admin/homework/HomeworkList';
import Deadlines from './pages/admin/homework/Deadlines';
import EditHomework from './pages/admin/homework/EditHomework';
import EditFees from './pages/admin/fees/EditFees';
import DueReport from './pages/admin/fees/DueReport';
import ClassSummary from './pages/admin/fees/ClassSummary';
import SalaryReport from './pages/admin/fees/SalaryReport';
import ManageIncomeExpense from './pages/admin/ManageIncomeExpense';
import AddIncome from './pages/admin/income-expense/AddIncome';
import AddExpense from './pages/admin/income-expense/AddExpense';
import IncomeExpenseReport from './pages/admin/income-expense/IncomeExpenseReport';
import MonthlySummaryIE from './pages/admin/income-expense/MonthlySummary';
import YearlySummaryIE from './pages/admin/income-expense/YearlySummary';
import CreateExam from './pages/admin/exams/CreateExam';
import ExamList from './pages/admin/exams/ExamList';
import MarkEntry from './pages/admin/exams/MarkEntry';
import ClassResult from './pages/admin/exams/ClassResult';
import EditResult from './pages/admin/exams/EditResult';
import ExportExamReport from './pages/admin/exams/ExportExamReport';
import AdmitCard from './pages/admin/exams/AdmitCard';
import SeatPlan from './pages/admin/exams/SeatPlan';
import GradeProcessing from './pages/admin/exams/GradeProcessing';
import ResultSummary from './pages/admin/exams/ResultSummary';
import PublishResult from './pages/admin/exams/PublishResult';
import ExamSubjectAssignment from './pages/admin/exams/ExamSubjectAssignment';
import NombroPotro from './pages/admin/exams/NombroPotro';
import EvaluationReport from './pages/admin/exams/EvaluationReport';
import StudentFeeReport from './pages/admin/reports/StudentFeeReport';
import ClassFeeSummaryReport from './pages/admin/reports/ClassFeeSummaryReport';
import ManageRoutine from './pages/admin/ManageRoutine';
import ClassRoutine from './pages/admin/routine/ClassRoutine';
import ExamRoutine from './pages/admin/routine/ExamRoutine';
import ManageUserRoles from './pages/admin/ManageUserRoles';
import CreateUser from './pages/admin/user-roles/CreateUser';
import UserList from './pages/admin/user-roles/UserList';
import Permissions from './pages/admin/user-roles/Permissions';
import ManageMadrasaExams from './pages/admin/ManageMadrasaExams';
import GuardianLayout from './components/layouts/GuardianLayout';
import GuardianDashboard from './pages/guardian/GuardianDashboard';
import GuardianViewAttendance from './pages/guardian/ViewAttendance';
import GuardianViewMarks from './pages/guardian/ViewMarks';
import { PermissionGuard } from './components/PermissionGuard';
import InstitutionCode from './pages/admin/institution/InstitutionCode';
import AutomaticNotifications from './pages/admin/settings/AutomaticNotifications';
import GuardianNotifications from './pages/guardian/Notifications';
import ViewHomework from './pages/student/ViewHomework';
import ViewNotices from './pages/student/ViewNotices';
import ViewFees from './pages/student/ViewFees';
import ViewClassRoutine from './pages/student/ViewClassRoutine';
import ViewExamRoutine from './pages/student/ViewExamRoutine';
import Documents from './pages/student/Documents';
import PublishedResult from './pages/student/PublishedResult';
import { SuperAdminProvider } from './context/SuperAdminContext';
import SuperAdminLayout from './components/layouts/SuperAdminLayout';
import SuperAdminDashboard from './pages/superadmin/SuperAdminDashboard';
import ManageInstitutions from './pages/superadmin/ManageInstitutions';
import { signInAnonymously } from 'firebase/auth';
import { auth } from './services/firebase';
import InstitutionRegistration from './pages/superadmin/InstitutionRegistration';
import SystemSettings from './pages/superadmin/SystemSettings';
import Spinner from './components/Spinner';
import LinksPage from './pages/LinksPage';
import LinksManagement from './pages/superadmin/LinksManagement';
import TarbiyatiReport from './pages/admin/madrasa-result/TarbiyatiReport';
import HifzProgress from './pages/admin/madrasa-result/HifzProgress';
import MadrasaExamTypes from './pages/admin/madrasa-result/MadrasaExamTypes';
import ManageHifzEsaleen from './pages/admin/ManageHifzEsaleen';
import HifzMarkEntry from './pages/admin/hifz-esaleen/HifzMarkEntry';
import HifzResultSheet from './pages/admin/hifz-esaleen/HifzResultSheet';
import HifzMarksheet from './pages/admin/hifz-esaleen/HifzMarksheet';
import HifzGradeProcessing from './pages/admin/hifz-esaleen/HifzGradeProcessing';
import HifzSubjectAssignment from './pages/admin/hifz-esaleen/HifzSubjectAssignment';
import HifzExamTypes from './pages/admin/hifz-esaleen/HifzExamTypes';


const MainLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const location = useLocation();
    const isAuthPage = ['/login', '/register-institution', '/online-admission'].includes(location.pathname);
    
    const wrapperClass = !isAuthPage ? "bg-gray-50 min-h-screen" : "min-h-screen";

    return (
        <div className={wrapperClass}>
            {children}
        </div>
    );
};

const ProtectedRoute: React.FC<{ children: React.ReactElement; roles: UserRole[] }> = ({ children, roles }) => {
  const { user, loading } = useAuth();

  if (loading) {
    return <Spinner />;
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (!roles.includes(user.role)) {
      const dashboardPath = user.role === UserRole.STUDENT || user.role === UserRole.GUARDIAN ? '/student/dashboard' 
                            : user.role === UserRole.SUPER_ADMIN ? '/superadmin/dashboard'
                            : '/app/dashboard';
      return <Navigate to={dashboardPath} replace />;
  }

  return children;
};

const AppRoutes: React.FC = () => {
    const { user } = useAuth();
    
    const getRootRedirect = () => {
        if (!user) return <Navigate to="/login" replace />;
        const path = user.role === UserRole.STUDENT || user.role === UserRole.GUARDIAN ? '/student/dashboard' 
                    : user.role === UserRole.SUPER_ADMIN ? '/superadmin/dashboard'
                    : '/app/dashboard';
        return <Navigate to={path} replace />;
    };

    return (
        <Routes>
            <Route path="/" element={getRootRedirect()} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register-institution" element={<InstitutionRegistration />} />
            <Route path="/online-admission" element={<OnlineAdmission />} />

             <Route 
              path="/superadmin/*" 
              element={
                <ProtectedRoute roles={[UserRole.SUPER_ADMIN]}>
                  <SuperAdminProvider>
                    <SuperAdminLayout>
                        <Routes>
                          <Route path="dashboard" element={<SuperAdminDashboard />} />
                          <Route path="institutions" element={<ManageInstitutions />} />
                          <Route path="system-settings" element={<SystemSettings />} />
                          <Route path="links-management" element={<LinksManagement />} />
                          <Route path="*" element={<Navigate to="/superadmin/dashboard" />} />
                        </Routes>
                    </SuperAdminLayout>
                  </SuperAdminProvider>
                </ProtectedRoute>
              } 
            />
            
            <Route 
              path="/app/*" 
              element={
                <ProtectedRoute roles={[UserRole.ADMIN, UserRole.TEACHER, UserRole.ACCOUNTANT]}>
                  <AppLayout>
                    <Routes>
                      <Route path="dashboard" element={<PermissionGuard permission="dashboard:view"><Dashboard /></PermissionGuard>} />
                      <Route path="links" element={<LinksPage />} />
                      
                      <Route path="institution">
                        <Route index element={<PermissionGuard permission="institution:edit_name"><InstitutionInfo /></PermissionGuard>} />
                        <Route path="name" element={<PermissionGuard permission="institution:edit_name"><InstitutionName /></PermissionGuard>} />
                        <Route path="code" element={<PermissionGuard permission="institution:edit_code"><InstitutionCode /></PermissionGuard>} />
                        <Route path="logo" element={<PermissionGuard permission="institution:edit_logo"><UploadLogo /></PermissionGuard>} />
                        <Route path="address" element={<PermissionGuard permission="institution:edit_address"><Address /></PermissionGuard>} />
                        <Route path="contact" element={<PermissionGuard permission="institution:edit_contact"><ContactInfo /></PermissionGuard>} />
                        <Route path="session" element={<PermissionGuard permission="institution:manage_sessions"><AcademicSession /></PermissionGuard>} />
                        <Route path="manager" element={<PermissionGuard permission="institution:edit_manager_info"><ManagerInfo /></PermissionGuard>} />
                        <Route path="schedule" element={<PermissionGuard permission="institution:manage_activities"><Schedule /></PermissionGuard>} />
                        <Route path="sections" element={<PermissionGuard permission="institution:manage_sections"><Sections /></PermissionGuard>} />
                        <Route path="social" element={<PermissionGuard permission="institution:edit_social_media"><SocialMedia /></PermissionGuard>} />
                        <Route path="license" element={<PermissionGuard permission="institution:manage_licenses"><License /></PermissionGuard>} />
                      </Route>

                      <Route path="students">
                        <Route index element={<PermissionGuard permission="student:view_list"><ManageStudents /></PermissionGuard>} />
                        <Route path="add" element={<PermissionGuard permission="student:create_office"><AddStudent /></PermissionGuard>} />
                        <Route path="pending-applications" element={<PermissionGuard permission="student:manage_pending_applications"><PendingApplications /></PermissionGuard>} />
                        <Route path="list" element={<PermissionGuard permission="student:view_list"><StudentList /></PermissionGuard>} />
                        <Route path="profile" element={<PermissionGuard permission="student:view_profile"><StudentProfile /></PermissionGuard>} />
                        <Route path="guardians" element={<PermissionGuard permission="student:view_guardian_info"><GuardianInfo /></PermissionGuard>} />
                        <Route path="id-card" element={<PermissionGuard permission="student:generate_id_card"><GenerateIdCard /></PermissionGuard>} />
                        <Route path="change-roll-section" element={<PermissionGuard permission="student:change_roll_section"><RollSectionChange /></PermissionGuard>} />
                        <Route path="status" element={<PermissionGuard permission="student:change_status"><StatusChange /></PermissionGuard>} />
                        <Route path="promotion" element={<PermissionGuard permission="student:promote"><Promotion /></PermissionGuard>} />
                      </Route>

                      <Route path="teachers">
                        <Route index element={<PermissionGuard permission="teacher:view_list"><ManageTeachers /></PermissionGuard>} />
                        <Route path="add" element={<PermissionGuard permission="teacher:create"><AddTeacher /></PermissionGuard>} />
                        <Route path="list" element={<PermissionGuard permission="teacher:view_list"><TeacherList /></PermissionGuard>} />
                        <Route path="profile" element={<PermissionGuard permission="teacher:view_profile"><TeacherProfile /></PermissionGuard>} />
                        <Route path="class-assignment" element={<PermissionGuard permission="teacher:assign_class_teacher"><ClassAssignment /></PermissionGuard>} />
                        <Route path="subject-assignment" element={<PermissionGuard permission="teacher:assign_subjects"><SubjectAssignment /></PermissionGuard>} />
                        <Route path="student-assignment" element={<PermissionGuard permission="teacher:view_assignments"><StudentAssignment /></PermissionGuard>} />
                        <Route path="assign-homework" element={<PermissionGuard permission="homework:create"><AssignHomework /></PermissionGuard>} />
                        <Route path="student-progress" element={<PermissionGuard permission="student:manage_progress_behavior"><ProgressBehavior /></PermissionGuard>} />
                        <Route path="notice" element={<PermissionGuard permission="communication:send_message_teacher"><TeacherNoticeMessage /></PermissionGuard>} />
                        <Route path="report" element={<PermissionGuard permission="teacher:view_reports"><TeacherReport /></PermissionGuard>} />
                        <Route path="status" element={<PermissionGuard permission="teacher:change_status"><TeacherStatusChange /></PermissionGuard>} />
                      </Route>
                      
                      <Route path="attendance">
                        <Route index element={<PermissionGuard permission="attendance:view_student_report"><ManageAttendance /></PermissionGuard>} />
                        <Route path="daily" element={<PermissionGuard permission="attendance:take_manual"><DailyAttendance /></PermissionGuard>} />
                        <Route path="arrival-departure" element={<PermissionGuard permission="attendance:take_qr"><ArrivalDeparture /></PermissionGuard>} />
                        <Route path="report" element={<PermissionGuard permission="attendance:view_student_report"><AttendanceReport /></PermissionGuard>} />
                        <Route path="edit" element={<PermissionGuard permission="attendance:edit_student"><EditAttendance /></PermissionGuard>} />
                        <Route path="summary" element={<PermissionGuard permission="attendance:view_absence_summary"><AbsenceSummary /></PermissionGuard>} />
                        <Route path="export" element={<PermissionGuard permission="attendance:export_student_report"><ExportReport /></PermissionGuard>} />
                      </Route>

                      <Route path="teacher-attendance">
                        <Route index element={<PermissionGuard permission="attendance:take_teacher"><ManageTeacherAttendance /></PermissionGuard>} />
                        <Route path="daily" element={<PermissionGuard permission="attendance:take_teacher"><DailyTeacherAttendance /></PermissionGuard>} />
                        <Route path="leave-applications" element={<PermissionGuard permission="attendance:manage_teacher_leave"><LeaveApplications /></PermissionGuard>} />
                      </Route>

                      <Route path="curriculum">
                        <Route index element={<PermissionGuard permission="curriculum:manage_subjects"><ManageCurriculum /></PermissionGuard>} />
                        <Route path="subjects" element={<PermissionGuard permission="curriculum:manage_subjects"><CurriculumSubjects /></PermissionGuard>} />
                        <Route path="progress-tracking" element={<PermissionGuard permission="student:manage_progress_behavior"><CurriculumProgressTracking /></PermissionGuard>} />
                        <Route path="teacher-comments" element={<PermissionGuard permission="student:manage_progress_behavior"><TeacherComments /></PermissionGuard>} />
                      </Route>

                      <Route path="homework">
                        <Route index element={<PermissionGuard permission="homework:view_list"><ManageHomework /></PermissionGuard>} />
                        <Route path="add" element={<PermissionGuard permission="homework:create"><AddHomework /></PermissionGuard>} />
                        <Route path="list" element={<PermissionGuard permission="homework:view_list"><HomeworkList /></PermissionGuard>} />
                        <Route path="deadlines" element={<PermissionGuard permission="homework:view_deadlines"><Deadlines /></PermissionGuard>} />
                        <Route path="edit" element={<PermissionGuard permission="homework:edit"><EditHomework /></PermissionGuard>} />
                      </Route>
                      
                      <Route path="exams">
                        <Route index element={<PermissionGuard permission="exam:create"><ManageExams /></PermissionGuard>} />
                        <Route path="create" element={<PermissionGuard permission="exam:create"><CreateExam /></PermissionGuard>} />
                        <Route path="list" element={<PermissionGuard permission="exam:create"><ExamList /></PermissionGuard>} />
                        <Route path="entry" element={<PermissionGuard permission="exam:enter_marks"><MarkEntry /></PermissionGuard>} />
                        <Route path="edit-result" element={<PermissionGuard permission="exam:edit_results"><EditResult /></PermissionGuard>} />
                        <Route path="class-result" element={<PermissionGuard permission="exam:view_class_result"><ClassResult /></PermissionGuard>} />
                        <Route path="nombro-potro" element={<PermissionGuard permission="exam:generate_marksheet_blank"><NombroPotro /></PermissionGuard>} />
                        <Route path="marksheet" element={<PermissionGuard permission="exam:generate_marksheet_filled"><EvaluationReport /></PermissionGuard>} />
                        <Route path="result-summary" element={<PermissionGuard permission="exam:view_result_summary"><ResultSummary /></PermissionGuard>} />
                        <Route path="export" element={<PermissionGuard permission="exam:export_results"><ExportExamReport /></PermissionGuard>} />
                        <Route path="publish-result" element={<PermissionGuard permission="exam:publish_results"><PublishResult /></PermissionGuard>} />
                        <Route path="admit-card" element={<PermissionGuard permission="exam:generate_admit_card"><AdmitCard /></PermissionGuard>} />
                        <Route path="seat-plan" element={<PermissionGuard permission="exam:generate_seat_plan"><SeatPlan /></PermissionGuard>} />
                        <Route path="grade-processing" element={<PermissionGuard permission="exam:manage_grade_system"><GradeProcessing /></PermissionGuard>} />
                        <Route path="subject-assignment" element={<PermissionGuard permission="exam:manage_subject_assignment"><ExamSubjectAssignment /></PermissionGuard>} />
                      </Route>
                      <Route path="madrasa-result">
                        <Route index element={<PermissionGuard permission="exam:manage_madrasa_results"><ManageMadrasaExams /></PermissionGuard>} />
                        <Route path="tarbiyati-report" element={<PermissionGuard permission="exam:manage_madrasa_results"><TarbiyatiReport /></PermissionGuard>} />
                        <Route path="hifz-progress" element={<PermissionGuard permission="exam:manage_madrasa_results"><HifzProgress /></PermissionGuard>} />
                        <Route path="exam-types" element={<PermissionGuard permission="exam:manage_madrasa_results"><MadrasaExamTypes /></PermissionGuard>} />
                        <Route path="subject-assignment" element={<PermissionGuard permission="exam:manage_subject_assignment"><ExamSubjectAssignment /></PermissionGuard>} />
                        <Route path="entry" element={<PermissionGuard permission="exam:enter_marks"><MarkEntry /></PermissionGuard>} />
                        <Route path="edit-result" element={<PermissionGuard permission="exam:edit_results"><EditResult /></PermissionGuard>} />
                        <Route path="class-result" element={<PermissionGuard permission="exam:view_class_result"><ClassResult /></PermissionGuard>} />
                        <Route path="marksheet" element={<PermissionGuard permission="exam:generate_marksheet_filled"><EvaluationReport /></PermissionGuard>} />
                        <Route path="result-summary" element={<PermissionGuard permission="exam:view_result_summary"><ResultSummary /></PermissionGuard>} />
                        <Route path="export" element={<PermissionGuard permission="exam:export_results"><ExportExamReport /></PermissionGuard>} />
                        <Route path="publish-result" element={<PermissionGuard permission="exam:publish_results"><PublishResult /></PermissionGuard>} />
                        <Route path="grade-processing" element={<PermissionGuard permission="exam:manage_grade_system"><GradeProcessing /></PermissionGuard>} />
                      </Route>
                      
                      <Route path="hifz-esaleen">
                        <Route index element={<PermissionGuard permission="hifz:manage"><ManageHifzEsaleen /></PermissionGuard>} />
                        <Route path="entry" element={<PermissionGuard permission="hifz:enter_marks"><HifzMarkEntry /></PermissionGuard>} />
                        <Route path="result-sheet" element={<PermissionGuard permission="hifz:view_result_sheet"><HifzResultSheet /></PermissionGuard>} />
                        <Route path="marksheet" element={<PermissionGuard permission="hifz:generate_marksheet"><HifzMarksheet /></PermissionGuard>} />
                        <Route path="grade-processing" element={<PermissionGuard permission="hifz:manage_grade_system"><HifzGradeProcessing /></PermissionGuard>} />
                        <Route path="subject-assignment" element={<PermissionGuard permission="hifz:manage_subject_assignment"><HifzSubjectAssignment /></PermissionGuard>} />
                        <Route path="exam-types" element={<PermissionGuard permission="hifz:manage_exam_types"><HifzExamTypes /></PermissionGuard>} />
                      </Route>
                      
                      <Route path="fees">
                        <Route index element={<PermissionGuard permission="fees:collect_student_fees"><ManageFees /></PermissionGuard>} />
                        <Route path="student-fees" element={<PermissionGuard permission="fees:collect_student_fees"><FeeInfo /></PermissionGuard>} />
                        <Route path="edit-fees" element={<PermissionGuard permission="fees:edit_fee_records"><EditFees /></PermissionGuard>} />
                        <Route path="due-report" element={<PermissionGuard permission="fees:view_due_report"><DueReport /></PermissionGuard>} />
                        <Route path="class-summary" element={<PermissionGuard permission="fees:view_class_summary"><ClassSummary /></PermissionGuard>} />
                        <Route path="teacher-salary" element={<PermissionGuard permission="salary:manage_teacher_salary"><Salary /></PermissionGuard>} />
                        <Route path="salary-report" element={<PermissionGuard permission="salary:view_teacher_salary_report"><SalaryReport /></PermissionGuard>} />
                        <Route path="fee-types" element={<PermissionGuard permission="settings:manage_fee_types"><FeeTypes /></PermissionGuard>} />
                      </Route>

                      <Route path="income-expense">
                        <Route index element={<PermissionGuard permission="accounting:view_income_expense_report"><ManageIncomeExpense /></PermissionGuard>} />
                        <Route path="add-income" element={<PermissionGuard permission="accounting:add_income"><AddIncome /></PermissionGuard>} />
                        <Route path="add-expense" element={<PermissionGuard permission="accounting:add_expense"><AddExpense /></PermissionGuard>} />
                        <Route path="report" element={<PermissionGuard permission="accounting:view_income_expense_report"><IncomeExpenseReport /></PermissionGuard>} />
                        <Route path="monthly-summary" element={<PermissionGuard permission="accounting:view_monthly_summary"><MonthlySummaryIE /></PermissionGuard>} />
                        <Route path="yearly-summary" element={<PermissionGuard permission="accounting:view_yearly_summary"><YearlySummaryIE /></PermissionGuard>} />
                      </Route>

                      <Route path="routine">
                        <Route index element={<PermissionGuard permission="routine:manage_class_routine"><ManageRoutine /></PermissionGuard>} />
                        <Route path="class-routine" element={<PermissionGuard permission="routine:manage_class_routine"><ClassRoutine /></PermissionGuard>} />
                        <Route path="exam-routine" element={<PermissionGuard permission="routine:manage_exam_routine"><ExamRoutine /></PermissionGuard>} />
                      </Route>
                      
                      <Route path="notices" element={<PermissionGuard permission="notice:create"><ManageNotices /></PermissionGuard>} />

                      <Route path="reports">
                        <Route index element={<PermissionGuard permission="student:view_list"><ManageReports /></PermissionGuard>} />
                        <Route path="student-fee-report" element={<PermissionGuard permission="fees:collect_student_fees"><StudentFeeReport /></PermissionGuard>} />
                        <Route path="class-fee-summary-report" element={<PermissionGuard permission="fees:view_class_summary"><ClassFeeSummaryReport /></PermissionGuard>} />
                      </Route>

                      <Route path="user-roles">
                        <Route index element={<PermissionGuard permission="users:manage_permissions"><ManageUserRoles /></PermissionGuard>} />
                        <Route path="create" element={<PermissionGuard permission="users:create"><CreateUser /></PermissionGuard>} />
                        <Route path="list" element={<PermissionGuard permission="users:view_list"><UserList /></PermissionGuard>} />
                        <Route path="permissions" element={<PermissionGuard permission="users:manage_permissions"><Permissions /></PermissionGuard>} />
                      </Route>
                      
                      <Route path="settings">
                        <Route index element={<PermissionGuard permission="settings:manage_general"><Settings /></PermissionGuard>} />
                        <Route path="academic-year" element={<PermissionGuard permission="institution:manage_sessions"><AcademicYearSetup /></PermissionGuard>} />
                        <Route path="class-setup" element={<PermissionGuard permission="settings:manage_classes_sections"><ClassSetup /></PermissionGuard>} />
                        <Route path="holiday-list" element={<PermissionGuard permission="settings:manage_holidays"><HolidayList /></PermissionGuard>} />
                        <Route path="fund-category" element={<PermissionGuard permission="settings:manage_funds"><FundCategory /></PermissionGuard>} />
                        <Route path="automatic-notifications" element={<PermissionGuard permission="settings:manage_notifications"><AutomaticNotifications /></PermissionGuard>} />
                        <Route path="payment-gateway" element={<PermissionGuard permission="settings:manage_payment_gateways"><PaymentGatewaySettings /></PermissionGuard>} />
                        <Route path="database-backup" element={<PermissionGuard permission="settings:manage_database"><DatabaseBackup /></PermissionGuard>} />
                        <Route path="general-settings" element={<PermissionGuard permission="settings:manage_general"><GeneralSettings /></PermissionGuard>} />
                      </Route>
                      
                      <Route path="global-settings">
                        <Route index element={<PermissionGuard permission="global_settings:manage_genders"><GlobalSettings /></PermissionGuard>} />
                        <Route path="genders" element={<PermissionGuard permission="global_settings:manage_genders"><ManageGenders /></PermissionGuard>} />
                        <Route path="blood-groups" element={<PermissionGuard permission="global_settings:manage_blood_groups"><ManageBloodGroups /></PermissionGuard>} />
                        <Route path="religions" element={<PermissionGuard permission="global_settings:manage_religions"><ManageReligions /></PermissionGuard>} />
                        <Route path="nationalities" element={<PermissionGuard permission="global_settings:manage_nationalities"><ManageNationalities /></PermissionGuard>} />
                        <Route path="designations" element={<PermissionGuard permission="global_settings:manage_designations"><ManageDesignations /></PermissionGuard>} />
                      </Route>

                      <Route path="teacher-attendance-entry" element={<PermissionGuard permission="attendance:take_manual"><StudentAttendance/></PermissionGuard>} />
                      <Route path="marks-entry" element={<PermissionGuard permission="exam:enter_marks"><EnterMarks/></PermissionGuard>} />

                      <Route path="*" element={<Navigate to="/app/dashboard" />} />
                    </Routes>
                  </AppLayout>
                </ProtectedRoute>
              } 
            />
            
            <Route path="/student/*" element={
                <ProtectedRoute roles={[UserRole.STUDENT, UserRole.GUARDIAN]}>
                    <GuardianLayout>
                        <Routes>
                            <Route path="dashboard" element={<PermissionGuard permission="portal:view_dashboard"><GuardianDashboard /></PermissionGuard>} />
                            <Route path="links" element={<LinksPage />} />
                            <Route path="attendance" element={<PermissionGuard permission="portal:view_attendance"><GuardianViewAttendance /></PermissionGuard>} />
                            <Route path="marks" element={<PermissionGuard permission="portal:view_marks"><GuardianViewMarks /></PermissionGuard>} />
                            <Route path="notifications" element={<PermissionGuard permission="portal:view_notices"><GuardianNotifications /></PermissionGuard>} />
                            <Route path="homework" element={<PermissionGuard permission="portal:view_homework"><ViewHomework /></PermissionGuard>} />
                            <Route path="notices" element={<PermissionGuard permission="portal:view_notices"><ViewNotices /></PermissionGuard>} />
                            <Route path="fees" element={<PermissionGuard permission="portal:view_fees"><ViewFees /></PermissionGuard>} />
                            <Route path="class-routine" element={<PermissionGuard permission="portal:view_class_routine"><ViewClassRoutine /></PermissionGuard>} />
                            <Route path="exam-routine" element={<PermissionGuard permission="portal:view_exam_routine"><ViewExamRoutine /></PermissionGuard>} />
                            <Route path="documents" element={<PermissionGuard permission="portal:view_admit_card"><Documents /></PermissionGuard>} />
                            <Route path="published-result" element={<PermissionGuard permission="portal:view_marks"><PublishedResult /></PermissionGuard>} />
                            <Route path="*" element={<Navigate to="/student/dashboard" />} />
                        </Routes>
                    </GuardianLayout>
                </ProtectedRoute>
            } />

            <Route path="*" element={<Navigate to="/" />} />
        </Routes>
    );
};

function App() {
  const [authStatus, setAuthStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [authError, setAuthError] = useState<string | null>(null);
  const signInAttempted = useRef(false);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(user => {
      if (user) {
        // If we have any user (anonymous or logged in), we're ready.
        setAuthStatus('ready');
      } else {
        // No user, and we haven't hit an error state yet. Try to sign in once.
        if (!signInAttempted.current) {
            signInAttempted.current = true;
            signInAnonymously(auth).catch(error => {
                console.error("Anonymous sign-in failed:", error);
                setAuthError("ইন্টারনেট সংযোগ বা সার্ভার ত্রুটির কারণে অ্যাপ্লিকেশন শুরু করা যায়নি।");
                setAuthStatus('error');
            });
        }
      }
    });
    return () => unsubscribe();
  }, []); // Run only once on mount.

  if (authStatus === 'loading') {
    return <Spinner />;
  }

  if (authStatus === 'error') {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-100 p-4">
        <div className="text-center max-w-lg">
            <h1 className="text-9xl font-bold text-teal-600">404</h1>
            <h2 className="text-3xl font-bold text-gray-800 mt-4">সংযোগ ত্রুটি</h2>
            <p className="mt-4 text-gray-600">অনুগ্রহ পূর্বক ইন্টারনেট সংযোগ চেক করুন।</p>
            <p className="mt-2 text-gray-600">ধন্যবাদ</p>
        </div>
      </div>
    );
  }
  
  return (
    <AuthProvider>
      <InstitutionProvider>
        <NotificationProvider>
          <HashRouter>
            <MainLayout>
              <AppRoutes />
            </MainLayout>
          </HashRouter>
        </NotificationProvider>
      </InstitutionProvider>
    </AuthProvider>
  );
}

export default App;
