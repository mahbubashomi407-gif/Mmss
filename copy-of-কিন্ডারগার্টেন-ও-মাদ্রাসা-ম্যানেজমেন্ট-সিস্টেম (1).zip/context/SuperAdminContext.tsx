
import React, { createContext, useState, useContext, ReactNode, useEffect } from 'react';
import { db } from '../services/firebase';
import { doc, onSnapshot, setDoc } from 'firebase/firestore';
import { useAuth } from './AuthContext';
import { UserRole } from '../types';
import Spinner from '../components/Spinner';

export interface DirectorInfo {
    name: string;
    address: string;
    mobile: string;
    whatsapp: string;
}

export interface SuperAdminSettings {
    directorInfo: DirectorInfo;
    isRegistrationOpen: boolean;
    showQuickLoginButton: boolean;
}

export interface Institution {
    id: string;
    name: string;
    code: string; // Will be empty for pending
    subscriptionEndDate: string;
    status: 'Active' | 'Expired' | 'Pending'; // Added 'Pending'
    principalName?: string;
    principalMobile?: string;
    adminEmail?: string;
}

export interface LinkCard {
    id: string;
    title: string;
    url: string;
    type: 'navigation' | 'download';
}

export interface LinkSection {
    id: string;
    title: string;
    cards: LinkCard[];
}

interface SuperAdminContextType {
    institutions: Institution[];
    updateInstitutions: (data: Institution[]) => Promise<void>;
    settings: SuperAdminSettings;
    updateSettings: (data: SuperAdminSettings) => Promise<void>;
    links: LinkSection[];
    updateLinks: (data: LinkSection[]) => Promise<void>;
}

const SuperAdminContext = createContext<SuperAdminContextType | undefined>(undefined);

const MOCK_INSTITUTIONS: Institution[] = [
    { id: 'default', name: 'আমার প্রতিষ্ঠান', code: '501', subscriptionEndDate: '2099-12-31', status: 'Active' }
];

const DEFAULT_SETTINGS: SuperAdminSettings = {
    directorInfo: {
        name: 'মুহা.ওয়ালীউল্লাহ রাব্বানী',
        address: 'ঈশ্বরগঞ্জ, ময়মনসিংহ, ঢাকা বাংলাদেশ',
        mobile: '01965929731',
        whatsapp: '01965929731',
    },
    isRegistrationOpen: true,
    showQuickLoginButton: true,
};

const COLLECTION_NAME = 'superAdminData';
const INSTITUTIONS_DOC_ID = 'institutions';
const SETTINGS_DOC_ID = 'settings';
const LINKS_DOC_ID = 'links';


export const SuperAdminProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const [institutions, setInstitutions] = useState<Institution[]>(MOCK_INSTITUTIONS);
    const [settings, setSettings] = useState<SuperAdminSettings>(DEFAULT_SETTINGS);
    const [links, setLinks] = useState<LinkSection[]>([]);
    const [loading, setLoading] = useState(true);

    // Real-time sync for all super admin data
    useEffect(() => {
        if (user && user.role === UserRole.SUPER_ADMIN) {
            setLoading(true);
            const instDocRef = doc(db, COLLECTION_NAME, INSTITUTIONS_DOC_ID);
            const settingsDocRef = doc(db, COLLECTION_NAME, SETTINGS_DOC_ID);
            const linksDocRef = doc(db, COLLECTION_NAME, LINKS_DOC_ID);

            const unsubInstitutions = onSnapshot(instDocRef, (docSnap) => {
                if (docSnap.exists() && docSnap.data().list) {
                    setInstitutions(docSnap.data().list);
                } else {
                    setDoc(instDocRef, { list: MOCK_INSTITUTIONS }).catch(e => console.error("Failed to create initial institutions doc:", e));
                }
            }, (error) => console.error("SuperAdmin institutions listener error:", error));

            const unsubSettings = onSnapshot(settingsDocRef, (docSnap) => {
                if (docSnap.exists() && docSnap.data().settings) {
                    setSettings({ ...DEFAULT_SETTINGS, ...docSnap.data().settings });
                } else {
                    setDoc(settingsDocRef, { settings: DEFAULT_SETTINGS });
                }
            }, (error) => console.error("SuperAdmin settings listener error:", error));

            const unsubLinks = onSnapshot(linksDocRef, (docSnap) => {
                if (docSnap.exists() && docSnap.data().list) {
                    setLinks(docSnap.data().list);
                } else {
                    setDoc(linksDocRef, { list: [] });
                }
            }, (error) => console.error("SuperAdmin links listener error:", error));

            // A short delay to allow initial data to arrive before hiding the spinner.
            const timer = setTimeout(() => setLoading(false), 1200);

            return () => {
                unsubInstitutions();
                unsubSettings();
                unsubLinks();
                clearTimeout(timer);
            };
        } else {
            setLoading(false);
        }
    }, [user]);

    // Firestore update functions
    const updateInstitutions = async (data: Institution[]) => {
        if (user?.role !== UserRole.SUPER_ADMIN) return;
        const docRef = doc(db, COLLECTION_NAME, INSTITUTIONS_DOC_ID);
        await setDoc(docRef, { list: data });
    };

    const updateSettings = async (data: SuperAdminSettings) => {
        if (user?.role !== UserRole.SUPER_ADMIN) return;
        const docRef = doc(db, COLLECTION_NAME, SETTINGS_DOC_ID);
        await setDoc(docRef, { settings: data });
    };
    
    const updateLinks = async (data: LinkSection[]) => {
        if (user?.role !== UserRole.SUPER_ADMIN) return;
        const docRef = doc(db, COLLECTION_NAME, LINKS_DOC_ID);
        await setDoc(docRef, { list: data });
    };

    const value: SuperAdminContextType = {
        institutions,
        updateInstitutions,
        settings,
        updateSettings,
        links,
        updateLinks
    };

    if (loading) {
        return <Spinner />;
    }

    return (
        <SuperAdminContext.Provider value={value}>
            {children}
        </SuperAdminContext.Provider>
    );
};

export const useSuperAdmin = () => {
    const context = useContext(SuperAdminContext);
    if (context === undefined) {
        throw new Error('useSuperAdmin must be used within a SuperAdminProvider');
    }
    return context;
};
