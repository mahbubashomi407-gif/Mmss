
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useMemo } from 'react';
import { db } from '../services/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { ALL_PERMISSION_KEYS } from '../constants/permissions';
import { MOCK_INSTITUTION_DATA } from '../data/mockData';
import { useAuth } from './AuthContext';
import { UserRole } from '../types';
import Spinner from '../components/Spinner';


// Interface for address details
export interface Address {
    village: string;
    postOffice: string;
    upazila: string;
    district: string;
    division: string;
    country: string;
    mapLink: string;
}

// Interface for contact info
export interface ContactInfo {
    primaryPhone: string;
    secondaryPhone: string;
    email: string;
    website: string;
}

// Interface for academic session
export interface AcademicSessionData {
    id: string;
    name: string;
    startDate: string;
    endDate: string;
    isActive: boolean;
}

// Interface for manager info
export interface ManagerInfo {
    name: string;
    designation: string;
    phone: string;
    email: string;
    message: string;
    photoUrl: string | null;
    signatureUrl: string | null;
}

// Interface for activity
export interface ActivityData {
    id: string;
    title: string;
    description: string;
}

// Interface for section
export interface SectionData {
    id: string;
    classLevel: string;
    name: string;
    teacherName: string;
    studentCount: number;
}

// Interface for subject
export interface SubjectData {
    id: string;
    name: string;
}

// Interface for class level
export interface ClassLevelData {
    id: string;
    name: string;
    subjects: SubjectData[];
}

// Interface for Teacher Role
export interface TeacherRoleData {
    id: string;
    name: string;
    permissions: string[];
}

// Interface for Accountant Role
export interface AccountantRoleData {
    id: string;
    name: string;
    permissions: string[];
}


// Interface for Student Role
export interface StudentRoleData {
    id: string;
    name: string;
    permissions: string[];
}

// Interface for Fee Type
export interface FeeTypeData {
    id: string;
    name: string;
    amount: number;
    applicableClasses: string[]; // Array of class names
    description?: string;
}

// Interface for Holiday
export interface HolidayData {
    id: string;
    title: string;
    startDate: string;
    endDate: string;
    type: 'Public' | 'Institutional';
}

// Interface for Fund Category
export interface FundCategoryData {
    id: string;
    name: string;
}

// Interface for Fund Head
export interface FundHeadData {
    id: string;
    name: string;
    fundCategoryId: string;
    type: 'Income' | 'Expense';
}


// Interface for Notification Settings
export interface NotificationSettingsData {
    smsGateway: {
        enabled: boolean;
        apiKey: string;
        senderId: string;
    };
    automaticNotifications: {
        studentAbsence: { sms: boolean; app: boolean; };
        newNotice: { sms: boolean; app: boolean; };
        feeDue: { sms: boolean; app: boolean; };
        resultsPublished: { sms: boolean; app: boolean; };
        studentArrival: { sms: boolean; app: boolean; };
        studentDeparture: { sms: boolean; app: boolean; };
        feePayment: { sms: boolean; app: boolean; };
    };
}

// Interface for SMS Templates
export interface SmsTemplatesData {
    studentArrival: string;
    studentDeparture: string;
    studentAbsence: string;
    newNotice: string;
    feeDue: string;
    resultsPublished: string;
    feePayment: string;
}

// Interface for Guardian Notification
export interface GuardianNotificationData {
    id: string;
    studentId: string;
    timestamp: string; // ISO string
    title: string;
    message: string;
    isRead: boolean;
}


// Interface for Notice
export interface NoticeData {
    id: string;
    title: string;
    details: string;
    publishDate: string;
    target: ('Guardians' | 'Teachers')[];
    sendSms: boolean;
    smsContent?: string;
}

// Interface for General Settings
export interface GeneralSettingsData {
    language: 'bn';
    currencySymbol: string;
    dateFormat: 'DD-MM-YYYY' | 'MM-DD-YYYY' | 'YYYY-MM-DD';
    timezone: string;
}


// Interface for social media links
export interface SocialMediaLinks {
    website: string;
    facebook: string;
    youtube: string;
}

// Interface for License Document
export interface LicenseData {
    id: string;
    name: string;
    fileUrl: string; // Base64 data URL for now
    fileName: string;
    expiryDate?: string;
}

// Interface for Student
export interface StudentData {
    id: string;
    uniqueId: string;
    photoUrl?: string | null;
    nameBn: string;
    nameEn: string;
    dob: string;
    gender: 'ছাত্র' | 'ছাত্রী' | 'অন্যান্য';
    bloodGroup?: string;
    religion: string;
    birthCertNo?: string;
    nationality: string;
    admissionDate: string;
    academicYear: string;
    classLevel: string;
    section: string;
    roll: number | '';
    fatherNameBn: string;
    fatherNameEn: string;
    fatherNid?: string;
    fatherPhone: string;
    fatherOccupation?: string;
    motherNameBn: string;
    motherNameEn: string;
    motherNid?: string;
    motherPhone: string;
    motherOccupation?: string;
    presentAddress: { village: string; postOffice: string; upazila: string; district: string; };
    permanentAddress: { village: string; postOffice: string; upazila: string; district: string; };
    isSameAddress: boolean;
    status: 'চলমান' | 'ছাড়পত্র' | 'উত্তীর্ণ' | 'বাতিল' | 'পেন্ডিং';
}

// Interface for Teacher
export interface TeacherData {
    id: string;
    uniqueId: string;
    photoUrl?: string | null;
    nameBn: string;
    nameEn: string;
    dob: string;
    gender: 'পুরুষ' | 'মহিলা' | 'অন্যান্য';
    bloodGroup?: string;
    religion: string;
    nid?: string;
    nationality: string;
    joiningDate: string;
    designation: string;
    roleId: string;
    academicQualifications: string;
    professionalTraining?: string;
    email?: string;
    phone: string;
    presentAddress: { village: string; postOffice: string; upazila: string; district: string; };
    permanentAddress: { village: string; postOffice: string; upazila: string; district: string; };
    isSameAddress: boolean;
    status: 'সক্রিয়' | 'নিষ্ক্রিয়' | 'ছুটিতে';
    assignments?: Array<{ classLevelId: string; subjectId: string; }>;
    monthlySalary?: number;
}

// Interface for Payment Gateway
export interface PaymentGatewayData {
    id: string;
    name: string;
    apiKey: string; // Represents API key, merchant ID, etc.
    instructions: string;
    enabled: boolean;
}

// Interface for Attendance Record
export interface AttendanceRecordData {
    id: string;
    studentId: string;
    date: string; // YYYY-MM-DD
    status: 'present' | 'absent' | 'leave';
}

// Interface for Teacher Attendance Record
export interface TeacherAttendanceRecordData {
    id: string;
    teacherId: string;
    date: string; // YYYY-MM-DD
    status: 'Present' | 'Absent' | 'On Leave';
}

export interface TeacherSalaryRecordData {
    id: string;
    teacherId: string;
    amount: number;
    paymentDate: string; // YYYY-MM-DD
    month: string; // e.g., 'জানুয়ারি', 'ফেব্রুয়ারি'
    year: number;
    paymentMethod: 'ক্যাশ' | 'ব্যাংক' | 'অন্যান্য';
    notes?: string;
}

// Interface for Homework
export interface HomeworkData {
    id: string;
    title: string;
    description: string;
    classLevel: string;
    section: string;
    subject: string;
    assignDate: string;
    submissionDate: string;
    fileUrl?: string;
    fileName?: string;
}

// Interface for Progress/Behavior Record
export interface ProgressBehaviorData {
    id: string;
    studentId: string;
    date: string; // YYYY-MM-DD
    type: 'Progress' | 'Behavior';
    note: string;
    recordedBy: string;
}

export interface SubjectAssignment {
  subjectId: string;
  totalMarks: number;
}

// New interface for Madrasa subject identifier
export interface MadrasaSubjectIdentifier {
    subjectId: string;
}

// Interface for Exam
export interface ExamData {
    id: string;
    name: string;
    academicYear: string;
    classLevels: string[]; // Applicable class names
    subjectAssignments?: { // For Academic
        [classLevelName: string]: SubjectAssignment[];
    };
    madrasaSubjectAssignments?: { // For Madrasa
        [classLevelName: string]: {
            [examTypeId: string]: MadrasaSubjectIdentifier[];
        }
    };
    defaultMarks?: number;
}

// Interface for Mark Record
export interface MarkRecordData {
    id: string;
    studentId: string;
    examId: string;
    subjectId: string;
    examTypeId?: string; // For Madrasa
    marksObtained: number;
    totalMarks: number;
}

// Interface for Student Fee Record
export interface StudentFeeRecordData {
    id: string;
    studentId: string;
    feeTypeId: string;
    amountPaid: number;
    paymentDate: string; // YYYY-MM-DD
    month?: string; // e.g., 'January', 'February'
    year: number;
    invoiceNumber: string;
    paymentMethod: 'ক্যাশ' | 'বিকাশ' | 'নগদ' | 'অন্যান্য';
    notes?: string;
}

// Interface for Student Fee Setup
export interface StudentFeeSetupData {
    id: string; // `${studentId}-${academicYear}`
    studentId: string;
    academicYear: string;
    monthlyFeeMonths: string[];
    oneTimeFeeTypeIds: string[];
}

// Interface for Student Message
export interface StudentMessageData {
    id: string;
    title: string;
    message: string;
    sentDate: string; // YYYY-MM-DD
    recipientIds: string[]; // Array of student IDs
    sentViaSms: boolean;
}

// Interface for Teacher Message
export interface TeacherMessageData {
    id: string;
    title: string;
    message: string;
    sentDate: string; // YYYY-MM-DD
    recipientIds: string[]; // Array of teacher IDs
    sentViaSms: boolean;
}

// Interface for Leave Application
export interface LeaveApplicationData {
    id: string;
    teacherId: string;
    teacherName: string; // Denormalized for easier display
    applicationDate: string; // YYYY-MM-DD
    leaveStartDate: string; // YYYY-MM-DD
    leaveEndDate: string; // YYYY-MM-DD
    reason: string;
    status: 'Pending' | 'Approved' | 'Rejected';
}

// Interface for Gate Log (Arrival/Departure)
export interface GateLogData {
    id: string; // unique log entry id, e.g., `${studentId}-${date}`
    studentId: string;
    date: string; // YYYY-MM-DD
    status: 'উপস্থিত' | 'অনুপস্থিত' | 'ছুটি';
    arrivalTime?: string; // HH:MM:SS
    departureTime?: string; // HH:MM:SS
}

// Interface for Gender
export interface GenderData {
    id: string;
    name: string;
    isDefault?: boolean;
}

// Interface for Blood Group
export interface BloodGroupData {
    id: string;
    name: string;
    isDefault?: boolean;
}

// Interface for Religion
export interface ReligionData {
    id: string;
    name: string;
    isDefault?: boolean;
}

// Interface for Nationality
export interface NationalityData {
    id: string;
    name: string;
    isDefault?: boolean;
}

// Interface for Designation
export interface DesignationData {
    id: string;
    name: string;
    isDefault?: boolean;
}

// Interface for Routine
export interface TimeSlotData {
    id: string;
    startTime: string; // "10:00"
    endTime: string;   // "10:45"
}

export interface RoutineSlotData {
    id: string; // composite key like `${day}-${timeSlotId}-${classLevelId}`
    day: string; // 'শনিবার'
    timeSlotId: string;
    classLevelId: string;
    subjectId: string;
    teacherId: string;
}

export interface ExamRoutineSlotData {
    id: string; // e.g., `${examId}-${classLevelId}-${date}-${session}`
    examId: string;
    classLevelId: string;
    subjectId: string;
    date: string; // YYYY-MM-DD
    session: 'Morning' | 'Afternoon'; // সকাল | বিকাল
}

// Interface for Grade
export interface GradeData {
    id: string;
    name: string;
    gpa: number;
    minPercentage: number;
    maxPercentage: number;
    comment: string;
    isRankable?: boolean;
}

// Interface for Madrasa Result Settings
export interface MadrasaResultSettings {
  enableAbsentStatus: boolean;
  enableSuspendedStatus: boolean;
  enableMaqbulOnSingleFail: boolean;
}

// Interface for Madrasa Exam Type
export interface MadrasaExamTypeData {
    id: string;
    name: string;
    totalMarks: number;
}

// Interface for Hifz Exam Type
export interface HifzExamTypeData {
    id: string;
    name: string;
}

// Interface for Hifz Subject
export interface HifzSubjectData {
    id: string;
    name: string;
    totalMarks: number;
    passMarks: number;
}

// Interface for Hifz Grade
export interface HifzGradeData {
    id: string;
    name: string;
    minHifzMarks: number;
    minTotalMarks: number;
    isRankable?: boolean;
}

// Interface for Hifz Result Settings
export interface HifzResultSettings {
  enableAbsentStatus: boolean;
  enableSuspendedStatus: boolean;
}


// Interface for Income Record
export interface IncomeData {
    id: string;
    date: string; // YYYY-MM-DD
    fundHeadId: string; // From FundHeadData
    amount: number;
    description: string;
    receiptNo?: string;
}

// Interface for Expense Record
export interface ExpenseData {
    id: string;
    date: string; // YYYY-MM-DD
    fundHeadId: string; // From FundHeadData
    amount: number;
    description: string;
    voucherNo?: string;
}

// Interface for System User
export interface SystemUserData {
    id: string;
    email: string;
    role: 'Admin' | 'Teacher' | 'Accountant' | 'Student';
    status: 'Active' | 'Inactive';
    linkedTeacherId?: string;
}


// Grade calculation utility
export const calculateGradeInfo = (percentage: number, grades: GradeData[]): { grade: string; gpa: number; comment: string } => {
    // Ensure percentage is a number and within 0-100 range
    if (typeof percentage !== 'number' || isNaN(percentage)) {
        return { grade: 'N/A', gpa: 0.0, comment: 'Invalid input' };
    }
    const clampedPercentage = Math.max(0, Math.min(100, percentage));

    if (!grades || grades.length === 0) {
        // Fallback to a default system if grades are not configured
        if (clampedPercentage >= 80) return { grade: 'A+', gpa: 5.0, comment: 'Outstanding' };
        if (clampedPercentage >= 70) return { grade: 'A', gpa: 4.0, comment: 'Excellent' };
        if (clampedPercentage >= 60) return { grade: 'A-', gpa: 3.5, comment: 'Very Good' };
        if (clampedPercentage >= 50) return { grade: 'B', gpa: 3.0, comment: 'Good' };
        if (clampedPercentage >= 40) return { grade: 'C', gpa: 2.0, comment: 'Average' };
        if (clampedPercentage >= 33) return { grade: 'D', gpa: 1.0, comment: 'Pass' };
        return { grade: 'F', gpa: 0.0, comment: 'অকৃতকার্য' };
    }

    // Sort grades by minPercentage in descending order to handle overlaps correctly (highest range first)
    const sortedGrades = [...grades].sort((a, b) => b.minPercentage - a.minPercentage);

    for (const grade of sortedGrades) {
        // Use a small tolerance for maxPercentage to handle floating point issues like 79.99
        if (clampedPercentage >= grade.minPercentage && clampedPercentage <= grade.maxPercentage + 0.001) {
            return {
                grade: grade.name,
                gpa: grade.gpa,
                comment: grade.comment
            };
        }
    }
    
    // If no grade matches (should not happen with comprehensive ranges), return a default fail grade
    const failGrade = sortedGrades.find(g => g.gpa === 0);
    if (failGrade) {
        return { grade: failGrade.name, gpa: failGrade.gpa, comment: failGrade.comment };
    }
    
    // Fallback if no 0-GPA grade defined either
    return { grade: 'F', gpa: 0.0, comment: 'অকৃতকার্য' };
};


// New context to manage institution-wide settings like logo and UI preferences.
type InstitutionDataType = typeof MOCK_INSTITUTION_DATA;
type Setters = {
    [K in keyof InstitutionDataType as `set${Capitalize<K>}`]: React.Dispatch<React.SetStateAction<InstitutionDataType[K]>>
}

// A more flexible approach to satisfy the existing context type
interface InstitutionContextType extends InstitutionDataType {
    setLogo: React.Dispatch<React.SetStateAction<string | null>>;
    setInstitutionName: React.Dispatch<React.SetStateAction<string>>;
    [key: string]: any; // Allow for dynamic setters
}


const InstitutionContext = createContext<InstitutionContextType | undefined>(undefined);

const COLLECTION_NAME = 'institutionData';

// Utility function to recursively remove undefined properties from an object
function removeUndefined(obj: any): any {
    if (obj === null || typeof obj !== 'object') {
        return obj;
    }

    if (Array.isArray(obj)) {
        return obj.map(item => removeUndefined(item));
    }

    const newObj: { [key: string]: any } = {};
    for (const key in obj) {
        if (Object.prototype.hasOwnProperty.call(obj, key)) {
            const value = obj[key];
            if (value !== undefined) { // Explicitly check for undefined
                newObj[key] = removeUndefined(value);
            }
        }
    }
    return newObj;
}


export const InstitutionProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    const { user, institutionId } = useAuth();
    const [state, setState] = useState<InstitutionDataType>(MOCK_INSTITUTION_DATA);
    const [loading, setLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    // Load data from Firestore on initial mount or when institutionId changes
    useEffect(() => {
        if (user && user.role !== UserRole.SUPER_ADMIN && institutionId) {
            const loadData = async () => {
                setLoading(true);
                const docRef = doc(db, COLLECTION_NAME, institutionId);
                try {
                    const docSnap = await getDoc(docRef);
                    if (docSnap.exists()) {
                        const firestoreData = docSnap.data();
                        setState(currentMock => ({ ...currentMock, ...firestoreData }));
                    } else {
                        // This is a new institution, seed it with default data
                        await setDoc(docRef, removeUndefined(MOCK_INSTITUTION_DATA)); // Use removeUndefined here too
                        setState(MOCK_INSTITUTION_DATA);
                    }
                } catch (error) {
                    console.error("Error loading institution data from Firestore:", error);
                } finally {
                    setLoading(false);
                }
            };
            loadData();
        } else if (!user) { // User logged out, reset state
            setState(MOCK_INSTITUTION_DATA);
            setLoading(false);
        } else { // Super admin or no institutionId
            setLoading(false);
        }
    }, [user, institutionId]);

    // Cleanup old guardian notifications
    useEffect(() => {
        if (!loading && user && user.role === UserRole.ADMIN && institutionId) {
            const oneMonthAgo = new Date();
            oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
            
            // Filter out notifications older than one month
            const filteredNotifications = state.guardianNotifications.filter(notification => {
                const notificationDate = new Date(notification.timestamp);
                return notificationDate >= oneMonthAgo;
            });

            // Only update if there are actual changes to prevent unnecessary re-renders/saves
            if (filteredNotifications.length !== state.guardianNotifications.length) {
                setState(prev => ({
                    ...prev,
                    guardianNotifications: filteredNotifications
                }));
            }
        }
    }, [user, loading, institutionId, state.guardianNotifications]);


    // Save data to Firestore whenever state changes
    useEffect(() => {
        if (!loading && !isSaving && user && user.role !== UserRole.SUPER_ADMIN && institutionId) {
            const timer = setTimeout(() => { // Debounce saving
                setIsSaving(true);
                const docRef = doc(db, COLLECTION_NAME, institutionId);
                const stateToSave = removeUndefined(state); // Apply utility here
                setDoc(docRef, stateToSave, { merge: true })
                    .catch(error => console.error("Error saving institution data:", error))
                    .finally(() => setIsSaving(false));
            }, 2500); // Save 2.5 seconds after the last change

            return () => clearTimeout(timer);
        }
    }, [state, loading, isSaving, user, institutionId]);
    
    // Generic setter creation
    const createSetter = useCallback(<K extends keyof InstitutionDataType>(key: K) => {
        return (value: React.SetStateAction<InstitutionDataType[K]>) => {
            setState(prev => ({
                ...prev,
                [key]: value instanceof Function ? value(prev[key]) : value,
            }));
        };
    }, []);

    const value = useMemo(() => ({
        ...state,
        setLogo: createSetter('logoUrl'),
        setInstitutionName: createSetter('institutionName'),
        setAddress: createSetter('address'),
        setContactInfo: createSetter('contactInfo'),
        setAcademicSessions: createSetter('academicSessions'),
        setManagerInfo: createSetter('managerInfo'),
        setActivities: createSetter('activities'),
        setClassLevels: createSetter('classLevels'),
        setSections: createSetter('sections'),
        setTeacherRoles: createSetter('teacherRoles'),
        setAccountantRoles: createSetter('accountantRoles'),
        setStudentRoles: createSetter('studentRoles'),
        setFeeTypes: createSetter('feeTypes'),
        setHolidays: createSetter('holidays'),
        setFundCategories: createSetter('fundCategories'),
        setFundHeads: createSetter('fundHeads'),
        setNotificationSettings: createSetter('notificationSettings'),
        setSmsTemplates: createSetter('smsTemplates'),
        setAppNotificationTemplates: createSetter('appNotificationTemplates'),
        setNotices: createSetter('notices'),
        setGeneralSettings: createSetter('generalSettings'),
        setSocialMediaLinks: createSetter('socialMediaLinks'),
        setLicenses: createSetter('licenses'),
        setStudents: createSetter('students'),
        setTeachers: createSetter('teachers'),
        setPaymentGateways: createSetter('paymentGateways'),
        setOnlineAdmissionFee: createSetter('onlineAdmissionFee'),
        setAttendanceRecords: createSetter('attendanceRecords'),
        setTeacherAttendanceRecords: createSetter('teacherAttendanceRecords'),
        setTeacherSalaryRecords: createSetter('teacherSalaryRecords'),
        setHomeworks: createSetter('homeworks'),
        setProgressBehaviorRecords: createSetter('progressBehaviorRecords'),
        setExams: createSetter('exams'),
        setMarkRecords: createSetter('markRecords'),
        setStudentFeeRecords: createSetter('studentFeeRecords'),
        setStudentFeeSetups: createSetter('studentFeeSetups'),
        setStudentMessages: createSetter('studentMessages'),
        setTeacherMessages: createSetter('teacherMessages'),
        setLeaveApplications: createSetter('leaveApplications'),
        setGateLogs: createSetter('gateLogs'),
        setGenders: createSetter('genders'),
        setBloodGroups: createSetter('bloodGroups'),
        setReligions: createSetter('religions'),
        setNationalities: createSetter('nationalities'),
        setDesignations: createSetter('designations'),
        setTimeSlots: createSetter('timeSlots'),
        setRoutineSlots: createSetter('routineSlots'),
        setExamRoutineSlots: createSetter('examRoutineSlots'),
        setGrades: createSetter('grades'),
        setMadrasaGrades: createSetter('madrasaGrades'),
        setMadrasaResultSettings: createSetter('madrasaResultSettings'),
        setMadrasaExamTypes: createSetter('madrasaExamTypes'),
        setHifzExamTypes: createSetter('hifzExamTypes'),
        setHifzSubjects: createSetter('hifzSubjects'),
        setHifzGrades: createSetter('hifzGrades'),
        setHifzResultSettings: createSetter('hifzResultSettings'),
        setIncomeRecords: createSetter('incomeRecords'),
        setExpenseRecords: createSetter('expenseRecords'),
        setSystemUsers: createSetter('systemUsers'),
        setGuardianNotifications: createSetter('guardianNotifications'),
    }), [state, createSetter]);

    if (loading) {
        return <Spinner />;
    }

    return (
        <InstitutionContext.Provider value={value}>
            {children}
        </InstitutionContext.Provider>
    );
};

export const useInstitution = () => {
    const context = useContext(InstitutionContext);
    if (context === undefined) {
        throw new Error('useInstitution must be used within an InstitutionProvider');
    }
    return context;
};
