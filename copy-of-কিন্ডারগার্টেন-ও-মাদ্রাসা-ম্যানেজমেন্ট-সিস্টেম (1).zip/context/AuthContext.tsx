
import React, { createContext, useState, useContext, ReactNode, useCallback, useEffect } from 'react';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db, auth } from '../services/firebase';
import { User, UserRole } from '../types';
import { MOCK_INSTITUTION_DATA } from '../data/mockData';
import { signInWithEmailAndPassword, signOut } from 'firebase/auth';
import Spinner from '../components/Spinner';

// Extended User type to include permissions
interface UserWithPermissions extends User {
    permissions: string[];
}

interface AuthContextType {
  user: UserWithPermissions | null;
  loading: boolean;
  login: (institutionCode: string, email: string, pass: string) => Promise<void>;
  studentLogin: (institutionCode: string, studentId: string, pass: string) => Promise<void>;
  logout: () => void;
  switchUser: (role: UserRole) => void; // For dev purposes
  hasPermission: (permissionKey: string) => boolean;
  institutionId: string | null;
  impersonateAdmin: (institution: { id: string; code: string; }) => void;
  stopImpersonation: () => void;
  originalUser: UserWithPermissions | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock users for easy switching in development
const MOCK_USERS_FOR_DEV: { [key in UserRole]: User } = {
    [UserRole.SUPER_ADMIN]: { uid: 'superadmin01', email: 'superadmin@example.com', role: UserRole.SUPER_ADMIN, displayName: 'সুপার অ্যাডমিন' },
    [UserRole.ADMIN]: { uid: 'admin01', email: 'admin@example.com', role: UserRole.ADMIN, displayName: 'অ্যাডমিন' },
    [UserRole.TEACHER]: { uid: 't-1', email: 'teacher@example.com', role: UserRole.TEACHER, displayName: 'শিক্ষক আহমেদ', roleId: 'role_teacher_main' },
    [UserRole.ACCOUNTANT]: { uid: 'acc01', email: 'accountant@example.com', role: UserRole.ACCOUNTANT, displayName: 'হিসাবরক্ষক', roleId: 'accrole1' },
    [UserRole.STUDENT]: { uid: 'std-1721832948123', email: 'student@example.com', role: UserRole.STUDENT, displayName: 'শিক্ষার্থী আরিফ', roleId: 'srole1' },
    [UserRole.GUARDIAN]: { uid: 'std-1721832948123', email: 'guardian@example.com', role: UserRole.GUARDIAN, displayName: 'অভিভাবক রহমান', roleId: 'srole1' },
};

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserWithPermissions | null>(null);
  const [originalUser, setOriginalUser] = useState<UserWithPermissions | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    try {
        const storedUser = localStorage.getItem('user');
        const storedOriginalUser = localStorage.getItem('originalUser');
        
        if (storedUser) {
            setUser(JSON.parse(storedUser));
        }
        if (storedOriginalUser) {
            setOriginalUser(JSON.parse(storedOriginalUser));
        }
    } catch (error) {
        console.error("Failed to parse user from localStorage:", error);
        localStorage.removeItem('user');
        localStorage.removeItem('originalUser');
    } finally {
        setLoading(false);
    }
  }, []);
  
  const hasPermission = useCallback((permissionKey: string): boolean => {
    if (!user) return false;
    // Admins have all permissions implicitly
    if (user.role === UserRole.ADMIN || user.role === UserRole.SUPER_ADMIN) return true;

    // Check permissions array on the user object
    return user.permissions?.includes(permissionKey);
  }, [user]);

  const login = async (instCode: string, email: string, pass: string) => {
    setLoading(true);
    await new Promise(res => setTimeout(res, 500));

    if (instCode.toUpperCase() === 'SUPERADMIN') {
        try {
            await signInWithEmailAndPassword(auth, email, pass);
            const superAdminUser: UserWithPermissions = { 
                ...MOCK_USERS_FOR_DEV[UserRole.SUPER_ADMIN],
                email: email, // use the actual email
                uid: auth.currentUser?.uid || 'superadmin01', // use actual UID from firebase
                permissions: [] 
            };
            setUser(superAdminUser);
            localStorage.setItem('user', JSON.stringify(superAdminUser));
            setLoading(false);
            return;
        } catch (error: any) {
            setLoading(false);
            if (error.code === 'auth/invalid-credential' || error.code === 'auth/wrong-password' || error.code === 'auth/user-not-found' || error.code === 'auth/invalid-email') {
                 throw new Error('সুপার অ্যাডমিন ইমেইল বা পাসওয়ার্ড সঠিক নয়।');
            }
            console.error("Super Admin Login Error:", error);
            throw new Error('সুপার অ্যাডমিন লগইন করার সময় একটি ত্রুটি ঘটেছে।');
        }
    }

    const instListDocRef = doc(db, 'superAdminData', 'institutions');
    let instListSnap = await getDoc(instListDocRef);
    if (!instListSnap.exists()) { 
        await setDoc(instListDocRef, { list: [{ id: 'default', name: 'আমার প্রতিষ্ঠান', code: '501', subscriptionEndDate: '2099-12-31', status: 'Active' }] });
        instListSnap = await getDoc(instListDocRef);
        if (!instListSnap.exists()) {
            throw new Error("Institution list not found and could not be created.");
        }
    }
    const institutions = instListSnap.data().list;
    const institution = institutions.find((i: any) => i.code === instCode);

    if (!institution) {
        setLoading(false);
        throw new Error('এই কোড সহ কোনো প্রতিষ্ঠান খুঁজে পাওয়া যায়নি।');
    }
    const institutionId = institution.id;
    const today = new Date(); today.setHours(0,0,0,0);
    if (new Date(institution.subscriptionEndDate) < today) {
        setLoading(false);
        throw new Error('এই প্রতিষ্ঠানের সাবস্ক্রিপশন মেয়াদ উত্তীর্ণ হয়েছে।');
    }

    // --- DEMO RESET LOGIC ---
    if (instCode === '501' && institutionId === 'default') {
        const institutionDataRef = doc(db, 'institutionData', institutionId);
        const institutionDataSnap = await getDoc(institutionDataRef);
        if (institutionDataSnap.exists()) {
            const data = institutionDataSnap.data();
            const lastReset = data.lastResetTimestamp ? new Date(data.lastResetTimestamp).getTime() : 0;
            const threeDaysInMillis = 3 * 24 * 60 * 60 * 1000;
            if (Date.now() - lastReset > threeDaysInMillis) {
                const resetData = { ...MOCK_INSTITUTION_DATA, lastResetTimestamp: new Date().toISOString() };
                await setDoc(institutionDataRef, resetData);
                console.log("Demo account data has been reset.");
            }
        }
    }
    // --- END DEMO RESET LOGIC ---

    if (pass !== '123456') {
        setLoading(false);
        throw new Error('পাসওয়ার্ড সঠিক নয়।');
    }

    const institutionDataRef = doc(db, 'institutionData', institutionId);
    let institutionDataSnap = await getDoc(institutionDataRef);
    if (!institutionDataSnap.exists()) {
        const newInstitutionData = { ...MOCK_INSTITUTION_DATA, lastResetTimestamp: new Date().toISOString() };
        if (institution.adminEmail) {
            newInstitutionData.systemUsers[0] = { ...newInstitutionData.systemUsers[0], email: institution.adminEmail };
        }
        await setDoc(institutionDataRef, newInstitutionData);
        institutionDataSnap = await getDoc(institutionDataRef);
        if (!institutionDataSnap.exists()) {
            setLoading(false);
            throw new Error('প্রাতিষ্ঠানিক ডেটা তৈরি করা যায়নি।');
        }
    }
    const { systemUsers, teacherRoles, accountantRoles } = institutionDataSnap.data() as any;
    
    const systemUser = systemUsers.find((u: any) => u.email.toLowerCase() === email.toLowerCase() && u.role !== 'Student');
    if (!systemUser) {
        setLoading(false);
        throw new Error('ইমেইলটি খুঁজে পাওয়া যায়নি।');
    }
    if (systemUser.status !== 'Active') {
        setLoading(false);
        throw new Error('আপনার অ্যাকাউন্টটি সক্রিয় নয়।');
    }

    let userToLogin: UserWithPermissions | null = null;
    let userPermissions: string[] = [];

    switch(systemUser.role) {
        case 'Admin': 
            userToLogin = { ...MOCK_USERS_FOR_DEV[UserRole.ADMIN], permissions: [] };
            break;
        case 'Teacher': 
            const teacherRole = teacherRoles.find((r: any) => r.id === MOCK_USERS_FOR_DEV[UserRole.TEACHER].roleId);
            userPermissions = teacherRole?.permissions || [];
            userToLogin = { ...MOCK_USERS_FOR_DEV[UserRole.TEACHER], permissions: userPermissions };
            break;
        case 'Accountant': 
            const accountantRole = accountantRoles.find((r: any) => r.id === MOCK_USERS_FOR_DEV[UserRole.ACCOUNTANT].roleId);
            userPermissions = accountantRole?.permissions || [];
            userToLogin = { ...MOCK_USERS_FOR_DEV[UserRole.ACCOUNTANT], permissions: userPermissions };
            break;
        default:
            setLoading(false);
            throw new Error('অবৈধ ব্যবহারকারীর ভূমিকা।');
    }

    if (userToLogin) {
        userToLogin.institutionId = institutionId;
        userToLogin.institutionCode = instCode;
        setUser(userToLogin);
        localStorage.setItem('user', JSON.stringify(userToLogin));
    }
    setLoading(false);
  };

  const studentLogin = async (code: string, studentId: string, pass: string) => {
    setLoading(true);
    await new Promise(res => setTimeout(res, 500));

    if (pass !== '123456') {
        setLoading(false);
        throw new Error('পাসওয়ার্ড সঠিক নয়।');
    }

    const instListDocRef = doc(db, 'superAdminData', 'institutions');
    let instListSnap = await getDoc(instListDocRef);
    if (!instListSnap.exists()) { 
        await setDoc(instListDocRef, { list: [{ id: 'default', name: 'আমার প্রতিষ্ঠান', code: '501', subscriptionEndDate: '2099-12-31', status: 'Active' }] });
        instListSnap = await getDoc(instListDocRef);
        if (!instListSnap.exists()) {
            throw new Error("Institution list not found and could not be created.");
        }
    }
    const institutions = instListSnap.data().list;
    const institution = institutions.find((i: any) => i.code === code);

    if (!institution) {
        setLoading(false);
        throw new Error('এই কোড সহ কোনো প্রতিষ্ঠান খুঁজে পাওয়া যায়নি।');
    }
    const institutionId = institution.id;
    const today = new Date(); today.setHours(0,0,0,0);
    if (new Date(institution.subscriptionEndDate) < today) {
        setLoading(false);
        throw new Error('এই প্রতিষ্ঠানের সাবস্ক্রিপশন মেয়াদ উত্তীর্ণ হয়েছে।');
    }
    
    const institutionDataRef = doc(db, 'institutionData', institutionId);
    let institutionDataSnap = await getDoc(institutionDataRef);
    if (!institutionDataSnap.exists()) {
        await setDoc(institutionDataRef, MOCK_INSTITUTION_DATA);
        institutionDataSnap = await getDoc(institutionDataRef);
        if (!institutionDataSnap.exists()) {
            setLoading(false);
            throw new Error('প্রাতিষ্ঠানিক ডেটা তৈরি করা যায়নি।');
        }
    }
    const { students, studentRoles } = institutionDataSnap.data() as any;

    const studentData = students.find((s: any) => s.uniqueId === studentId && s.status !== 'পেন্ডিং');

    if (studentData) {
        const studentRole = studentRoles.find((r: any) => r.id === 'srole1'); // Default role
        const permissions = studentRole?.permissions || [];

        const studentUser: UserWithPermissions = {
            uid: studentData.id,
            email: `${studentData.uniqueId}@student.local`, // Dummy email
            role: UserRole.STUDENT,
            displayName: studentData.nameBn,
            roleId: 'srole1', // Default student role ID
            permissions: permissions,
            institutionId: institutionId,
            institutionCode: code,
        };
        setUser(studentUser);
        localStorage.setItem('user', JSON.stringify(studentUser));
    } else {
        setLoading(false);
        throw new Error('শিক্ষার্থী আইডি খুঁজে পাওয়া যায়নি।');
    }
    setLoading(false);
  };

  const logout = async () => {
    await signOut(auth);
    localStorage.removeItem('user');
    localStorage.removeItem('originalUser');
    sessionStorage.removeItem('demoWarningShown'); // Clear demo warning flag on logout
    setUser(null);
    setOriginalUser(null);
    window.location.hash = '/';
  };
  
  const impersonateAdmin = (institution: { id: string; code: string; }) => {
    if (!user || user.role !== UserRole.SUPER_ADMIN) return;

    const impersonatedAdmin: UserWithPermissions = {
        ...MOCK_USERS_FOR_DEV[UserRole.ADMIN],
        institutionId: institution.id,
        institutionCode: institution.code,
        permissions: [], // Admin has all permissions implicitly
    };
    
    setOriginalUser(user);
    localStorage.setItem('originalUser', JSON.stringify(user));
    
    setUser(impersonatedAdmin);
    localStorage.setItem('user', JSON.stringify(impersonatedAdmin));
  };

  const stopImpersonation = () => {
      if (!originalUser) return;

      setUser(originalUser);
      localStorage.setItem('user', JSON.stringify(originalUser));
      
      setOriginalUser(null);
      localStorage.removeItem('originalUser');
  };

  const switchUser = (role: UserRole) => {
      const newUser = MOCK_USERS_FOR_DEV[role];
      if (newUser) {
          let permissions: string[] = [];
          // FIX: Updated to correctly check against MOCK_INSTITUTION_DATA for roles to get permissions.
          // Also ensures institutionId and institutionCode are correctly assigned for non-SUPER_ADMIN roles.
          if (role === UserRole.TEACHER) {
            const teacherRole = MOCK_INSTITUTION_DATA.teacherRoles.find(r => r.id === newUser.roleId);
            permissions = teacherRole?.permissions || [];
        } else if (role === UserRole.ACCOUNTANT) {
            const accountantRole = MOCK_INSTITUTION_DATA.accountantRoles.find(r => r.id === newUser.roleId);
            permissions = accountantRole?.permissions || [];
        } else if (role === UserRole.STUDENT || role === UserRole.GUARDIAN) {
            const studentRole = MOCK_INSTITUTION_DATA.studentRoles.find(r => r.id === newUser.roleId);
            permissions = studentRole?.permissions || [];
        }
        
        const userWithPerms: UserWithPermissions = { 
            ...newUser, 
            permissions,
            // Assign default institution for non-super-admin mock users
            institutionId: (role !== UserRole.SUPER_ADMIN) ? 'default' : undefined,
            institutionCode: (role !== UserRole.SUPER_ADMIN) ? '501' : undefined,
        };
        setUser(userWithPerms);
        localStorage.setItem('user', JSON.stringify(userWithPerms));
      }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, studentLogin, logout, switchUser, hasPermission, institutionId: user?.institutionId || null, impersonateAdmin, stopImpersonation, originalUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
