
import React from 'react';
import {
    DashboardIcon,
    AttendanceIcon,
    HomeIcon,
    ClipboardListIcon,
    CurrencyBangladeshiIcon,
    MegaphoneIcon,
    ReceiptIcon,
    MarksIcon,
    ClockIcon,
    CalendarIcon,
    DocumentIcon,
    AddUserIcon,
} from '../components/icons';

const BellIcon: React.FC<{className?: string}> = ({className}) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
    </svg>
);


export interface DashboardItem {
    permission: string;
    title: string;
    link: string;
    icon: React.ReactNode;
    roles: ('teacher' | 'accountant' | 'student')[];
}

export const DASHBOARD_ITEMS: DashboardItem[] = [
    // --- Teacher Role Items ---
    {
        permission: 'dashboard:view', // Assuming a generic view permission
        title: 'ড্যাশবোর্ড',
        link: 'dashboard',
        icon: <DashboardIcon className="w-10 h-10" />,
        roles: ['teacher'],
    },
    {
        permission: 'attendance:take_manual',
        title: 'শিক্ষার্থীদের হাজিরা',
        link: 'teacher-attendance-entry',
        icon: <AttendanceIcon className="w-10 h-10" />,
        roles: ['teacher'],
    },
    {
        permission: 'exam:enter_marks',
        title: 'নম্বর প্রদান',
        link: 'marks-entry',
        icon: <MarksIcon className="w-10 h-10" />,
        roles: ['teacher'],
    },

    // --- Accountant Role Items ---
    {
        permission: 'fees:collect_student_fees',
        title: 'ফি আদায় ও তালিকা',
        link: 'fees/student-fees',
        icon: <CurrencyBangladeshiIcon className="w-10 h-10" />,
        roles: ['accountant'],
    },
    {
        permission: 'fees:edit_fee_records',
        title: 'ফি রেকর্ড সংশোধন',
        link: 'fees/edit-fees',
        icon: <ReceiptIcon className="w-10 h-10" />,
        roles: ['accountant'],
    },
    {
        permission: 'fees:view_due_report',
        title: 'বকেয়া ফি রিপোর্ট',
        link: 'fees/due-report',
        icon: <ClipboardListIcon className="w-10 h-10" />,
        roles: ['accountant'],
    },
    {
        permission: 'accounting:add_income',
        title: 'আয় যোগ করুন',
        link: 'income-expense/add-income',
        icon: <CurrencyBangladeshiIcon className="w-10 h-10" />,
        roles: ['accountant'],
    },
    {
        permission: 'accounting:add_expense',
        title: 'ব্যয় যোগ করুন',
        link: 'income-expense/add-expense',
        icon: <ReceiptIcon className="w-10 h-10" />,
        roles: ['accountant'],
    },
    {
        permission: 'accounting:view_income_expense_report',
        title: 'আয়-ব্যয় রিপোর্ট',
        link: 'income-expense/report',
        icon: <ClipboardListIcon className="w-10 h-10" />,
        roles: ['accountant'],
    },


    // --- Student/Guardian Role Items ---
    {
        permission: 'portal:view_dashboard',
        title: 'ড্যাশবোর্ড',
        link: '/student/dashboard',
        icon: <DashboardIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_notices',
        title: 'নোটিফিকেশন',
        link: '/student/notifications',
        icon: <BellIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_attendance',
        title: 'আমার হাজিরা',
        link: '/student/attendance',
        icon: <AttendanceIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_marks',
        title: 'আমার ফলাফল',
        link: '/student/marks',
        icon: <ClipboardListIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_marks',
        title: 'ফলাফল প্রকাশ',
        link: '/student/published-result',
        icon: <MegaphoneIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_homework',
        title: 'আমার হোমওয়ার্ক',
        link: '/student/homework',
        icon: <HomeIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_notices',
        title: 'নোটিশ বোর্ড',
        link: '/student/notices',
        icon: <MegaphoneIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_fees',
        title: 'ফি ও পেমেন্ট',
        link: '/student/fees',
        icon: <CurrencyBangladeshiIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_class_routine',
        title: 'ক্লাস রুটিন',
        link: '/student/class-routine',
        icon: <ClockIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_exam_routine',
        title: 'পরীক্ষার রুটিন',
        link: '/student/exam-routine',
        icon: <CalendarIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_admit_card',
        title: 'নথিপত্র',
        link: '/student/documents',
        icon: <DocumentIcon className="w-10 h-10" />,
        roles: ['student'],
    },
    {
        permission: 'portal:view_dashboard', // Re-use a common permission
        title: 'নতুন ভর্তি আবেদন',
        link: '/online-admission',
        icon: <AddUserIcon className="w-10 h-10" />,
        roles: ['student'],
    },
];
