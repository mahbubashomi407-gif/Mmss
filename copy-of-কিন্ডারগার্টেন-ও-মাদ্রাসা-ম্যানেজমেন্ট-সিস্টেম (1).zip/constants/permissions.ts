
export const PERMISSIONS = {
  dashboard: {
    title: 'ড্যাশবোর্ড',
    permissions: {
      'dashboard:view': 'ড্যাশবোর্ড দেখুন',
    }
  },
  institutionInfo: {
    title: 'প্রতিষ্ঠান তথ্য',
    permissions: {
      'institution:edit_name': 'প্রতিষ্ঠানের নাম পরিবর্তন',
      'institution:edit_code': 'প্রতিষ্ঠান কোড পরিবর্তন', // New: Permission for Institution Code
      'institution:edit_address': 'ঠিকানা ও লোকেশন পরিবর্তন',
      'institution:edit_contact': 'যোগাযোগ তথ্য পরিবর্তন',
      'institution:edit_logo': 'লোগো আপলোড ও পরিবর্তন',
      'institution:manage_sessions': 'শিক্ষা বর্ষ / সেশন পরিচালনা',
      'institution:edit_manager_info': 'প্রধান শিক্ষক/ম্যানেজার তথ্য',
      'institution:manage_activities': 'কার্যক্রম পরিচালনা',
      'institution:manage_sections': 'বিভাগ/সেকশন তালিকা পরিচালনা',
      'institution:edit_social_media': 'সোশ্যাল মিডিয়া লিঙ্ক পরিবর্তন',
      'institution:manage_licenses': 'লাইসেন্স ও নথি পরিচালনা',
    }
  },
  studentManagement: {
    title: 'শিক্ষার্থী ব্যবস্থাপনা',
    permissions: {
      'student:create_office': 'অফিস থেকে ভর্তি',
      'student:manage_pending_applications': 'অনলাইন ও পেন্ডিং আবেদন',
      'student:view_list': 'শিক্ষার্থী তালিকা দেখা',
      'student:view_profile': 'শিক্ষার্থী প্রোফাইল দেখা',
      'student:edit': 'শিক্ষার্থী তথ্য সম্পাদনা',
      'student:delete': 'শিক্ষার্থী মুছে ফেলা',
      'student:view_guardian_info': 'অভিভাবক তথ্য দেখা',
      'student:generate_id_card': 'আইডি কার্ড তৈরী',
      'student:change_roll_section': 'রোল ও সেকশন পরিবর্তন',
      'student:change_status': 'শিক্ষার্থী স্ট্যাটাস পরিবর্তন',
      'student:promote': 'শিক্ষার্থী প্রমোশন',
    }
  },
  teacherManagement: {
    title: 'শিক্ষক ব্যবস্থাপনা',
    permissions: {
      'teacher:create': 'নতুন শিক্ষক যোগ',
      'teacher:view_list': 'শিক্ষক তালিকা দেখা',
      'teacher:view_profile': 'শিক্ষক প্রোফাইল দেখা',
      'teacher:edit': 'শিক্ষক তথ্য সম্পাদনা',
      'teacher:assign_class_teacher': 'শ্রেণি শিক্ষক দায়িত্ব বরাদ্দ',
      'teacher:assign_subjects': 'বিষয়ভিত্তিক শিক্ষক বরাদ্দ',
      'teacher:view_assignments': 'শিক্ষক দায়িত্ব তালিকা দেখা',
      'teacher:view_reports': 'শিক্ষক রিপোর্ট দেখা',
      'teacher:change_status': 'শিক্ষক স্ট্যাটাস পরিবর্তন',
    }
  },
  attendance: {
    title: 'হাজিরা ব্যবস্থাপনা (শিক্ষার্থী)',
    permissions: {
      'attendance:take_manual': 'ম্যানুয়াল হাজিরা গ্রহণ',
      'attendance:take_qr': 'QR কোড দ্বারা হাজিরা',
      'attendance:view_student_report': 'হাজিরা রিপোর্ট দেখা',
      'attendance:edit_student': 'হাজিরা সংশোধন করা',
      'attendance:view_absence_summary': 'অনুপস্থিতি সারসংক্ষেপ',
      'attendance:export_student_report': 'হাজিরা রিপোর্ট এক্সপোর্ট',
    }
  },
  teacherAttendance: {
    title: 'হাজিরা ব্যবস্থাপনা (শিক্ষক)',
    permissions: {
        'attendance:take_teacher': 'দৈনিক শিক্ষক হাজিরা',
        'attendance:manage_teacher_leave': 'ছুটির আবেদন পরিচালনা',
    }
  },
  curriculum: {
      title: 'পাঠ্য ও অগ্রগতি',
      permissions: {
          'curriculum:manage_subjects': 'বিষয় / কিতাব তালিকা',
          'student:manage_progress_behavior': 'শিক্ষার্থী অগ্রগতি ও মন্তব্য',
      }
  },
  homework: {
      title: 'হোম ওয়ার্ক',
      permissions: {
          'homework:create': 'নতুন হোমওয়ার্ক তৈরি',
          'homework:view_list': 'হোমওয়ার্ক তালিকা দেখা',
          'homework:edit': 'হোমওয়ার্ক সম্পাদনা',
          'homework:delete': 'হোমওয়ার্ক মুছে ফেলা',
          'homework:view_deadlines': 'ডিউ ডেট / সময়সীমা দেখা',
      }
  },
  exams: {
    title: 'পরীক্ষা ও মূল্যায়ন',
    permissions: {
      'exam:create': 'নতুন পরীক্ষা তৈরি',
      'exam:manage_madrasa_results': 'মাদরাসা রেজাল্ট মডিউল অ্যাক্সেস',
      'exam:enter_marks': 'নম্বর এন্ট্রি করা',
      'exam:edit_results': 'ফলাফল ইডিট করা',
      'exam:view_class_result': 'রেজাল্ট শিট দেখা',
      'exam:generate_marksheet_blank': 'খালি নম্বর পত্র তৈরি',
      'exam:generate_marksheet_filled': 'মার্কশীট তৈরি ও দেখা',
      'exam:view_result_summary': 'ফলাফল সামারি দেখা',
      'exam:export_results': 'ফলাফল রিপোর্ট এক্সপোর্ট',
      'exam:publish_results': 'ফলাফল প্রকাশ ও অনুসন্ধান',
      'exam:generate_admit_card': 'প্রবেশপত্র তৈরি',
      'exam:generate_seat_plan': 'আসন বিন্যাস তৈরি',
      'exam:manage_grade_system': 'গ্রেড সিস্টেম সেটআপ',
      'exam:manage_subject_assignment': 'পরীক্ষার বিষয় অ্যাসাইনমেন্ট',
    }
  },
  hifzEsaleen: {
    title: 'হিফজ এসালাইন',
    permissions: {
      'hifz:manage': 'হিফজ এসালাইন মডিউল পরিচালনা',
      'hifz:enter_marks': 'হিফজ নম্বর এন্ট্রি',
      'hifz:view_result_sheet': 'হিফজ রেজাল্ট শিট',
      'hifz:generate_marksheet': 'হিফজ মার্কশীট',
      'hifz:manage_grade_system': 'হিফজ গ্রেড সিস্টেম সেটআপ',
      'hifz:manage_subject_assignment': 'হিফজ বিষয় অ্যাসাইনমেন্ট',
      'hifz:manage_exam_types': 'হিফজ পরীক্ষার ধরণ',
    }
  },
  feesAndSalary: {
    title: 'ফি ও বেতন',
    permissions: {
      'fees:collect_student_fees': 'শিক্ষার্থী ফি আদায়',
      'fees:edit_fee_records': 'ফি রেকর্ড সংশোধন',
      'fees:view_due_report': 'বকেয়া ফি রিপোর্ট দেখা',
      'fees:view_class_summary': 'ক্লাস ভিত্তিক ফি সারসংক্ষেপ',
      'salary:manage_teacher_salary': 'শিক্ষক বেতন পরিশোধ',
      'salary:view_teacher_salary_report': 'বেতন রিপোর্ট দেখা',
    }
  },
  accounting: {
    title: 'আয় ও ব্যয়',
    permissions: {
      'accounting:add_income': 'আয় যোগ করা',
      'accounting:add_expense': 'ব্যয় যোগ করা',
      'accounting:view_income_expense_report': 'আয়-ব্যয় রিপোর্ট দেখা',
      'accounting:view_monthly_summary': 'মাসিক সারসংক্ষেপ দেখা',
      'accounting:view_yearly_summary': 'বার্ষিক সারসংক্ষেপ দেখা',
    }
  },
  routine: {
      title: 'রুটিন',
      permissions: {
          'routine:manage_class_routine': 'ক্লাস রুটিন তৈরি ও সম্পাদনা',
          'routine:manage_exam_routine': 'পরীক্ষার রুটিন তৈরি ও সম্পাদনা',
      }
  },
  communication: {
      title: 'নোটিশ ও যোগাযোগ',
      permissions: {
          'notice:create': 'সাধারণ নোটিশ তৈরি ও প্রকাশ',
          'communication:send_message_student': 'শিক্ষার্থীদের বার্তা প্রেরণ',
          'communication:send_message_teacher': 'শিক্ষকদের বার্তা প্রেরণ',
      }
  },
  userManagement: {
      title: 'ইউজার ম্যানেজমেন্ট',
      permissions: {
          'users:create': 'নতুন ইউজার তৈরি',
          'users:view_list': 'ইউজার তালিকা দেখা',
          'users:manage_permissions': 'ইউজার পারমিশন পরিচালনা',
      }
  },
  settings: {
    title: 'সিস্টেম সেটিংস',
    permissions: {
      'settings:manage_general': 'সাধারণ সিস্টেম সেটিং',
      'settings:manage_classes_sections': 'শ্রেণি, সেকশন ও বিষয় সেটআপ',
      'settings:manage_fee_types': 'ফি-এর ধরন সেটআপ',
      'settings:manage_holidays': 'ছুটির তালিকা পরিচালনা',
      'settings:manage_funds': 'তহবিল ক্যাটাগরি ও খাত পরিচালনা',
      'settings:manage_notifications': 'নোটিফিকেশন ও SMS গেটওয়ে',
      'settings:manage_sms_templates': 'SMS টেমপ্লেট সম্পাদনা',
      'settings:manage_payment_gateways': 'পেমেন্ট গেটওয়ে সেটিং',
      'settings:manage_database': 'ডাটাবেস ব্যাকআপ ও রিস্টোর',
    }
  },
  globalSettings: {
      title: 'গ্লোবাল সেটিংস',
      permissions: {
          'global_settings:manage_genders': 'লিঙ্গ পরিচালনা',
          'global_settings:manage_blood_groups': 'রক্তের গ্রুপ পরিচালনা',
          'global_settings:manage_religions': 'ধর্ম পরিচালনা',
          'global_settings:manage_nationalities': 'জাতীয়তা পরিচালনা',
          'global_settings:manage_designations': 'শিক্ষকের পদবি পরিচালনা',
      }
  },
  studentPortal: {
    title: 'শিক্ষার্থী / অভিভাবক পোর্টাল',
    permissions: {
      'portal:view_dashboard': 'ড্যাশবোর্ড দেখা',
      'portal:view_attendance': 'হাজিরা দেখা',
      'portal:view_marks': 'ফলাফল দেখা',
      'portal:view_homework': 'হোমওয়ার্ক দেখা',
      'portal:view_notices': 'নোটিশ দেখা',
      'portal:view_fees': 'ফি তথ্য দেখা',
      'portal:view_class_routine': 'ক্লাস রুটিন দেখুন',
      'portal:view_exam_routine': 'পরীক্ষার রুটিন দেখুন',
      'portal:view_admit_card': 'নথিপত্র দেখুন',
    }
  }
};

export type PermissionKey = keyof typeof PERMISSIONS[keyof typeof PERMISSIONS]['permissions'];

// Helper to get all permission keys
export const ALL_PERMISSION_KEYS = Object.values(PERMISSIONS).reduce((acc, category) => {
    return [...acc, ...Object.keys(category.permissions)];
}, [] as string[]);

// Helper to get permission label from key
export const getPermissionLabel = (key: string): string => {
    for (const category of Object.values(PERMISSIONS)) {
        if (category.permissions[key as keyof typeof category.permissions]) {
            return category.permissions[key as keyof typeof category.permissions];
        }
    }
    return key;
}
