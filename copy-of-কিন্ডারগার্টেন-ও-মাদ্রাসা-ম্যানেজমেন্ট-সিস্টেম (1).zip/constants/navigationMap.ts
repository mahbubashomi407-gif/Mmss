
import React from 'react';
import { 
    DashboardIcon, GraduationCapIcon, TeachersIcon, LogoutIcon,
    CalendarIcon, BookOpenIcon, HomeIcon, ClipboardListIcon,
    CurrencyBangladeshiIcon, MegaphoneIcon, ChartBarIcon, CogIcon,
    BuildingOfficeIcon,
    GlobeAltIcon,
    AttendanceIcon,
    ClockIcon,
    ReceiptIcon,
    UsersIcon
} from '../components/icons';

export const NAVIGATION_MAP = [
    { to: '/app/dashboard', permission: 'dashboard:view', icon: React.createElement(DashboardIcon, { className: "w-6 h-6" }), text: 'ড্যাশবোর্ড' },
    { to: '/app/institution', permission: 'institution:edit_name', icon: React.createElement(BuildingOfficeIcon, { className: "w-6 h-6" }), text: 'প্রতিষ্ঠান তথ্য' },
    { to: '/app/students', permission: 'student:view_list', icon: React.createElement(GraduationCapIcon, { className: "w-6 h-6" }), text: 'শিক্ষার্থী ব্যবস্থাপনা' },
    { to: '/app/teachers', permission: 'teacher:view_list', icon: React.createElement(TeachersIcon, { className: "w-6 h-6" }), text: 'শিক্ষক / উস্তাদ ব্যবস্থাপনা' },
    { to: '/app/attendance', permission: 'attendance:view_student_report', icon: React.createElement(AttendanceIcon, { className: "w-6 h-6" }), text: 'হাজিরা ব্যবস্থাপনা' },
    { to: '/app/teacher-attendance', permission: 'attendance:take_teacher', icon: React.createElement(CalendarIcon, { className: "w-6 h-6" }), text: 'শিক্ষক হাজিরা' },
    { to: '/app/curriculum', permission: 'curriculum:manage_subjects', icon: React.createElement(BookOpenIcon, { className: "w-6 h-6" }), text: 'পাঠ্য ও অগ্রগতি' },
    { to: '/app/homework', permission: 'homework:view_list', icon: React.createElement(HomeIcon, { className: "w-6 h-6" }), text: 'হোম ওয়ার্ক' },
    { to: '/app/exams', permission: 'exam:create', icon: React.createElement(ClipboardListIcon, { className: "w-6 h-6" }), text: 'পরীক্ষা ও মূল্যায়ন' },
    { to: '/app/madrasa-result', permission: 'exam:manage_madrasa_results', icon: React.createElement(ClipboardListIcon, { className: "w-6 h-6" }), text: 'মাদরাসা রেজাল্ট' },
    { to: '/app/hifz-esaleen', permission: 'hifz:manage', icon: React.createElement(BookOpenIcon, { className: "w-6 h-6" }), text: 'হিফজ এসালাইন' },
    { to: '/app/fees', permission: 'fees:collect_student_fees', icon: React.createElement(CurrencyBangladeshiIcon, { className: "w-6 h-6" }), text: 'ফি ও হিসাব' },
    { to: '/app/income-expense', permission: 'accounting:view_income_expense_report', icon: React.createElement(ReceiptIcon, { className: "w-6 h-6" }), text: 'আয় ও ব্যয়' },
    { to: '/app/routine', permission: 'routine:manage_class_routine', icon: React.createElement(ClockIcon, { className: "w-6 h-6" }), text: 'রুটিন' },
    { to: '/app/notices', permission: 'notice:create', icon: React.createElement(MegaphoneIcon, { className: "w-6 h-6" }), text: 'নোটিশ ও যোগাযোগ' },
    { to: '/app/reports', permission: 'student:view_list', icon: React.createElement(ChartBarIcon, { className: "w-6 h-6" }), text: 'রিপোর্ট ও ডাটা' },
    { to: '/app/user-roles', permission: 'users:manage_permissions', icon: React.createElement(UsersIcon, { className: "w-6 h-6" }), text: 'ইউজার রোল কন্ট্রোল' },
    { to: '/app/global-settings', permission: 'global_settings:manage_genders', icon: React.createElement(GlobeAltIcon, { className: "w-6 h-6" }), text: 'গ্লোবাল সেটিং' },
    { to: '/app/settings', permission: 'settings:manage_general', icon: React.createElement(CogIcon, { className: "w-6 h-6" }), text: 'সেটিংস' },
];
