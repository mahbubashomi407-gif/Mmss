import React, { useState, useMemo, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, StudentData, StudentFeeSetupData } from '../context/InstitutionContext';

interface StudentFeeSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (setupData: StudentFeeSetupData) => void;
  student: StudentData | null;
  academicYear: string;
}

const months = ["জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন", "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"];

const StudentFeeSetupModal: React.FC<StudentFeeSetupModalProps> = ({ isOpen, onClose, onSave, student, academicYear }) => {
    const { feeTypes, studentFeeSetups } = useInstitution();
    
    const [selectedMonths, setSelectedMonths] = useState<string[]>([]);
    const [selectedOneTimeFees, setSelectedOneTimeFees] = useState<string[]>([]);

    const isEditing = useMemo(() => {
        if (!student || !academicYear) return false;
        return studentFeeSetups.some(s => s.studentId === student.id && s.academicYear === academicYear);
    }, [student, academicYear, studentFeeSetups]);
    
    const monthlyFee = useMemo(() => {
        if (!student) return null;
        return feeTypes.find(ft => ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel));
    }, [student, feeTypes]);

    useEffect(() => {
        if(isOpen && student && academicYear) {
            const existingSetup = studentFeeSetups.find(s => s.studentId === student.id && s.academicYear === academicYear);
            if (existingSetup) {
                // Load existing setup for editing
                setSelectedMonths(existingSetup.monthlyFeeMonths);
                setSelectedOneTimeFees(existingSetup.oneTimeFeeTypeIds);
            } else {
                // Default for new setup: select all months and applicable one-time fees
                setSelectedMonths(months);
                const applicableOneTime = feeTypes
                    .filter(ft => !ft.name.includes('মাসিক') && student && ft.applicableClasses.includes(student.classLevel))
                    .map(ft => ft.id);
                setSelectedOneTimeFees(applicableOneTime);
            }
        }
    }, [isOpen, student, academicYear, studentFeeSetups, feeTypes]);

    const applicableOneTimeFees = useMemo(() => {
        if (!student) return [];
        return feeTypes.filter(ft => !ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel));
    }, [student, feeTypes]);

    if (!isOpen || !student) return null;

    const handleMonthToggle = (month: string) => {
        setSelectedMonths(prev => prev.includes(month) ? prev.filter(m => m !== month) : [...prev, month]);
    };

    const handleOneTimeFeeToggle = (feeId: string) => {
        setSelectedOneTimeFees(prev => prev.includes(feeId) ? prev.filter(id => id !== feeId) : [...prev, feeId]);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const newSetup: StudentFeeSetupData = {
            id: `${student.id}-${academicYear}`,
            studentId: student.id,
            academicYear,
            monthlyFeeMonths: selectedMonths,
            oneTimeFeeTypeIds: selectedOneTimeFees
        };
        onSave(newSetup);
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold">{isEditing ? 'ফি সেটাপ সম্পাদনা করুন' : 'ফি সেটাপ করুন'}: {student.nameBn}</h3>
                        <p className="text-sm text-gray-500">শিক্ষা বর্ষ: {academicYear}</p>
                    </div>
                    <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div>
                            <h4 className="font-semibold mb-2">মাসিক বেতন {monthlyFee && `(প্রতি মাস ৳${monthlyFee.amount.toLocaleString('bn-BD')})`}</h4>
                            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                                {months.map(month => (
                                    <label key={month} className="flex items-center space-x-2 p-2 bg-gray-50 rounded-md cursor-pointer hover:bg-gray-100">
                                        <input type="checkbox" checked={selectedMonths.includes(month)} onChange={() => handleMonthToggle(month)} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"/>
                                        <span className="text-sm">{month}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2">অন্যান্য ফি</h4>
                             <div className="space-y-2">
                                {applicableOneTimeFees.map(fee => (
                                    <label key={fee.id} className="flex items-center space-x-2 p-2 bg-gray-50 rounded-md cursor-pointer hover:bg-gray-100">
                                         <input type="checkbox" checked={selectedOneTimeFees.includes(fee.id)} onChange={() => handleOneTimeFeeToggle(fee.id)} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"/>
                                        <span className="text-sm">{fee.name} (৳{fee.amount.toLocaleString('bn-BD')})</span>
                                    </label>
                                ))}
                                {applicableOneTimeFees.length === 0 && <p className="text-sm text-gray-500">এই শ্রেণির জন্য অন্য কোনো ফি প্রযোজ্য নয়।</p>}
                            </div>
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700">{isEditing ? 'সেটাপ আপডেট করুন' : 'সেটাপ সংরক্ষণ করুন'}</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default StudentFeeSetupModal;