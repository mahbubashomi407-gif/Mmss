import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { ReligionData } from '../context/InstitutionContext';

interface ReligionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (religion: { name: string; id?: string }) => void;
  religionToEdit?: ReligionData | null;
}

const ReligionModal: React.FC<ReligionModalProps> = ({ isOpen, onClose, onSave, religionToEdit }) => {
  const [name, setName] = useState('');

  useEffect(() => {
    if (religionToEdit) {
      setName(religionToEdit.name);
    } else {
      setName('');
    }
  }, [religionToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave({
      id: religionToEdit?.id,
      name,
    });
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{religionToEdit ? 'ধর্ম সম্পাদনা করুন' : 'নতুন ধর্ম যোগ করুন'}</h3>
                <div className="mt-4">
                    <label htmlFor="religionName" className="block text-sm font-medium text-gray-700">ধর্মের নাম</label>
                    <input
                        id="religionName"
                        type="text"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                        placeholder="উদাহরণ: হিন্দু"
                        required
                        autoFocus
                    />
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default ReligionModal;