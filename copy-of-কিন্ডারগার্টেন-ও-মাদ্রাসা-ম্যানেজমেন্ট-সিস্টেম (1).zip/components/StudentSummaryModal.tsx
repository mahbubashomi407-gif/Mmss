
import React, { useState, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution } from '../context/InstitutionContext';
import { CalendarIcon } from './icons';

interface SummaryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const toBengaliNumber = (numStr: string | number): string => {
    const num = String(numStr);
    const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
    return num.replace(/[0-9]/g, match => map[match]);
};


const StudentSummaryModal: React.FC<SummaryModalProps> = ({ isOpen, onClose }) => {
  const { students, academicSessions, classLevels, institutionName, logoUrl } = useInstitution();
  
  const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);
  const [selectedYear, setSelectedYear] = useState(activeSession?.name || '');

  const summaryData = useMemo(() => {
    const session = academicSessions.find(s => s.name === selectedYear);
    if (!session) return { classSummaries: [], grandTotals: { total: 0, male: 0, female: 0, new: 0, old: 0 } };

    const sessionStartDate = new Date(session.startDate);
    const studentsInYear = students.filter(s => s.academicYear === selectedYear && s.status !== 'পেন্ডিং');

    const classSummaries = classLevels
        .map(cl => {
            const studentsInClass = studentsInYear.filter(s => s.classLevel === cl.name);
            if (studentsInClass.length === 0) return null;

            const total = studentsInClass.length;
            const male = studentsInClass.filter(s => s.gender === 'ছাত্র').length;
            const female = studentsInClass.filter(s => s.gender === 'ছাত্রী').length;
            const newStudents = studentsInClass.filter(s => new Date(s.admissionDate) >= sessionStartDate).length;
            const oldStudents = total - newStudents;

            return { className: cl.name, total, male, female, new: newStudents, old: oldStudents };
        })
        .filter(Boolean) as { className: string; total: number; male: number; female: number; new: number; old: number }[];

    const grandTotals = classSummaries.reduce((acc, curr) => {
        acc.total += curr.total;
        acc.male += curr.male;
        acc.female += curr.female;
        acc.new += curr.new;
        acc.old += curr.old;
        return acc;
    }, { total: 0, male: 0, female: 0, new: 0, old: 0 });

    return { classSummaries, grandTotals };

  }, [selectedYear, students, classLevels, academicSessions]);
  
  const handlePrint = () => {
        const printContent = document.getElementById('printable-summary');
        if (printContent) {
            const printWindow = window.open('', '', 'height=800,width=1200');
            if(printWindow){
                printWindow.document.write('<html><head><title>শিক্ষার্থী সারসংক্ষেপ</title>');
                printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                printWindow.document.write(`
                    <style>
                        body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
                        @page { size: A4 portrait; margin: 0.75in; }
                        .no-print { display: none; }
                        table { width: 100%; border-collapse: collapse; }
                        th, td { border: 1px solid #ddd; padding: 6px; font-size: 12px; }
                        th { background-color: #f2f2f2 !important; text-align: center; }
                        td { text-align: center; }
                        tfoot { font-weight: bold; background-color: #f9f9f9 !important; }
                        .header-info { text-align: center; margin-bottom: 1rem; }
                        .header-info img { height: 50px; width: 50px; border-radius: 50%; object-fit: cover; margin: 0 auto 0.5rem; }
                    </style>
                `);
                printWindow.document.write('</head><body>');
                 printWindow.document.write(`<div class="header-info">
                    ${logoUrl ? `<img src="${logoUrl}" alt="Logo" />` : ''}
                    <h1 style="font-size: 1.5rem; font-weight: bold;">${institutionName}</h1>
                    <h2 style="font-size: 1.2rem;">শিক্ষার্থী সারসংক্ষেপ (${toBengaliNumber(selectedYear)})</h2>
                </div>`);
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 500);
            }
        }
  };


  if (!isOpen) return null;

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={onClose}>
        <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl m-4 h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
            <div className="p-4 border-b flex justify-between items-center no-print">
                <h3 className="text-lg font-bold text-gray-800">শিক্ষার্থী সারসংক্ষেপ</h3>
                <div className="flex items-center gap-4">
                     <div className="relative">
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none"><CalendarIcon className="w-5 h-5 text-gray-400" /></span>
                        <select value={selectedYear} onChange={e => setSelectedYear(e.target.value)} className="pl-10 pr-4 py-2 border rounded-lg bg-white appearance-none">
                            {academicSessions.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                        </select>
                    </div>
                    <button onClick={handlePrint} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700">প্রিন্ট করুন</button>
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বন্ধ করুন</button>
                </div>
            </div>
            <div className="p-4 flex-grow overflow-y-auto">
                <div id="printable-summary">
                    <table className="w-full text-sm">
                        <thead className="bg-gray-100">
                            <tr>
                                <th className="p-2 border">শ্রেণি</th>
                                <th className="p-2 border">মোট শিক্ষার্থী</th>
                                <th className="p-2 border">ছাত্র</th>
                                <th className="p-2 border">ছাত্রী</th>
                                <th className="p-2 border">নতুন</th>
                                <th className="p-2 border">পুরাতন</th>
                            </tr>
                        </thead>
                        <tbody>
                            {summaryData.classSummaries.map(row => (
                                <tr key={row.className} className="border-b">
                                    <td className="p-2 border font-semibold">{row.className}</td>
                                    <td className="p-2 border">{toBengaliNumber(row.total)}</td>
                                    <td className="p-2 border">{toBengaliNumber(row.male)}</td>
                                    <td className="p-2 border">{toBengaliNumber(row.female)}</td>
                                    <td className="p-2 border">{toBengaliNumber(row.new)}</td>
                                    <td className="p-2 border">{toBengaliNumber(row.old)}</td>
                                </tr>
                            ))}
                        </tbody>
                        <tfoot>
                            <tr className="font-bold bg-gray-100">
                                <td className="p-2 border text-right">সর্বমোট</td>
                                <td className="p-2 border">{toBengaliNumber(summaryData.grandTotals.total)}</td>
                                <td className="p-2 border">{toBengaliNumber(summaryData.grandTotals.male)}</td>
                                <td className="p-2 border">{toBengaliNumber(summaryData.grandTotals.female)}</td>
                                <td className="p-2 border">{toBengaliNumber(summaryData.grandTotals.new)}</td>
                                <td className="p-2 border">{toBengaliNumber(summaryData.grandTotals.old)}</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>
    </div>,
    document.body
  );
};

export default StudentSummaryModal;
