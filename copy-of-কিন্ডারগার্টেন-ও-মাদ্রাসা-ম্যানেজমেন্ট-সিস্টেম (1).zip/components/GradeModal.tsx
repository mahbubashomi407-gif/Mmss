
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { GradeData } from '../context/InstitutionContext';

interface GradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (grade: Omit<GradeData, 'id'> & { id?: string }) => void;
  gradeToEdit: GradeData | null;
  existingGrades: GradeData[];
  isMadrasaMode?: boolean;
}

const GradeModal: React.FC<GradeModalProps> = ({ isOpen, onClose, onSave, gradeToEdit, existingGrades, isMadrasaMode = false }) => {
    const [name, setName] = useState('');
    const [gpa, setGpa] = useState<number | ''>('');
    const [minPercentage, setMinPercentage] = useState<number | ''>('');
    const [maxPercentage, setMaxPercentage] = useState<number | ''>('');
    const [comment, setComment] = useState('');
    const [isRankable, setIsRankable] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        if (gradeToEdit) {
            setName(gradeToEdit.name);
            setGpa(gradeToEdit.gpa);
            setMinPercentage(gradeToEdit.minPercentage);
            setMaxPercentage(gradeToEdit.maxPercentage);
            setComment(gradeToEdit.comment);
            setIsRankable(gradeToEdit.isRankable ?? true);
        } else {
            setName(''); setGpa(''); setMinPercentage(''); setMaxPercentage(''); setComment('');
            setIsRankable(true);
        }
        setError('');
    }, [gradeToEdit, isOpen]);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        
        if (name.trim() === '' || gpa === '' || minPercentage === '' || maxPercentage === '' || comment.trim() === '') {
            setError('অনুগ্রহ করে সকল ঘর পূরণ করুন।'); return;
        }
        if (minPercentage > maxPercentage) {
            setError('সর্বনিম্ন শতাংশ সর্বোচ্চ শতাংশের চেয়ে বেশি হতে পারে না।'); return;
        }

        // Overlap check
        for (const grade of existingGrades) {
            if (grade.id === gradeToEdit?.id) continue;
            // Check if (StartA <= EndB) and (EndA >= StartB)
            if (Math.max(minPercentage, grade.minPercentage) <= Math.min(maxPercentage, grade.maxPercentage)) {
                setError(`এই শতাংশের পরিসীমা "${grade.name}" গ্রেডের সাথে ওভারল্যাপ করছে (${grade.minPercentage}% - ${grade.maxPercentage}%)।`);
                return;
            }
        }

        const dataToSave: Omit<GradeData, 'id'> & { id?: string } = { 
            id: gradeToEdit?.id, name, gpa, minPercentage, maxPercentage, comment 
        };

        if (isMadrasaMode) {
            dataToSave.isRankable = isRankable;
        }

        onSave(dataToSave);
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold text-gray-800">{gradeToEdit ? 'গ্রেড সম্পাদনা করুন' : 'নতুন গ্রেড যোগ করুন'}</h3>
                    </div>
                    <div className="p-5 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">গ্রেডের নাম</label>
                                <input type="text" value={name} onChange={e => setName(e.target.value)} className="mt-1 w-full p-2 border border-gray-300 rounded-md" placeholder="A+" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">জিপিএ</label>
                                <input type="number" step="0.01" value={gpa} onChange={e => setGpa(e.target.value === '' ? '' : Number(e.target.value))} className="mt-1 w-full p-2 border border-gray-300 rounded-md" placeholder="5.00" required />
                            </div>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">সর্বনিম্ন শতাংশ (%)</label>
                                <input type="number" step="0.01" value={minPercentage} onChange={e => setMinPercentage(e.target.value === '' ? '' : Number(e.target.value))} className="mt-1 w-full p-2 border border-gray-300 rounded-md" placeholder="80" required />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">সর্বোচ্চ শতাংশ (%)</label>
                                <input type="number" step="0.01" value={maxPercentage} onChange={e => setMaxPercentage(e.target.value === '' ? '' : Number(e.target.value))} className="mt-1 w-full p-2 border border-gray-300 rounded-md" placeholder="100" required />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">মন্তব্য</label>
                            <input type="text" value={comment} onChange={e => setComment(e.target.value)} className="mt-1 w-full p-2 border border-gray-300 rounded-md" placeholder="Outstanding" required />
                        </div>
                        {isMadrasaMode && (
                            <div className="flex items-center">
                                <input
                                    id="isRankable"
                                    type="checkbox"
                                    checked={isRankable}
                                    onChange={e => setIsRankable(e.target.checked)}
                                    className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                                />
                                <label htmlFor="isRankable" className="ml-2 block text-sm font-medium text-gray-700">মেধা স্থানে অন্তর্ভুক্ত করুন</label>
                            </div>
                        )}
                        {error && <p className="text-sm text-center text-red-500 bg-red-50 p-2 rounded-md">{error}</p>}
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বাতিল করুন</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700">সংরক্ষণ করুন</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};
export default GradeModal;
