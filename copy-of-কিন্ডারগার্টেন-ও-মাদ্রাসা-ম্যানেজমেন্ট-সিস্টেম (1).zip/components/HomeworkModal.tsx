
import React, { useState, useEffect, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, HomeworkData } from '../context/InstitutionContext';

interface HomeworkModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<HomeworkData, 'id'> & { id?: string }) => void;
  homeworkToEdit: HomeworkData | null;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const HomeworkModal: React.FC<HomeworkModalProps> = ({ isOpen, onClose, onSave, homeworkToEdit }) => {
    const { classLevels, sections } = useInstitution();
    const today = new Date().toISOString().split('T')[0];

    const [title, setTitle] = useState('');
    const [classLevel, setClassLevel] = useState('');
    const [section, setSection] = useState('');
    const [subject, setSubject] = useState('');
    const [description, setDescription] = useState('');
    const [assignDate, setAssignDate] = useState(today);
    const [submissionDate, setSubmissionDate] = useState('');
    const [file, setFile] = useState<File | null>(null);

    const availableSections = useMemo(() => classLevel ? sections.filter(s => s.classLevel === classLevel).map(s => s.name) : [], [classLevel, sections]);
    const availableSubjects = useMemo(() => classLevel ? classLevels.find(cl => cl.name === classLevel)?.subjects.map(s => s.name) || [] : [], [classLevel, classLevels]);
    
    useEffect(() => {
        if (isOpen) {
            if (homeworkToEdit) {
                setTitle(homeworkToEdit.title);
                setClassLevel(homeworkToEdit.classLevel);
                setSection(homeworkToEdit.section);
                setSubject(homeworkToEdit.subject);
                setDescription(homeworkToEdit.description);
                setAssignDate(homeworkToEdit.assignDate);
                setSubmissionDate(homeworkToEdit.submissionDate);
                setFile(null); // Reset file on open
            } else {
                setTitle(''); setClassLevel(''); setSection(''); setSubject(''); setDescription('');
                setAssignDate(today); setSubmissionDate(''); setFile(null);
            }
        }
    }, [isOpen, homeworkToEdit, today]);
    
    useEffect(() => {
        // Reset section and subject if class changes
        if (!availableSections.includes(section)) setSection('');
        if (!availableSubjects.includes(subject)) setSubject('');
    }, [classLevel, availableSections, availableSubjects, section, subject]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        let fileUrl, fileName;
        if (file) {
            fileUrl = await fileToBase64(file);
            fileName = file.name;
        }

        const dataToSave = {
            id: homeworkToEdit?.id,
            title, classLevel, section, subject, description, assignDate, submissionDate,
            fileUrl: fileUrl || homeworkToEdit?.fileUrl,
            fileName: fileName || homeworkToEdit?.fileName
        };
        onSave(dataToSave);
    };

    if (!isOpen) return null;

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4">
                <form onSubmit={handleSubmit} className="flex flex-col">
                    <div className="p-5 border-b"><h3 className="text-lg font-bold">{homeworkToEdit ? 'হোমওয়ার্ক সম্পাদনা করুন' : 'নতুন হোমওয়ার্ক'}</h3></div>
                    <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <select value={classLevel} onChange={e => setClassLevel(e.target.value)} required className="p-2 border rounded-md"><option value="">শ্রেণি*</option>{classLevels.map(cl => <option key={cl.id}>{cl.name}</option>)}</select>
                            <select value={section} onChange={e => setSection(e.target.value)} required disabled={!classLevel} className="p-2 border rounded-md"><option value="">সেকশন*</option>{availableSections.map(s => <option key={s}>{s}</option>)}</select>
                            <select value={subject} onChange={e => setSubject(e.target.value)} required disabled={!classLevel} className="p-2 border rounded-md"><option value="">বিষয়*</option>{availableSubjects.map(s => <option key={s}>{s}</option>)}</select>
                        </div>
                        <input type="text" value={title} onChange={e => setTitle(e.target.value)} placeholder="শিরোনাম*" required className="w-full p-2 border rounded-md" />
                        <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="বিবরণ" rows={4} className="w-full p-2 border rounded-md"></textarea>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><label className="text-xs">দেওয়ার তারিখ</label><input type="date" value={assignDate} onChange={e => setAssignDate(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                            <div><label className="text-xs">জমা দেওয়ার তারিখ</label><input type="date" value={submissionDate} min={assignDate} onChange={e => setSubmissionDate(e.target.value)} required className="w-full p-2 border rounded-md"/></div>
                        </div>
                        <div>
                           <label className="text-xs">ফাইল সংযুক্ত করুন (ঐচ্ছিক)</label>
                           <input type="file" onChange={e => setFile(e.target.files ? e.target.files[0] : null)} className="w-full text-sm"/>
                           {homeworkToEdit?.fileName && !file && <span className="text-xs text-gray-500">বর্তমান ফাইল: {homeworkToEdit.fileName}</span>}
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">সংরক্ষণ</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default HomeworkModal;
