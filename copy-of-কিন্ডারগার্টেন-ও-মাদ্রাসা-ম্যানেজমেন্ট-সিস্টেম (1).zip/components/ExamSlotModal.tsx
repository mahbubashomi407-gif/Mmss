import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { SubjectData } from '../context/InstitutionContext';

interface ExamSlotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (subjectId: string | null) => void;
  slotInfo: {
    className: string;
    subjects: SubjectData[];
    date: string;
    session: 'Morning' | 'Afternoon';
    existingSubjectId?: string;
  };
}

const ExamSlotModal: React.FC<ExamSlotModalProps> = ({ isOpen, onClose, onSave, slotInfo }) => {
    const [selectedSubjectId, setSelectedSubjectId] = useState<string>('');

    useEffect(() => {
        setSelectedSubjectId(slotInfo.existingSubjectId || '');
    }, [slotInfo, isOpen]);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(selectedSubjectId);
        onClose();
    };
    
    const handleClear = () => {
        onSave(null);
        onClose();
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold">পরীক্ষার বিষয় নির্ধারণ করুন</h3>
                        <div className="text-sm text-gray-500 mt-1">
                            <span>{slotInfo.className} | {new Date(slotInfo.date).toLocaleDateString('bn-BD')} | {slotInfo.session === 'Morning' ? 'সকাল' : 'বিকাল'}</span>
                        </div>
                    </div>
                    <div className="p-5">
                        <label htmlFor="subject" className="block text-sm font-medium text-gray-700">বিষয় নির্বাচন করুন</label>
                        <select
                            id="subject"
                            value={selectedSubjectId}
                            onChange={e => setSelectedSubjectId(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                        >
                            <option value="">-- বিষয় নেই --</option>
                            {slotInfo.subjects.map(subject => (
                                <option key={subject.id} value={subject.id}>{subject.name}</option>
                            ))}
                        </select>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-between items-center border-t">
                        <button type="button" onClick={handleClear} className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 text-sm">স্লট খালি করুন</button>
                        <div className="flex gap-3">
                            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বাতিল</button>
                            <button type="submit" disabled={!selectedSubjectId} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 disabled:bg-gray-400">সংরক্ষণ</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default ExamSlotModal;