import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, StudentFeeRecordData } from '../context/InstitutionContext';

interface EditFeeRecordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: StudentFeeRecordData) => void;
  recordToEdit: StudentFeeRecordData | null;
}

const EditFeeRecordModal: React.FC<EditFeeRecordModalProps> = ({ isOpen, onClose, onSave, recordToEdit }) => {
    const { students, feeTypes } = useInstitution();
    
    // State for form fields
    const [amount, setAmount] = useState<number | ''>('');
    const [paymentDate, setPaymentDate] = useState('');
    const [paymentMethod, setPaymentMethod] = useState<'ক্যাশ' | 'বিকাশ' | 'নগদ' | 'অন্যান্য'>('ক্যাশ');
    const [notes, setNotes] = useState('');
    
    // Derived display data
    const student = students.find(s => s.id === recordToEdit?.studentId);
    const feeType = feeTypes.find(ft => ft.id === recordToEdit?.feeTypeId);
    
    // Populate form when modal opens with a record
    useEffect(() => {
        if (recordToEdit) {
            setAmount(recordToEdit.amountPaid);
            setPaymentDate(recordToEdit.paymentDate);
            setPaymentMethod(recordToEdit.paymentMethod);
            setNotes(recordToEdit.notes || '');
        }
    }, [recordToEdit]);
    
    if (!isOpen || !recordToEdit) return null;
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (amount === '' || amount <= 0) return;
        
        const updatedRecord: StudentFeeRecordData = {
            ...recordToEdit,
            amountPaid: amount,
            paymentDate,
            paymentMethod,
            notes,
        };
        onSave(updatedRecord);
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold text-gray-800">ফি রেকর্ড সম্পাদনা করুন</h3>
                        <p className="text-sm text-gray-500">ইনভয়েস নং: {recordToEdit.invoiceNumber}</p>
                    </div>
                    <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div className="p-3 bg-gray-50 rounded-md text-sm">
                            <p><strong>শিক্ষার্থী:</strong> {student?.nameBn || 'অজানা'}</p>
                            <p><strong>ফি-এর ধরন:</strong> {feeType?.name || 'অজানা'} {recordToEdit.month && `(${recordToEdit.month} - ${recordToEdit.year.toLocaleString('bn-BD')})`}</p>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                             <div>
                                <label className="block text-sm font-medium text-gray-700">টাকার পরিমাণ<span className="text-red-500">*</span></label>
                                <input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} required className="mt-1 w-full p-2 border border-gray-300 rounded-md" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">পেমেন্টের তারিখ</label>
                                <input type="date" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} required className="mt-1 w-full p-2 border border-gray-300 rounded-md" />
                            </div>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">পেমেন্ট পদ্ধতি</label>
                            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as any)} className="mt-1 w-full p-2 border border-gray-300 rounded-md bg-white">
                                <option>ক্যাশ</option><option>বিকাশ</option><option>নগদ</option><option>অন্যান্য</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">নোট (ঐচ্ছিক)</label>
                            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="mt-1 w-full p-2 border border-gray-300 rounded-md"></textarea>
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বাতিল করুন</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700">সংরক্ষণ করুন</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default EditFeeRecordModal;