
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { TeacherRoleData, AccountantRoleData, StudentRoleData } from '../context/InstitutionContext';
import { PERMISSIONS } from '../constants/permissions';

type RoleDataType = TeacherRoleData | AccountantRoleData | StudentRoleData;

interface RoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (roleData: { name: string, permissions: string[], id?: string }) => void;
  roleToEdit?: RoleDataType | null;
  permissionSet?: typeof PERMISSIONS;
}

type PermissionCategory = {
    title: string;
    permissions: Record<string, string>;
};

const RoleModal: React.FC<RoleModalProps> = ({ isOpen, onClose, onSave, roleToEdit, permissionSet }) => {
  const [name, setName] = useState('');
  const [permissions, setPermissions] = useState<string[]>([]);

  const permissionsToUse = permissionSet || PERMISSIONS;
  const allKeys = Object.values(permissionsToUse).reduce((acc: string[], category) => {
    return acc.concat(Object.keys((category as PermissionCategory).permissions));
  }, []);


  useEffect(() => {
    if (roleToEdit) {
      setName(roleToEdit.name);
      setPermissions(roleToEdit.permissions);
    } else {
      setName('');
      setPermissions([]);
    }
  }, [roleToEdit, isOpen]);

  if (!isOpen) return null;

  const handlePermissionChange = (permissionKey: string, checked: boolean) => {
    setPermissions(prev => 
      checked ? [...prev, permissionKey] : prev.filter(p => p !== permissionKey)
    );
  };
  
  const handleSelectAll = (categoryPermissions: string[]) => {
      setPermissions(prev => {
          const newPermissions = [...new Set([...prev, ...categoryPermissions])];
          return newPermissions;
      });
  };
  
  const handleDeselectAll = (categoryPermissions: string[]) => {
       setPermissions(prev => prev.filter(p => !categoryPermissions.includes(p)));
  }

  const handleSelectAllSystem = () => {
      setPermissions(allKeys);
  };

  const handleDeselectAllSystem = () => {
      setPermissions([]);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    onSave({ id: roleToEdit?.id, name, permissions });
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4 transform transition-all flex flex-col h-[90vh]">
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
            <div className="p-5 border-b">
                <h3 className="text-lg font-bold text-gray-800">{roleToEdit ? 'ভূমিকা সম্পাদনা করুন' : 'নতুন ভূমিকা তৈরি করুন'}</h3>
                <div className="mt-4">
                    <label htmlFor="roleName" className="block text-sm font-medium text-gray-700">ভূমিকার নাম</label>
                    <input
                        id="roleName"
                        type="text"
                        value={name}
                        onChange={e => setName(e.target.value)}
                        className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 read-only:bg-gray-100 read-only:cursor-not-allowed"
                        placeholder="উদাহরণ: শ্রেণি শিক্ষক"
                        required
                        readOnly={!!roleToEdit}
                    />
                </div>
            </div>

            <div className="p-5 flex-grow overflow-y-auto">
                <h4 className="font-semibold text-gray-800 mb-2">অনুমতি নির্ধারণ করুন</h4>
                <div className="flex justify-end gap-2 mb-3">
                    <button type="button" onClick={handleSelectAllSystem} className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded">সব নির্বাচন করুন</button>
                    <button type="button" onClick={handleDeselectAllSystem} className="text-xs px-2 py-1 bg-gray-100 text-gray-700 rounded">সব বাতিল করুন</button>
                </div>
                <div className="space-y-4">
                    {Object.entries(permissionsToUse).map(([categoryKey, category]) => {
                        const categoryPermissions = Object.keys((category as PermissionCategory).permissions);
                        return (
                            <div key={categoryKey} className="p-3 border rounded-lg">
                                <div className="flex justify-between items-center mb-2">
                                    <h5 className="font-bold text-gray-700">{(category as PermissionCategory).title}</h5>
                                    <div className="space-x-2">
                                        <button type="button" onClick={() => handleSelectAll(categoryPermissions)} className="text-xs text-blue-600 hover:underline">সব</button>
                                        <button type="button" onClick={() => handleDeselectAll(categoryPermissions)} className="text-xs text-gray-600 hover:underline">কোনোটিই না</button>
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                                    {Object.entries((category as PermissionCategory).permissions).map(([key, label]) => (
                                        <label key={key} className="flex items-center space-x-2 text-sm p-1 rounded hover:bg-gray-50 cursor-pointer">
                                            <input
                                                type="checkbox"
                                                checked={permissions.includes(key)}
                                                onChange={e => handlePermissionChange(key, e.target.checked)}
                                                className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                                            />
                                            <span className="text-gray-600">{label as string}</span>
                                        </label>
                                    ))}
                                </div>
                            </div>
                        )
                    })}
                </div>
            </div>
            
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
                >
                    বাতিল করুন
                </button>
                <button
                    type="submit"
                    className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
                >
                    সংরক্ষণ করুন
                </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default RoleModal;
