import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { NoticeData } from '../context/InstitutionContext';
import { useInstitution } from '../context/InstitutionContext';

interface NoticeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (notice: Omit<NoticeData, 'id' | 'publishDate'> & { id?: string }) => void;
  noticeToEdit?: NoticeData | null;
}

const NoticeModal: React.FC<NoticeModalProps> = ({ isOpen, onClose, onSave, noticeToEdit }) => {
  const { smsTemplates } = useInstitution();
  const [title, setTitle] = useState('');
  const [details, setDetails] = useState('');
  const [target, setTarget] = useState<('Guardians' | 'Teachers')[]>([]);
  const [sendSms, setSendSms] = useState(false);
  const [smsContent, setSmsContent] = useState('');

  useEffect(() => {
    if (isOpen) {
        if (noticeToEdit) {
            setTitle(noticeToEdit.title);
            setDetails(noticeToEdit.details);
            setTarget(noticeToEdit.target);
            setSendSms(noticeToEdit.sendSms);
            setSmsContent(noticeToEdit.smsContent || smsTemplates.newNotice);
        } else {
            // Reset form for new entry
            setTitle('');
            setDetails('');
            setTarget(['Guardians']); // Default to guardians
            setSendSms(false);
            setSmsContent(smsTemplates.newNotice);
        }
    }
  }, [noticeToEdit, isOpen, smsTemplates.newNotice]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !details.trim() || target.length === 0) {
        // Basic validation feedback can be added here
        return;
    };
    onSave({
      id: noticeToEdit?.id,
      title,
      details,
      target,
      sendSms,
      smsContent: sendSms ? smsContent : undefined,
    });
  };

  const handleTargetChange = (value: 'Guardians' | 'Teachers') => {
    setTarget(prev => 
      prev.includes(value) ? prev.filter(t => t !== value) : [...prev, value]
    );
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4 transform transition-all flex flex-col max-h-[90vh]">
        <form onSubmit={handleSubmit} className="flex flex-col h-full">
          <div className="p-5 border-b">
            <h3 className="text-lg font-bold text-gray-800">{noticeToEdit ? 'নোটিশ সম্পাদনা করুন' : 'নতুন নোটিশ যোগ করুন'}</h3>
          </div>
          <div className="p-5 flex-grow overflow-y-auto space-y-4">
              <div>
                <label htmlFor="noticeTitle" className="block text-sm font-medium text-gray-700">শিরোনাম</label>
                <input
                  id="noticeTitle" type="text" value={title} onChange={e => setTitle(e.target.value)}
                  className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                  required
                />
              </div>
              <div>
                <label htmlFor="noticeDetails" className="block text-sm font-medium text-gray-700">বিবরণ</label>
                <textarea
                  id="noticeDetails" rows={5} value={details} onChange={e => setDetails(e.target.value)}
                  className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">কাদের জন্য নোটিশ?</label>
                <div className="mt-2 flex gap-4">
                  <label className="flex items-center">
                    <input type="checkbox" checked={target.includes('Guardians')} onChange={() => handleTargetChange('Guardians')} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500" />
                    <span className="ml-2 text-sm text-gray-700">সকল অভিভাবক</span>
                  </label>
                  <label className="flex items-center">
                    <input type="checkbox" checked={target.includes('Teachers')} onChange={() => handleTargetChange('Teachers')} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500" />
                    <span className="ml-2 text-sm text-gray-700">সকল শিক্ষক</span>
                  </label>
                </div>
              </div>
              <div className="pt-2">
                <label className="flex items-center">
                  <input type="checkbox" checked={sendSms} onChange={e => setSendSms(e.target.checked)} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500" />
                  <span className="ml-2 text-sm font-medium text-gray-700">এই নোটিশের জন্য SMS পাঠান</span>
                </label>
              </div>
              {sendSms && (
                <div className="transition-all duration-300">
                  <label htmlFor="smsContent" className="block text-sm font-medium text-gray-700">SMS বার্তা</label>
                  <textarea
                    id="smsContent" rows={3} value={smsContent} onChange={e => setSmsContent(e.target.value)}
                    className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 bg-gray-50"
                  />
                   <p className="text-xs text-gray-500 mt-1">এখানে ডিফল্ট টেমপ্লেট দেখানো হচ্ছে। আপনি এই নোটিশের জন্য বার্তাটি পরিবর্তন করতে পারেন।</p>
                </div>
              )}
          </div>
          <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors">বাতিল</button>
            <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors">সংরক্ষণ করুন</button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
};
export default NoticeModal;