
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { ActivityData } from '../context/InstitutionContext';

interface ActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (activity: Omit<ActivityData, 'id'> & { id?: string }) => void;
  activityToEdit?: ActivityData | null;
}

const ActivityModal: React.FC<ActivityModalProps> = ({ isOpen, onClose, onSave, activityToEdit }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');

  useEffect(() => {
    if (activityToEdit) {
      setTitle(activityToEdit.title);
      setDescription(activityToEdit.description);
    } else {
      // Reset form for new entry
      setTitle('');
      setDescription('');
    }
  }, [activityToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onSave({
      id: activityToEdit?.id,
      title,
      description,
    });
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{activityToEdit ? 'কার্যক্রম সম্পাদনা করুন' : 'নতুন কার্যক্রম যোগ করুন'}</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label htmlFor="activityTitle" className="block text-sm font-medium text-gray-700">কার্যক্রমের শিরোনাম</label>
                        <input
                            id="activityTitle"
                            type="text"
                            value={title}
                            onChange={e => setTitle(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                            placeholder="উদাহরণ: শারীরিক বিকাশ"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="activityDescription" className="block text-sm font-medium text-gray-700">বিবরণ</label>
                        <textarea
                            id="activityDescription"
                            rows={5}
                            value={description}
                            onChange={e => setDescription(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                            placeholder="কার্যক্রমের বিস্তারিত বিবরণ লিখুন..."
                        />
                    </div>
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default ActivityModal;
