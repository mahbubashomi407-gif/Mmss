
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { LicenseData } from '../context/InstitutionContext';

interface LicenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (license: Omit<LicenseData, 'id'>) => void;
}

const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = error => reject(error);
    });
};

const LicenseModal: React.FC<LicenseModalProps> = ({ isOpen, onClose, onSave }) => {
  const [name, setName] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!isOpen) {
      setName('');
      setExpiryDate('');
      setFile(null);
      setError('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !file) {
      setError('নথির নাম এবং একটি ফাইল নির্বাচন করা আবশ্যক।');
      return;
    }
    
    try {
        setError('');
        const fileUrl = await fileToBase64(file);
        onSave({
          name,
          expiryDate: expiryDate || undefined,
          fileUrl,
          fileName: file.name,
        });
    } catch (err) {
        setError('ফাইল আপলোড করতে সমস্যা হয়েছে।');
        console.error(err);
    }
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">নতুন নথি যোগ করুন</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label htmlFor="licenseName" className="block text-sm font-medium text-gray-700">নথির নাম</label>
                        <input
                            id="licenseName"
                            type="text"
                            value={name}
                            onChange={e => setName(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                            placeholder="উদাহরণ: ট্রেড লাইসেন্স"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="expiryDate" className="block text-sm font-medium text-gray-700">মেয়াদ উত্তীর্ণের তারিখ (ঐচ্ছিক)</label>
                        <input
                            id="expiryDate"
                            type="date"
                            value={expiryDate}
                            onChange={e => setExpiryDate(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                        />
                    </div>
                     <div>
                        <label htmlFor="fileUpload" className="block text-sm font-medium text-gray-700">ফাইল আপলোড করুন</label>
                         <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                            <div className="space-y-1 text-center">
                                <svg className="mx-auto h-12 w-12 text-gray-400" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"></path></svg>
                                <div className="flex text-sm text-gray-600">
                                    <label htmlFor="file-upload-input" className="relative cursor-pointer bg-white rounded-md font-medium text-teal-600 hover:text-teal-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-teal-500">
                                        <span>একটি ফাইল নির্বাচন করুন</span>
                                        <input id="file-upload-input" name="file-upload" type="file" className="sr-only" onChange={(e) => setFile(e.target.files?.[0] || null)} />
                                    </label>
                                </div>
                                {file ? <p className="text-xs text-gray-500">{file.name}</p> : <p className="text-xs text-gray-500">PNG, JPG, PDF (সর্বোচ্চ 5MB)</p>}
                            </div>
                        </div>
                    </div>
                    {error && <p className="text-sm text-center text-red-500">{error}</p>}
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default LicenseModal;
