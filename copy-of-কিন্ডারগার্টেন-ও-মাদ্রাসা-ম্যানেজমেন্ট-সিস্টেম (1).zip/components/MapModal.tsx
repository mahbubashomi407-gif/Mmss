
import React, { useState, useEffect, useMemo, useRef } from 'react';
import ReactDOM from 'react-dom';
import { MapContainer, TileLayer, Marker, useMapEvents, useMap } from 'react-leaflet';
import L from 'leaflet';

// Leaflet এর ডিফল্ট আইকন সমস্যার সমাধান
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

interface MapModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLocationSelect: (lat: number, lng: number) => void;
}

const LocationMarker: React.FC<{ position: L.LatLng, setPosition: (pos: L.LatLng) => void }> = ({ position, setPosition }) => {
  const markerRef = useRef<L.Marker>(null);
  useMapEvents({
      click(e) {
          setPosition(e.latlng);
      },
  });

  const eventHandlers = useMemo(() => ({
    dragend() {
      const marker = markerRef.current;
      if (marker != null) {
        setPosition(marker.getLatLng());
      }
    },
  }), [setPosition]);

  return (
    <Marker
      draggable={true}
      eventHandlers={eventHandlers}
      position={position}
      ref={markerRef}
    />
  );
};

// This component handles map view updates and ensures it's sized correctly.
const MapController: React.FC<{ center: L.LatLng }> = ({ center }) => {
    const map = useMap();

    useEffect(() => {
        // Fly to the new center when it changes
        map.flyTo(center, map.getZoom(), {
            animate: true,
            duration: 0.5,
        });
    }, [center, map]);

    useEffect(() => {
        // Invalidate map size after a short delay to account for modal animations
        const timer = setTimeout(() => map.invalidateSize(), 200);
        return () => clearTimeout(timer);
    }, [map]);

    return null;
}


const MapModal: React.FC<MapModalProps> = ({ isOpen, onClose, onLocationSelect }) => {
    const defaultPosition = useMemo(() => new L.LatLng(23.8103, 90.4125), []); // Default: Dhaka
    const [position, setPosition] = useState<L.LatLng>(defaultPosition);
    const [mapCenter, setMapCenter] = useState<L.LatLng>(defaultPosition);
    const [isLoading, setIsLoading] = useState(true);
    
    useEffect(() => {
        if (isOpen) {
            setIsLoading(true);
            // Reset position to default before fetching new one
            setPosition(defaultPosition);
            setMapCenter(defaultPosition);

            navigator.geolocation.getCurrentPosition(
                (pos) => {
                    const userPos = new L.LatLng(pos.coords.latitude, pos.coords.longitude);
                    setPosition(userPos);
                    setMapCenter(userPos);
                    setIsLoading(false);
                },
                () => {
                    // Use default location on failure
                    setIsLoading(false); 
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
            );
        }
    }, [isOpen, defaultPosition]);

    if (!isOpen) return null;

    const handleConfirm = () => {
        onLocationSelect(position.lat, position.lng);
        onClose();
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl h-[80vh] m-4 transform transition-all flex flex-col">
                <div className="p-4 border-b">
                    <h3 className="text-lg font-bold text-gray-800">মানচিত্র থেকে অবস্থান নির্বাচন করুন</h3>
                    <p className="text-sm text-gray-500">মানচিত্রে ক্লিক করে বা মার্কার টেনে আপনার অবস্থান ঠিক করুন।</p>
                </div>
                <div className="flex-grow relative">
                    {isLoading && (
                         <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-75 z-20">
                            <div className="text-center">
                                <svg className="animate-spin h-8 w-8 text-teal-600 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                                <p className="mt-2 font-semibold text-gray-600">আপনার অবস্থান লোড হচ্ছে...</p>
                            </div>
                        </div>
                    )}
                    <MapContainer center={defaultPosition} zoom={13} style={{ height: '100%', width: '100%' }} className="z-10">
                        <TileLayer
                            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        <LocationMarker position={position} setPosition={setPosition} />
                        <MapController center={mapCenter} />
                    </MapContainer>
                </div>
                <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
                    <button onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors">বাতিল করুন</button>
                    <button onClick={handleConfirm} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors">এই অবস্থানটি ব্যবহার করুন</button>
                </div>
            </div>
        </div>,
        document.body
    );
};

export default MapModal;
