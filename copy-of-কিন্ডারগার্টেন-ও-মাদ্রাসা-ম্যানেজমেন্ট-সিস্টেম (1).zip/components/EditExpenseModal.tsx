
import React, { useState, useEffect, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, ExpenseData } from '../context/InstitutionContext';

interface EditExpenseModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: ExpenseData) => void;
  recordToEdit: ExpenseData | null;
}

const EditExpenseModal: React.FC<EditExpenseModalProps> = ({ isOpen, onClose, onSave, recordToEdit }) => {
    const { fundCategories, fundHeads } = useInstitution();

    const [date, setDate] = useState('');
    const [fundCategoryId, setFundCategoryId] = useState('');
    const [fundHeadId, setFundHeadId] = useState('');
    const [amount, setAmount] = useState<number | ''>('');
    const [description, setDescription] = useState('');
    const [voucherNo, setVoucherNo] = useState('');

    useEffect(() => {
        if (recordToEdit) {
            const head = fundHeads.find(h => h.id === recordToEdit.fundHeadId);
            setDate(recordToEdit.date);
            setFundCategoryId(head?.fundCategoryId || '');
            setFundHeadId(recordToEdit.fundHeadId);
            setAmount(recordToEdit.amount);
            setDescription(recordToEdit.description);
            setVoucherNo(recordToEdit.voucherNo || '');
        }
    }, [recordToEdit, fundHeads]);

    const availableHeads = useMemo(() => {
        if (!fundCategoryId) return [];
        return fundHeads.filter(head => head.fundCategoryId === fundCategoryId && head.type === 'Expense');
    }, [fundCategoryId, fundHeads]);

    useEffect(() => {
        if (fundCategoryId && !availableHeads.some(h => h.id === fundHeadId)) {
            setFundHeadId('');
        }
    }, [fundCategoryId, availableHeads, fundHeadId]);

    if (!isOpen || !recordToEdit) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!fundHeadId || amount === '' || amount <= 0 || !date) {
            return;
        }

        const updatedRecord: ExpenseData = {
            ...recordToEdit,
            date,
            fundHeadId,
            amount: Number(amount),
            description,
            voucherNo: voucherNo || undefined,
        };
        onSave(updatedRecord);
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold">ব্যয় সম্পাদনা করুন</h3>
                    </div>
                    <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                         <div><label className="block text-sm font-medium">তারিখ*</label><input type="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" /></div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div><label className="block text-sm font-medium">তহবিল ক্যাটাগরি*</label><select value={fundCategoryId} onChange={e => setFundCategoryId(e.target.value)} required className="mt-1 w-full p-2 border rounded-md bg-white"><option value="">নির্বাচন করুন</option>{fundCategories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
                            <div><label className="block text-sm font-medium">ব্যয়ের খাত*</label><select value={fundHeadId} onChange={e => setFundHeadId(e.target.value)} required disabled={!fundCategoryId} className="mt-1 w-full p-2 border rounded-md bg-white"><option value="">নির্বাচন করুন</option>{availableHeads.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}</select></div>
                        </div>
                        <div><label className="block text-sm font-medium">পরিমাণ (টাকা)*</label><input type="number" value={amount} onChange={e => setAmount(Number(e.target.value))} required className="mt-1 w-full p-2 border rounded-md" /></div>
                        <div><label className="block text-sm font-medium">বিবরণ</label><textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} className="mt-1 w-full p-2 border rounded-md"></textarea></div>
                        <div><label className="block text-sm font-medium">ভাউচার নম্বর</label><input type="text" value={voucherNo} onChange={e => setVoucherNo(e.target.value)} className="mt-1 w-full p-2 border rounded-md" /></div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">সংরক্ষণ</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default EditExpenseModal;
