
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { FeeTypeData, ClassLevelData } from '../context/InstitutionContext';

interface FeeTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (feeType: Omit<FeeTypeData, 'id'> & { id?: string }) => void;
  feeTypeToEdit?: FeeTypeData | null;
  classLevels: ClassLevelData[];
}

const FeeTypeModal: React.FC<FeeTypeModalProps> = ({ isOpen, onClose, onSave, feeTypeToEdit, classLevels }) => {
  const [name, setName] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [applicableClasses, setApplicableClasses] = useState<string[]>([]);
  const [description, setDescription] = useState('');

  const allClassNames = classLevels.map(cl => cl.name);

  useEffect(() => {
    if (feeTypeToEdit) {
      setName(feeTypeToEdit.name);
      setAmount(feeTypeToEdit.amount);
      setApplicableClasses(feeTypeToEdit.applicableClasses);
      setDescription(feeTypeToEdit.description || '');
    } else {
      // Reset form for new entry
      setName('');
      setAmount('');
      setApplicableClasses([]);
      setDescription('');
    }
  }, [feeTypeToEdit, isOpen]);

  if (!isOpen) return null;

  const handleClassChange = (className: string, checked: boolean) => {
    setApplicableClasses(prev => 
      checked ? [...prev, className] : prev.filter(c => c !== className)
    );
  };
  
  const handleSelectAllClasses = (checked: boolean) => {
    if (checked) {
        setApplicableClasses(allClassNames);
    } else {
        setApplicableClasses([]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || amount === '' || applicableClasses.length === 0) return;
    onSave({
      id: feeTypeToEdit?.id,
      name,
      amount,
      applicableClasses,
      description,
    });
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{feeTypeToEdit ? 'ফি টাইপ সম্পাদনা করুন' : 'নতুন ফি টাইপ যোগ করুন'}</h3>
                <div className="mt-4 space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="feeName" className="block text-sm font-medium text-gray-700">ফি-এর নাম</label>
                            <input
                                id="feeName" type="text" value={name} onChange={e => setName(e.target.value)}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                                placeholder="উদাহরণ: মাসিক বেতন" required
                            />
                        </div>
                        <div>
                            <label htmlFor="feeAmount" className="block text-sm font-medium text-gray-700">পরিমাণ (টাকা)</label>
                            <input
                                id="feeAmount" type="number" value={amount} onChange={e => setAmount(Number(e.target.value))}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                                placeholder="উদাহরণ: ৫০০" required
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">প্রযোজ্য শ্রেণি</label>
                        <div className="mt-2 p-3 border border-gray-200 rounded-md max-h-40 overflow-y-auto">
                            <div className="flex items-center justify-between border-b pb-2 mb-2">
                                <span className="text-xs font-semibold text-gray-500">শ্রেণি নির্বাচন করুন</span>
                                <label className="flex items-center space-x-2 text-xs cursor-pointer">
                                    <input
                                        type="checkbox"
                                        checked={applicableClasses.length === allClassNames.length}
                                        onChange={(e) => handleSelectAllClasses(e.target.checked)}
                                        className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                                    />
                                    <span>সব</span>
                                </label>
                            </div>
                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                {classLevels.map(cl => (
                                    <label key={cl.id} className="flex items-center space-x-2 text-sm p-1 rounded cursor-pointer">
                                        <input
                                            type="checkbox"
                                            checked={applicableClasses.includes(cl.name)}
                                            onChange={(e) => handleClassChange(cl.name, e.target.checked)}
                                            className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                                        />
                                        <span className="text-gray-600">{cl.name}</span>
                                    </label>
                                ))}
                            </div>
                        </div>
                    </div>
                    <div>
                        <label htmlFor="feeDescription" className="block text-sm font-medium text-gray-700">বিবরণ (ঐচ্ছিক)</label>
                        <textarea
                            id="feeDescription" rows={2} value={description} onChange={e => setDescription(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                            placeholder="ফি সম্পর্কে অতিরিক্ত তথ্য..."
                        />
                    </div>
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default FeeTypeModal;
