import React, { useState } from 'react';
import ReactDOM from 'react-dom';

interface AddTimeSlotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (startTime: string, endTime: string) => void;
}

const AddTimeSlotModal: React.FC<AddTimeSlotModalProps> = ({ isOpen, onClose, onSave }) => {
    const [startTime, setStartTime] = useState('');
    const [endTime, setEndTime] = useState('');
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!startTime || !endTime) {
            setError('অনুগ্রহ করে শুরু এবং শেষের সময় দিন।');
            return;
        }
        if (startTime >= endTime) {
            setError('শুরুর সময় শেষের সময়ের আগে হতে হবে।');
            return;
        }
        setError('');
        onSave(startTime, endTime);
        onClose();
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-sm m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5">
                        <h3 className="text-lg font-bold text-gray-800">নতুন সময়সূচী যোগ করুন</h3>
                        <div className="mt-4 space-y-4">
                             <div>
                                <label htmlFor="startTime" className="block text-sm font-medium text-gray-700">শুরুর সময়</label>
                                <input id="startTime" type="time" value={startTime} onChange={e => setStartTime(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" />
                            </div>
                             <div>
                                <label htmlFor="endTime" className="block text-sm font-medium text-gray-700">শেষের সময়</label>
                                <input id="endTime" type="time" value={endTime} onChange={e => setEndTime(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" />
                            </div>
                            {error && <p className="text-xs text-red-500">{error}</p>}
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">যোগ করুন</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default AddTimeSlotModal;