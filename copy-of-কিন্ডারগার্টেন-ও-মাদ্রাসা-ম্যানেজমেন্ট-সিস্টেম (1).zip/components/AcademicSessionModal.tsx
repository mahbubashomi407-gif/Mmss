
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { AcademicSessionData } from '../context/InstitutionContext';

interface AcademicSessionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (session: Omit<AcademicSessionData, 'id'> & { id?: string }) => void;
  sessionToEdit?: AcademicSessionData | null;
}

const AcademicSessionModal: React.FC<AcademicSessionModalProps> = ({ isOpen, onClose, onSave, sessionToEdit }) => {
  const [name, setName] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    if (sessionToEdit) {
      setName(sessionToEdit.name);
      setStartDate(sessionToEdit.startDate);
      setEndDate(sessionToEdit.endDate);
      setIsActive(sessionToEdit.isActive);
    } else {
      // Reset form for new entry
      setName('');
      setStartDate('');
      setEndDate('');
      setIsActive(false);
    }
  }, [sessionToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: sessionToEdit?.id,
      name,
      startDate,
      endDate,
      isActive
    });
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{sessionToEdit ? 'শিক্ষা বর্ষ সম্পাদনা করুন' : 'নতুন শিক্ষা বর্ষ যোগ করুন'}</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label htmlFor="sessionName" className="block text-sm font-medium text-gray-700">সেশনের নাম</label>
                        <input
                            id="sessionName"
                            type="text"
                            value={name}
                            onChange={e => setName(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                            placeholder="উদাহরণ: ২০২৪-২০২৫"
                            required
                        />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">শুরুর তারিখ</label>
                            <input
                                id="startDate"
                                type="date"
                                value={startDate}
                                onChange={e => setStartDate(e.target.value)}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">শেষের তারিখ</label>
                            <input
                                id="endDate"
                                type="date"
                                value={endDate}
                                onChange={e => setEndDate(e.target.value)}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                                required
                            />
                        </div>
                    </div>
                     <div className="flex items-start">
                        <div className="flex items-center h-5">
                            <input
                                id="isActive"
                                name="isActive"
                                type="checkbox"
                                checked={isActive}
                                onChange={e => setIsActive(e.target.checked)}
                                className="focus:ring-teal-500 h-4 w-4 text-teal-600 border-gray-300 rounded"
                            />
                        </div>
                        <div className="ml-3 text-sm">
                            <label htmlFor="isActive" className="font-medium text-gray-700">সক্রিয় সেশন হিসাবে সেট করুন</label>
                            <p className="text-gray-500">এটি সক্রিয় করলে, অন্য সব সেশন নিষ্ক্রিয় হয়ে যাবে।</p>
                        </div>
                    </div>
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default AcademicSessionModal;
