import React, { useState, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, StudentData } from '../context/InstitutionContext';
import { SearchIcon } from './icons';

interface StudentSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectStudent: (student: StudentData) => void;
}

const StudentSearchModal: React.FC<StudentSearchModalProps> = ({ isOpen, onClose, onSelectStudent }) => {
    const { students } = useInstitution();
    const [searchTerm, setSearchTerm] = useState('');

    const activeStudents = useMemo(() => students.filter(s => s.status !== 'পেন্ডিং'), [students]);

    const filteredStudents = useMemo(() => {
        if (!searchTerm.trim()) return [];
        const lowerSearch = searchTerm.toLowerCase();
        return activeStudents.filter(s => 
            s.nameBn.toLowerCase().includes(lowerSearch) || 
            s.uniqueId.toLowerCase().includes(lowerSearch) ||
            s.fatherPhone.includes(lowerSearch) ||
            s.motherPhone.includes(lowerSearch)
        ).slice(0, 20); // Limit results to avoid performance issues
    }, [searchTerm, activeStudents]);

    if (!isOpen) return null;

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={onClose}>
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4 h-[80vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="p-4 border-b">
                    <h3 className="text-lg font-bold text-gray-800">বিদ্যমান শিক্ষার্থী খুঁজুন</h3>
                    <div className="relative mt-2">
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                            placeholder="আইডি, নাম বা মোবাইল নম্বর দিয়ে খুঁজুন..."
                            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                            autoFocus
                        />
                        <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            <SearchIcon className="w-5 h-5 text-gray-400" />
                        </span>
                    </div>
                </div>
                <div className="flex-grow overflow-y-auto">
                    {searchTerm.trim() ? (
                        filteredStudents.length > 0 ? (
                            <ul className="divide-y divide-gray-200">
                                {filteredStudents.map(student => (
                                    <li key={student.id} className="p-3 flex justify-between items-center hover:bg-gray-50">
                                        <div>
                                            <p className="font-semibold text-gray-800">{student.nameBn} <span className="text-xs text-gray-500 font-mono">({student.uniqueId})</span></p>
                                            <p className="text-xs text-gray-600">পিতার নাম: {student.fatherNameBn} | শ্রেণি: {student.classLevel} ({student.section})</p>
                                        </div>
                                        <button
                                            onClick={() => onSelectStudent(student)}
                                            className="px-3 py-1 bg-teal-600 text-white text-xs font-semibold rounded-md hover:bg-teal-700"
                                        >
                                            তথ্য নিন
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        ) : (
                            <p className="text-center text-gray-500 py-10">কোনো শিক্ষার্থী পাওয়া যায়নি।</p>
                        )
                    ) : (
                        <p className="text-center text-gray-500 py-10">অনুগ্রহ করে শিক্ষার্থীর তথ্য দিয়ে অনুসন্ধান করুন।</p>
                    )}
                </div>
                <div className="bg-gray-50 px-5 py-3 flex justify-end border-t">
                    <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বন্ধ করুন</button>
                </div>
            </div>
        </div>,
        document.body
    );
};

export default StudentSearchModal;
