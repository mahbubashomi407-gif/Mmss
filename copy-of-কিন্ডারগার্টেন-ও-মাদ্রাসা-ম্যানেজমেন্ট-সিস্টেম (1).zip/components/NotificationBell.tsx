import React, { useState, useEffect } from 'react';
import { requestNotificationPermission } from '../utils/notificationService';
import { BellIcon, BellSlashIcon } from './icons';
import { useNotification } from '../context/NotificationContext';

const NotificationBell: React.FC = () => {
    const [permission, setPermission] = useState<NotificationPermission>('default');
    const { addToast } = useNotification();

    useEffect(() => {
        if ('Notification' in window) {
            setPermission(Notification.permission);
        }
    }, []);

    const handlePermissionRequest = async () => {
        const result = await requestNotificationPermission();
        setPermission(result);
        if (result === 'granted') {
            addToast('নোটিফিকেশন সক্রিয় করা হয়েছে!', 'success');
        } else if (result === 'denied') {
            addToast('নোটিফিকেশন ব্লক করা হয়েছে। ব্রাউজার সেটিং থেকে এটি পরিবর্তন করতে পারবেন।', 'error');
        }
    };

    const getIcon = () => {
        switch (permission) {
            case 'granted':
                return <BellIcon className="w-6 h-6 text-green-500" />;
            case 'denied':
                return <BellSlashIcon className="w-6 h-6 text-red-500" />;
            default:
                return <BellIcon className="w-6 h-6 text-gray-500" />;
        }
    };
    
    const getTitle = () => {
         switch (permission) {
            case 'granted':
                return 'নোটিফিকেশন সক্রিয় আছে';
            case 'denied':
                return 'নোটিফিকেশন ব্লক করা আছে';
            default:
                return 'নোটিফিকেশন সক্রিয় করুন';
        }
    }

    if (!('Notification' in window)) {
        return null; // Don't render if not supported
    }
    
    return (
        <button
            onClick={handlePermissionRequest}
            disabled={permission !== 'default'}
            className="p-2 rounded-full hover:bg-gray-100 disabled:cursor-not-allowed"
            title={getTitle()}
            aria-label={getTitle()}
        >
            {getIcon()}
        </button>
    );
};

export default NotificationBell;
