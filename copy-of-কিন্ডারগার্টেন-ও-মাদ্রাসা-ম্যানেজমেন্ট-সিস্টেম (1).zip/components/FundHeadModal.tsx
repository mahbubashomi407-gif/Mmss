
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { FundHeadData, FundCategoryData } from '../context/InstitutionContext';

interface FundHeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (head: Omit<FundHeadData, 'id'> & { id?: string }) => void;
  headToEdit?: FundHeadData | null;
  fundCategories: FundCategoryData[];
  defaultType?: 'Income' | 'Expense';
  hideTypeSelection?: boolean;
}

const FundHeadModal: React.FC<FundHeadModalProps> = ({ isOpen, onClose, onSave, headToEdit, fundCategories, defaultType = 'Income', hideTypeSelection = false }) => {
  const [name, setName] = useState('');
  const [fundCategoryId, setFundCategoryId] = useState('');
  const [type, setType] = useState<'Income' | 'Expense'>(defaultType);

  useEffect(() => {
    if (headToEdit) {
      setName(headToEdit.name);
      setFundCategoryId(headToEdit.fundCategoryId);
      setType(headToEdit.type);
    } else {
      setName('');
      setFundCategoryId(fundCategories.length > 0 ? fundCategories[0].id : '');
      setType(defaultType);
    }
  }, [headToEdit, isOpen, fundCategories, defaultType]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !fundCategoryId) return;
    onSave({
      id: headToEdit?.id,
      name,
      fundCategoryId,
      type
    });
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{headToEdit ? 'খাত সম্পাদনা করুন' : 'নতুন খাত যোগ করুন'}</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label htmlFor="headName" className="block text-sm font-medium text-gray-700">খাতের নাম</label>
                        <input
                            id="headName" type="text" value={name} onChange={e => setName(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                            placeholder="উদাহরণ: ভর্তি ফি" required autoFocus
                        />
                    </div>
                     <div>
                        <label htmlFor="fundCategory" className="block text-sm font-medium text-gray-700">তহবিল ক্যাটাগরি</label>
                        <select
                            id="fundCategory" value={fundCategoryId} onChange={e => setFundCategoryId(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 bg-white" required
                        >
                            <option value="">ক্যাটাগরি নির্বাচন করুন</option>
                            {fundCategories.map(cat => (
                                <option key={cat.id} value={cat.id}>{cat.name}</option>
                            ))}
                        </select>
                    </div>
                    {!hideTypeSelection && (
                        <div>
                            <label className="block text-sm font-medium text-gray-700">খাতের ধরন</label>
                            <div className="mt-2 flex gap-4">
                                <label className="flex items-center">
                                    <input type="radio" value="Income" checked={type === 'Income'} onChange={() => setType('Income')} className="h-4 w-4 text-teal-600 border-gray-300 focus:ring-teal-500" />
                                    <span className="ml-2 text-sm text-gray-700">আয়ের খাত</span>
                                </label>
                                <label className="flex items-center">
                                    <input type="radio" value="Expense" checked={type === 'Expense'} onChange={() => setType('Expense')} className="h-4 w-4 text-teal-600 border-gray-300 focus:ring-teal-500" />
                                    <span className="ml-2 text-sm text-gray-700">ব্যয়ের খাত</span>
                                </label>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default FundHeadModal;
