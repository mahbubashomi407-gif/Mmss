
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { HifzExamTypeData } from '../context/InstitutionContext';

interface HifzExamTypeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<HifzExamTypeData, 'id'> & { id?: string }) => void;
  examTypeToEdit: HifzExamTypeData | null;
}

const HifzExamTypeModal: React.FC<HifzExamTypeModalProps> = ({ isOpen, onClose, onSave, examTypeToEdit }) => {
    const [name, setName] = useState('');

    useEffect(() => {
        if (examTypeToEdit) {
            setName(examTypeToEdit.name);
        } else {
            setName('');
        }
    }, [examTypeToEdit, isOpen]);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim()) {
            return;
        }
        onSave({ id: examTypeToEdit?.id, name });
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold text-gray-800">{examTypeToEdit ? 'হিফজ পরীক্ষার ধরণ সম্পাদনা করুন' : 'নতুন হিফজ পরীক্ষার ধরণ'}</h3>
                    </div>
                    <div className="p-5 space-y-4">
                        <div>
                            <label htmlFor="examTypeName" className="block text-sm font-medium text-gray-700">পরীক্ষার ধরণ</label>
                            <input
                                id="examTypeName"
                                type="text"
                                value={name}
                                onChange={e => setName(e.target.value)}
                                className="mt-1 w-full p-2 border border-gray-300 rounded-md shadow-sm"
                                placeholder="উদাহরণ: মাসিক পরীক্ষা"
                                required
                            />
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700">সংরক্ষণ</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default HifzExamTypeModal;
