import React, { useMemo, useState } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, StudentData, StudentFeeRecordData } from '../context/InstitutionContext';
import { useNotification } from '../context/NotificationContext';
import { ReceiptIcon, PencilIcon, TrashIcon } from './icons';
import Modal from './Modal';
import EditFeeRecordModal from './EditFeeRecordModal';


interface FeeHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentData | null;
}

const FeeHistoryModal: React.FC<FeeHistoryModalProps> = ({ isOpen, onClose, student }) => {
    const { institutionName, logoUrl, address, contactInfo, studentFeeRecords, setStudentFeeRecords, feeTypes, academicSessions } = useInstitution();
    const { addToast } = useNotification();
    
    const [receiptToPrint, setReceiptToPrint] = useState<StudentFeeRecordData | null>(null);
    const [editModal, setEditModal] = useState<{ isOpen: boolean; record: StudentFeeRecordData | null }>({ isOpen: false, record: null });
    const [deleteModal, setDeleteModal] = useState<{ isOpen: boolean; record: StudentFeeRecordData | null }>({ isOpen: false, record: null });

    const studentHistory = useMemo(() => {
        if (!student) return [];
        return studentFeeRecords
            .filter(rec => rec.studentId === student.id)
            .sort((a, b) => new Date(b.paymentDate).getTime() - new Date(a.paymentDate).getTime());
    }, [student, studentFeeRecords]);

    const getFeeTypeName = (id: string) => feeTypes.find(ft => ft.id === id)?.name || 'Unknown';
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    const calculateDues = (currentStudent: StudentData, allFeeRecords: StudentFeeRecordData[]): { totalDue: number, totalPaid: number, arrears: number } => {
        if (!currentStudent) return { totalDue: 0, totalPaid: 0, arrears: 0 };
        let totalDue = 0;
        const studentAdmissionDate = new Date(currentStudent.admissionDate);
        
        const applicableOneTimeFees = feeTypes.filter(ft => 
            !ft.name.includes('মাসিক') && ft.applicableClasses.includes(currentStudent.classLevel)
        );
        applicableOneTimeFees.forEach(fee => totalDue += fee.amount);

        const monthlyFee = feeTypes.find(ft => ft.name.includes('মাসিক') && ft.applicableClasses.includes(currentStudent.classLevel));
        if (monthlyFee && activeSession) {
            const sessionStartDate = new Date(activeSession.startDate);
            const sessionEndDate = new Date(activeSession.endDate);
            const today = new Date();
            
            const calculationStartDate = studentAdmissionDate > sessionStartDate ? studentAdmissionDate : sessionStartDate;
            const calculationEndDate = today < sessionEndDate ? today : sessionEndDate;

            if (calculationEndDate > calculationStartDate) {
                const months = (calculationEndDate.getFullYear() - calculationStartDate.getFullYear()) * 12 + (calculationEndDate.getMonth() - calculationStartDate.getMonth()) + 1;
                totalDue += months * monthlyFee.amount;
            }
        }

        const totalPaid = allFeeRecords
            .filter(rec => rec.studentId === currentStudent.id)
            .reduce((sum, rec) => sum + rec.amountPaid, 0);
            
        const arrears = totalDue - totalPaid;

        return { totalDue, totalPaid, arrears };
    };

    const handleSaveEdit = (updatedRecord: StudentFeeRecordData) => {
        setStudentFeeRecords(studentFeeRecords.map(r => r.id === updatedRecord.id ? updatedRecord : r));
        addToast('ফি রেকর্ড সফলভাবে আপডেট করা হয়েছে!', 'success');
        setEditModal({ isOpen: false, record: null });
    };

    const handleConfirmDelete = () => {
        if (deleteModal.record) {
            setStudentFeeRecords(studentFeeRecords.filter(r => r.id !== deleteModal.record!.id));
            addToast('ফি রেকর্ড সফলভাবে মুছে ফেলা হয়েছে!', 'success');
        }
        setDeleteModal({ isOpen: false, record: null });
    };

    const handlePrint = (printableId: string, title: string) => {
        const printContents = document.getElementById(printableId)?.innerHTML;
        if (printContents) {
            const printWindow = window.open('', '', 'height=800,width=800');
            if(printWindow){
                printWindow.document.write('<html><head>');
                printWindow.document.write(`<title>${title}</title>`);
                printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                printWindow.document.write('<style>body { font-family: "SolaimanLipi", sans-serif; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; } @page { size: A4 portrait; margin: 0.5in; } .no-print { display: none; } table { width: 100%; border-collapse: collapse; } th, td { border: 1px solid #eee; padding: 6px; font-size: 12px; } th { background-color: #f9f9f9 !important; } </style>');
                printWindow.document.write('</head><body>');
                printWindow.document.write(printContents);
                printWindow.document.write('</body></html>');
                printWindow.document.close();
                printWindow.focus();
                setTimeout(() => {
                    printWindow.print();
                    printWindow.close();
                }, 500);
            }
        }
    };
    
    if (!isOpen || !student) return null;

    if (receiptToPrint) {
        const feeType = getFeeTypeName(receiptToPrint.feeTypeId);
        const receiptMonthYear = new Date(receiptToPrint.paymentDate).toLocaleString('bn-BD', { month: 'long', year: 'numeric' });
        const currentArrears = calculateDues(student, studentFeeRecords).arrears;
        const formatCurrency = (amount: number) => `৳ ${amount.toLocaleString('bn-BD')}`;
        const formatDateTime = (dateString: string) => new Date(dateString).toLocaleString('bn-BD', {
            day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
        });

        return ReactDOM.createPortal(
            <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-50">
                <div className="bg-white rounded-lg shadow-xl w-full max-w-sm m-4 transform transition-all flex flex-col max-h-[90vh]">
                    <div id="printable-receipt" className="p-3 text-xs overflow-y-auto">
                        <div className="text-center mb-3 border-b pb-2">
                            <div className="flex items-center justify-center gap-2">
                                {logoUrl && <img src={logoUrl} alt="Logo" className="w-12 h-12 rounded-full" />}
                                <div>
                                    <h2 className="text-xl font-bold">{institutionName}</h2>
                                    <p className="text-[10px]">{`${address.village}, ${address.upazila}`}</p>
                                </div>
                            </div>
                            <div className="mt-2 inline-block bg-green-600 text-white px-3 py-0.5 rounded-full font-semibold text-sm">
                                ফি রশিদ - ({receiptMonthYear})
                            </div>
                        </div>
                        <div className="mb-3 p-2 bg-gray-100 rounded-md">
                            <h3 className="font-bold text-center mb-1 text-sm">Student Details</h3>
                            <div className="flex justify-between">
                                <table className="w-2/3 text-[10px]">
                                    <tbody>
                                        <tr><td className="pr-1 font-semibold">Name</td><td>: {student.nameEn}</td></tr>
                                        <tr><td className="pr-1 font-semibold">Class</td><td>: {student.classLevel}</td></tr>
                                        <tr><td className="pr-1 font-semibold">Section</td><td>: {student.section}</td></tr>
                                        <tr><td className="pr-1 font-semibold">Roll No</td><td>: {student.roll}</td></tr>
                                    </tbody>
                                </table>
                                <div className="w-1/3 flex flex-col items-center">
                                    <img src={student.photoUrl || 'https://via.placeholder.com/80x100?text=S'} alt="student" className="w-16 h-20 object-cover border-2 border-gray-300 rounded" />
                                    <p className="text-[9px] font-mono bg-gray-200 px-1 py-0.5 mt-1 rounded">{student.uniqueId}</p>
                                </div>
                            </div>
                        </div>
                        <div className="mb-3">
                            <h3 className="font-bold text-center mb-1 p-0.5 bg-gray-100 rounded-md text-xs">Payment Details</h3>
                            <table className="w-full text-[9px]"><thead className="bg-gray-200"><tr><th className="p-1 border">SL.</th><th className="p-1 border">Invoice No</th><th className="p-1 border">Date</th><th className="p-1 border">Method</th><th className="p-1 border">Status</th><th className="p-1 border text-right">Amount</th></tr></thead><tbody><tr><td className="p-1 border text-center">1</td><td className="p-1 border">{receiptToPrint.invoiceNumber}</td><td className="p-1 border">{new Date(receiptToPrint.paymentDate).toLocaleDateString('bn-BD')}</td><td className="p-1 border">{receiptToPrint.paymentMethod}</td><td className="p-1 border text-center font-semibold text-green-700">PAID</td><td className="p-1 border text-right">{formatCurrency(receiptToPrint.amountPaid)}</td></tr></tbody></table>
                        </div>
                        <div className="mb-3">
                            <h3 className="font-bold text-center mb-1 p-0.5 bg-gray-100 rounded-md text-xs">Fee Head List</h3>
                            <table className="w-full text-[9px]"><thead className="bg-gray-200"><tr><th className="p-1 border">SL.</th><th className="p-1 border">Fee Name</th><th className="p-1 border">Status</th><th className="p-1 border text-right">Amount</th></tr></thead><tbody><tr><td className="p-1 border text-center">1</td><td className="p-1 border">{feeType} {receiptToPrint.month && `(${receiptToPrint.month})`}</td><td className="p-1 border text-center font-semibold text-green-700">Paid</td><td className="p-1 border text-right">{formatCurrency(receiptToPrint.amountPaid)}</td></tr></tbody></table>
                        </div>
                        <div className="flex justify-end mb-3">
                            <table className="w-1/2 text-[10px]">
                                <tbody>
                                    <tr><td className="pr-2 text-right font-semibold">Payable</td><td className="text-right">{formatCurrency(receiptToPrint.amountPaid)}</td></tr>
                                    <tr><td className="pr-2 text-right font-semibold border-b">Paid</td><td className="text-right border-b">{formatCurrency(receiptToPrint.amountPaid)}</td></tr>
                                    <tr><td className="pr-2 text-right font-semibold">Due</td><td className="text-right font-bold">{formatCurrency(currentArrears)}</td></tr>
                                </tbody>
                            </table>
                        </div>
                        <div className="pt-4">
                            <div className="flex justify-between items-center text-[9px]">
                                <div className="w-1/3 text-center"><p className="border-t border-gray-400 pt-1">Account's Signature</p></div>
                                <div className="w-1/3 text-center"><p className="border-t border-gray-400 pt-1">Principal's Signature</p></div>
                            </div>
                            <p className="text-right text-[8px] text-gray-500 mt-2">Payment Date: {formatDateTime(receiptToPrint.paymentDate)}</p>
                        </div>
                    </div>
                    <div className="bg-gray-100 p-3 flex justify-end gap-3 no-print flex-shrink-0">
                        <button onClick={() => setReceiptToPrint(null)} className="px-4 py-2 bg-gray-300 rounded-lg">ফিরে যান</button>
                        <button onClick={() => handlePrint('printable-receipt', `Fee Receipt - ${student.nameEn}`)} className="px-4 py-2 bg-teal-600 text-white rounded-lg">প্রিন্ট করুন</button>
                    </div>
                </div>
            </div>,
            document.body
        );
    }

    const totalPaid = studentHistory.reduce((sum, rec) => sum + rec.amountPaid, 0);

    return ReactDOM.createPortal(
        <>
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl m-4 h-[80vh] flex flex-col">
                <div className="p-5 border-b">
                    <h3 className="text-lg font-bold text-gray-800">পেমেন্ট হিস্ট্রি</h3>
                    <p className="text-sm text-gray-500">শিক্ষার্থী: {student.nameBn}</p>
                </div>
                <div className="p-5 flex-grow overflow-y-auto">
                    {studentHistory.length > 0 ? (
                        <table className="w-full text-sm">
                            <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                                <tr>
                                    <th className="p-2">তারিখ</th>
                                    <th className="p-2">বিবরণ</th>
                                    <th className="p-2 text-right">টাকা</th>
                                    <th className="p-2">পদ্ধতি</th>
                                    <th className="p-2 text-center">পদক্ষেপ</th>
                                </tr>
                            </thead>
                            <tbody>
                                {studentHistory.map(rec => (
                                    <tr key={rec.id} className="border-b hover:bg-gray-50">
                                        <td className="p-2">{new Date(rec.paymentDate).toLocaleDateString('bn-BD')}</td>
                                        <td className="p-2">{getFeeTypeName(rec.feeTypeId)} {rec.month && `(${rec.month} ${rec.year})`}</td>
                                        <td className="p-2 text-right font-semibold">৳ {rec.amountPaid.toLocaleString('bn-BD')}</td>
                                        <td className="p-2">{rec.paymentMethod}</td>
                                        <td className="p-2 text-center space-x-1">
                                            <button onClick={() => setReceiptToPrint(rec)} className="p-1 text-teal-600 hover:bg-teal-100 rounded-full" title="রসিদ দেখুন"><ReceiptIcon className="w-4 h-4" /></button>
                                            <button onClick={() => setEditModal({ isOpen: true, record: rec })} className="p-1 text-blue-600 hover:bg-blue-100 rounded-full" title="সম্পাদনা"><PencilIcon className="w-4 h-4" /></button>
                                            <button onClick={() => setDeleteModal({ isOpen: true, record: rec })} className="p-1 text-red-600 hover:bg-red-100 rounded-full" title="মুছুন"><TrashIcon className="w-4 h-4" /></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <p className="text-center text-gray-500 py-10">এই শিক্ষার্থীর কোনো পেমেন্ট রেকর্ড নেই।</p>
                    )}
                </div>
                <div className="bg-gray-50 px-5 py-3 flex justify-between items-center border-t">
                    <button type="button" onClick={() => handlePrint('printable-history', 'পেমেন্ট হিস্ট্রি')} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700" disabled={studentHistory.length === 0}>সবগুলো প্রিন্ট করুন</button>
                    <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বন্ধ করুন</button>
                </div>
            </div>
        </div>

        {/* Hidden Printable History Report */}
        <div id="printable-history" className="hidden p-4 text-sm">
            <div className="text-center mb-4 border-b pb-2">
                <div className="flex items-center justify-center gap-4">
                    {logoUrl && <img src={logoUrl} alt="Logo" className="w-16 h-16 rounded-full" />}
                    <div>
                        <h2 className="text-2xl font-bold">{institutionName}</h2>
                        <p className="text-xs">{`${address.village}, ${address.upazila}, ${address.district}`}</p>
                    </div>
                </div>
                <div className="mt-2 inline-block bg-green-600 text-white px-4 py-1 rounded-full font-semibold">
                    পেমেন্ট হিস্ট্রি রিপোর্ট
                </div>
            </div>
            
            <div className="mb-4 p-2 bg-gray-100 rounded-md">
                <h3 className="font-bold text-center mb-2">Student Details</h3>
                <div className="flex justify-between">
                    <table className="w-2/3 text-xs">
                        <tbody>
                            <tr><td className="pr-2 font-semibold">Name</td><td>: {student.nameEn}</td></tr>
                            <tr><td className="pr-2 font-semibold">Class</td><td>: {student.classLevel}</td></tr>
                            <tr><td className="pr-2 font-semibold">Section</td><td>: {student.section}</td></tr>
                            <tr><td className="pr-2 font-semibold">Roll No</td><td>: {student.roll}</td></tr>
                        </tbody>
                    </table>
                    <div className="w-1/3 flex flex-col items-center">
                        <img src={student.photoUrl || 'https://via.placeholder.com/80x100?text=S'} alt="student" className="w-20 h-24 object-cover border-2 border-gray-300 rounded" />
                        <p className="text-xs font-mono bg-gray-200 px-2 py-0.5 mt-1 rounded">{student.uniqueId}</p>
                    </div>
                </div>
            </div>

            <h3 className="font-bold text-center mb-1 p-1 bg-gray-100 rounded-md text-sm">Payment History</h3>
            <table className="w-full text-xs">
                <thead className="bg-gray-200">
                    <tr>
                        <th className="p-1 border">তারিখ</th>
                        <th className="p-1 border">ইনভয়েস নং</th>
                        <th className="p-1 border">বিবরণ</th>
                        <th className="p-1 border">পদ্ধতি</th>
                        <th className="p-1 border text-right">টাকা</th>
                    </tr>
                </thead>
                <tbody>
                    {studentHistory.map(rec => (
                        <tr key={rec.id}>
                            <td className="p-1 border">{new Date(rec.paymentDate).toLocaleDateString('bn-BD')}</td>
                            <td className="p-1 border">{rec.invoiceNumber}</td>
                            <td className="p-1 border">{getFeeTypeName(rec.feeTypeId)} {rec.month && `(${rec.month} ${rec.year})`}</td>
                            <td className="p-1 border">{rec.paymentMethod}</td>
                            <td className="p-1 border text-right">৳ {rec.amountPaid.toLocaleString('bn-BD')}</td>
                        </tr>
                    ))}
                </tbody>
                <tfoot>
                    <tr className="font-bold bg-gray-100">
                        <td colSpan={4} className="p-2 border text-right">মোট জমা</td>
                        <td className="p-2 border text-right">৳ {totalPaid.toLocaleString('bn-BD')}</td>
                    </tr>
                </tfoot>
            </table>

            <div className="pt-8">
                <div className="flex justify-between items-center text-[10px]">
                    <div className="w-1/3 text-center"><p className="border-t border-gray-400 pt-1">Account's Signature</p></div>
                    <div className="w-1/3 text-center"><p className="border-t border-gray-400 pt-1">Principal's Signature</p></div>
                </div>
            </div>
        </div>
        
        <EditFeeRecordModal isOpen={editModal.isOpen} onClose={() => setEditModal({isOpen: false, record: null})} onSave={handleSaveEdit} recordToEdit={editModal.record} />
        <Modal isOpen={deleteModal.isOpen} onClose={() => setDeleteModal({ isOpen: false, record: null })} onConfirm={handleConfirmDelete} title="রেকর্ড মুছে ফেলুন">
            আপনি কি নিশ্চিতভাবে এই পেমেন্ট রেকর্ডটি মুছে ফেলতে চান?
        </Modal>
        </>,
        document.body
    );
};

export default FeeHistoryModal;