
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { StudentData, ProgressBehaviorData } from '../context/InstitutionContext';

interface ProgressBehaviorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<ProgressBehaviorData, 'id' | 'recordedBy'> & { id?: string }) => void;
  student: StudentData | null;
  noteToEdit: ProgressBehaviorData | null;
}

const ProgressBehaviorModal: React.FC<ProgressBehaviorModalProps> = ({ isOpen, onClose, onSave, student, noteToEdit }) => {
    const today = new Date().toISOString().split('T')[0];
    const [date, setDate] = useState(today);
    const [type, setType] = useState<'Progress' | 'Behavior'>('Progress');
    const [note, setNote] = useState('');

    useEffect(() => {
        if (isOpen) {
            if (noteToEdit) {
                setDate(noteToEdit.date);
                setType(noteToEdit.type);
                setNote(noteToEdit.note);
            } else {
                setDate(today);
                setType('Progress');
                setNote('');
            }
        }
    }, [isOpen, noteToEdit, today]);

    if (!isOpen || !student) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if(!note.trim()) return;
        onSave({
            id: noteToEdit?.id,
            studentId: student.id,
            date,
            type,
            note
        });
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold">{noteToEdit ? 'নোট সম্পাদনা করুন' : 'নতুন নোট যোগ করুন'}</h3>
                        <p className="text-sm text-gray-500">শিক্ষার্থী: {student.nameBn}</p>
                    </div>
                    <div className="p-5 space-y-4">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label htmlFor="noteDate" className="block text-sm font-medium text-gray-700">তারিখ</label>
                                <input id="noteDate" type="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md"/>
                            </div>
                            <div>
                                <label htmlFor="noteType" className="block text-sm font-medium text-gray-700">ধরন</label>
                                <select id="noteType" value={type} onChange={e => setType(e.target.value as any)} className="mt-1 w-full p-2 border rounded-md bg-white">
                                    <option value="Progress">অগ্রগতি</option>
                                    <option value="Behavior">আচরণ</option>
                                </select>
                            </div>
                        </div>
                        <div>
                            <label htmlFor="noteContent" className="block text-sm font-medium text-gray-700">নোট</label>
                            <textarea id="noteContent" value={note} onChange={e => setNote(e.target.value)} rows={4} placeholder="এখানে বিস্তারিত লিখুন..." required className="mt-1 w-full p-2 border rounded-md"></textarea>
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">সংরক্ষণ</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default ProgressBehaviorModal;
