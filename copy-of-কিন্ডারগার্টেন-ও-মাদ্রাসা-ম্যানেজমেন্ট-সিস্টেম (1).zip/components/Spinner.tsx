
import React from 'react';

const Spinner: React.FC = () => (
  <div className="spinner-container">
    <div className="loading-spinner" />
  </div>
);

export default Spinner;
