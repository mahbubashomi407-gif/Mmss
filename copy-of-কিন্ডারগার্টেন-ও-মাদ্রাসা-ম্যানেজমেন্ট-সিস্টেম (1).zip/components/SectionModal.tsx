import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { SectionData, ClassLevelData, TeacherData } from '../context/InstitutionContext';

interface SectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (section: Omit<SectionData, 'id' | 'studentCount'> & { id?: string }) => void;
  sectionToEdit?: SectionData | null;
  classLevels: ClassLevelData[];
  teachers: TeacherData[];
  preselectedClass?: string | null;
}

const SectionModal: React.FC<SectionModalProps> = ({ isOpen, onClose, onSave, sectionToEdit, classLevels, teachers, preselectedClass }) => {
  const [classLevel, setClassLevel] = useState('');
  const [name, setName] = useState('');
  const [teacherName, setTeacherName] = useState('');

  useEffect(() => {
    if (sectionToEdit) {
      setClassLevel(sectionToEdit.classLevel);
      setName(sectionToEdit.name);
      setTeacherName(sectionToEdit.teacherName);
    } else {
      // Reset form for new entry
      setClassLevel(preselectedClass || (classLevels.length > 0 ? classLevels[0].name : ''));
      setName('');
      setTeacherName('');
    }
  }, [sectionToEdit, isOpen, classLevels, preselectedClass]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !classLevel.trim()) return;
    onSave({
      id: sectionToEdit?.id,
      classLevel,
      name,
      teacherName,
    });
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{sectionToEdit ? 'সেকশন সম্পাদনা করুন' : 'নতুন সেকশন যোগ করুন'}</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label htmlFor="classLevel" className="block text-sm font-medium text-gray-700">শ্রেণি</label>
                        <select
                            id="classLevel"
                            value={classLevel}
                            onChange={e => setClassLevel(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                            required
                        >
                            <option value="" disabled>শ্রেণি নির্বাচন করুন</option>
                            {classLevels.map(level => (
                                <option key={level.id} value={level.name}>{level.name}</option>
                            ))}
                        </select>
                    </div>
                    <div>
                        <label htmlFor="sectionName" className="block text-sm font-medium text-gray-700">সেকশনের নাম</label>
                        <input
                            id="sectionName"
                            type="text"
                            value={name}
                            onChange={e => setName(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500"
                            placeholder="উদাহরণ: ক, Morning Shift"
                            required
                        />
                    </div>
                    <div>
                        <label htmlFor="teacherName" className="block text-sm font-medium text-gray-700">শ্রেণি শিক্ষকের নাম (ঐচ্ছিক)</label>
                         <select
                            id="teacherName"
                            value={teacherName}
                            onChange={e => setTeacherName(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500 focus:border-teal-500 bg-white"
                        >
                            <option value="">-- শিক্ষক নেই --</option>
                            {teachers.map(teacher => (
                                <option key={teacher.id} value={teacher.nameBn}>
                                    {teacher.nameBn} ({teacher.uniqueId})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default SectionModal;