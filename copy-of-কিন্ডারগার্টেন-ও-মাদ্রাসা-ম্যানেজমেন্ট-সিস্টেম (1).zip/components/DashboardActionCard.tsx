
import React from 'react';
import { Link } from 'react-router-dom';

interface DashboardActionCardProps {
    icon: React.ReactNode;
    title: string;
    to: string;
}

const DashboardActionCard: React.FC<DashboardActionCardProps> = ({ icon, title, to }) => {
    return (
        <Link 
            to={to}
            className="bg-white p-2 rounded-lg shadow-md flex flex-col items-center justify-center text-center cursor-pointer 
                       transition-all duration-300 ease-in-out transform hover:-translate-y-1 hover:shadow-lg hover:bg-teal-50 h-full"
        >
            <div className="w-12 h-12 flex items-center justify-center mb-2 text-teal-600">
                {icon}
            </div>
            <h3 className="font-semibold text-gray-700 text-xs sm:text-sm">{title}</h3>
        </Link>
    );
};

export default DashboardActionCard;
