
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';

interface SelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (value: string) => void;
  title: string;
  options: string[];
}

const SelectionModal: React.FC<SelectionModalProps> = ({ isOpen, onClose, onSelect, title, options }) => {
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (isOpen) {
      setSearchTerm(''); // Reset search on open
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const filteredOptions = options.filter(option =>
    option.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSelect = (option: string) => {
    onSelect(option);
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-md h-[70vh] m-4 transform transition-all flex flex-col">
        <div className="p-4 border-b flex justify-between items-center">
          <h3 className="text-lg font-bold text-gray-800">{title}</h3>
           <button onClick={onClose} className="text-gray-500 hover:text-gray-800">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
            </button>
        </div>
        <div className="p-4">
            <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="এখানে খুঁজুন..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                autoFocus
            />
        </div>
        <div className="flex-grow overflow-y-auto px-4 pb-4">
            {filteredOptions.length > 0 ? (
                <ul className="space-y-1">
                    {filteredOptions.map((option, index) => (
                    <li
                        key={index}
                        onClick={() => handleSelect(option)}
                        className="px-4 py-2 cursor-pointer hover:bg-teal-100 rounded-md text-gray-700 font-medium transition-colors"
                    >
                        {option}
                    </li>
                    ))}
                </ul>
            ) : (
                <p className="px-4 py-2 text-gray-500 text-center">কোনো ফলাফল পাওয়া যায়নি</p>
            )}
        </div>
      </div>
    </div>,
    document.body
  );
};

export default SelectionModal;
