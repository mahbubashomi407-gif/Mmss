
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { Institution } from '../context/SuperAdminContext';

interface InstitutionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<Institution, 'id' | 'status'> & { id?: string }) => void;
  institutionToEdit: Institution | null;
}

const InstitutionModal: React.FC<InstitutionModalProps> = ({ isOpen, onClose, onSave, institutionToEdit }) => {
    const [name, setName] = useState('');
    const [code, setCode] = useState('');
    const [subscriptionEndDate, setSubscriptionEndDate] = useState('');
    const isPendingApproval = institutionToEdit?.status === 'Pending';

    useEffect(() => {
        if (institutionToEdit) {
            setName(institutionToEdit.name);
            setCode(institutionToEdit.code);
            setSubscriptionEndDate(institutionToEdit.subscriptionEndDate);
        } else {
            setName('');
            setCode('');
            const nextYear = new Date();
            nextYear.setFullYear(nextYear.getFullYear() + 1);
            setSubscriptionEndDate(nextYear.toISOString().split('T')[0]);
        }
    }, [institutionToEdit, isOpen]);

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ id: institutionToEdit?.id, name, code, subscriptionEndDate, principalName: institutionToEdit?.principalName, principalMobile: institutionToEdit?.principalMobile, adminEmail: institutionToEdit?.adminEmail });
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold">{institutionToEdit ? (isPendingApproval ? 'আবেদন অনুমোদন করুন' : 'প্রতিষ্ঠান সম্পাদনা করুন') : 'নতুন প্রতিষ্ঠান যোগ করুন'}</h3>
                    </div>
                    <div className="p-5 space-y-4">
                        {isPendingApproval && institutionToEdit && (
                             <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg text-sm space-y-1">
                                <p><strong>প্রতিষ্ঠানের নাম:</strong> {institutionToEdit.name}</p>
                                <p><strong>প্রধানের নাম:</strong> {institutionToEdit.principalName}</p>
                                <p><strong>মোবাইল:</strong> {institutionToEdit.principalMobile}</p>
                                <p><strong>এডমিন ইমেইল:</strong> {institutionToEdit.adminEmail}</p>
                            </div>
                        )}
                        {!isPendingApproval && (
                            <div>
                                <label className="block text-sm font-medium">প্রতিষ্ঠানের নাম</label>
                                <input type="text" value={name} onChange={e => setName(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" />
                            </div>
                        )}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-sm font-medium">প্রতিষ্ঠানের কোড<span className="text-red-500">*</span></label>
                                <input type="text" value={code} onChange={e => setCode(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" autoFocus={isPendingApproval} />
                            </div>
                             <div>
                                <label className="block text-sm font-medium">সাবস্ক্রিপশনের মেয়াদ শেষ<span className="text-red-500">*</span></label>
                                <input type="date" value={subscriptionEndDate} onChange={e => setSubscriptionEndDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" />
                            </div>
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">{isPendingApproval ? 'অনুমোদন ও সংরক্ষণ' : 'সংরক্ষণ'}</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default InstitutionModal;
