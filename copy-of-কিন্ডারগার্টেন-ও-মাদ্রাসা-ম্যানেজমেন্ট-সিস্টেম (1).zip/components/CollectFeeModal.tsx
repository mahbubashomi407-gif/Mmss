
import React, { useState, useEffect, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, StudentData, StudentFeeRecordData, FeeTypeData, GuardianNotificationData } from '../context/InstitutionContext';
import { useNotification } from '../context/NotificationContext';

interface CollectFeeModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentData | null;
}

interface DueItem {
    id: string; 
    type: 'onetime' | 'monthly';
    name: string;
    amount: number;
    paid: number;
    due: number;
    feeTypeId: string;
    month?: string;
    year?: number;
}

const CollectFeeModal: React.FC<CollectFeeModalProps> = ({ isOpen, onClose, student }) => {
    const { 
        feeTypes, studentFeeRecords, setStudentFeeRecords, studentFeeSetups, 
        academicSessions, notificationSettings, setGuardianNotifications, institutionName,
        appNotificationTemplates
    } = useInstitution();
    const { addToast } = useNotification();
    
    const activeSession = useMemo(() => academicSessions.find(s => s.isActive), [academicSessions]);

    const [dueItems, setDueItems] = useState<DueItem[]>([]);
    const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
    const [amountToPay, setAmountToPay] = useState<number | ''>('');
    const [paymentDate, setPaymentDate] = useState(new Date().toISOString().split('T')[0]);
    const [paymentMethod, setPaymentMethod] = useState<'ক্যাশ' | 'বিকাশ' | 'নগদ' | 'অন্যান্য'>('ক্যাশ');
    const [notes, setNotes] = useState('');

    useEffect(() => {
        if (!isOpen || !student || !activeSession) {
            setDueItems([]);
            return;
        }

        const setup = studentFeeSetups.find(s => s.studentId === student.id && s.academicYear === activeSession.name);
        if (!setup) {
            onClose(); // Should not open if no setup, but as a safeguard
            return;
        }

        const items: DueItem[] = [];
        const monthlyFee = feeTypes.find(ft => ft.name.includes('মাসিক') && ft.applicableClasses.includes(student.classLevel));
        const currentYear = new Date(activeSession.startDate).getFullYear();

        // One-time fees
        setup.oneTimeFeeTypeIds.forEach(feeId => {
            const feeType = feeTypes.find(ft => ft.id === feeId);
            if (feeType) {
                const paid = studentFeeRecords
                    .filter(r => r.studentId === student.id && r.feeTypeId === feeId && !r.month)
                    .reduce((sum, r) => sum + r.amountPaid, 0);
                if (feeType.amount > paid) {
                    items.push({
                        id: `onetime-${feeId}`, type: 'onetime', name: feeType.name,
                        amount: feeType.amount, paid, due: feeType.amount - paid, feeTypeId: feeId, year: currentYear
                    });
                }
            }
        });

        // Monthly fees
        if (monthlyFee) {
            setup.monthlyFeeMonths.forEach(month => {
                const paid = studentFeeRecords
                    .filter(r => r.studentId === student.id && r.feeTypeId === monthlyFee.id && r.month === month && r.year === currentYear)
                    .reduce((sum, r) => sum + r.amountPaid, 0);
                if (monthlyFee.amount > paid) {
                    items.push({
                        id: `monthly-${monthlyFee.id}-${month}-${currentYear}`, type: 'monthly',
                        name: `${monthlyFee.name} (${month})`, amount: monthlyFee.amount,
                        paid, due: monthlyFee.amount - paid, feeTypeId: monthlyFee.id, month, year: currentYear
                    });
                }
            });
        }
        
        setDueItems(items);
        // Reset form state
        setSelectedItems(new Set());
        setAmountToPay('');
        setPaymentDate(new Date().toISOString().split('T')[0]);
        setPaymentMethod('ক্যাশ');
        setNotes('');

    }, [isOpen, student, studentFeeSetups, studentFeeRecords, feeTypes, activeSession, onClose]);

    useEffect(() => {
        const totalDueOfSelected = dueItems
            .filter(item => selectedItems.has(item.id))
            .reduce((sum, item) => sum + item.due, 0);
        setAmountToPay(totalDueOfSelected > 0 ? totalDueOfSelected : '');
    }, [selectedItems, dueItems]);

    const handleItemSelection = (itemId: string) => {
        const newSet = new Set(selectedItems);
        if (newSet.has(itemId)) newSet.delete(itemId);
        else newSet.add(itemId);
        setSelectedItems(newSet);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!student || amountToPay === '' || amountToPay <= 0) {
            addToast('টাকার পরিমাণ সঠিক নয়।', 'error');
            return;
        }

        let remainingAmount = amountToPay;
        const newRecords: StudentFeeRecordData[] = [];
        const invoiceNumber = `INV-${Date.now()}`;
        
        const itemsToPayFor = [
            ...dueItems.filter(item => selectedItems.has(item.id)),
            ...dueItems.filter(item => !selectedItems.has(item.id)),
        ];

        for (const item of itemsToPayFor) {
            if (remainingAmount <= 0) break;
            
            const amountForThisItem = Math.min(remainingAmount, item.due);
            
            newRecords.push({
                id: `${item.id}-${Date.now()}`,
                studentId: student!.id,
                feeTypeId: item.feeTypeId,
                amountPaid: amountForThisItem,
                paymentDate,
                month: item.month,
                year: item.year!,
                invoiceNumber,
                paymentMethod,
                notes
            });

            remainingAmount -= amountForThisItem;
        }
        
        if (newRecords.length === 0) {
            addToast('কোনো বকেয়া আইটেম পরিশোধ করা হয়নি।', 'error');
            return;
        }

        setStudentFeeRecords([...studentFeeRecords, ...newRecords]);
        addToast(`${newRecords.length}টি ফি লেনদেন সফলভাবে রেকর্ড করা হয়েছে!`, 'success');
        
        // --- Trigger App Notification ---
        const { feePayment } = notificationSettings.automaticNotifications;
        
        if (feePayment.app) {
             let message = appNotificationTemplates.feePayment;
            message = message.replace('{{student_name}}', student.nameBn)
                           .replace('{{amount}}', `৳${(amountToPay as number).toLocaleString('bn-BD')}`);

            const notification: GuardianNotificationData = {
                id: `noti-fee-${Date.now()}`,
                studentId: student.id,
                timestamp: new Date().toISOString(),
                title: 'ফি প্রদান',
                message: message,
                isRead: false
            };
            setGuardianNotifications(prev => [notification, ...prev]);
        }

        onClose();
    };

    if (!isOpen || !student) return null;

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold text-gray-800">ফি আদায় করুন</h3>
                        <p className="text-sm text-gray-500">শিক্ষার্থী: {student.nameBn}</p>
                    </div>
                    <div className="p-5 space-y-4 max-h-[70vh] overflow-y-auto">
                        <div>
                            <h4 className="font-semibold mb-2">বকেয়া ফি তালিকা</h4>
                            {dueItems.length > 0 ? (
                                <div className="space-y-2">
                                {dueItems.map(item => (
                                    <label key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 border has-[:checked]:border-teal-500 has-[:checked]:bg-teal-50">
                                        <div className="flex items-center">
                                            <input type="checkbox" checked={selectedItems.has(item.id)} onChange={() => handleItemSelection(item.id)} className="h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"/>
                                            <div className="ml-3">
                                                <span className="font-medium text-gray-800">{item.name}</span>
                                                <span className="text-xs text-gray-500 ml-2">(মোট: ৳{item.amount.toLocaleString('bn-BD')})</span>
                                            </div>
                                        </div>
                                        <span className="text-sm font-semibold text-red-600">বকেয়া: ৳{item.due.toLocaleString('bn-BD')}</span>
                                    </label>
                                ))}
                                </div>
                            ) : (
                                <p className="text-center text-gray-500 py-4">এই শিক্ষার্থীর কোনো বকেয়া নেই।</p>
                            )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">টাকার পরিমাণ<span className="text-red-500">*</span></label>
                                <input type="number" value={amountToPay} onChange={e => setAmountToPay(e.target.value === '' ? '' : Number(e.target.value))} required className="mt-1 w-full p-2 border rounded-md" placeholder="টাকার পরিমাণ দিন" />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">পেমেন্টের তারিখ</label>
                                <input type="date" value={paymentDate} onChange={e => setPaymentDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" />
                            </div>
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-gray-700">পেমেন্ট পদ্ধতি</label>
                            <select value={paymentMethod} onChange={e => setPaymentMethod(e.target.value as any)} className="mt-1 w-full p-2 border rounded-md bg-white">
                                <option>ক্যাশ</option><option>বিকাশ</option><option>নগদ</option><option>অন্যান্য</option>
                            </select>
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">নোট (ঐচ্ছিক)</label>
                            <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className="mt-1 w-full p-2 border rounded-md"></textarea>
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3 border-t">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300">বাতিল করুন</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700" disabled={amountToPay === '' || amountToPay <= 0}>আদায় করুন</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default CollectFeeModal;
