
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { LogoutIcon, DashboardIcon, BuildingOfficeIcon, CogIcon, LinkIcon } from '../icons';
import BottomNav from '../BottomNav';
import NotificationBell from '../NotificationBell';


const SuperAdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, logout } = useAuth();
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const navLinks = [
        { to: '/superadmin/dashboard', icon: <DashboardIcon className="w-6 h-6" />, text: 'ড্যাশবোর্ড' },
        { to: '/superadmin/institutions', icon: <BuildingOfficeIcon className="w-6 h-6" />, text: 'প্রতিষ্ঠান পরিচালনা' },
        { to: '/superadmin/system-settings', icon: <CogIcon className="w-6 h-6" />, text: 'সিস্টেম সেটিংস' }
    ];

    const NavItem: React.FC<{ to: string, icon: React.ReactElement, text: string, onClick?: () => void }> = ({ to, icon, text, onClick }) => (
        <NavLink
            to={to}
            onClick={onClick}
            className={({ isActive }) =>
                `flex items-center p-2 my-1 rounded-lg transition-all duration-200 ${
                isActive
                    ? 'bg-purple-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-purple-100 hover:text-purple-800'
                }`
            }
        >
            {icon}
            <span className="ml-3 font-semibold text-sm">{text}</span>
        </NavLink>
    );

    const bottomNavItems = [
        { to: '/superadmin/dashboard', icon: <DashboardIcon className="w-6 h-6" />, label: 'ড্যাশবোর্ড' },
        { to: '/superadmin/institutions', icon: <BuildingOfficeIcon className="w-6 h-6" />, label: 'প্রতিষ্ঠান' },
        { to: '/superadmin/links-management', icon: <LinkIcon className="w-7 h-7" />, label: 'লিংক' },
        { to: '/superadmin/system-settings', icon: <CogIcon className="w-6 h-6" />, label: 'সেটিংস' },
        { onClick: logout, icon: <LogoutIcon className="w-6 h-6" />, label: 'লগআউট' },
    ];

    return (
        <div className="flex h-screen bg-gray-100">
            {sidebarOpen && <div className="fixed inset-0 z-20 bg-black bg-opacity-50 md:hidden" onClick={() => setSidebarOpen(false)}></div>}

            <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 md:relative md:translate-x-0 flex flex-col`}>
                <div className="p-4 bg-purple-800 text-white">
                     <h1 className="text-xl font-bold">সুপার অ্যাডমিন</h1>
                     <h2 className="text-sm font-semibold text-purple-200">ম্যানেজমেন্ট সিস্টেম</h2>
                </div>
                <nav className="p-2 flex-grow overflow-y-auto">
                    {navLinks.map(link => <NavItem key={link.to} {...link} onClick={() => setSidebarOpen(false)} />)}
                </nav>
                <div className="p-2 border-t">
                    <button onClick={logout} className="flex items-center w-full p-2 my-1 text-red-500 rounded-lg hover:bg-red-100">
                        <LogoutIcon className="w-6 h-6" />
                        <span className="ml-3 font-semibold">লগ আউট</span>
                    </button>
                </div>
            </aside>

            <div className="flex-1 flex flex-col overflow-hidden">
                <header className="flex items-center justify-between p-3 bg-white border-b">
                    <div className="flex items-center gap-2">
                        <button onClick={() => setSidebarOpen(true)} className="text-gray-500 focus:outline-none md:hidden">
                           <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none"><path d="M4 6H20M4 12H20M4 18H11Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                       </button>
                       <h1 className="text-lg font-bold text-gray-800 md:hidden">সুপার অ্যাডমিন</h1>
                    </div>
                    <div className="flex items-center gap-2">
                        <NotificationBell />
                        <span className="font-semibold text-gray-700 hidden md:block">স্বাগতম, {user?.displayName}</span>
                        <button
                            onClick={logout}
                            className="p-2 text-red-500 rounded-full hover:bg-red-100 md:hidden"
                            aria-label="লগ আউট"
                        >
                            <LogoutIcon className="w-6 h-6" />
                        </button>
                    </div>
                </header>
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-4 pb-20">
                    {children}
                </main>
                 <BottomNav items={bottomNavItems} />
            </div>
        </div>
    );
};

export default SuperAdminLayout;
