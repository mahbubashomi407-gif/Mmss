
import React, { useState, useMemo } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';
import { DASHBOARD_ITEMS } from '../../constants/dashboardMap';
import { LogoutIcon } from '../icons';

const StudentLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, logout } = useAuth();
    const { logoUrl, institutionName, studentRoles } = useInstitution();
    const [sidebarOpen, setSidebarOpen] = useState(false);

    const permissions = useMemo(() => {
        if (!user?.roleId) return [];
        const role = studentRoles.find(r => r.id === user.roleId);
        return role?.permissions || [];
    }, [user, studentRoles]);
    
    const navLinks = DASHBOARD_ITEMS.filter(item => item.roles.includes('student') && permissions.includes(item.permission));

    const NavItem: React.FC<{ to: string, icon: React.ReactElement, text: string, onClick?: () => void }> = ({ to, icon, text, onClick }) => (
        <NavLink
            to={to}
            onClick={onClick}
            className={({ isActive }) =>
                `flex items-center p-2 my-1 rounded-lg transition-all duration-200 ${
                isActive
                    ? 'bg-green-600 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-green-100 hover:text-green-800'
                }`
            }
        >
            {React.cloneElement(icon, { className: "w-6 h-6" })}
            <span className="ml-3 font-semibold text-sm">{text}</span>
        </NavLink>
    );

    return (
        <div className="flex h-screen bg-gray-100">
            {sidebarOpen && <div className="fixed inset-0 z-20 bg-black bg-opacity-50 md:hidden" onClick={() => setSidebarOpen(false)}></div>}

            <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 md:relative md:translate-x-0 flex flex-col`}>
                <div className="p-4 bg-green-700">
                     <div className="flex items-center gap-3">
                        {logoUrl && <img src={logoUrl} alt="Logo" className="w-12 h-12 rounded-full border-2 border-green-300 object-cover" />}
                        <div className="flex-1 min-w-0">
                            <h1 className="text-lg font-bold text-white truncate leading-tight">{institutionName}</h1>
                            <h2 className="text-sm font-semibold text-green-200">শিক্ষার্থী পোর্টাল</h2>
                        </div>
                    </div>
                </div>
                <nav className="p-2 flex-grow overflow-y-auto">
                    {navLinks.map(link => <NavItem key={link.link} to={link.link} icon={link.icon} text={link.title} onClick={() => setSidebarOpen(false)} />)}
                </nav>
                <div className="p-2 border-t">
                    <button onClick={logout} className="flex items-center w-full p-2 my-1 text-red-500 rounded-lg hover:bg-red-100">
                        <LogoutIcon className="w-6 h-6" />
                        <span className="ml-3 font-semibold">লগ আউট</span>
                    </button>
                </div>
            </aside>

            <div className="flex-1 flex flex-col overflow-hidden">
                <header className="flex items-center justify-between p-3 bg-white border-b">
                     <button onClick={() => setSidebarOpen(true)} className="text-gray-500 focus:outline-none md:hidden">
                        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none"><path d="M4 6H20M4 12H20M4 18H11Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                    </button>
                    <span className="font-semibold text-gray-700 ml-auto">স্বাগতম, {user?.displayName}</span>
                </header>
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-4">
                    {children}
                </main>
            </div>
        </div>
    );
};

export default StudentLayout;
