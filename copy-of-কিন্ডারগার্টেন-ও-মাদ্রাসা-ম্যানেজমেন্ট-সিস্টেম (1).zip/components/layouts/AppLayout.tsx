
import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useInstitution } from '../../context/InstitutionContext';
import { NAVIGATION_MAP } from '../../constants/navigationMap';
import { LogoutIcon, ArrowLeftOnRectangleIcon, DashboardIcon, StudentsIcon, ClipboardListIcon, CurrencyBangladeshiIcon, LinkIcon } from '../icons';
import BottomNav from '../BottomNav';
import NotificationBell from '../NotificationBell';


const AppLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user, logout, hasPermission, originalUser, stopImpersonation } = useAuth();
    const { logoUrl, institutionName } = useInstitution();
    const [sidebarOpen, setSidebarOpen] = useState(false);
    const navigate = useNavigate();
    const [showDemoWarning, setShowDemoWarning] = useState(false);

    useEffect(() => {
        if (user?.institutionCode === '501' && (user?.role === 'admin' || originalUser?.role === 'super_admin') && !sessionStorage.getItem('demoWarningShown')) {
            const timer = setTimeout(() => {
                setShowDemoWarning(true);
                sessionStorage.setItem('demoWarningShown', 'true');
            }, 1500); // 1.5 seconds delay
            return () => clearTimeout(timer);
        }
    }, [user, originalUser]);


    const navLinks = NAVIGATION_MAP.filter(link => hasPermission(link.permission));
    
    const panelTitle = {
        admin: 'অ্যাডমিন প্যানেল',
        teacher: 'শিক্ষক প্যানেল',
        accountant: 'হিসাবরক্ষক প্যানেল',
    }[user!.role] || 'ড্যাশবোর্ড';

    const headerColor = {
        admin: 'bg-teal-700',
        teacher: 'bg-indigo-700',
        accountant: 'bg-blue-700',
    }[user!.role] || 'bg-gray-700';

    const NavItem: React.FC<{ to: string, icon: React.ReactElement, text: string, onClick?: () => void }> = ({ to, icon, text, onClick }) => (
        <NavLink
            to={to}
            onClick={onClick}
            className={({ isActive }) =>
                `flex items-center p-2 my-1 rounded-lg transition-all duration-200 ${
                isActive
                    ? 'bg-teal-600 text-white shadow-lg ring-2 ring-teal-300'
                    : 'text-gray-600 hover:bg-teal-100 hover:text-teal-800'
                }`
            }
        >
            {icon}
            <span className="ml-3 font-semibold text-sm">{text}</span>
        </NavLink>
    );
    
    const handleReturnToSuperAdmin = () => {
        stopImpersonation();
        navigate('/superadmin/dashboard');
    };
    
    const bottomNavItems = [
        { to: '/app/dashboard', icon: <DashboardIcon className="w-6 h-6" />, label: 'ড্যাশবোর্ড' },
        { to: '/app/students', icon: <StudentsIcon className="w-6 h-6" />, label: 'শিক্ষার্থী' },
        { to: '/app/links', icon: <LinkIcon className="w-7 h-7" />, label: 'লিংক' },
        { to: '/app/exams', icon: <ClipboardListIcon className="w-6 h-6" />, label: 'পরীক্ষা' },
        { to: '/app/fees', icon: <CurrencyBangladeshiIcon className="w-6 h-6" />, label: 'ফি' },
    ];


    return (
        <div className="flex h-screen bg-gray-100">
            {sidebarOpen && (
                <div 
                    className="fixed inset-0 z-20 bg-black bg-opacity-50 transition-opacity md:hidden"
                    onClick={() => setSidebarOpen(false)}
                ></div>
            )}
            <aside className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out md:relative md:translate-x-0 flex flex-col`}>
                <div className={`p-4 ${headerColor}`}>
                    <div className="flex items-center gap-3">
                        {logoUrl && <img src={logoUrl} alt="Institution Logo" className="w-12 h-12 rounded-full border-2 border-teal-300 object-cover" />}
                        <div className="flex-1 min-w-0">
                            <h1 className="text-lg font-bold text-white truncate leading-tight">{institutionName}</h1>
                            <h2 className="text-sm font-semibold text-teal-200">{panelTitle}</h2>
                        </div>
                        <button onClick={() => setSidebarOpen(false)} className="text-white md:hidden p-1 -mr-2">
                             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                </div>
                <nav className="p-2 flex-grow overflow-y-auto">
                    {navLinks.map(link => <NavItem key={link.to} {...link} onClick={() => setSidebarOpen(false)} />)}
                </nav>
                <div className="p-2 border-t">
                    <button
                        onClick={logout}
                        className="flex items-center w-full p-2 my-1 text-red-500 rounded-lg hover:bg-red-100"
                    >
                        <LogoutIcon className="w-6 h-6" />
                        <span className="ml-3 font-semibold">লগ আউট</span>
                    </button>
                </div>
            </aside>
            <div className="flex-1 flex flex-col overflow-hidden">
                 {originalUser && (
                    <div className="bg-purple-800 text-white p-2 text-center text-sm font-semibold flex items-center justify-center gap-4 z-10">
                        <span>আপনি "{institutionName}" প্রতিষ্ঠানের অ্যাডমিন হিসেবে দেখছেন।</span>
                        <button onClick={handleReturnToSuperAdmin} className="flex items-center gap-1 bg-purple-600 hover:bg-purple-500 px-3 py-1 rounded-md text-xs">
                            <ArrowLeftOnRectangleIcon className="w-4 h-4" />
                            সুপার অ্যাডমিনে ফিরে যান
                        </button>
                    </div>
                )}
                <header className="flex items-center justify-between p-3 bg-white border-b">
                     <div className="flex items-center gap-2">
                        <button onClick={() => setSidebarOpen(true)} className="text-gray-500 focus:outline-none md:hidden">
                            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M4 6H20M4 12H20M4 18H11Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                            </svg>
                        </button>
                         <h1 className="text-lg font-bold text-gray-800 md:hidden">{institutionName}</h1>
                    </div>
                    <div className="flex items-center gap-2">
                        <NotificationBell />
                        <span className="font-semibold text-gray-700 hidden md:block">স্বাগতম, {user?.displayName}</span>
                         <button
                            onClick={logout}
                            className="p-2 text-red-500 rounded-full hover:bg-red-100 md:hidden"
                            aria-label="লগ আউট"
                        >
                            <LogoutIcon className="w-6 h-6" />
                        </button>
                    </div>
                </header>
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-4 pb-20">
                    {children}
                </main>
                <BottomNav items={bottomNavItems} />
            </div>

            {/* Demo Account Warning Modal */}
            <div 
                className={`fixed bottom-0 inset-x-0 z-50 p-4 transition-transform duration-500 ease-in-out ${showDemoWarning ? 'translate-y-0' : 'translate-y-full'}`}
            >
                <div className="max-w-2xl mx-auto bg-yellow-100 border-l-4 border-yellow-500 text-yellow-800 p-4 rounded-r-lg shadow-lg flex items-center justify-between">
                    <div>
                        <p className="font-bold">সতর্কতা: এটি একটি ডেমো অ্যাকাউন্ট</p>
                        <p className="text-sm">তিন দিন পর আপনার সকল পরিবর্তন মুছে যাবে। এর জন্য কর্তৃপক্ষ দায়ী থাকবে না।</p>
                    </div>
                    <button onClick={() => setShowDemoWarning(false)} className="font-bold text-xl p-1">&times;</button>
                </div>
            </div>

        </div>
    );
};

export default AppLayout;
