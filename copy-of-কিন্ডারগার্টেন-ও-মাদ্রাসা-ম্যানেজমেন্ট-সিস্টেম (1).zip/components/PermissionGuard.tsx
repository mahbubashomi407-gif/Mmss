
import React from 'react';
import { useAuth } from '../context/AuthContext';

const PermissionDenied: React.FC = () => (
    <div className="text-center p-10 bg-white rounded-lg shadow-md">
        <h2 className="text-2xl font-bold text-red-600">অনুমতি নেই</h2>
        <p className="text-gray-600 mt-2">এই পৃষ্ঠাটি দেখার জন্য আপনার প্রয়োজনীয় অনুমতি নেই।</p>
        <p className="text-sm text-gray-400 mt-1">অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।</p>
    </div>
);

export const PermissionGuard: React.FC<{ children: React.ReactElement; permission: string }> = ({ children, permission }) => {
  const { hasPermission } = useAuth();

  if (hasPermission(permission)) {
    return children;
  }

  return <PermissionDenied />;
};
