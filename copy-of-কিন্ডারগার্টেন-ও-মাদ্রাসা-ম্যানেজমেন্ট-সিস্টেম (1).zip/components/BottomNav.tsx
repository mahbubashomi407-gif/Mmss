
import React from 'react';
import { NavLink } from 'react-router-dom';

export interface BottomNavItemProps {
    to?: string;
    icon: React.ReactNode;
    label: string;
    onClick?: () => void;
}

const BottomNav: React.FC<{ items: BottomNavItemProps[] }> = ({ items }) => {

    const renderItem = (item: BottomNavItemProps, index: number) => {
        const baseClasses = "flex flex-col items-center justify-center text-xs w-full h-full transition-colors";
        
        if (item.to) {
             return (
                <NavLink
                    key={item.label + index}
                    to={item.to}
                    className={({ isActive }) => `${baseClasses} ${isActive ? 'text-teal-600 font-bold' : 'text-gray-500'}`}
                >
                    {item.icon}
                    <span className="mt-1">{item.label}</span>
                </NavLink>
            );
        }
        return (
             <button
                key={item.label + index}
                onClick={item.onClick}
                className={`${baseClasses} text-gray-500`}
            >
                {item.icon}
                <span className="mt-1">{item.label}</span>
            </button>
        );
    };

    return (
        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-white border-t border-gray-200 md:hidden flex justify-around items-center z-40 shadow-[0_-2px_5px_rgba(0,0,0,0.05)]">
            {items.map((item, index) => renderItem(item, index))}
        </nav>
    );
};

export default BottomNav;
