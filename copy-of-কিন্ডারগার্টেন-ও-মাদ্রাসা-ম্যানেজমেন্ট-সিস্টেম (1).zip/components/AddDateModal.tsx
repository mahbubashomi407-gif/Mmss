import React, { useState } from 'react';
import ReactDOM from 'react-dom';

interface AddDateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (date: string) => void;
}

const AddDateModal: React.FC<AddDateModalProps> = ({ isOpen, onClose, onSave }) => {
    const [date, setDate] = useState('');
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!date) {
            setError('অনুগ্রহ করে একটি তারিখ নির্বাচন করুন।');
            return;
        }
        setError('');
        onSave(date);
        onClose();
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-sm m-4">
                <form onSubmit={handleSubmit}>
                    <div className="p-5">
                        <h3 className="text-lg font-bold text-gray-800">রুটিনে নতুন তারিখ যোগ করুন</h3>
                        <div className="mt-4">
                            <label htmlFor="examDate" className="block text-sm font-medium text-gray-700">তারিখ নির্বাচন করুন</label>
                            <input id="examDate" type="date" value={date} onChange={e => setDate(e.target.value)} required className="mt-1 w-full p-2 border rounded-md" />
                            {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg">বাতিল</button>
                        <button type="submit" className="px-4 py-2 bg-teal-600 text-white rounded-lg">যোগ করুন</button>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default AddDateModal;