
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeftIcon } from './icons';

interface PageHeaderProps {
  title: string;
  icon: string;
  children?: React.ReactNode;
}

const PageHeader: React.FC<PageHeaderProps> = ({ title, icon, children }) => {
  const navigate = useNavigate();

  return (
    <div className="flex items-center justify-between mb-6">
      <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
        <span className="text-3xl">{icon}</span>
        {title}
      </h1>
      <div className="flex items-center gap-3">
        {children}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 px-4 py-2 bg-white text-gray-700 font-semibold rounded-lg shadow-md hover:bg-gray-100 transition-colors border border-gray-200"
          title="আগের পেজে যান"
        >
          <ArrowLeftIcon className="w-5 h-5" />
          <span>ফিরে যান</span>
        </button>
      </div>
    </div>
  );
};

export default PageHeader;
