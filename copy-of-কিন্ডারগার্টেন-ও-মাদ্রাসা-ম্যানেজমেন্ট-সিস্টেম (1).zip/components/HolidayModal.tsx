
import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom';
import { HolidayData } from '../context/InstitutionContext';

interface HolidayModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (holiday: Omit<HolidayData, 'id'> & { id?: string }) => void;
  holidayToEdit?: HolidayData | null;
}

const HolidayModal: React.FC<HolidayModalProps> = ({ isOpen, onClose, onSave, holidayToEdit }) => {
  const [title, setTitle] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [type, setType] = useState<'Public' | 'Institutional'>('Public');

  useEffect(() => {
    if (holidayToEdit) {
      setTitle(holidayToEdit.title);
      setStartDate(holidayToEdit.startDate);
      setEndDate(holidayToEdit.endDate);
      setType(holidayToEdit.type);
    } else {
      // Reset form for new entry, default to today
      setTitle('');
      const today = new Date().toISOString().split('T')[0];
      setStartDate(today);
      setEndDate(today);
      setType('Public');
    }
  }, [holidayToEdit, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !startDate || !endDate) return;
    onSave({
      id: holidayToEdit?.id,
      title,
      startDate,
      endDate,
      type
    });
  };
  
  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newStartDate = e.target.value;
    setStartDate(newStartDate);
    // If endDate is before the new start date, update it to be the same as the start date
    if (endDate && new Date(endDate) < new Date(newStartDate)) {
        setEndDate(newStartDate);
    }
  };

  return ReactDOM.createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
        <form onSubmit={handleSubmit}>
            <div className="p-5">
                <h3 className="text-lg font-bold text-gray-800">{holidayToEdit ? 'ছুটি সম্পাদনা করুন' : 'নতুন ছুটি যোগ করুন'}</h3>
                <div className="mt-4 space-y-4">
                    <div>
                        <label htmlFor="holidayTitle" className="block text-sm font-medium text-gray-700">ছুটির নাম</label>
                        <input
                            id="holidayTitle" type="text" value={title} onChange={e => setTitle(e.target.value)}
                            className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                            placeholder="উদাহরণ: ঈদুল ফিতর" required
                        />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label htmlFor="startDate" className="block text-sm font-medium text-gray-700">শুরুর তারিখ</label>
                            <input
                                id="startDate" type="date" value={startDate} onChange={handleStartDateChange}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">শেষের তারিখ</label>
                            <input
                                id="endDate" type="date" value={endDate} onChange={e => setEndDate(e.target.value)}
                                min={startDate}
                                className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500"
                                required
                            />
                        </div>
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">ছুটির ধরন</label>
                        <div className="mt-2 flex gap-4">
                           <label className="flex items-center">
                                <input type="radio" value="Public" checked={type === 'Public'} onChange={() => setType('Public')} className="h-4 w-4 text-teal-600 border-gray-300 focus:ring-teal-500" />
                                <span className="ml-2 text-sm text-gray-700">সরকারি ছুটি</span>
                            </label>
                             <label className="flex items-center">
                                <input type="radio" value="Institutional" checked={type === 'Institutional'} onChange={() => setType('Institutional')} className="h-4 w-4 text-teal-600 border-gray-300 focus:ring-teal-500" />
                                <span className="ml-2 text-sm text-gray-700">প্রাতিষ্ঠানিক ছুটি</span>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div className="bg-gray-50 px-5 py-3 flex justify-end gap-3">
            <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors"
            >
                বাতিল করুন
            </button>
            <button
                type="submit"
                className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors"
            >
                সংরক্ষণ করুন
            </button>
            </div>
        </form>
      </div>
    </div>,
    document.body
  );
};

export default HolidayModal;
