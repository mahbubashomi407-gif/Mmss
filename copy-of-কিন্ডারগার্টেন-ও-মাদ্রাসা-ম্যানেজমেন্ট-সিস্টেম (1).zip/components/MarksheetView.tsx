
import React, { useMemo } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, StudentData, ExamData, calculateGradeInfo, GradeData, SubjectData } from '../context/InstitutionContext';

declare global {
    interface Window {
        html2pdf: any;
    }
}

const toBengaliNumber = (numStr: string | number | undefined | null): string => {
    if (numStr === null || numStr === undefined || numStr === '') return '--';
    const num = String(numStr);
    const map: { [key: string]: string } = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯',
        '.': '.', '%': '%'
    };
    return num.replace(/[0-9.%]/g, (match) => map[match] || match);
};

export interface ReportData {
    student: StudentData & { 
        totalObtained: number; 
        grade: string; 
        gpa: number; 
        resultStatus: 'Passed' | 'Failed' | 'কৃতকার্য' | 'অকৃতকার্য' | 'স্থগিত' | 'অনুপস্থিত'; 
        rank: number | '-';
        marksBySubject: Record<string, { obtained: number | null; total: number }>;
    };
    exam: ExamData;
    subjectRows: { 
        name: string; 
        fullMarks: number; 
        highestMark: number; 
        totalMarks: number | null; 
        letterGrade: string; 
        gradePoint: string 
    }[];
    failedSubjectsCount: number;
    totalFullMarks: number;
}

export const ReportCardContent: React.FC<{ reportData: ReportData; isMadrasaMode: boolean; }> = ({ reportData, isMadrasaMode }) => {
    const { institutionName, logoUrl, managerInfo, grades, madrasaGrades, address } = useInstitution();
    const { student, exam, subjectRows, failedSubjectsCount, totalFullMarks } = reportData;
    
    const currentGrades = isMadrasaMode ? madrasaGrades : grades;

    const getStatusText = (status: ReportData['student']['resultStatus']) => {
        switch(status) {
            case 'Passed': return 'কৃতকার্য';
            case 'Failed': return 'অকৃতকার্য';
            default: return status;
        }
    };
    
    if (isMadrasaMode) {
        const MADRASA_TOTAL_ROWS = 12;
        const madrasaDisplayRows = [...subjectRows];
        while (madrasaDisplayRows.length < MADRASA_TOTAL_ROWS) {
            madrasaDisplayRows.push(null);
        }

        const gradeStatus = student.resultStatus === 'কৃতকার্য' ? student.grade : getStatusText(student.resultStatus);
        
        // Get top 4 grades for the merit division box
        const topGrades = [...currentGrades].sort((a,b) => b.minPercentage - a.minPercentage).slice(0, 4);

        return (
            <div className="marksheet-container bg-white p-2 font-['SolaimanLipi'] text-[11px] border border-black flex flex-col h-full w-full relative" style={{ boxSizing: 'border-box' }}>
                {/* Watermark Logo */}
                {logoUrl && <img src={logoUrl} alt="watermark" className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 opacity-10" />}

                {/* Header */}
                <header className="relative z-10 flex items-start justify-between p-1" style={{ fontFamily: "'SolaimanLipi', sans-serif" }}>
                    {/* Logo Left */}
                    <div style={{ flexShrink: 0, width: '45px' }}>
                        {logoUrl && <img src={logoUrl} alt="Logo" style={{ height: '45px', width: '45px', objectFit: 'cover' }} />}
                    </div>

                    {/* Main Header Content - Centered */}
                    <div style={{ flexGrow: 1, textAlign: 'center', fontFamily: "'SolaimanLipi', sans-serif" }}>
                        <h1 style={{ fontSize: '13px', fontWeight: 'bold', margin: '0' }}>{institutionName}</h1>
                        <p style={{ fontSize: '9px', margin: '0 0 2px', color: '#4a5568' }}>{`${address.upazila}, ${address.district}`}</p>
                        <p style={{ fontSize: '10px', fontWeight: 'bold', marginBottom: '2px' }}>শিক্ষাবর্ষ: {toBengaliNumber(exam.academicYear)}</p>
                        <h2 style={{ fontSize: '15px', fontWeight: 'bold', display: 'inline-block', border: '1px solid #000', padding: '2px 10px', margin: '0' }}>ব্যক্তিগত মার্কশিট - {exam.name}</h2>
                    </div>

                    {/* Merit Division Right */}
                    <div style={{ flexShrink: 0, width: '130px', border: '1px solid #000', fontSize: '9px', fontFamily: "'SolaimanLipi', sans-serif" }}>
                        <h3 style={{ fontWeight: 'bold', textAlign: 'center', backgroundColor: '#f2f2f2 !important', borderBottom: '1px solid #000', padding: '2px' }}>মেধা বিভাগ</h3>
                        <ul style={{ listStyle: 'none', padding: '4px', margin: '0' }}>
                            {topGrades.map(g => (
                                <li key={g.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '1px 0' }}>
                                    <span>{g.name}</span>
                                    <span>{toBengaliNumber(g.minPercentage)}-{toBengaliNumber(g.maxPercentage)}%</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                </header>

                <section className="mt-1 grid grid-cols-2 gap-x-4 gap-y-0.5 text-sm z-10" style={{ fontFamily: "'SolaimanLipi', sans-serif" }}>
                    <p><strong>শিক্ষার্থীর নাম:</strong> {student.nameBn}</p>
                    <p><strong>রেজি:</strong> {toBengaliNumber(student.uniqueId)}</p>
                    <p><strong>পিতার নাম:</strong> {student.fatherNameBn}</p>
                    <p><strong>রোল:</strong> {toBengaliNumber(student.roll || '')}</p>
                    <p><strong>জামাত:</strong> {student.classLevel}</p>
                </section>

                <section className="mt-0.5 flex-grow z-10" style={{ fontFamily: "'SolaimanLipi', sans-serif" }}>
                    <table className="w-full border-collapse border border-black text-xs">
                        <thead>
                            <tr className="bg-gray-100 font-bold">
                                <td className="border border-black py-2 px-1 text-center w-12">ক্রমিক</td> {/* Changed py-1.5 to py-2 */}
                                <td className="border border-black py-2 px-1">বিষয়</td> {/* Changed py-1.5 to py-2 */}
                                <td className="border border-black py-2 px-1 text-center w-24">প্রাপ্ত নাম্বার</td> {/* Changed py-1.5 to py-2 */}
                                <td className="border border-black py-2 px-1 text-center w-24">সর্বোচ্চ নাম্বার</td> {/* Changed py-1.5 to py-2 */}
                            </tr>
                        </thead>
                        <tbody>
                            {madrasaDisplayRows.map((row: any, index: number) => (
                                <tr key={row ? row.name + index : `empty-${index}`}>
                                    {row ? (
                                        <>
                                            <td className="border border-black py-2 px-1 text-center">{toBengaliNumber(index + 1)}</td> {/* Changed py-1.5 to py-2 */}
                                            <td className="border border-black py-2 px-1">{row.name}</td> {/* Changed py-1.5 to py-2 */}
                                            <td className="border border-black py-2 px-1 text-center">{row && (student.resultStatus === 'অনুপস্থিত' || student.resultStatus === 'স্থগিত' ? '--' : toBengaliNumber(row.totalMarks))}</td> {/* Changed py-1.5 to py-2 */}
                                            <td className="border border-black py-2 px-1 text-center">{row ? toBengaliNumber(row.fullMarks) : ''}</td> {/* Changed highestMark to fullMarks */}
                                        </>
                                    ) : (
                                        <>
                                            <td className="border border-black py-2 px-1">&nbsp;</td><td className="border border-black py-2 px-1">&nbsp;</td><td className="border border-black py-2 px-1">&nbsp;</td>
                                            <td className="border border-black py-2 px-1">&nbsp;</td>
                                        </>
                                    )}
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </section>
                
                <footer className="mt-1 pt-1 text-sm flex-shrink-0 z-10" style={{ fontFamily: "'SolaimanLipi', sans-serif" }}>
                    <div className="grid grid-cols-3 gap-2 border-t border-black pt-1">
                        <p><strong>মোট নাম্বার:</strong> {student.resultStatus === 'অনুপস্থিত' || student.resultStatus === 'স্থগিত' ? '--' : toBengaliNumber(student.totalObtained)}</p>
                        <p><strong>গ্রেড:</strong> {gradeStatus}</p>
                        <p><strong>মেধা স্থান:</strong> {student.resultStatus === 'অনুপস্থিত' || student.resultStatus === 'স্থগিত' ? '--' : toBengaliNumber(student.rank)}</p>
                    </div>
                    <div className="flex justify-between items-end mt-3">
                        <div className="text-center w-40"><p className="border-t border-dotted border-black pt-1">অভিভাবকের স্বাক্ষর</p></div>
                        <div className="text-center w-40"><p className="border-t border-dotted border-black pt-1">শিক্ষাসচিবের স্বাক্ষর</p></div>
                        <div className="text-center w-40">
                             {managerInfo.signatureUrl ? (
                                <img src={managerInfo.signatureUrl} alt="Signature" className="h-6 mx-auto object-contain" />
                            ) : <div className="h-6"></div> }
                            <p className="border-t border-dotted border-black pt-1">প্রিন্সিপালের স্বাক্ষর</p>
                        </div>
                    </div>
                </footer>
            </div>
        );
    }
    
    // Academic Mode
    const sortedGrades = [...currentGrades].sort((a,b) => b.minPercentage - a.minPercentage);
    const fullAddress = `${address.village}, ${address.upazila}, ${address.district}`;

    const TOTAL_SUBJECT_ROWS = 13;
    const displayRows = [...subjectRows];
    while (displayRows.length < TOTAL_SUBJECT_ROWS) {
        displayRows.push(null);
    }

    return (
        <div className="marksheet-container bg-white p-3 font-['SolaimanLipi'] text-sm border-2 border-teal-600">
            <header className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                    {logoUrl && <img src={logoUrl} alt="Logo" className="w-14 h-14" />}
                    <div>
                        <h1 className="text-xl font-bold text-gray-800">{institutionName}</h1>
                        <p className="text-[10px]">{fullAddress}</p>
                    </div>
                </div>
                <table className="text-[9px] border-collapse w-[110px] flex-shrink-0">
                    <thead><tr className="bg-gray-100"><th className="border py-0 px-1">Range</th><th className="border py-0 px-1">Grade</th><th className="border py-0 px-1">GPA</th></tr></thead>
                    <tbody>{sortedGrades.map(g => (<tr key={g.id}><td className="border py-0 px-1 text-center">{toBengaliNumber(g.minPercentage)}-{toBengaliNumber(g.maxPercentage)}</td><td className="border py-0 px-1 text-center">{g.name}</td><td className="border py-0 px-1 text-center">{toBengaliNumber(g.gpa.toFixed(2))}</td></tr>))}</tbody>
                </table>
            </header>
            
            <div className="text-center mb-1 -mt-4"><div className="inline-block bg-teal-500 text-white rounded-md px-6 py-0.5 text-base font-bold">Marks Sheet</div></div>
            
            <section className="flex gap-3">
                <img src={student.photoUrl || 'https://via.placeholder.com/100x120?text=Photo'} alt="student" className="w-20 h-24 object-cover border-2 flex-shrink-0" />
                <div className="grid grid-cols-[auto_1fr_auto_1fr] gap-x-3 gap-y-0.5 text-[11px]">
                    <strong>Student's Name</strong> <span className="truncate">: {student.nameEn}</span>
                    <strong>Exam</strong> <span>: {exam.name}</span>
                    <strong>Father's Name</strong> <span className="truncate">: {student.fatherNameEn}</span>
                    <strong>Class</strong> <span>: {student.classLevel}</span>
                    <strong>Mother's Name</strong> <span className="truncate">: {student.motherNameEn}</span>
                    <strong>Section</strong> <span>: {student.section}</span>
                    <strong>Student's ID</strong> <span className="truncate">: {toBengaliNumber(student.uniqueId)}</span>
                    <strong>Roll No..</strong> <span>: {toBengaliNumber(student.roll || '')}</span>
                </div>
            </section>
            
            <section className="mt-2">
                <table className="w-full text-[11px] border-collapse">
                    <thead><tr className="bg-gray-100"><th className="border py-0.5 px-1">Name of Subjects</th><th className="border py-0.5 px-1">Full Marks</th><th className="border py-0.5 px-1">Highest Marks</th><th className="border py-0.5 px-1">Total Marks</th><th className="border py-0.5 px-1">Letter Grade</th><th className="border py-0.5 px-1">Grade Point</th></tr></thead>
                    <tbody>
                        {displayRows.map((row: any, index: number) => (
                            <tr key={index}>
                                {row ? (
                                    <>
                                        <td className="border py-0.5 px-1">{row.name}</td><td className="border py-0.5 px-1 text-center">{toBengaliNumber(row.fullMarks)}</td><td className="border py-0.5 px-1 text-center">{toBengaliNumber(row.highestMark)}</td>
                                        <td className="border py-0.5 px-1 text-center">{toBengaliNumber(row.totalMarks)}</td><td className="border py-0.5 px-1 text-center font-bold">{row.letterGrade}</td><td className="border py-0.5 px-1 text-center">{toBengaliNumber(row.gradePoint)}</td>
                                    </>
                                ) : (
                                    <>
                                        <td className="border py-0.5 px-1">&nbsp;</td><td className="border py-0.5 px-1">&nbsp;</td><td className="border py-0.5 px-1">&nbsp;</td>
                                        <td className="border py-0.5 px-1">&nbsp;</td><td className="border py-0.5 px-1">&nbsp;</td><td className="border py-0.5 px-1">&nbsp;</td>
                                    </>
                                )}
                            </tr>
                        ))}
                    </tbody>
                    <tfoot className="font-bold bg-yellow-100">
                        <tr>
                            <td className="border py-0.5 px-1 text-right">Obtained Marks & GPA</td><td className="border py-0.5 px-1 text-center">{toBengaliNumber(totalFullMarks)}</td><td className="border py-0.5 px-1"></td>
                            <td className="border py-0.5 px-1 text-center">{toBengaliNumber(student.totalObtained.toFixed(1))}</td><td className="border py-0.5 px-1 text-center">{student.grade}</td><td className="border py-0.5 px-1 text-center">{toBengaliNumber(student.gpa.toFixed(2))}</td>
                        </tr>
                    </tfoot>
                </table>
            </section>
            
            <footer className="pt-2 text-xs">
                <div className="flex gap-2">
                    <table className="w-1/2 border-collapse text-[10px]">
                        <tbody>
                            <tr><td className="border p-0.5 font-semibold">Result Status</td><td className="border p-0.5 font-semibold">{getStatusText(student.resultStatus)}</td></tr>
                            <tr><td className="border p-0.5 font-semibold">Class Position</td><td className="border p-0.5">{toBengaliNumber(student.rank)}</td></tr>
                            <tr><td className="border p-0.5 font-semibold">GPA</td><td className="border p-0.5">{toBengaliNumber(student.gpa.toFixed(2))}</td></tr>
                            <tr><td className="border p-0.5 font-semibold">Failed Subject(s)</td><td className="border p-0.5">{toBengaliNumber(failedSubjectsCount)}</td></tr>
                        </tbody>
                    </table>
                    <div className="w-1/2 border p-1"><p className="font-semibold text-[11px]">Comments:</p></div>
                </div>
                <div className="flex justify-between items-end mt-4 pt-6 text-[10px]">
                    <div className="text-center w-40"><p className="border-t border-gray-400 pt-1">Guardian's Signature</p></div>
                    <div className="text-center w-40"><p className="border-t border-gray-400 pt-1">Class Teacher's Signature</p></div>
                    <div className="text-center w-40">
                        {managerInfo.signatureUrl ? (
                            <img src={managerInfo.signatureUrl} alt="Signature" className="h-6 mx-auto object-contain" />
                        ) : (
                            <div className="h-6" /> 
                        )}
                        <p className="border-t border-gray-400 pt-1">Principal's Signature</p>
                    </div>
                </div>
                <div className="flex justify-between mt-1 text-[9px] text-gray-500">
                    <p>Powered by waliullah rabbani</p>
                    <p>Published Date: {toBengaliNumber(new Date().toLocaleDateString('en-CA'))}</p>
                </div>
            </footer>
        </div>
    );
};


interface ReportCardModalProps {
    isOpen: boolean;
    onClose: () => void;
    student: StudentData | null;
    reportData: ReportData | null;
    isMadrasaMode: boolean;
}

export const ReportCardModal: React.FC<ReportCardModalProps> = ({ isOpen, onClose, student, reportData, isMadrasaMode }) => {
    if (!isOpen || !student || !reportData) return null;

    const handlePrint = () => {
        const printContent = document.getElementById('printable-marksheet-modal');
        if (printContent) {
            const printWindow = window.open('', '', 'height=800,width=1200');
            if(printWindow){
                printWindow.document.write('<html><head><title>মার্কশীট</title>');
                printWindow.document.write('<script src="https://cdn.tailwindcss.com"></script>');
                printWindow.document.write('<link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">');
                printWindow.document.write(`<style> body { font-family: "SolaimanLipi", sans-serif !important; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; margin: 0; } @page { size: A4 portrait; margin: 0.7cm; } #printable-marksheet-container { width: 100%; height: 100%; display: flex; flex-direction: column; } .marksheet-container { page-break-inside: avoid; height: 100%; padding: 0.5rem; } </style>`);
                printWindow.document.write('</head><body><div id="printable-marksheet-container">');
                printWindow.document.write(printContent.innerHTML);
                printWindow.document.write('</div></body></html>');
                printWindow.document.close();
                setTimeout(() => { printWindow.focus(); printWindow.print(); printWindow.close(); }, 750);
            }
        }
    };

    const handlePdfDownload = () => {
        if (!reportData) return;
        
        const element = document.getElementById('printable-marksheet-modal');
        if (element) {
            const studentName = (reportData.student.nameEn || 'student').replace(/\s/g, '_');
            const examName = (reportData.exam.name || 'exam').replace(/\s/g, '_');
            
            const opt = {
                margin:       1, // 1cm on all sides
                filename:     `Marksheet_${studentName}_${examName}.pdf`,
                image:        { type: 'jpeg', quality: 0.98 },
                html2canvas:  { scale: 2, useCORS: true },
                jsPDF:        { unit: 'cm', format: 'a4', orientation: 'portrait' }
            };
    
            window.html2pdf().from(element).set(opt).save();
        }
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" onClick={onClose}>
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl m-4 h-[90vh] flex flex-col" onClick={e => e.stopPropagation()}>
                <div className="p-4 border-b flex justify-between items-center no-print">
                    <h3 className="text-lg font-bold">মার্কশীট প্রিভিউ: {student.nameBn}</h3>
                    <div className="flex gap-2">
                        <button onClick={handlePdfDownload} className="px-4 py-2 bg-green-600 text-white font-semibold rounded-lg text-sm">পিডিএফ</button>
                        <button onClick={handlePrint} className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg text-sm">প্রিন্ট</button>
                        <button onClick={onClose} className="px-4 py-2 bg-gray-200 rounded-lg text-sm">বন্ধ করুন</button>
                    </div>
                </div>
                <div className="flex-grow overflow-y-auto p-4 flex justify-center bg-gray-100">
                    <div className="w-[21cm] h-[29.7cm] bg-white p-2 box-border transform scale-[0.9] -translate-y-[5%] origin-top shadow-lg">
                        <div id="printable-marksheet-modal" style={{height: '100%', width: '100%'}}>
                           <ReportCardContent reportData={reportData} isMadrasaMode={isMadrasaMode} />
                        </div>
                    </div>
                </div>
            </div>
        </div>,
        document.body
    );
};
