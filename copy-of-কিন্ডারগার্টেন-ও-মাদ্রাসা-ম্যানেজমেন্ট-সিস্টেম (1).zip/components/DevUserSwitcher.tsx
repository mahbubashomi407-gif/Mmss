
import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserRole } from '../types';
import { CogIcon } from './icons';

const DevUserSwitcher: React.FC = () => {
    const { switchUser, user } = useAuth();
    const [isOpen, setIsOpen] = useState(false);

    const roles = Object.values(UserRole);

    const handleSwitch = (role: UserRole) => {
        switchUser(role);
        setIsOpen(false);
    };

    return (
        <div className="fixed bottom-4 right-4 z-[1000]">
            {isOpen && (
                <div className="bg-white p-2 rounded-lg shadow-xl mb-2 flex flex-col items-start w-40 border border-gray-200">
                    <p className="text-xs font-bold px-2 pb-1 border-b w-full mb-1 text-gray-600">ব্যবহারকারী পরিবর্তন করুন</p>
                    {roles.map(role => (
                        <button
                            key={role}
                            onClick={() => handleSwitch(role)}
                            className={`w-full text-left px-2 py-1 text-sm rounded capitalize ${user?.role === role ? 'bg-teal-600 text-white font-semibold' : 'hover:bg-gray-100 text-gray-700'}`}
                        >
                            {role}
                        </button>
                    ))}
                </div>
            )}
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-12 h-12 bg-teal-600 text-white rounded-full shadow-lg flex items-center justify-center hover:bg-teal-700 transition transform hover:rotate-45"
                title="ব্যবহারকারী পরিবর্তন করুন"
                aria-label="ব্যবহারকারী পরিবর্তন করুন"
            >
                <CogIcon className="w-6 h-6" />
            </button>
        </div>
    );
};

export default DevUserSwitcher;
