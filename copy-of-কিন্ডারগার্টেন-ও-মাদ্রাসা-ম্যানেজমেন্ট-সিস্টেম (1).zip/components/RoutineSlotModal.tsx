import React, { useState, useEffect, useMemo } from 'react';
import ReactDOM from 'react-dom';
import { useInstitution, TimeSlotData, TeacherData, ClassLevelData, SubjectData, RoutineSlotData } from '../context/InstitutionContext';

interface RoutineSlotModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (slotData: { classLevelId: string; subjectId: string } | null) => void;
  slotInfo: {
    day: string;
    timeSlot: TimeSlotData;
    teacher: TeacherData;
    existingSlot?: RoutineSlotData;
  };
}

const RoutineSlotModal: React.FC<RoutineSlotModalProps> = ({ isOpen, onClose, onSave, slotInfo }) => {
    const { classLevels } = useInstitution();
    const [selectedClassId, setSelectedClassId] = useState('');
    const [selectedSubjectId, setSelectedSubjectId] = useState('');

    const subjectsForClass = useMemo(() => {
        const classData = classLevels.find(cl => cl.id === selectedClassId);
        return classData?.subjects || [];
    }, [classLevels, selectedClassId]);

    useEffect(() => {
        if (isOpen) {
            const classId = slotInfo.existingSlot?.classLevelId || '';
            setSelectedClassId(classId);
            setSelectedSubjectId(slotInfo.existingSlot?.subjectId || '');
        }
    }, [isOpen, slotInfo.existingSlot]);
    
    useEffect(() => {
        // Reset subject if class changes and the selected subject is not in the new class's list
        if (!subjectsForClass.some(s => s.id === selectedSubjectId)) {
            setSelectedSubjectId('');
        }
    }, [selectedClassId, subjectsForClass, selectedSubjectId]);


    if (!isOpen) return null;

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (selectedClassId && selectedSubjectId) {
            onSave({ classLevelId: selectedClassId, subjectId: selectedSubjectId });
        }
    };

    const handleClear = () => {
        onSave(null);
    };
    
    const toBengaliNumber = (numStr: string | number) => {
        const num = String(numStr);
        const map: { [key: string]: string } = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯', ':': ':' };
        return num.replace(/[0-9:]/g, (match) => map[match]);
    };

    return ReactDOM.createPortal(
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50" aria-modal="true" role="dialog">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-lg m-4 transform transition-all">
                <form onSubmit={handleSubmit}>
                    <div className="p-5 border-b">
                        <h3 className="text-lg font-bold text-gray-800">রুটিন স্লট সম্পাদনা</h3>
                        <div className="text-sm text-gray-500 mt-1">
                            <span>শিক্ষক: {slotInfo.teacher.nameBn}</span> | <span>{toBengaliNumber(slotInfo.timeSlot.startTime)} - {toBengaliNumber(slotInfo.timeSlot.endTime)}</span>
                        </div>
                    </div>
                    <div className="p-5 space-y-4">
                        <div>
                            <label htmlFor="class" className="block text-sm font-medium text-gray-700">শ্রেণি নির্বাচন করুন</label>
                            <select id="class" value={selectedClassId} onChange={e => setSelectedClassId(e.target.value)} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500">
                                <option value="">-- শ্রেণি নেই --</option>
                                {classLevels.map(cl => (
                                    <option key={cl.id} value={cl.id}>{cl.name}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="subject" className="block text-sm font-medium text-gray-700">বিষয় নির্বাচন করুন</label>
                            <select id="subject" value={selectedSubjectId} onChange={e => setSelectedSubjectId(e.target.value)} className="mt-1 w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-teal-500" disabled={!selectedClassId}>
                                <option value="">-- বিষয় নেই --</option>
                                {subjectsForClass.map(subject => (
                                    <option key={subject.id} value={subject.id}>{subject.name}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                    <div className="bg-gray-50 px-5 py-3 flex justify-between items-center border-t">
                        <button type="button" onClick={handleClear} className="px-4 py-2 bg-red-500 text-white font-semibold rounded-lg hover:bg-red-600 transition-colors text-sm">
                            স্লট খালি করুন
                        </button>
                        <div className="flex gap-3">
                            <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-200 text-gray-800 font-semibold rounded-lg hover:bg-gray-300 transition-colors">বাতিল</button>
                            <button type="submit" disabled={!selectedClassId || !selectedSubjectId} className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed">সংরক্ষণ করুন</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>,
        document.body
    );
};

export default RoutineSlotModal;