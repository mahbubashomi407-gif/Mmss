
import {
    AcademicSessionData,
    ActivityData,
    Address,
    ClassLevelData,
    ContactInfo,
    FeeTypeData,
    GeneralSettingsData,
    HolidayData,
    LicenseData,
    ManagerInfo,
    NoticeData,
    SectionData,
    SocialMediaLinks,
    StudentData,
    TeacherData,
    FundCategoryData,
    FundHeadData,
    NotificationSettingsData,
    SmsTemplatesData,
    PaymentGatewayData,
    AttendanceRecordData,
    TeacherAttendanceRecordData,
    TeacherSalaryRecordData,
    HomeworkData,
    ProgressBehaviorData,
    ExamData,
    MarkRecordData,
    StudentFeeRecordData,
    StudentFeeSetupData,
    StudentMessageData,
    TeacherMessageData,
    LeaveApplicationData,
    GateLogData,
    GenderData,
    BloodGroupData,
    ReligionData,
    NationalityData,
    DesignationData,
    TimeSlotData,
    RoutineSlotData,
    ExamRoutineSlotData,
    GradeData,
    MadrasaResultSettings,
    IncomeData,
    ExpenseData,
    SystemUserData,
    TeacherRoleData,
    AccountantRoleData,
    StudentRoleData,
    GuardianNotificationData,
    MadrasaExamTypeData,
    HifzExamTypeData,
    HifzSubjectData,
    HifzGradeData,
    HifzResultSettings
} from '../context/InstitutionContext';


const defaultAddress: Address = {
    village: '',
    postOffice: '',
    upazila: '',
    district: '',
    division: '',
    country: 'বাংলাদেশ',
    mapLink: ''
};

const defaultContactInfo: ContactInfo = {
    primaryPhone: '',
    secondaryPhone: '',
    email: '',
    website: ''
};

const defaultAcademicSessions: AcademicSessionData[] = [
    { id: '1', name: '2024-2025', startDate: '2024-01-01', endDate: '2024-12-31', isActive: true }
];

const defaultManagerInfo: ManagerInfo = {
    name: '',
    designation: '',
    phone: '',
    email: '',
    message: '',
    photoUrl: null,
    signatureUrl: null,
};

const defaultActivities: ActivityData[] = [
    { id: '1', title: 'শারীরিক বিকাশ', description: 'মোটর স্কিল উন্নয়ন, খেলাধুলার মাধ্যমে স্বাস্থ্য বৃদ্ধি।' },
    { id: '2', title: 'মানসিক ও বুদ্ধিবিকাশ', description: 'চিন্তাশক্তি, সমস্যা সমাধান, কল্পনাশক্তি ও মনোযোগ বৃদ্ধি।' },
    { id: '3', title: 'ভাষা ও যোগাযোগ', description: 'মৌখিক ও লিখিত ভাষা দক্ষতা (বাংলা, আরবি, ইংরেজি)।\nগল্প, ধাঁধা, কথোপকথনের মাধ্যমে ভাষা উন্নয়ন।' },
    { id: '4', title: 'সামাজিক ও নৈতিক শিক্ষা', description: 'ধৈর্য, শেয়ারিং, বন্ধুত্ব, দলবদ্ধ কাজ।\nনৈতিকতা, চরিত্র, দায়িত্ববোধ ও আত্মনিয়ন্ত্রণ শেখানো।' },
    { id: '5', title: 'শিক্ষামূলক পাঠ্যক্রম', description: 'প্রাথমিক ধারণা: সংখ্যা, অক্ষর, রঙ, আকার।\nধর্মীয় শিক্ষা: কোরআন, হাদিস, ফিকাহ (যথাসম্ভব)।\nসাধারণ শিক্ষা: গণিত, বিজ্ঞান, সামাজিক শিক্ষা ইত্যাদি।' },
    { id: '6', title: 'আত্মনির্ভরতা ও আত্মবিশ্বাস', description: 'নিজে খাওয়া, পরিধান, ছোট দায়িত্ব পালন।\nকাজ সম্পন্ন করে আত্মবিশ্বাস বৃদ্ধি।' },
    { id: '7', title: 'মূল্যায়ন ও অগ্রগতি', description: 'শিক্ষার্থীর বিকাশ পরিমাপ করা।\nপ্রয়োজন অনুযায়ী উন্নয়ন পরিকল্পনা তৈরি।' },
];

const defaultClassLevels: ClassLevelData[] = [
    { id: 'cl1', name: 'প্লে', subjects: [{id: 's1', name: 'বাংলা'}, {id: 's2', name: 'গণিত'}] },
    { id: 'cl2', name: 'নার্সারি', subjects: [{id: 's3', name: 'বাংলা'}, {id: 's4', name: 'গণিত'}, {id: 's5', name: 'ইংরেজি'}] },
    { id: 'cl3', name: 'কেজি', subjects: [] },
];

const defaultSections: SectionData[] = [
    { id: 'sec1', classLevel: 'প্লে', name: 'ক', teacherName: 'আহমেদ হোসাইন', studentCount: 20 },
    { id: 'sec2', classLevel: 'প্লে', name: 'খ', teacherName: 'ফাতেমা বেগম', studentCount: 1 },
    { id: 'sec3', classLevel: 'নার্সারি', name: 'Morning', teacherName: '', studentCount: 2 },
];

const defaultTeacherRoles: TeacherRoleData[] = [
    { id: 'role_teacher_main', name: 'শিক্ষক', permissions: [
        'dashboard:view',
        'student:view_list',
        'student:view_profile',
        'student:edit',
        'attendance:take_manual',
        'attendance:view_student_report',
        'exam:enter_marks',
        'notice:create'
    ] },
];

const defaultAccountantRoles: AccountantRoleData[] = [
    { id: 'accrole1', name: 'হিসাবরক্ষক', permissions: [
        'accounting:add_income', 
        'accounting:add_expense', 
        'accounting:view_income_expense_report', 
        'fees:collect_student_fees', 
        'fees:view_due_report', 
        'fees:view_class_summary', 
        'settings:manage_fee_types'
    ] },
];

const defaultStudentRoles: StudentRoleData[] = [
    { id: 'srole1', name: 'সাধারণ শিক্ষার্থী', permissions: ['portal:view_dashboard', 'portal:view_attendance', 'portal:view_marks', 'portal:view_homework', 'portal:view_notices', 'portal:view_fees', 'portal:view_class_routine', 'portal:view_exam_routine', 'portal:view_admit_card'] },
];

const defaultFeeTypes: FeeTypeData[] = [
    { id: 'ft1', name: 'মাসিক বেতন', amount: 500, applicableClasses: ['প্লে', 'নার্সারি', 'কেজি'] },
    { id: 'ft2', name: 'ভর্তি ফি', amount: 2000, applicableClasses: ['প্লে', 'নার্সারি', 'কেজি'] },
    { id: 'ft3', name: 'পরীক্ষার ফি', amount: 300, applicableClasses: ['নার্সারি', 'কেজি'] },
];

const defaultHolidays: HolidayData[] = [
    { id: 'h1', title: 'শীতকালীন ছুটি', startDate: '2024-12-25', endDate: '2024-12-31', type: 'Institutional' },
    { id: 'h2', title: 'শহীদ দিবস ও আন্তর্জাতিক মাতৃভাষা দিবস', startDate: '2025-02-21', endDate: '2025-02-21', type: 'Public' },
];

const defaultFundCategories: FundCategoryData[] = [
    { id: 'fc4', name: 'সাধারণ ফান্ড' },
    { id: 'fc5', name: 'গোরাবা ফান্ড' },
];

const defaultFundHeads: FundHeadData[] = [
    { id: 'fh1', name: 'শিক্ষার্থীর বেতন', fundCategoryId: 'fc4', type: 'Income' },
    { id: 'fh2', name: 'ভর্তি ফি', fundCategoryId: 'fc4', type: 'Income' },
    { id: 'fh3', name: 'শিক্ষকের বেতন', fundCategoryId: 'fc4', type: 'Expense' },
    { id: 'fh4', name: 'অফিস খরচ', fundCategoryId: 'fc4', type: 'Expense' },
    { id: 'fh5', name: 'দান', fundCategoryId: 'fc5', type: 'Income' },
    { id: 'fh6', name: 'সাহায্য প্রদান', fundCategoryId: 'fc5', type: 'Expense' },
];

const defaultNotificationSettings: NotificationSettingsData = {
    smsGateway: {
        enabled: false,
        apiKey: '',
        senderId: '',
    },
    automaticNotifications: {
        studentAbsence: { sms: true, app: true },
        newNotice: { sms: false, app: true },
        feeDue: { sms: true, app: true },
        resultsPublished: { sms: false, app: true },
        studentArrival: { sms: false, app: true },
        studentDeparture: { sms: false, app: true },
        feePayment: { sms: true, app: true },
    },
};

const defaultSmsTemplates: SmsTemplatesData = {
    studentAbsence: 'প্রিয় অভিভাবক, আপনার সন্তান {{student_name}}, শ্রেণি: {{class}}, আজ {{date}} তারিখে অনুপস্থিত। - {{institution_name}}',
    newNotice: 'প্রিয় অভিভাবক, একটি নতুন নোটিশ প্রকাশিত হয়েছে। বিস্তারিত জানতে প্রতিষ্ঠানে যোগাযোগ করুন। - {{institution_name}}',
    feeDue: 'প্রিয় অভিভাবক, আপনার সন্তান {{student_name}}-এর {{month}} মাসের বেতন {{amount}} টাকা বকেয়া রয়েছে। অনুগ্রহ করে পরিশোধ করুন। - {{institution_name}}',
    resultsPublished: 'প্রিয় অভিভাবক, {{exam_name}} পরীক্ষার ফলাফল প্রকাশিত হয়েছে। আপনার সন্তানের ফলাফল জানতে যোগাযোগ করুন। - {{institution_name}}',
    studentArrival: 'প্রিয় অভিভাবক, আপনার সন্তান {{student_name}} {{time}} টায় প্রতিষ্ঠানে উপস্থিত হয়েছে। - {{institution_name}}',
    studentDeparture: 'প্রিয় অভিভাবক, আপনার সন্তান {{student_name}} {{time}} টায় প্রতিষ্ঠান থেকে প্রস্থান করেছে। - {{institution_name}}',
    feePayment: 'প্রিয় অভিভাবক, আপনার সন্তান {{student_name}}-এর ফি বাবদ {{amount}} টাকা জমা হয়েছে। ধন্যবাদ। - {{institution_name}}',
};

// New: Default templates for App Notifications
const defaultAppNotificationTemplates: SmsTemplatesData = {
    studentAbsence: 'আপনার সন্তান {{student_name}} (শ্রেণি: {{class}}) আজ অনুপস্থিত।',
    newNotice: 'প্রতিষ্ঠানের পক্ষ থেকে একটি নতুন নোটিশ প্রকাশ করা হয়েছে।',
    feeDue: 'আপনার সন্তান {{student_name}}-এর {{month}} মাসের বেতন {{amount}} টাকা বকেয়া রয়েছে।',
    resultsPublished: '{{exam_name}} পরীক্ষার ফলাফল প্রকাশিত হয়েছে। বিস্তারিত দেখুন।',
    studentArrival: 'আপনার সন্তান {{student_name}} {{time}} টায় প্রতিষ্ঠানে পৌঁছেছে।',
    studentDeparture: 'আপনার সন্তান {{student_name}} {{time}} টায় প্রতিষ্ঠান থেকে প্রস্থান করেছে।',
    feePayment: 'আপনার সন্তান {{student_name}}-এর ফি বাবদ {{amount}} টাকা জমা হয়েছে। ধন্যবাদ।',
};


const defaultNotices: NoticeData[] = [
    {
        id: '1',
        title: 'অভিভাবক সভা সংক্রান্ত নোটিশ',
        details: 'এতদ্বারা সকল শিক্ষার্থীর সম্মানিত অভিভাবকদের জানানো যাচ্ছে যে, আগামী শুক্রবার সকাল ১০ ঘটিকায় বিদ্যালয়ে এক অভিভাবক সভা অনুষ্ঠিত হবে। আপনাদের উপস্থিতি একান্ত কাম্য।',
        publishDate: '2024-07-20',
        target: ['Guardians'],
        sendSms: true,
        smsContent: 'প্রিয় অভিভাবক, আগামী শুক্রবার সকাল ১০টায় অভিভাবক সভা অনুষ্ঠিত হবে। আপনার উপস্থিতি জরুরি। - কর্তৃপক্ষ'
    },
    {
        id: '2',
        title: 'ঈদের ছুটি সংক্রান্ত বিজ্ঞপ্তি',
        details: 'পবিত্র ঈদ-উল-আযহা উপলক্ষে আগামী ১০ই জুলাই থেকে ১৫ই জুলাই পর্যন্ত বিদ্যালয়ের সকল কার্যক্রম বন্ধ থাকবে।',
        publishDate: '2024-07-08',
        target: ['Guardians', 'Teachers'],
        sendSms: false,
    }
];

const defaultGeneralSettings: GeneralSettingsData = {
    language: 'bn',
    currencySymbol: '৳',
    dateFormat: 'DD-MM-YYYY',
    timezone: 'Asia/Dhaka',
};


const defaultSocialMediaLinks: SocialMediaLinks = {
    website: '',
    facebook: '',
    youtube: '',
};

const defaultGenders: GenderData[] = [
    { id: 'male_student', name: 'ছাত্র', isDefault: true },
    { id: 'female_student', name: 'ছাত্রী', isDefault: true },
    { id: 'male_teacher', name: 'পুরুষ', isDefault: true },
    { id: 'female_teacher', name: 'মহিলা', isDefault: true },
    { id: 'other', name: 'অন্যান্য', isDefault: true },
];

const defaultBloodGroups: BloodGroupData[] = [
    { id: 'bg1', name: 'A+', isDefault: true }, { id: 'bg2', name: 'A-', isDefault: true },
    { id: 'bg3', name: 'B+', isDefault: true }, { id: 'bg4', name: 'B-', isDefault: true },
    { id: 'bg5', name: 'AB+', isDefault: true }, { id: 'bg6', name: 'AB-', isDefault: true },
    { id: 'bg7', name: 'O+', isDefault: true }, { id: 'bg8', name: 'O-', isDefault: true },
];

const defaultReligions: ReligionData[] = [ { id: 'islam', name: 'ইসলাম', isDefault: true } ];

const defaultNationalities: NationalityData[] = [ { id: 'bd', name: 'বাংলাদেশী', isDefault: true } ];

const defaultDesignations: DesignationData[] = [
    { id: 'd1', name: 'প্রধান শিক্ষক', isDefault: true },
    { id: 'd2', name: 'সহকারী শিক্ষক', isDefault: true },
    { id: 'd3', name: 'সহকারী শিক্ষিকা', isDefault: true },
];

const defaultTimeSlots: TimeSlotData[] = [
    { id: 'ts1', startTime: '10:00', endTime: '10:45' }, { id: 'ts2', startTime: '10:45', endTime: '11:30' },
    { id: 'ts3', startTime: '11:30', endTime: '12:15' }, { id: 'ts4', startTime: '12:15', endTime: '01:00' },
];

const defaultGrades: GradeData[] = [
    { id: 'g1', name: 'A+', gpa: 5.0, minPercentage: 80, maxPercentage: 100, comment: 'চমৎকার' },
    { id: 'g2', name: 'A', gpa: 4.0, minPercentage: 70, maxPercentage: 79.99, comment: 'খুব ভাল' },
    { id: 'g3', name: 'A-', gpa: 3.5, minPercentage: 60, maxPercentage: 69.99, comment: 'ভাল' },
    { id: 'g4', name: 'B', gpa: 3.0, minPercentage: 50, maxPercentage: 59.99, comment: 'সন্তোষজনক' },
    { id: 'g5', name: 'C', gpa: 2.0, minPercentage: 40, maxPercentage: 49.99, comment: 'মোটামুটি' },
    { id: 'g6', name: 'D', gpa: 1.0, minPercentage: 33, maxPercentage: 39.99, comment: 'পাশ' },
    { id: 'g7', name: 'F', gpa: 0.0, minPercentage: 0, maxPercentage: 32.99, comment: 'অকৃতকার্য' },
];

const defaultMadrasaGrades: GradeData[] = [
    { id: 'mg1', name: 'মুমতাজ', gpa: 5.0, minPercentage: 80, maxPercentage: 100, comment: 'চমৎকার', isRankable: true },
    { id: 'mg2', name: 'জায়্যিদ জিদ্দান', gpa: 4.0, minPercentage: 65, maxPercentage: 79.99, comment: 'খুব ভাল', isRankable: true },
    { id: 'mg3', name: 'জায়্যিদ', gpa: 3.0, minPercentage: 50, maxPercentage: 64.99, comment: 'ভাল', isRankable: true },
    { id: 'mg4', name: 'মকবুল', gpa: 2.0, minPercentage: 33, maxPercentage: 49.99, comment: 'সন্তোষজনক', isRankable: false },
    { id: 'mg5', name: 'রাসিব', gpa: 0.0, minPercentage: 0, maxPercentage: 32.99, comment: 'অকৃতকার্য', isRankable: false },
];

const defaultMadrasaResultSettings: MadrasaResultSettings = {
    enableAbsentStatus: true,
    enableSuspendedStatus: true,
    enableMaqbulOnSingleFail: true,
};

const defaultHifzSubjects: HifzSubjectData[] = [
    { id: 'hifz-1', name: 'হিফয (ইয়াদ)', totalMarks: 100, passMarks: 50 },
    { id: 'hifz-2', name: 'তাজবীদ', totalMarks: 50, passMarks: 20 },
    { id: 'hifz-3', name: 'মাসাইল', totalMarks: 50, passMarks: 20 },
];

const defaultHifzGrades: HifzGradeData[] = [
    { id: 'hifz-grade-4', name: 'মুমতায (স্টার মার্ক)', minHifzMarks: 80, minTotalMarks: 170, isRankable: true },
    { id: 'hifz-grade-3', name: '১ম বিভাগ (জায়্যিদ জিদ্দান)', minHifzMarks: 70, minTotalMarks: 150, isRankable: true },
    { id: 'hifz-grade-2', name: 'দ্বিতীয় বিভাগ (জায়্যিদ)', minHifzMarks: 60, minTotalMarks: 120, isRankable: true },
    { id: 'hifz-grade-1', name: 'তৃতীয় বিভাগ (মাকবূল)', minHifzMarks: 50, minTotalMarks: 90, isRankable: false },
    { id: 'hifz-grade-0', name: 'রাসিব (অকৃতকার্য)', minHifzMarks: 0, minTotalMarks: 0, isRankable: false },
];

const defaultHifzResultSettings: HifzResultSettings = {
    enableAbsentStatus: true,
    enableSuspendedStatus: true,
};


const defaultSystemUsers: SystemUserData[] = [
    { id: 'user-1', email: 'admin@example.com', role: 'Admin', status: 'Active' },
    { id: 'user-2', email: 'teacher@example.com', role: 'Teacher', status: 'Active', linkedTeacherId: 't-1' },
    { id: 'user-3', email: 'accountant@example.com', role: 'Accountant', status: 'Active' }
];

const defaultStudents: StudentData[] = [
    {
        id: 'std-1721832948123', uniqueId: '24001', photoUrl: null, nameBn: 'আরিফ ইসলাম', nameEn: 'Arif Islam', dob: '2020-01-15',
        gender: 'ছাত্র', bloodGroup: 'A+', religion: 'ইসলাম', birthCertNo: '20201234567890123', nationality: 'বাংলাদেশী',
        admissionDate: '2024-01-10', academicYear: '2024-2025', classLevel: 'প্লে', section: 'ক', roll: 1, fatherNameBn: 'সাইফুল ইসলাম',
        fatherNameEn: 'Saiful Islam', fatherNid: '', fatherPhone: '01711111111', fatherOccupation: 'ব্যবসায়ী', motherNameBn: 'আমিনা বেগম',
        motherNameEn: 'Amina Begum', motherNid: '', motherPhone: '01811111111', motherOccupation: 'গৃহিণী',
        presentAddress: { village: 'বাড়ি নং ৫, রোড নং ৩', postOffice: 'গুলশান', upazila: 'গুলশান', district: 'ঢাকা' },
        permanentAddress: { village: 'বাড়ি নং ৫, রোড নং ৩', postOffice: 'গুলশান', upazila: 'গুলশান', district: 'ঢাকা' },
        isSameAddress: true, status: 'চলমান',
    },
    // ... More students
];

const defaultTeachers: TeacherData[] = [
    {
        id: 't-1', uniqueId: 'T24001', photoUrl: null, nameBn: 'আহমেদ হোসাইন', nameEn: 'Ahmed Hossain', dob: '1985-05-15', gender: 'পুরুষ',
        religion: 'ইসলাম', nationality: 'বাংলাদেশী', joiningDate: '2022-01-10', designation: 'সহকারী শিক্ষক', roleId: 'role_teacher_main',
        academicQualifications: 'এম.এ (বাংলা)', email: 'ahmed@example.com', phone: '01711223344',
        presentAddress: { village: 'বাড়ি নং ১০', postOffice: 'মিরপুর', upazila: 'মিরপুর', district: 'ঢাকা' },
        permanentAddress: { village: 'বাড়ি নং ১০', postOffice: 'মিরপুর', upazila: 'মিরপুর', district: 'ঢাকা' },
        isSameAddress: true, status: 'সক্রিয়', assignments: [ { classLevelId: 'cl1', subjectId: 's1' }, { classLevelId: 'cl2', subjectId: 's3' }, ], monthlySalary: 15000,
    },
    // ... More teachers
];
const generateMockAttendance = (students: StudentData[]): AttendanceRecordData[] => { /* ... */ return []; };
const generateMockTeacherAttendance = (teachers: TeacherData[]): TeacherAttendanceRecordData[] => { /* ... */ return []; };

const defaultPaymentGateways: PaymentGatewayData[] = [
    { id: '1', name: 'বিকাশ', apiKey: '', instructions: 'আপনার বিকাশ নম্বর থেকে পেমেন্ট করুন।', enabled: false },
    { id: '2', name: 'নগদ', apiKey: '', instructions: 'আপনার নগদ নম্বর থেকে পেমেন্ট করুন।', enabled: false },
];

const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 1);

export const MOCK_INSTITUTION_DATA = {
  logoUrl: null,
  institutionName: 'আমার প্রতিষ্ঠান',
  lastResetTimestamp: '2020-01-01T00:00:00.000Z',
  address: defaultAddress,
  contactInfo: defaultContactInfo,
  academicSessions: defaultAcademicSessions,
  managerInfo: defaultManagerInfo,
  activities: defaultActivities,
  classLevels: defaultClassLevels,
  sections: defaultSections,
  teacherRoles: defaultTeacherRoles,
  accountantRoles: defaultAccountantRoles,
  studentRoles: defaultStudentRoles,
  feeTypes: defaultFeeTypes,
  holidays: defaultHolidays,
  fundCategories: defaultFundCategories,
  fundHeads: defaultFundHeads,
  notificationSettings: defaultNotificationSettings,
  smsTemplates: defaultSmsTemplates,
  appNotificationTemplates: defaultAppNotificationTemplates, // New: Added app templates
  notices: defaultNotices,
  generalSettings: defaultGeneralSettings,
  socialMediaLinks: defaultSocialMediaLinks,
  licenses: [] as LicenseData[],
  students: defaultStudents,
  teachers: defaultTeachers,
  paymentGateways: defaultPaymentGateways,
  onlineAdmissionFee: 1000,
  attendanceRecords: generateMockAttendance(defaultStudents),
  teacherAttendanceRecords: generateMockTeacherAttendance(defaultTeachers),
  teacherSalaryRecords: [] as TeacherSalaryRecordData[],
  homeworks: [] as HomeworkData[],
  progressBehaviorRecords: [] as ProgressBehaviorData[],
  exams: [] as ExamData[],
  markRecords: [] as MarkRecordData[],
  studentFeeRecords: [] as StudentFeeRecordData[],
  studentFeeSetups: [] as StudentFeeSetupData[],
  studentMessages: [] as StudentMessageData[],
  teacherMessages: [] as TeacherMessageData[],
  leaveApplications: [] as LeaveApplicationData[],
  gateLogs: [] as GateLogData[],
  genders: defaultGenders,
  bloodGroups: defaultBloodGroups,
  religions: defaultReligions,
  nationalities: defaultNationalities,
  designations: defaultDesignations,
  timeSlots: defaultTimeSlots,
  routineSlots: [] as RoutineSlotData[],
  examRoutineSlots: [] as ExamRoutineSlotData[],
  grades: defaultGrades,
  madrasaGrades: defaultMadrasaGrades,
  madrasaResultSettings: defaultMadrasaResultSettings,
  madrasaExamTypes: [] as MadrasaExamTypeData[],
  hifzExamTypes: [] as HifzExamTypeData[],
  hifzSubjects: defaultHifzSubjects,
  hifzGrades: defaultHifzGrades,
  hifzResultSettings: defaultHifzResultSettings,
  incomeRecords: [] as IncomeData[],
  expenseRecords: [] as ExpenseData[],
  systemUsers: defaultSystemUsers,
  guardianNotifications: [] as GuardianNotificationData[],
};

// Populate with more detailed mock data for students and teachers
MOCK_INSTITUTION_DATA.students = [
    {
        id: 'std-1721832948123', uniqueId: '24001', photoUrl: null, nameBn: 'আরিফ ইসলাম', nameEn: 'Arif Islam', dob: '2020-01-15',
        gender: 'ছাত্র', bloodGroup: 'A+', religion: 'ইসলাম', birthCertNo: '20201234567890123', nationality: 'বাংলাদেশী',
        admissionDate: '2024-01-10', academicYear: '2024-2025', classLevel: 'প্লে', section: 'ক', roll: 1, fatherNameBn: 'সাইফুল ইসলাম',
        fatherNameEn: 'Saiful Islam', fatherNid: '', fatherPhone: '01711111111', fatherOccupation: 'ব্যবসায়ী', motherNameBn: 'আমিনা বেগম',
        motherNameEn: 'Amina Begum', motherNid: '', motherPhone: '01811111111', motherOccupation: 'গৃহিণী',
        presentAddress: { village: 'বাড়ি নং ৫, রোড নং ৩', postOffice: 'গুলশান', upazila: 'গুলশান', district: 'ঢাকা' },
        permanentAddress: { village: 'বাড়ি নং ৫, রোড নং ৩', postOffice: 'গুলশান', upazila: 'গুলশান', district: 'ঢাকা' },
        isSameAddress: true, status: 'চলমান',
    },
    // ... More students
];

MOCK_INSTITUTION_DATA.teachers = [
    {
        id: 't-1', uniqueId: 'T24001', photoUrl: null, nameBn: 'আহমেদ হোসাইন', nameEn: 'Ahmed Hossain', dob: '1985-05-15', gender: 'পুরুষ',
        religion: 'ইসলাম', nationality: 'বাংলাদেশী', joiningDate: '2022-01-10', designation: 'সহকারী শিক্ষক', roleId: 'role_teacher_main',
        academicQualifications: 'এম.এ (বাংলা)', email: 'ahmed@example.com', phone: '01711223344',
        presentAddress: { village: 'বাড়ি নং ১০', postOffice: 'মিরপুর', upazila: 'মিরপুর', district: 'ঢাকা' },
        permanentAddress: { village: 'বাড়ি নং ১০', postOffice: 'মিরপুর', upazila: 'মিরপুর', district: 'ঢাকা' },
        isSameAddress: true, status: 'সক্রিয়', assignments: [ { classLevelId: 'cl1', subjectId: 's1' }, { classLevelId: 'cl2', subjectId: 's3' }, ], monthlySalary: 15000,
    },
    // ... More teachers
];
MOCK_INSTITUTION_DATA.attendanceRecords = generateMockAttendance(MOCK_INSTITUTION_DATA.students);
MOCK_INSTITUTION_DATA.teacherAttendanceRecords = generateMockTeacherAttendance(MOCK_INSTITUTION_DATA.teachers);
// ... Other dynamic mock data initializations
