
export enum UserRole {
    ADMIN = 'admin',
    TEACHER = 'teacher',
    ACCOUNTANT = 'accountant',
    STUDENT = 'student',
    GUARDIAN = 'guardian',
    SUPER_ADMIN = 'super_admin',
}

export interface User {
    uid: string;
    email: string;
    role: UserRole;
    displayName: string;
    roleId?: string;
    institutionId?: string; // New: for multi-tenancy
    institutionCode?: string; // New: for display/convenience
}

export interface Student {
    id: string;
    name: string;
    class: string;
    roll: number;
    guardianId: string;
    guardianName: string;
}

export interface Teacher {
    id: string;
    name: string;
    subject: string;
    email: string;
}

export interface Guardian {
    id: string;
    name: string;
    studentId: string;
    studentName: string;
}

export interface AttendanceRecord {
    studentId: string;
    studentName: string;
    status: 'present' | 'absent';
}

export interface MarkRecord {
    studentId: string;
    studentName: string;
    subject: string;
    marks: number;
    totalMarks: number;
}
